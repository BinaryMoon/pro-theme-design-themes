<?php

add_color_rule( 'bg', '#ffffff', array(
	array( 'body', 'background-color' ),
	array( '#main article, ol.commentlist li.comment.bypostauthor, #main .archive-pagination a, #main .postnav, #main #comments-container, .col-sidebar', 'background' ),
	array( '#main #footer, a.post-edit-link, #main article .tags a, #main article .categories a', 'background', '-1' ),
	array( 'a.post-edit-link:hover', 'background', '-2' ),
	),
	__( 'Content Area Background', 'kent' )
);

add_color_rule( 'txt', '#cccccc', array(
 	array( '#main header.masthead h1.logo a, #main header.masthead h2.description, #main header.masthead h1.logo a:hover', 'color', 'bg' ),
),
	__( 'Site Title and Description Color', 'kent' )
	
);
add_color_rule( 'link', '#4998cc', array(
	array( 'a, #main header, .page-main-nav a, #aside a, #main a', 'color', 'bg' ),
	array( 'a:hover, #respond p.logged-in-as a:hover, #aside a:hover, #main a:hover', 'color', 'bg', 1 ),	
	array( '#main .posttitle, #main .posttitle a, #main .archive-pagination a, .writer h3, h3#comments, .widgettitle, .widgettitle a', 'color', 'bg' ),	
	array( '#main .posttitle a:hover, #footer a:hover, a.post-edit-link:hover, ', 'color', 'bg' ),
	array( 'blockquote, form input[type=text]:focus, form input[type=password]:focus, form input[type=email]:focus, form input[type=url]:focus, form input.text:focus, form textarea:focus, form input.settings-input:focus, form input[type=submit], ol.commentlist li.comment.bypostauthor, ol.commentlist li.comment .reply a, ol.commentlist li.comment .reply a:hover, #aside .social_container .social_links a:hover, #aside .social_container .social_links a:hover, #main .archive-pagination span, #main .archive-pagination span.current, #main .archive-pagination span.current, .col-sidebar', 'border-color', 'bg' ),
	array( '#main article.sticky:after', 'border-top-color', 'bg' ),	
	array( '#main article.sticky:after', 'border-left-color', 'bg' ),	
	array( '#main article.sticky:after', 'border-right-color', 'bg' ),	
	array( 'blockquote, form input[type=text]:focus, form input[type=password]:focus, form input[type=email]:focus, form input[type=url]:focus, form input.text:focus, form textarea:focus, form input.settings-input:focus, form input[type=submit]', 'outline-color', 'bg' ),	
	array( 'form input[type=submit]:hover, .infinite-scroll #infinite-handle span, ol.commentlist li.comment .reply a:hover, #aside .social_container .social_links a:hover, #aside .social_container .social_links a:hover', 'background-color' ),		
	array( '#main article .tags a:hover, #main article .categories a:hover, #main .archive-pagination span, #main .archive-pagination span.current, #main .archive-pagination span, #main .archive-pagination span.current, #main p.page-404, nav.menu, .page-main-nav a:hover, .page-main-nav a:hover, .infinite-scroll #infinite-handle span', 'background' ),	
	array( '#main .writer', 'border-top-color' ),
	array( '#main article.sticky, .col-sidebar section.widget.widget_search', 'background', 0.3 ),
  	array( '.page-main-nav a, #aside .social_container .social_links a, .searchform button.searchsubmit', 'color', '#ffffff' ), 	
  	array( '.page-main-nav a:hover, #aside .social_container .social_links a:hover', 'border-color' ),
	),
	__( 'Link & Primary Accent Color', 'kent' )
);

/* Extra Colors */

add_color_rule( 'extra', '#ffffff', array(
	array( 'input[type="submit"].alt:hover, .site-main .button.alt:hover', 'color', 'bg' ),	
	array( '#main .archive-pagination span, #main .archive-pagination span.current, nav.menu ul li a, .page-main-nav a:hover, #aside .social_container .social_links a:hover, #main article .tags a:hover, #main article .categories a:hover, .infinite-scroll #infinite-handle span:hover, .infinite-scroll #infinite-handle span', 'color', 'link' ),		
) );
add_color_rule( 'extra', '#666666', array(
	array( 'body', 'color', 'bg' ),		
) );
add_color_rule( 'extra', '#999999', array(
	array( '#main article .postmetadata a.reading-time, #main article .postmetadata, .wpl-count', 'color', 'bg' ),		
) );


/*
 * Extra CSS
 */
add_theme_support( 'custom_colors_extra_css', 'kent_extra_css' );
function kent_extra_css() { ?>
form input[type=submit],
form input[type=submit]:hover,
ol.commentlist li.comment .reply a,
ol.commentlist li.comment .reply a:hover {
	background-image: none;
}
nav.menu a.menu-close {
	background: rgba( 0, 0, 0, 0.28 );
	color: rgba( 255, 255, 255, 0.5 );
}
nav.menu a.menu-close:hover {
	background: rgba( 0, 0, 0, 0.3 );
	color: rgba( 255, 255, 255, 1 );
}
nav.menu ul li a.menu-expand {
	background: rgba( 0, 0, 0, 0.28 );
	color: rgba( 255, 255, 255, 1 );
}
nav.menu ul li a.menu-expand:hover {
	background: rgba( 0, 0, 0, 0.3 );
}
nav.menu ul li a:hover {
    background-color: rgba(255, 255, 255, 0.26);
}
nav.menu ul li, nav.menu form.searchform {
	border-color: rgba( 255, 255, 255, 0.26 );
}
#main .archive-pagination a:hover {
	background: rgba( 0, 0, 0, 0.28 );
}
#main .archive-pagination a, 
#main article.post, 
#main article.page,
ol.commentlist li.comment, 
ol.commentlist li.trackback, 
ol.commentlist li.pingback,
table {
	border-color: rgba( 0, 0, 0, 0.18 );
}
#main .writer {
	border-bottom-color: rgba( 0, 0, 0, 0.18 );
}
#main .postnav .prev a,
#main .postnav .next a {
    background-color: rgba(0, 0, 0, 0.28);
    background-image: none;
    border: none;
    box-shadow: none;
    color: rgba( 255, 255, 255, 1 );
}
#main .postnav .prev a:hover,
#main .postnav .next a:hover,
.infinite-scroll #infinite-handle span:hover {
	background-color: rgba( 0, 0, 0, 0.3 );
	background-image: none;
	border-color: transparent;
}
table tr:nth-child(2n),
#wp-calendar th, 
#wp-calendar caption {
	background: transparent;
}

<?php
}