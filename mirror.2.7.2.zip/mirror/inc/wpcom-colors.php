<?php
/* Custom Colors: Mirror */

//Background
add_color_rule( 'bg', '#ffffff', array(
	array( 'body', 'background-color' ),
) );

//Green accent
add_color_rule( 'txt', '#77b84b', array(
	//No contrast
	array( 'ol.commentlist li.comment .reply a, ol.commentlist li.trackback .reply a, ol.commentlist li.pingback .reply a, ol.commentlist li.comment .reply a:hover, ol.commentlist li.trackback .reply a:hover, ol.commentlist li.pingback .reply a:hover, input[type=submit], input[type=submit]:hover', 'border-color' ),
	array( '.showcase nav a:hover, .showcase nav a.selected', 'background-color' ),
	array( '.post-archive .post-info a, input[type=submit], ol.commentlist li.comment .reply a, ol.commentlist li.trackback .reply a, ol.commentlist li.pingback .reply a', 'background-color' ),
	array( '.post-archive .post-info a:hover, input[type=submit]:hover, ol.commentlist li.comment .reply a:hover, ol.commentlist li.trackback .reply a:hover, ol.commentlist li.pingback .reply a:hover', 'background-color', '-0.5' ),
	
	//Contrast against background
	array( 'a, a:hover', 'color', 'bg' ),
	array( '.masthead .menu li.page_item_has_children > a:after, .masthead .menu li.menu-item-has-children > a:after', 'border-top-color', 'bg' ),

),
__( 'Main Accent' ) );

//Unused

add_color_rule( 'link', '#ffffff', array(
) );

add_color_rule( 'fg1', '#ffffff', array(	
) );

add_color_rule( 'fg2', '#ffffff', array(
) );

//Extra rules

add_color_rule( 'extra', '#666666', array(
	array( 'body', 'color', 'bg' ),
) );

add_color_rule( 'extra', '#b3b3b3', array(
	array( '.post-meta-data a', 'color', 'bg' ),
) );

add_color_rule( 'extra', '#ffffff', array(
	array( '.post-archive .post-info a', 'color', 'txt' ),
	
	array( '.post-archive .entry a.read-more, .post-archive .entry a.read-more:hover', 'color', 'bg' ),
) );

add_color_rule( 'extra', '#f2f2f2', array(
	array( '.post-archive, .content-comments, .main .post-nav, footer#footer, ol.commentlist li.comment, ol.commentlist li.trackback, ol.commentlist li.pingback', 'border-color', 0.2 ),
	array( '.post-archive.sticky, footer#footer, a.post-edit-link', 'background-color', 0.2 ),
	
	array( 'a.post-edit-link:hover', 'background-color', 0.1 ),
) );

add_color_rule( 'extra', '#1a1a1a', array(
	array( '.post-archive h2.entry-title a', 'color', 'bg' ),
	array( 'h1, h2, h3, h4, h5, h6', 'color', 'bg' ),
) );

add_color_rule( 'extra', '#808080', array(
	array( '.post-archive .entry a.read-more', 'background-color', 0.15 ),
	array( '.post-archive .entry a.read-more:hover', 'background-color', 0.25 ),
	
) );

add_color_rule( 'extra', '#666666', array(
	array( '.post-meta-data a:hover', 'color', 'bg' ),
) );

add_color_rule( 'extra', '#999999', array(
	array( '.main article .taxonomy', 'color', 'bg' ),
) );

add_color_rule( 'extra', '#000000', array(
	array( '.masthead h1.site-title a, .masthead h1.site-title a:hover, .masthead h2.site-description, .main .post-nav .prev a:before, .main .post-nav .next a:before', 'color', 'bg' ),
) );


/* Custom Colors */

//Additional palettes

add_color_palette( array(
    '#9ab2c5',
    '#ccdfea',
), 'Palette 1' );

add_color_palette( array(
    '#490a3d',
    '#bd1550',
), 'Palette 2' );

add_color_palette( array(
    '#468145',
    '#e7d448',
), 'Palette 3' );

add_color_palette( array(
    '#f9e2cc',
    '#623131',
), 'Palette 4' );

add_color_palette( array(
    '#fae0e9',
    '#cf2069',
), 'Palette 5' );