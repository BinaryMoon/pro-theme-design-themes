<?php
/**
 * Post terms
 *
 * @package Mirror
 */

?>
		<div class="taxonomies">
			<p class="tax-categories taxonomy">
<?php
	printf( esc_html__( 'Categories: %s', 'mirror' ), get_the_category_list( _x( ', ', 'Category/ Tag list separator (includes a space after the comma)', 'mirror' ) ) );
?>
			</p>
<?php
	if ( get_the_tags() ) {
?>
			<p class="tax-tags taxonomy">
<?php
		printf( esc_html__( 'Tagged as: %s', 'mirror' ), get_the_tag_list( '', _x( ', ', 'Category/ Tag list separator (includes a space after the comma)', 'mirror' ), '' ) );
?>
			</p>
<?php
	}
?>
		</div>
