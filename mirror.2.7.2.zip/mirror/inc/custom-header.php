<?php
/**
 * Custom header codes
 *
 * @package Mirror
 */

/**
 * Custom header image
 */
function mirror_custom_header_support() {

	// Custom header image.
	add_theme_support(
		'custom-header',
		apply_filters( 'mirror_custom_header',
			array(
				'default-text-color' => '000000',
				'random-default' => false,
				'width' => apply_filters( 'mirror_header_width', 1500 ),
				'height' => apply_filters( 'mirror_header_height', 350 ),
				'flex-height' => true,
				'header-text' => true,
				'uploads' => true,
				'wp-head-callback' => 'mirror_colour_styles',
				'admin-head-callback' => '',
				'admin-preview-callback' => '',
			)
		)
	);

}

add_action( 'after_setup_theme', 'mirror_custom_header_support' );


/**
 * Print custom header styles
 *
 * @return array
 */
function mirror_colour_styles() {

?>
<style>
<?php
	if ( 'blank' === get_header_textcolor() ) {
?>
	.masthead h1.site-title,
	.masthead h2.site-description {
		display: none;
	}
<?php
	} else {
?>
	.masthead h1.site-title,
	.masthead h1.site-title a,
	.masthead h1.site-title a:hover,
	.masthead h2.site-description {
		color: #<?php echo esc_attr( get_header_textcolor() ); ?>;
	}
<?php
	}
?>
</style>
<?php

	return true;

}
