<?php
/**
 * Jetpack Compatibility File
 * See: http://jetpack.me/
 *
 * @package Mirror
 */

/**
 * Add theme support for Infinite Scroll.
 * See: http://jetpack.me/support/infinite-scroll/
 */
function mirror_jetpack_init() {

	add_theme_support(
		'infinite-scroll',
		array(
			'container' => 'main-content',
			'footer_widgets' => mirror_can_infinite_scroll(),
			'footer' => 'footer-widgets',
		)
	);

	add_theme_support( 'tonesque' );

	add_theme_support(
		'featured-content',
		array(
			'featured_content_filter' => 'mirror_get_featured_posts',
			'max_posts' => 5,
			'post_types' => array( 'post', 'page', 'jetpack-portfolio' ),
		)
	);

	add_theme_support( 'jetpack-responsive-videos' );

	add_theme_support(
		'site-logo',
		array(
			'size' => 'mirror-logo',
		)
	);

}

add_action( 'after_setup_theme', 'mirror_jetpack_init' );


/**
 * Get featured posts using Jetpack Featured content
 */
function mirror_get_featured_posts() {

	return apply_filters( 'mirror_get_featured_posts', array() );

}


/**
 * Check if Jetpack Featured Content has any featured posts available
 *
 * @param int $minimum Number of featured posts to display.
 * @return boolean
 */
function mirror_has_featured_posts( $minimum = 1 ) {

	if ( is_paged() ) {
		return false;
	}

	if ( ! is_home() && ! is_page() ) {
		return false;
	}

	$minimum = absint( $minimum );
	$featured_posts = apply_filters( 'mirror_get_featured_posts', array() );

	if ( ! is_array( $featured_posts ) ) {
		return false;
	}

	if ( $minimum > count( $featured_posts ) ) {
		return false;
	}

	return true;

}


/**
 * Can jetpack enable the auto loading infinite scroll
 */
function mirror_can_infinite_scroll() {

	if ( function_exists( 'jetpack_is_mobile' ) && jetpack_is_mobile() ) {
		return true;
	}

	if ( is_active_sidebar( 'sidebar-2' ) ) {
		return true;
	}

	return false;

}


/**
 * Flush rewrite rules for CPT on setup and switch
 */
function mirror_flush_rewrite_rules() {

	flush_rewrite_rules();

}

add_action( 'after_switch_theme', 'mirror_flush_rewrite_rules' );
