<?php
/**
 * Theme Customizer
 *
 * @link https://developer.wordpress.org/themes/advanced-topics/customizer-api/
 *
 * @package Mirror
 */

/**
 * Exit if we're not in the Customizer.
 */
if ( ! class_exists( 'WP_Customize_Control' ) ) {

	return null;

}


/**
 * Theme customizer properties
 *
 * @param object $wp_customize Customize object.
 */
function mirror_customizer_settings( $wp_customize ) {

	// Mirror theme options section.
	$wp_customize->add_section(
		'mirror_options',
		array(
			'title' => esc_html__( 'Theme', 'mirror' ),
			'description' => esc_html__( 'Options for the mirror theme.', 'mirror' ),
		)
	);

	// Setting to chose where the featured content slider will appear.
	$wp_customize->add_setting(
		'mirror_featured_content_display',
		array(
			'default' => 1,
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'mirror_sanitize_int',
		)
	);

	// Control for changing the header height.
	$wp_customize->add_control(
		'mirror_featured_content_display',
		array(
			'label' => esc_html__( 'Display featured content on...', 'mirror' ),
			'section' => 'mirror_options',
			'type' => 'radio',
			'choices'  => array(
				1 => esc_html__( 'All pages (default)', 'mirror' ),
				2 => esc_html__( 'Homepage only', 'mirror' ),
			),
		)
	);

}

add_action( 'customize_register', 'mirror_customizer_settings' );


/**
 * Update Theme Elements without refreshing content.
 *
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function mirror_register_customize_refresh( WP_Customize_Manager $wp_customize ) {

	// Ensure selective refresh is enabled.
	if ( ! isset( $wp_customize->selective_refresh ) ) {

		return false;

	}

	// Update site title.
	$wp_customize->get_setting( 'blogname' )->transport = 'postMessage';

	$wp_customize->selective_refresh->add_partial(
		'blogname',
		array(
			'selector' => '.site-title',
			'render_callback' => function() {
				bloginfo( 'name' );
			},
		)
	);

	// Update site description.
	$wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';

	$wp_customize->selective_refresh->add_partial(
		'blogdescription',
		array(
			'selector' => '.site-description',
			'render_callback' => function() {
				bloginfo( 'description' );
			},
		)
	);

	// Show and hide header text.
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

}

add_action( 'customize_register', 'mirror_register_customize_refresh' );


/**
 * Sanitize the category navigation setting
 *
 * @param int $setting Setting value.
 * @return int|string
 */
function mirror_sanitize_int( $setting ) {

	return (int) $setting;

}


/**
 * Binds JS handlers to make the Customizer preview reload changes asynchronously.
 */
function mirror_customize_preview_js() {

	wp_enqueue_script( 'mirror-customize-preview', get_theme_file_uri( '/js/customizer-preview.js' ), array( 'customize-preview' ), '1.0', true );

}

add_action( 'customize_preview_init', 'mirror_customize_preview_js' );
