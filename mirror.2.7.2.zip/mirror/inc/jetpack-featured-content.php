<?php
/**
 * Jetpack Featured Content
 * See: http://jetpack.me/support/featured-content/
 *
 * @package Mirror
 */

	$display_page = (int) get_theme_mod( 'mirror_featured_content_display', 1 );

	// If display is set to homepage only, and we're not on the homepage then quit.
	if ( ! is_front_page() && 2 === $display_page ) {
		return;
	}

	// If there's no featured posts to display then quit.
	if ( ! mirror_has_featured_posts() ) {
		return;
	}

	// Let's load those posts then.
	$featured_posts = mirror_get_featured_posts( 4 );
?>
	<section class="showcase">
<?php
	foreach ( $featured_posts as $post ) {
		setup_postdata( $post );

		$styles = array();
		$image = mirror_archive_image_url( get_the_ID(), 'mirror-header' );
		if ( $image[0] ) {
			$styles = array(
				'background-image:url(' . esc_url( $image[0] ) . ');'
			);
		}
?>
		<article class="<?php mirror_slider_class(); ?>" style="<?php echo implode( ' ', $styles ); ?>">
			<a href="<?php the_permalink(); ?>" class="entry">
				<h2 class="entry-title"><?php the_title(); ?></h2>
			</a>
		</article>
<?php
		}
?>
	</section>
<?php
	wp_reset_postdata();
