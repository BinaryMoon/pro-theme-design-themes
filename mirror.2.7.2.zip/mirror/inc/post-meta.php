<?php
/**
 * Post meta data
 *
 * @package Mirror
 */
?>
	<div class="post-meta-data">
<?php
	printf(
		'<a href="%1$s" title="%2$s" rel="bookmark"><time class="entry-date" datetime="%3$s">%4$s</time></a>',
		esc_url( get_permalink() ),
		esc_attr( get_the_time() ),
		esc_attr( get_the_date( 'c' ) ),
		mirror_human_time_diff()
	);

	if ( ! post_password_required() && ( comments_open() || '0' != get_comments_number() ) ) {
?>
		<span class="commentcount"><?php comments_popup_link( esc_html__( 'Leave a Comment', 'mirror' ), esc_html__( '1 Comment', 'mirror' ), esc_html__( '% Comments', 'mirror' ) ); ?></span>
<?php
	}
?>
	</div>
