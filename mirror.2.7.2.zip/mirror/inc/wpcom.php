<?php
/**
 * WordPress.com specific functionality
 *
 * @package Mirror
 */

/**
 * Theme colours for wp.com custom functionality
 *
 * @global string $themecolors
 */
function mirror_theme_colors() {

	global $themecolors;

	/**
	 * Set a default theme color array for WP.com.
	 *
	 * @global array $themecolors
	 */
	if ( ! isset( $themecolors ) ) {
		$themecolors = array(
			'bg'     => 'ffffff',
			'border' => 'cccccc',
			'text'   => '333333',
			'link'   => '6DC236',
			'url'    => 'cccccc',
		);
	}

}

add_action( 'after_setup_theme', 'mirror_theme_colors' );


/**
 * Dequeue Google Fonts if Custom Fonts are being used instead.
 *
 * @param  array $fonts List of fonts.
 * @return array
 */
function mirror_dequeue_fonts( $fonts ) {

	if ( class_exists( 'TypekitData' ) && class_exists( 'CustomDesign' ) && CustomDesign::is_upgrade_active() ) {
	    $custom_fonts = TypekitData::get( 'families' );

		// Make sure both fonts are custom before dequeing anything.
		if ( $custom_fonts && $custom_fonts['headings']['id'] && $custom_fonts['body-text']['id'] ) {
			wp_dequeue_style( 'mirror-font-roboto-slab' );
		}
	}

	return $fonts;

}

add_action( 'wp_enqueue_scripts', 'mirror_dequeue_fonts', 11 );
