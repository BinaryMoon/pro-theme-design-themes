<?php
/**
 * Generic content
 *
 * @package Mirror
 */

	$thumbnail_size = 'mirror-archive';
	if ( is_active_sidebar( 'sidebar-1' ) ) {
		$thumbnail_size = 'mirror-archive-square';
	}
	$image = get_the_post_thumbnail( get_the_ID(), $thumbnail_size );

	$category = get_the_category();
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<?php
	if ( isset( $category[0] ) ) {
?>
	<div class="post-info">
		<a href="<?php echo esc_url( get_category_link( $category[0]->term_id ) ); ?>"><?php echo esc_html( $category[0]->cat_name ); ?></a>
	</div>
<?php
	}

	if ( get_the_title() ) {
?>
		<h2 class="entry-title">
			<a href="<?php the_permalink() ?>" rel="bookmark">
				<?php the_title(); ?>
			</a>
		</h2>
<?php
	}

	if ( $image ) {
?>
	<a href="<?php echo esc_url( get_permalink() ); ?>" class="thumbnail">
		<?php echo $image; ?>
	</a>
<?php
	}
?>
	<section class="entry entry-archive">
<?php
	get_template_part( 'inc/post-meta' );
	echo wpautop( get_the_excerpt() );
?>
		<p><a href="<?php the_permalink(); ?>" class="read-more"><?php mirror_read_more_text(); ?></a></p>
	</section>
</article>
