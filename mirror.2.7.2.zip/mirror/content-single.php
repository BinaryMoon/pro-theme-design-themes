<?php
/**
 * Single post content
 *
 * @package Mirror
 */

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<?php
	the_title( '<h1 class="entry-title">', '</h1>' );
	get_template_part( 'inc/post-meta' );
?>
	<section class="entry entry-single">
<?php
	the_content();

	edit_post_link();

	wp_link_pages(
		array(
			'before' => '<div class="archive-pagination">',
			'after'  => '</div>',
			'link_before' => '<span>',
			'link_after'  => '</span>',
		)
	);

	get_template_part( 'inc/post-terms' );
?>
	</section>

</article>

<nav class="post-nav">
	<h1 class="screen-reader"><?php esc_html_e( 'Post navigation', 'mirror' ); ?></h1>
<?php
	previous_post_link( __( '<div class="prev">%link</div>', 'mirror' ), '<span>%title</span>' );
	next_post_link( __( '<div class="next">%link</div>', 'mirror' ), '<span>%title</span>' );
?>
</nav>
