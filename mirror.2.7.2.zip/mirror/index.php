<?php
/**
 * Homepage Template
 *
 * @package Mirror
 */

	get_header();

	if ( have_posts() ) {
?>
	<div id="main-content">
<?php
		while ( have_posts() ) {
			the_post();
			get_template_part( 'content', get_post_format() );
		}
		mirror_numeric_pagination();
?>
	</div>
<?php
	} else {
		get_template_part( 'content-empty' );
	}

	get_footer();
