<?php
/**
 * Header Template
 *
 * @package Mirror
 */

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta http-equiv="Content-Type" content="<?php bloginfo( 'html_type' ); ?>; charset=<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

	<a href="#main-content" class="screen-reader-shortcut"><?php esc_html_e( 'Skip to content', 'mirror' ); ?></a>

	<header class="masthead" role="banner">
		<div class="masthead-inner container">
			<div class="branding">

				<?php if ( function_exists( 'the_site_logo' ) ) { the_site_logo(); } ?>

				<h1 class="site-title">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php esc_attr_e( 'Home', 'mirror' ); ?>">
						<?php bloginfo( 'name' ); ?>
					</a>
				</h1>

<?php
	if ( '' !== get_bloginfo( 'description' ) ) {
?>
				<h2 class="site-description">
					<?php bloginfo( 'description' ); ?>
				</h2>
<?php
	}
?>
			</div>
			<nav class="menu" role="navigation">
<?php
	wp_nav_menu(
		array(
			'theme_location' => 'top_menu',
			'menu_id' => 'nav',
			'menu_class' => 'menu-wrap',
			'container' => '',
		)
	);
?>
			</nav>
		</div>
	</header>
<?php
	do_action( 'before' );

	mirror_header();

	get_template_part( 'inc/jetpack-featured-content' );
?>
<div class="container hfeed">
	<div class="main">
