=== Mirror ===

Contributors: binarymoon
Requires at least: 4.3
Tested up to: 4.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: art, artwork, blog, bright, cartoon, classic-menu, clean, conservative, contemporary, curved, custom-background, custom-colors, custom-header, custom-menu, elegant, featured-image-header, featured-images, flexible-heade, full-width-template, gray, green, holiday, infinite-scroll, journal, lifestream, light, light, magazine, minimal, modern, music, nature, one-column, photoblogging, photography, post-slider, responsive-layout, right-sidebar, rtl-language-support, silver, sticky-post, translation-ready, two-columns, white

== Description ==

Mirror is a blog focused theme showcasing large featured images and clear typography. A large featured content slider in the header helps your top content to shine.

[Theme documentation](https://prothemedesign.com/documentation/theme/mirror/)

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Mirror includes support for [Styleguide](https://wordpress.org/plugins/styleguide/) - a plugin that allows you to change fonts, and colours in WordPress themes.

Mirror includes support for most features in [Jetpack](https://wordpress.org/plugins/jetpack/), including Infinite Scroll, Featured Content, and Site Logo.

== Changelog ==

= 2.7.2 - 31st January 2021 =
* Clear html widget to prevent floated content from breaking the layout.

= 2.7.1 - 9th July 2020 =
* Remove use of deprecated Jetpack function `is_ipad`.

= 2.7 - 13th March 2020 =
* Add Gutenberg support.
* Fix 'no search results' page so that it doesn't show 2 headers and 2 search boxes.
* Minor tweaks to white space to improve readability.
* Improve responsive styles.

= 2.6 - 1st October 2019 =
* Add search form to search results page.
* Tweak search bar styles to make it more accessible, and more consistantly styled.

= 2.5.2 - 8th Janury 2019 =
* Ensure site title and description hide when hidden in the customizer.
* Make navigation stretch full width when site title and description are hidden.
* Update CSS prefixes.

= 2.5.1 - 20th August 2018 =
* Tweak infinite scroll button styles to make it more friendly.
* Ensure pill shapes stay as pills even with larger font sizes.

= 2.5 - 25th May 2018 =
* Add support for privacy policy link in the site footer.
* Fix display of the cookie consent checkbox in the comments form.

= 2.4 - 12th January 2018 =
* Tweak css styles for spacing and contrast to improve readability and accessibility

= 2.3.1 - 25th November 2017 =
* Tweak styles to improve readability & hierarchy of blog posts

= 2.3 - 5th October 2017 =
* Add option to display featured content on homepage only.
* Change customizer settings so they update in real time.
* Small style tweaks to improve readability of content.

= 2.2.2 - 13th July 2017 =
* Remove include for inc/wpcom.php, since it's automatically included by WordPress.com sites

= 2.2.1 - 10th March 2017 =
* Fix small bug with slider where the link doesn't fill the full width of the page.
* Make social widgets work better on small devices.

= 2.2 - 27th November 2016 =
* Fix image attachment template
* Fix article css clearing for hr and headers
* More code escaping on translations and coding standards improvements

= 2.1.2 - 27th October 2016 =
* Add support for pages and projects in slider.
* Tidy codes.

= 2.1.1 - 13th September 2016 =
* Update wordwrap css properties.

= 2.1 - 17th July 2016 =
* Improve coding standards and security
* Many minor improvements to css styles to improve compatibility and resilience

= 2.0 =
* wordpress.com release

= 1.0 =
* Initial release

== Credits ==

* [Roboto](https://fonts.google.com/specimen/Roboto) Font from Google Fonts, licensed under [Apache License, version 2.0](http://www.apache.org/licenses/LICENSE-2.0.html)
