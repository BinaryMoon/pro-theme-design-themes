<?php
/**
 * Search results template
 *
 * @package Mirror
 */

	get_header();
?>
	<header class="entry-archive-header">
		<h1 class="entry-title entry-archive-title">
			<?php printf( __( 'Search results for &#8216;<em>%s</em>&#8217;', 'mirror' ), get_search_query() ); ?>
		</h1>
<?php
	if ( ! have_posts() ) {
?>
		<div class="category-description">
			<p><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'mirror' ); ?></p>
		</div>
<?php
	}
?>
	</header>
<?php
	get_search_form();

	if ( have_posts() ) {
?>
	<div id="main-content" class="main-content">
<?php
		while ( have_posts() ) {
			the_post();
			get_template_part( 'content', get_post_format() );
		}
		mirror_numeric_pagination();
?>
	</div>
<?php
	}

	get_footer();
