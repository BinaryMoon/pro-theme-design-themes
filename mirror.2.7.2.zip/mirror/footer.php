<?php
/**
 * Footer Template
 *
 * @package Mirror
 */

?>
	</div>
<?php
	get_sidebar();
?>
</div>

<footer role="contentinfo" id="footer">
<?php
	mirror_social_links();

	if ( is_active_sidebar( 'sidebar-2' ) ) {
?>
	<aside class="footer-widgets sidebar-footer container">
		<?php dynamic_sidebar( 'sidebar-2' ); ?>
	</aside>
<?php
	}
?>
	<section class="footer-wrap container">
<?php
	if ( function_exists( 'the_privacy_policy_link' ) ) {
		the_privacy_policy_link( '', '<span class="sep"> | </span>' );
	}
?>
		<a href="http://wordpress.org/" title="<?php esc_attr_e( 'A Semantic Personal Publishing Platform', 'mirror' ); ?>" rel="generator"><?php printf( esc_html__( 'Proudly powered by %s', 'mirror' ), 'WordPress' ); ?></a>
		<span class="sep"> | </span>
		<?php printf( __( 'Theme: %1$s by %2$s.', 'mirror' ), 'Mirror', '<a href="https://prothemedesign.com/" rel="designer">Pro Theme Design</a>' ); ?>
	</section>
</footer>

<?php wp_footer(); ?>

</body>
</html>
