/**
 * main.js v1
 * Created by Ben Gillbanks <http://www.binarymoon.co.uk/>
 * Available under GPL2 license
 */

; ( function( $ ) {

	$( document ).ready( function() {

		if ( typeof $.fn.responsiveNavigation === 'function' ) {
			$( 'ul#nav' ).responsiveNavigation( {
				breakpoint: 549
			} );
		}

		// attachment page navigation
		if ( $( 'body' ).hasClass( 'attachment' ) ) {

			$( document ).keydown( function( e ) {

				if ( $( 'textarea, input' ).is( ':focus' ) ) {
					return;
				}

				var url = false;

				switch ( e.which ) {
					// left arrow key (previous attachment)
					case 37:
						url = $( '.image-previous a' ).attr( 'href' );
						break;

					// right arrow key (next attachment)
					case 39:
						url = $( '.image-next a' ).attr( 'href' );
						break;

				}

				if ( url ) {
					window.location = url;
				}
			} );

		}

		if ( typeof $.fn.masonry === 'function' ) {
			$( 'footer#footer .footer-widgets' ).imagesLoaded( function() {
				$( 'footer#footer .footer-widgets' ).masonry( {
					itemSelector: '.widget',
					gutter: 0,
					isOriginLeft: !$( 'body' ).is( '.rtl' )
				} );
			} );
		}

		if ( typeof $.fn.elementalSlides === 'function' ) {
			$( '.showcase' ).elementalSlides(
				{
					interval: 6000,
					'nav_arrows': true
				}
			);
		}

		$( '.menu' ).find( 'a' ).on( 'focus blur', function() {
			$( this ).parents().toggleClass( 'focus' );
		} );

	} );

} )( jQuery );