<?php
/**
 * Single post template
 *
 * @package Mirror
 */

	get_header();

?>
	<div class="main-content">
<?php

	if ( have_posts() ) {

		while ( have_posts() ) {

			the_post();
			get_template_part( 'content-single' );
			get_template_part( 'inc/comments' );

		}
	} else {

		get_template_part( 'content-empty' );

	}

?>
	</div>
<?php

	get_footer();
