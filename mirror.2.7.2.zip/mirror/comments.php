<?php
/**
 * Comments template.
 *
 * @package Mirror
 */

	if ( post_password_required() ) {
		return;
	}
?>
<section class="content-comments">
<?php
	if ( have_comments() ) {
?>
	<h3 id="comments">
<?php
		printf( _n( '1 Comment', '%1$s Comments', get_comments_number(), 'mirror' ), number_format_i18n( get_comments_number() ), '<span>' . get_the_title() . '</span>' );
?>
		<a href="#respond" title="<?php esc_attr_e( 'Leave a comment', 'mirror' ); ?>">&raquo;</a>
	</h3>
	<ol class="commentlist" id="singlecomments">
<?php
		wp_list_comments(
			array(
				'avatar_size' => 48,
				'format' => 'html5',
				'short_ping' => true,
			)
		);
?>
	</ol>
<?php
		if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) {
?>
	<nav class="post-nav">
		<h1 class="screen-reader"><?php esc_html_e( 'Comment navigation', 'mirror' ); ?></h1>
		<div class="prev">
			<?php previous_comments_link( esc_html__( 'Older Comments', 'mirror' ) ); ?>
		</div>
		<div class="next">
			<?php next_comments_link( esc_html__( 'Newer Comments', 'mirror' ) ); ?>
		</div>
	</nav>
<?php
		}
	}

	if ( 'open' === $post->comment_status ) {
		comment_form();
	}
?>
</section>
