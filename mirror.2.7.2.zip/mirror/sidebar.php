<?php
/**
 * Sidebar template
 *
 * @package Mirror
 */

	// Don't display on full width page.
	if ( is_page_template( 'page-templates/full-width.php' ) ) {
		return;
	}

	if ( ! is_active_sidebar( 'sidebar-1' ) ) {
		return;
	}

?>
<div class="sidebar sidebar-main" role="complementary">
<?php
	do_action( 'before_sidebar' );
	dynamic_sidebar( 'sidebar-1' );
?>
</div>
