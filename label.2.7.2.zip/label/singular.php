<?php
/**
 * Single post & page template
 *
 * @package Label
 */

	get_header();

?>

	<main role="main">

		<div class="main-content content-single">

<?php

	if ( have_posts() ) {

		while ( have_posts() ) {

			the_post();

			get_template_part( 'parts/content-single', get_post_type() );

		}
	} else {

		get_template_part( 'parts/content-empty' );

	}

?>

		</div>

	</main>

<?php

	if ( is_single() ) {

		the_post_navigation(
			array(
				'next_text' => '<span class="meta-nav" aria-hidden="true">' . esc_html__( 'Next', 'label' ) . '</span> ' .
					'<span class="screen-reader-text">' . esc_html__( 'Next post:', 'label' ) . '</span> ' .
					'<span class="post-title">%title</span>',
				'prev_text' => '<span class="meta-nav" aria-hidden="true">' . esc_html__( 'Previous', 'label' ) . '</span> ' .
					'<span class="screen-reader-text">' . esc_html__( 'Previous post:', 'label' ) . '</span> ' .
					'<span class="post-title">%title</span>',
			)
		);

	}

	get_footer();
