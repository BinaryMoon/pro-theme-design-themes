<?php
/**
 * Header Template
 *
 * @package Label
 */

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<div class="webpage">

	<a href="#site-content" class="screen-reader-shortcut"><?php esc_html_e( 'Skip to content', 'label' ); ?></a>

	<header class="masthead" id="header" role="banner">

		<div class="branding">

<?php
	if ( is_front_page() ) {
?>
			<h1 class="site-title">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
			</h1>
<?php
	} else {
?>
			<p class="site-title">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
			</p>
<?php
	}
?>
		</div>

		<?php the_custom_logo(); ?>

		<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false">
			<?php label_svg( 'menu-rows' ); ?>
			<span><?php esc_html_e( 'Menu', 'label' ); ?></span>
		</button>

	</header>

<?php

	get_template_part( 'parts/jetpack-featured-content' );

	if ( has_nav_menu( 'menu-2' ) ) {

?>

	<div class="menu-page-container" id="header-menu">

		<nav class="menu-page menu" role="navigation" aria-label="<?php esc_attr_e( 'Header Menu', 'label' ); ?>">

<?php
		wp_nav_menu(
			array(
				'theme_location' => 'menu-2',
				'menu_id' => 'nav',
				'menu_class' => 'menu-wrap',
				'container' => false,
				'fallback_cb' => false,
			)
		);
?>

		</nav>

	</div>

<?php

	}

	label_header();

	do_action( 'before' );
?>

	<div class="container" id="site-content">
