<?php
/**
 * Page content
 *
 * @package Label
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<header class="entry-header">

<?php
	label_breadcrumbs();

	if ( is_front_page() ) {

		the_title( '<h2 class="entry-title">', '</h2>' );

	} else {

		the_title( '<h1 class="entry-title">', '</h1>' );

	}

	get_template_part( 'parts/post-meta' );
?>

	</header>

<?php

	if ( get_theme_mod( 'label_display_featured_image', true ) ) {

		the_post_thumbnail( 'label-single-header', array( 'class' => 'singular-image' ) );

	}

?>

	<section class="entry entry-single">

<?php

	the_content(
		sprintf(
			esc_html__( 'Read more %s', 'label' ),
			the_title( '<span class="screen-reader-text">', '</span>', false )
		)
	);

	wp_link_pages(
		array(
			'before'      => '<div class="pagination">',
			'after'       => '</div>',
			'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', 'label' ) . ' </span>%',
		)
	);

	get_template_part( 'parts/comments' );

?>

	</section>

	<?php get_sidebar(); ?>

</article>
