<?php
/**
 * Post meta data
 *
 * @package Label
 */

?>

	<p class="post-meta-data"><?php

	if ( is_single() ) {

		label_post_time();

		label_post_author();

		label_comments_link();

		echo '<span class="meta tax-categories tax-post-categories">' . get_the_category_list( esc_html_x( ', ', 'Category/ Tag list separator (includes a space after the comma)', 'label' ) ) . '</span>';

	}

	if ( 'jetpack-portfolio' === get_post_type( get_the_ID() ) ) {

		echo '<span class="meta tax-categories tax-project-types">' . get_the_term_list( get_the_ID(), 'jetpack-portfolio-type', '', ' ' ) . '</span>';

	}

	get_template_part( 'parts/edit-post' );

?></p>
