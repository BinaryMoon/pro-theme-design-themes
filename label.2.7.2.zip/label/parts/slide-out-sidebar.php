<?php
/**
 * Menu Drawer
 *
 * @package Label
 */

?>

<div class="menu-drawer" id="menu-drawer">

<?php
	// Get site description.
	$description = get_bloginfo( 'description', 'display' );

	if ( $description || is_customize_preview() ) {
?>

		<p class="site-description">
			<?php echo $description; /* WPCS: xss ok. */ ?>
		</p>

<?php
	}

	if ( has_nav_menu( 'menu-1' ) ) {
?>

	<nav class="menu menu-primary" role="navigation" aria-label="<?php esc_attr_e( 'Slide-out Sidebar Menu', 'label' ); ?>">

<?php
		wp_nav_menu(
			array(
				'theme_location' => 'menu-1',
				'menu_id' => 'nav',
				'menu_class' => 'menu-wrap',
				'container' => false,
				'fallback_cb' => false,
			)
		);
?>

	</nav>

<?php
	}

	if ( has_nav_menu( 'menu-2' ) ) {
?>

	<nav class="menu menu-secondary" role="navigation" aria-label="<?php esc_attr_e( 'Secondary Menu', 'label' ); ?>">

<?php
		wp_nav_menu(
			array(
				'theme_location' => 'menu-2',
				'menu_id' => 'nav',
				'menu_class' => 'menu-wrap',
				'container' => false,
				'fallback_cb' => false,
			)
		);
?>

	</nav>

<?php
	}

	get_sidebar( 'overlay' );
?>

</div>
