<?php
/**
 * Contributors listing
 *
 * @package Label
 */

$contributors = get_users(
	array(
		'fields'  => 'ID',
		'order'   => 'DESC',
		'who'     => 'authors',
	)
);

foreach ( $contributors as $contributor_id ) {

	$post_count = count_user_posts( $contributor_id );

	// Move on if user has not published a post (yet).
	if ( ! $post_count ) {

		continue;

	}

	label_contributor( $contributor_id, $post_count );

}
