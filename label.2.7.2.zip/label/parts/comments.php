<?php
/**
 * Reusable code for adding comments to a page
 *
 * @package Label
 */

	if ( comments_open() || get_comments_number() ) {

		comments_template( '', true );

	}
