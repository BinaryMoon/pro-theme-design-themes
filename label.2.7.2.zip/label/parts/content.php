<?php
/**
 * Generic content
 *
 * @package Label
 */

	$image = get_the_post_thumbnail( get_the_ID(), 'label-archive' );
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

<?php
	if ( $image ) {
?>

	<a href="<?php echo esc_url( get_permalink() ); ?>" class="thumbnail">
		<?php echo $image; ?>
	</a>

<?php
	}
?>

	<section class="entry entry-archive">

<?php
	the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );

	the_excerpt();

	get_template_part( 'parts/post-meta' );
?>

	</section>

</article>
