<?php
/**
 * Individual Testimonial layout
 *
 * @package Label
 */

	$image = get_the_post_thumbnail( get_the_ID(), 'label-attachment', array( 'class' => 'avatar' ) );
?>

<article id="post-<?php the_ID(); ?>" class="testimonial">

	<div class="entry">

<?php
	the_content(
		sprintf(
			esc_html__( 'Read more %s', 'label' ),
			the_title( '<span class="screen-reader-text">', '</span>', false )
		)
	);
?>

	</div>

	<div class="entry-meta">

<?php
	if ( $image ) {
		echo $image;
	}

	the_title( '<h3>', '</h3>' );
?>

	</div>

</article>
