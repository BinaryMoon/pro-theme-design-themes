<?php
/**
 * Jetpack Featured Content
 * See: https://jetpack.me/support/featured-content/
 *
 * @package Label
 */

	if ( label_has_featured_posts() ) {

		$scroll_to = 'site-content';

		if ( has_nav_menu( 'menu-2' ) ) {
			$scroll_to = 'header-menu';
		}

		$featured_posts = label_get_featured_posts( 6 );
?>

	<section class="showcase">

		<a href="#<?php echo $scroll_to; ?>" class="scroll-to skip-slider">
			<span class="screen-reader-text"><?php esc_html_e( 'Skip Slider', 'label' ); ?></span>
		</a>

<?php
		foreach ( $featured_posts as $post ) {

			setup_postdata( $post );

			$styles = array();
			$image = label_archive_image_url( get_the_ID(), 'label-featured' );

			if ( $image ) {

				$styles = array(
					'background-image: url(' . esc_url( $image ) . ');'
				);

			}
?>

		<article <?php post_class(); ?> style="<?php echo esc_attr( implode( ' ', $styles ) ); ?>">

			<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" class="item-inner entry">

				<div class="entry-container">

					<h2 class="entry-title"><?php the_title(); ?></h2>

					<div class="entry-text">
						<?php echo wp_kses_post( wpautop( label_link_to_span( get_the_excerpt() ) ) ); ?>
					</div>

				</div>

			</a>

			<?php get_template_part( 'parts/edit-post' ); ?>

		</article>

<?php
		}
?>

	</section>

<?php
		wp_reset_postdata();
	}
