=== Label ===

Contributors: binarymoon
Requires at least: 4.3
Tested up to: 4.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: black, gray, green, white, light, one-column, two-columns, right-sidebar, responsive-layout, accessibility-ready, author-bio, blog-excerpts, breadcrumb-navigation, classic-menu, custom-background, custom-colors, custom-header, custom-menu, editor-style, featured-content-with-pages, featured-images, featured-image-header, flexible-header, full-width-template, infinite-scroll, multiple-menus, post-formats, post-slider, rtl-language-support, site-logo, sticky-post, testimonials, theme-options, threaded-comments, translation-ready, art, artwork, craft, design, fashion, food, music, nature, photoblogging, photography, seasonal, artistic, bright, clean, conservative, contemporary, elegant, light, minimal, modern, professional, simple, sophisticated

== Description ==

Label is a stylistic theme created specially for art and fashion bloggers. With a distinctive masonry powered layout, a full screen post slider, and a classy vertical header - it's sure to make your website stand out.

[Theme documentation](https://prothemedesign.com/documentation/theme/label/)

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Label includes support for [Styleguide](https://wordpress.org/plugins/styleguide/) - a plugin that allows you to change fonts, and colours in WordPress themes.

Label includes support for most features in [Jetpack](https://wordpress.org/plugins/jetpack/), including Infinite Scroll, Featured Content, and Site Logo.

== Changelog ==

= 2.7.2 - 12th August 2020 =
* Add support for 'no link logo' on homepage: https://make.wordpress.org/core/2020/07/28/themes-changes-related-to-get_custom_logo-in-wordpress-5-5/

= 2.7.1 - 13th July 2020 =
* Add support for accessible widget lists: https://make.wordpress.org/core/2020/07/09/accessibility-improvements-to-widgets-outputting-lists-of-links-in-5-5/

= 2.7 - 26th March 2020 =
* More Gutenberg improvements.

= 2.6.6 - 12th March 2020 =
* Improve Gutenberg styles.

= 2.6.5 - 5th December 2019 =
* Make gallery post types using Gutenberg display properly. "Fixes" get_post_gallery.
* Improve coding standards.

= 2.6.4 - 30th September 2019 =
* Improve default search input styles.

= 2.6.3 - 13th May 2019 =
* Add font display swap to Google Font loading, to increase font display speed.

= 2.6.2 - 26th November 2018 =
* Improve archive post loading when lazy loading is enabled.

= 2.6.1 - 4th September 2018 =
* Increase number of posts displayed on the child pages template.

= 2.6 - 25th May 2018 =
* Add support for privacy policy link in the site footer.
* Fix display of the cookie consent checkbox in the comments form.

= 2.5.6 - 16th February 2018 =
* Fix issue with video sizing on archive pages.
* Improve CSS formatting.
* Ensure empty paragraphs are hidden.
* Improve margins and padding for custom post formats to reduce wasted space.
* Tidy js
* Make sure masonry content reorders itself on orientation change

= 2.5.5 - 28th January 2018 =
* Optimize CSS.

= 2.5.4 - 27th January 2018 =
* Correct post navigation labels.

= 2.5.3 - 20th December 2017 =
* Further improvements to WooCommerce support.

= 2.5.2 - 11th December 2017 =
* Fix issues with admin bar on small devices.

= 2.5.1 - 3rd December 2017 =
* Tweak footer credits filter so it hides less html.

= 2.5 - 31st October 2017 =
* WooCommerce for all (.com and .org).
* Disable infinite-scroll on WooCommerce archive pages.

= 2.4.9 - 4th October 2017 =
* Add project type list to projects pages to keep the page layout consistent with the single post categories.

= 2.4.8 - 2nd October 2017 =
* Remove post time and other irrelevant info from pages.
* Fix post likes functionality for newer versions of Jetpack.

= 2.4.7 - 1st October 2017 =
* Reinitialize footer widget masonry after 2 seconds in order to ensure social widgets are positioned correctly.

= 2.4.6 - 27th September 2017 =
* Improve menu overlay display on ios Safari.

= 2.4.5 - 15th September 2017 =
* Improve breadcrumb display on small devices.
* Add a little more space below page titles to ensure page meta has enough room.
* Fix issue with header position on tablet devices.
* Tweak space between post meta items on small devices.

= 2.4.4 - 10th September 2017 =
* Remove duplicate comment form on full width template.
* Fix malformed html in slider navigation.
* Improve stylesheet formatting and update rtl.css
* Tweak site title spacing to reduce liklihood of title overlapping menu & logo.
* Fix dropdown menus on touch devices when no href is set.

= 2.4.3 - 13th July 2017 =
* Remove include for inc/wpcom.php, since it's automatically included by WordPress.com sites

= 2.4.2 - 3rd July 2017 =
* Fix PHP errors due to WooCommerce integration.

= 2.4.1 - 28th June 2017 =
* Stop dates from showing up on homepage when custom front page is being used.

= 2.4 - 18th June 2017 =
* Add support for WooCommerce

= 2.3.5 - 24th February 2017 =
* Make Jetpack infinite scroll load testimonials properly
* Improve social media widget responsive behaviour
* update rtl styles

= 2.3.4 - 9th December 2016 =
* Improve the editor-styles.css
* Update rtl.css
* Simplify form styles
* Add some animation to site title and logo

= 2.3.3 - 6th December 2016 =
* Add a bit of animation to the header for extra woosh
* Update rtl.css

= 2.3.2 - 4th December 2016 =
* Show and hide site title and description in customizer without full page refresh
* Update rtl.css

= 2.3.1 - 21st November 2016 =
* Improve infinite loading display on blog posts
* Make site title and site description customizer refresh even more real time

= 2.3 - 20th November 2016 =
* Add support for customizer refresh of site title and site description
* Add support for customizer refresh for widgets

= 2.2.5 - 17th November 2016 =
* Tweak responsive styles on the slider
* Fix issue with menu button on ios
* Tweak responsive styles on single post pages so that content makes better use of space
* Hide avatar outlines on small screens cos they look a bit odd (and aren't necessary)
* Improve print styles
* Update rtl styles

= 2.2.4 - 10th November 2016 =
* Fix issue with the header and menu button that happened on iOS devices only.

= 2.2.3 - 6th November 2016 =
* Fix minor issue with hamburger icon animation
* Fix related posts margin
* Fix gap between comment submit button and comment subscribe buttons

= 2.2.2 - 4th November 2016 =
* Improve support for post-series plugin

= 2.2.1 - 31st October 2016 =
* Small fix for mobile header height when site title is hidden

= 2.2 - 31st October 2016 =
* Improve image attachment page to display descriptions and captions and fix navigation styles
* update rtl.css styles

= 2.1.2 - 27th October 2016 =
* Tweak responsive styles to behave better on mobile devices.

= 2.1.1 - 8th October 2016 =
* Tweak styles of select boxes so they use browser defaults

= 2.1 - 6th October 2016 =
* Improve responsive layout

= 2.0 - 5th October 2016 =
* wordpress.com version release

= 1.0 =
* Initial release

== Credits ==

* [Source Serif Pro](https://fonts.google.com/specimen/Source+Serif+Pro) Font from Google Fonts, licensed under [SIL Open Font License, 1.1](http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL)
