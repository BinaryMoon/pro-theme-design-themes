<?php
/**
 * Reusable theme functions
 *
 * @link https://coolors.co/app/ffffff-f2f2f2-c6957f-000000-bdc667
 * @package Label
 */

// WordPress specific functionality (actions and filters).
require 'inc/wordpress.php';

// Custom header.
require 'inc/custom-header.php';

// Reusable Template Functions.
require 'inc/template-tags.php';

// Jetpack specific functionality.
require 'inc/jetpack.php';

// Customizer settings.
require 'inc/customizer.php';

// Customizer auto update controls without full page refresh.
require 'inc/customizer-refresh.php';

/**
 * Load WooCommerce compatibility file.
 */
if ( class_exists( 'WooCommerce' ) ) {
	require 'inc/woocommerce.php';
}
