<?php
/**
 * Overlay Sidebar template
 *
 * @package Label
 */

	if ( is_active_sidebar( 'sidebar-3' ) ) {
?>

	<!-- Sidebar Footer (3) -->

	<aside class="sidebar-overlay sidebar" role="complementary">

<?php
	dynamic_sidebar( 'sidebar-3' );
?>

	</aside>

<?php
	}
