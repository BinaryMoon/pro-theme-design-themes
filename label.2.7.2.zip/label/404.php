<?php
/**
 * Error - file not found
 *
 * @package Label
 */

	get_header();
?>

	<main role="main">

		<div class="header-404">
			<?php label_svg( '404' ); ?>
		</div>

		<div class="main-content">

			<?php get_template_part( 'parts/content-empty' ); ?>

		</div>

	</main>

<?php
	get_footer();
