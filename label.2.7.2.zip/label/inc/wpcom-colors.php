<?php
/* Custom Colors: Label */

//Background
add_color_rule( 'bg', '#f2f2f2', array(
    array( '#footer .jetpack-social-navigation:after,
            .content-posts article .entry,
            .content-single-extras:before,
            .post-password-required form,
            .taxonomies:before,
            .the-content,
            body,
            hr:after,
            q', 'background-color' ),
) );

add_color_rule( 'txt', '#000000', array(
    array( '.comment-navigation .post-title,
            .image-navigation .post-title,
            .infinite-scroll .infinite-loader,
            .menu-page-container ul.menu-wrap a,
            .post-navigation .post-title,
            h1,
            h1 a,
            h2,
            h2 a,
            h3,
            h3 a,
            h4,
            h4 a,
            h5,
            h5 a,
            h6,
            h6 a,
            table th', 'color', 'bg' ),

    array( '.sticky h1,
            .sticky h1 a,
            .sticky h2,
            .sticky h2 a,
            .sticky h3,
            .sticky h3 a,
            .sticky h4,
            .sticky h4 a,
            .sticky h5,
            .sticky h5 a,
            .sticky h6,
            .sticky h6 a,
            .sticky a,
            .showcase .item-inner h2', 'color', '#ffffff' ),

    array( '.showcase .item-inner a.permalink,
            .masthead .branding .site-title a,
            .masthead .branding .site-title a:hover,
            .masthead .branding p.site-description,
            .masthead .menu-toggle,
            .masthead .menu-toggle:focus,
            .masthead .menu-toggle:hover,
            .menu-drawer .menu a', 'color', '#ffffff' ),
),
__( 'Headings' ) );

add_color_rule( 'link', '#626e7a', array(
    array( 'a,
            .widget.widget_flickr #flickr_badge_uber_wrapper td a,
            .widget.widget_flickr #flickr_badge_wrapper td a', 'color', 'bg' ),

    array( '.showcase article .edit-link a', 'color', '#ffffff' ),

    array( '.menu-page-container .menu li ul:before', 'border-color' ),

    array( '.infinite-scroll #infinite-handle button,
            .menu-page-container .menu li ul,
            .pagination .current,
            .showcase article,
            .the-content .button,
            .woocommerce #respond input#submit,
            .woocommerce #respond input#submit.alt,
            .woocommerce a.button,
            .woocommerce a.button.alt,
            .woocommerce button.button,
            .woocommerce button.button.alt,
            .woocommerce input.button,
            .woocommerce input.button.alt,
            a.button,
            button,
            input[type=submit]', 'background-color' ),

    array( '.infinite-scroll #infinite-handle button:focus,
            .infinite-scroll #infinite-handle button:hover,
            .the-content .button:focus,
            .the-content .button:hover,
            .woocommerce #respond input#submit.alt:focus,
            .woocommerce #respond input#submit.alt:hover,
            .woocommerce #respond input#submit:focus,
            .woocommerce #respond input#submit:hover,
            .woocommerce a.button.alt:focus,
            .woocommerce a.button.alt:hover,
            .woocommerce a.button:focus,
            .woocommerce a.button:hover,
            .woocommerce button.button.alt:focus,
            .woocommerce button.button.alt:hover,
            .woocommerce button.button:focus,
            .woocommerce button.button:hover,
            .woocommerce input.button.alt:focus,
            .woocommerce input.button.alt:hover,
            .woocommerce input.button:focus,
            .woocommerce input.button:hover,
            a.button:focus,
            a.button:hover,
            button:focus,
            button:hover,
            input[type=submit]:focus,
            input[type=submit]:hover', 'background-color', '-0.7' ),

    array( '::-moz-selection', 'background-color' ),
    array( '::selection', 'background-color' ),
),
__( 'Links & Buttons' ) );

add_color_rule( 'fg1', '#404850', array(
    array( 'a:hover', 'color', 'bg' ),
    array( '.menu-drawer .menu a:hover', 'color', '#ffffff' ),
),
__( 'Link Hover' ) );

add_color_rule( 'fg2', '#ffffff', array(
) );


//Extra rules
add_color_rule( 'extra', '#ffffff', array(

    array( '.infinite-scroll #infinite-handle button,
            .menu-page-container .menu li ul,
            .pagination .current,
            .showcase article,
            .the-content .button,
            .woocommerce #respond input#submit,
            .woocommerce #respond input#submit.alt,
            .woocommerce a.button,
            .woocommerce a.button.alt,
            .woocommerce button.button,
            .woocommerce button.button.alt,
            .woocommerce input.button,
            .woocommerce input.button.alt,
            a.button,
            button,
            input[type=submit],
            .menu-page-container .menu li ul li a,
            .menu-page-container .menu li ul li a:focus,
            .menu-page-container .menu li ul li a:hover', 'color', 'link' ),

    array( '::-moz-selection', 'color', 'link' ),
    array ( '::selection', 'color', 'link' ),

    array( '.infinite-scroll #infinite-handle button:focus,
            .infinite-scroll #infinite-handle button:hover,
            .the-content .button:focus,
            .the-content .button:hover,
            .woocommerce #respond input#submit.alt:focus,
            .woocommerce #respond input#submit.alt:hover,
            .woocommerce #respond input#submit:focus,
            .woocommerce #respond input#submit:hover,
            .woocommerce a.button.alt:focus,
            .woocommerce a.button.alt:hover,
            .woocommerce a.button:focus,
            .woocommerce a.button:hover,
            .woocommerce button.button.alt:focus,
            .woocommerce button.button.alt:hover,
            .woocommerce button.button:focus,
            .woocommerce button.button:hover,
            .woocommerce input.button.alt:focus,
            .woocommerce input.button.alt:hover,
            .woocommerce input.button:focus,
            .woocommerce input.button:hover,
            a.button:focus,
            a.button:hover,
            button:focus,
            button:hover,
            input[type=submit]:focus,
            input[type=submit]:hover', 'color', 'link' ),
) );

add_color_rule( 'extra', '#000000', array(
    array( '.form-select:focus,
            .form-select:hover,
            input.settings-input:focus,
            input.settings-input:hover,
            input.text:focus,
            input.text:hover,
            input[type="date"]:focus,
            input[type="date"]:hover,
            input[type="datetime-local"]:focus,
            input[type="datetime-local"]:hover,
            input[type="month"]:focus,
            input[type="month"]:hover,
            input[type="number"]:focus,
            input[type="number"]:hover,
            input[type="tel"]:focus,
            input[type="tel"]:hover,
            input[type="time"]:focus,
            input[type="time"]:hover,
            input[type="week"]:focus,
            input[type="week"]:hover,
            input[type=email]:focus,
            input[type=email]:hover,
            input[type=password]:focus,
            input[type=password]:hover,
            input[type=search]:focus,
            input[type=search]:hover,
            input[type=text]:focus,
            input[type=text]:hover,
            input[type=url]:focus,
            input[type=url]:hover,
            textarea:focus,
            textarea:hover,
            .menu-drawer .menu .menu-expand:before', 'border-color', 0.2 ),


) );

add_color_rule( 'extra', '#333333', array(
    array( 'body', 'color', 'bg' ),
    array( '.content-posts article.sticky .entry', 'color', '#ffffff' ),
    array( 'blockquote', 'color', '#ffffff' ),
    array( '.showcase .item-inner p,
            .menu-drawer .site-description', 'color', '#ffffff' ),
) );

add_color_rule( 'extra', '#f2f2f2', array(
    array( '.showcase', 'border-color', 0.2 ),
) );

add_color_rule( 'extra', '#808080', array(
    array( '.menu-page-container,
            table td,
            .menu-drawer .menu ul ul,
            #footer .footer-wrap,
            .post-navigation .nav-links > div,
            #footer .jetpack-social-navigation:after,
            .avatar:before,
            .content-single-extras:before,
            .contributor .avatar-wrapper:before,
            .menu-drawer .menu:before,
            .menu-drawer .site-description:before,
            .post-navigation,
            .showcase .item-inner .entry-container:before,
            .taxonomies:before,
            .widget.widget_flickr #flickr_badge_wrapper,
            .wp-post-series-box,
            a.thumbnail:before,
            blockquote:before,
            hr:after,
            #footer .jetpack-social-navigation:before,
            .content-single-extras:after,
            .infinite-scroll #infinite-handle:before,
            .menu-drawer .menu:after,
            .menu-drawer .site-description:after,
            .taxonomies:after,
            hr,
            table th', 'border-color', 0.3 ),
) );

//Additional palettes

add_color_palette( array(
	'#e8ddcb',
	'#cdb380',
	'#036564',
	'#033649',
), 'Beige' );

add_color_palette( array(
	'#556270',
	'#4ecdc4',
	'#c7f464',
	'#5cb8f2',
), 'Bright' );

add_color_palette( array(
	'#1c211a',
	'#325b3d',
	'#a2ba62',
	'#d9d483',
), 'Forest Green' );

add_color_palette( array(
	'#fafcb3',
	'#fafcb3',
	'#f2c08b',
	'#f2c08b',
), 'Orange' );

add_color_palette( array(
	'#f4ede3',
	'#bae8f5',
	'#5f888c',
	'#002835',
), 'Light Blue' );

add_color_palette( array(
	'#715ba8',
	'#8e7195',
	'#af809c',
	'#d08fa3',
), 'Purple' );
