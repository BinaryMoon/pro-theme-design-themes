<?php
/**
 * WordPress.com specific functionality
 *
 * @package Label
 */

/**
 * Theme colours for wp.com custom functionality
 *
 * @global string $themecolors
 */
function label_theme_colors() {

	global $themecolors;

	/**
	 * Set a default theme color array for WP.com.
	 *
	 * @global array $themecolors
	 */
	if ( ! isset( $themecolors ) ) {
		$themecolors = array(
			'bg'     => 'f2f2f2',
			'border' => 'f2f2f2',
			'text'   => '333333',
			'link'   => '738290',
			'url'    => 'aaaaaa',
		);
	}

}

add_action( 'after_setup_theme', 'label_theme_colors' );


/**
 * Dequeue Google Fonts if Custom Fonts are being used instead.
 *
 * @param array $fonts Array of fonts being used in the theme.
 * @return type
 */
function label_dequeue_fonts( $fonts ) {

	if ( class_exists( 'TypekitData' ) && class_exists( 'CustomDesign' ) && CustomDesign::is_upgrade_active() ) {
	    $custom_fonts = TypekitData::get( 'families' );

		// Only unset if both headings and body-text are set, else it might still be needed.
		if ( $custom_fonts && $custom_fonts['headings']['id'] && $custom_fonts['body-text']['id'] ) {
			unset( $fonts['source-serif-pro'] );
		}
	}

	return $fonts;

}

add_action( 'label_fonts', 'label_dequeue_fonts', 11 );
