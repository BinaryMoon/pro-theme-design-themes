<?php
/**
 * Theme Customizer
 *
 * @package Label
 */

if ( ! class_exists( 'WP_Customize_Control' ) ) {

	return null;

}

/**
 * Theme customizer properties
 *
 * @param type $wp_customize WP Customize object.
 */
function label_customize_register( $wp_customize ) {

	/**
	 * Label theme options section.
	 */
	$wp_customize->add_section(
		'label_options',
		array(
			'title' => esc_html__( 'Theme Options', 'label' ),
		)
	);

	/**
	 * Setting to allow the featured image on single posts and pages to be hidden.
	 */
	$wp_customize->add_setting(
		'label_display_featured_image',
		array(
			'default' => true,
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'label_sanitize_checkboxes',
		)
	);

	$wp_customize->add_control(
		'label_display_featured_image',
		array(
			'label' => esc_html__( 'Display Featured Image on Posts and Pages', 'label' ),
			'section' => 'label_options',
			'type' => 'checkbox',
		)
	);

	/**
	 * Setting to control whether the slider autoplays or not.
	 */
	$wp_customize->add_setting(
		'label_autoplay_slider',
		array(
			'default' => false,
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'label_sanitize_checkboxes',
		)
	);

	$wp_customize->add_control(
		'label_autoplay_slider',
		array(
			'label' => esc_html__( 'Autoplay the Featured Content Slider', 'label' ),
			'section' => 'label_options',
			'type' => 'checkbox',
		)
	);

}

add_action( 'customize_register', 'label_customize_register' );


/**
 * Binds JS handlers to make the Customizer preview reload changes asynchronously.
 */
function label_customize_preview_js() {

	wp_enqueue_script( 'label-customize-preview', get_template_directory_uri() . '/assets/js/customizer-preview.js', array( 'customize-preview' ), '1.0', true );

}

add_action( 'customize_preview_init', 'label_customize_preview_js' );


/**
 * Sanitize checkbox
 *
 * @param type $setting Value to sanitize.
 * @return int|string
 */
function label_sanitize_checkboxes( $setting ) {

	if ( true === $setting ) {

		return true;

	} else {

		return false;

	}

}
