<?php
/**
 * Jetpack Compatibility File
 *
 * @link https://jetpack.com/
 *
 * @package Label
 */

/**
 * Add theme support for Jetpack
 *
 * @link: https://jetpack.me/support/infinite-scroll/
 */
function label_jetpack_init() {

	add_theme_support(
		'infinite-scroll',
		array(
			'container' => 'main-content',
			'footer_widgets' => 'sidebar-2',
			'footer' => 'footer-widgets',
			'posts_per_page' => 16,
			'render' => 'label_infinite_scroll_render',
			'wrapper' => false,
		)
	);

	add_theme_support(
		'featured-content',
		array(
			'featured_content_filter' => 'label_get_featured_posts',
			'max_posts' => 6,
			'post_types' => array( 'post', 'page', 'jetpack-portfolio' ),
		)
	);

	add_theme_support( 'jetpack-testimonial' );

	add_theme_support( 'jetpack-portfolio' );

	add_theme_support( 'jetpack-responsive-videos' );

	add_theme_support( 'jetpack-social-menu' );

	// Add supprt for content options.
	add_theme_support(
		'jetpack-content-options',
		array(
			'blog-display' => 'excerpt',			// The default setting of the theme: 'content' or 'excerpt'.
			'masonry'      => '#main-content',		// A CSS selector matching the elements that triggers a masonry refresh if the theme is using a masonry layout.
			'author-bio'   => true,				// Display or not the author bio: true or false.
			'post-details' => array(
				'stylesheet' => 'label-style',		// Name of the theme's stylesheet.
				'date'       => '.posted-on',		// A CSS selector matching the elements that display the post date.
				'categories' => '.tax-categories',	// A CSS selector matching the elements that display the post categories.
				'tags'       => '.tax-tags',		// A CSS selector matching the elements that display the post tags.
				'author'     => '.byline',			// A CSS selector matching the elements that display the post author.
			),
		)
	);

}

add_action( 'after_setup_theme', 'label_jetpack_init' );



/**
 * The function to display Author Bio in a theme.
 *
 * @return null
 */
function label_author_bio() {

	// If the theme doesn't support 'jetpack-content-options', don't continue.
	if ( ! current_theme_supports( 'jetpack-content-options' ) ) {
		return;
	}

	$options = get_theme_support( 'jetpack-content-options' );
	$author_bio = ( ! empty( $options[0]['author-bio'] ) ) ? $options[0]['author-bio'] : null;

	// If the theme doesn't support 'jetpack-content-options[ 'author-bio' ]', don't continue.
	if ( true !== $author_bio ) {
		return;
	}

	// If 'jetpack_content_author_bio' is false and we aren't in the customizer, don't continue.
	if ( ! get_option( 'jetpack_content_author_bio', 1 ) ) {
		return;
	}

	// If we aren't on a single post, don't continue.
	if ( ! is_single() ) {
		return;
	}

	// Don't display author if a password is required.
	if ( post_password_required() ) {
		return;
	}

	// Display the author bio.
	label_contributor();

}


/**
 * Render infinite scroll content using template parts
 */
function label_infinite_scroll_render() {

	while ( have_posts() ) {

		the_post();

		if ( is_post_type_archive( 'jetpack-testimonial' ) ) {

			get_template_part( 'parts/content', 'single-testimonial' );

		} else {

			get_template_part( 'parts/content', 'format-' . get_post_format() );

		}
	}

}


/**
 * Get featured posts using Jetpack Featured content
 *
 * @return array List of featured posts.
 */
function label_get_featured_posts() {

	return apply_filters( 'label_get_featured_posts', array() );

}


/**
 * Check if Jetpack Featured Content has any featured posts available
 *
 * @param integer $minimum Minimum number of posts to display in the featured post area.
 * @return boolean True if has featured posts, otherwise false.
 */
function label_has_featured_posts( $minimum = 1 ) {

	if ( ! is_front_page() ) {
		return false;
	}

	if ( is_paged() ) {
		return false;
	}

	$minimum = absint( $minimum );
	$featured_posts = apply_filters( 'label_get_featured_posts', array() );

	if ( ! is_array( $featured_posts ) ) {
		return false;
	}

	if ( $minimum > count( $featured_posts ) ) {
		return false;
	}

	return true;

}


/**
 * Change default jetpack infinite scroll settings
 *
 * @param array $settings Default infinite scroll settings.
 * @return array Modified infinite scroll settings.
 */
function label_infinite_scroll_js_settings( $settings ) {

	$settings['text'] = esc_html__( 'Load More', 'label' );

	return $settings;

}

add_filter( 'infinite_scroll_js_settings', 'label_infinite_scroll_js_settings' );


/**
 * Get Jetpack Testimonials Title
 */
function label_testimonials_title() {

	$jetpack_options = get_theme_mod( 'jetpack_testimonials' );

	if ( ! empty( $jetpack_options['page-title'] ) ) {
		echo esc_html( $jetpack_options['page-title'] );
	} else {
		esc_html_e( 'Testimonials', 'label' );
	}

}


/**
 * Retrieve and format jetpack testimonials description as set in theme customiser
 *
 * @param string $before html to display before testimonials description.
 * @param string $after html to display after testimonials description.
 * @return boolean|string Testimonials description, or false if no description exists.
 */
function label_testimonials_description( $before = '', $after = '' ) {

	$jetpack_options = get_theme_mod( 'jetpack_testimonials' );
	$content = '';

	if ( ! empty( $jetpack_options['page-content'] ) ) {
		$content = $jetpack_options['page-content'];
		$content = addslashes( $content );
		$content = wp_kses_post( $content );
		$content = stripslashes( $content );
		$content = wptexturize( $content );
		$content = convert_smilies( $content );
		$content = convert_chars( $content );
	}

	if ( $content ) {
		echo $before . $content . $after;
	}

	return false;

}


/**
 * Get Jetpack Testimonials Image
 *
 * @return string Testimonials image.
 */
function label_testimonials_image() {

	$jetpack_options = get_theme_mod( 'jetpack_testimonials' );
	$image = '';

	if ( '' !== $jetpack_options['featured-image'] ) {

		$image = wp_get_attachment_image( (int) $jetpack_options['featured-image'], 'label-header' );

	}

	return $image;

}


/**
 * Flush rewrite rules for CPT on setup and switch
 */
function label_flush_rewrite_rules() {

	flush_rewrite_rules();

}

add_action( 'after_switch_theme', 'label_flush_rewrite_rules' );


/**
 * Add breadcrumbs to a page (not blog post)
 */
function label_breadcrumbs() {

	if ( function_exists( 'jetpack_breadcrumbs' ) ) {

		jetpack_breadcrumbs();

	}

}


/**
 * Display social links using a custom menu
 */
function label_social_links() {

	if ( function_exists( 'jetpack_social_menu' ) ) {

		jetpack_social_menu();

	}

}


/**
 * Remove styles for contact form
 */
function label_remove_jetpack_stylesheets() {

	// Remove contact form styles.
	wp_dequeue_style( 'grunion.css' );

	// Remove infinite scroll styles.
	wp_dequeue_style( 'the-neverending-homepage' );

	// Remove related posts styles.
	wp_dequeue_style( 'jetpack_related-posts' );

}

add_action( 'wp_enqueue_scripts', 'label_remove_jetpack_stylesheets', 100 );


/**
 * Stop Jetpack from concatenating CSS.
 * We dequeue a number of the Jetpack styles so this stops them from being loaded
 */
add_filter( 'jetpack_implode_frontend_css', '__return_false' );


/**
 * Use the Jetpack Video Embed HTML to make sure the video post types are responsive
 * Has a simple fallback in case Jetpack is not available.
 *
 * @param string $html Video html.
 * @return string html wrapper with the video wrapper.
 */
function label_video_wrapper( $html ) {

	if ( function_exists( 'jetpack_responsive_videos_embed_html' ) ) {

		return jetpack_responsive_videos_embed_html( $html );

	} else {

		return '<div class="jetpack-video-wrapper">' . $html . '</div>';

	}

}


/**
 * Change the size of the Related Posts thumbnail images
 *
 * @param array $thumbnail_size Default thumbnail properties.
 * @return array
 */
function label_related_posts_thumbnail_size( $thumbnail_size ) {

	$thumbnail_size['width'] = 500;
	$thumbnail_size['height'] = 330;

	return $thumbnail_size;

}

add_filter( 'jetpack_relatedposts_filter_thumbnail_size', 'label_related_posts_thumbnail_size' );


/**
 * Change the number of related posts
 *
 * @param array $options Related posts options.
 * @return array
 */
function label_related_posts_quantity( $options ) {

	$options['size'] = 4;

	return $options;

}

add_filter( 'jetpack_relatedposts_filter_options', 'label_related_posts_quantity' );
