<?php
/**
 * Comments template.
 * Displays the comments, and the comment form.
 *
 * @package Label
 */

	if ( post_password_required() ) {
		return;
	}
?>

	<section class="content-comments">

<?php
	if ( have_comments() ) {
?>
		<h2 id="comments" class="comments-title">
<?php
		printf(
			esc_html( _nx( 'One thought on &ldquo;%2$s&rdquo;', '%1$s thoughts on &ldquo;%2$s&rdquo;', get_comments_number(), 'comments title', 'label' ) ),
			(int) number_format_i18n( get_comments_number() ),
			'<span>' . get_the_title() . '</span>'
		);
?>
			<a href="#respond" class="scroll-to">
				<span class="screen-reader-text"><?php esc_html_e( 'Leave a comment', 'label' ); ?></span>
				<?php esc_html_e( '&rsaquo;', 'label' ); ?>
			</a>
		</h2>

		<ol class="comment-list" id="singlecomments">
<?php
		wp_list_comments(
			array(
				'avatar_size' => 80,
				'short_ping' => true,
				'reply_text' => label_svg( 'reply', false ) . '<span class="screen-reader-text">' . esc_html__( 'Reply', 'label' ) . '</span>',
			)
		);
?>
		</ol>
<?php
		the_comments_navigation();

	}

	if ( 'open' === $post->comment_status ) {

		comment_form(
			array(
				'title_reply_before' => '<h2 class="comment-reply-title">',
				'title_reply_after'  => '</h2>',
				'cancel_reply_before' => '',
				'cancel_reply_after' => '',
				'cancel_reply_link' => label_svg( 'close', false ) . '<span class="screen-reader-text">' . esc_html__( 'Cancel Reply', 'label' ) . '</span>',
			)
		);

	}
?>

		<div class="user-icon-container">
			<?php label_svg( 'user' ); ?>
		</div>
	</section>
