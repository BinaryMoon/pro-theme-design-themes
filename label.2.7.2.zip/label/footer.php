<?php
/**
 * Footer Template
 *
 * @package Label
 */

?>

	</div>

	<footer role="contentinfo" id="footer">

<?php
	get_sidebar( 'footer' );

	label_social_links();

	/**
	 * Check to see if a custom credits option is set.
	 * If custom credits are set then the filter should output the credits and
	 * return a non false value. This will hide the default footer credits.
	 */
	if ( false === apply_filters( 'label_credits', false ) ) {

?>

		<section class="footer-wrap">
<?php
		if ( function_exists( 'the_privacy_policy_link' ) ) {
			the_privacy_policy_link( '', '<span class="sep"> | </span>' );
		}
?>
			<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'label' ) ); ?>" title="<?php esc_attr_e( 'A Semantic Personal Publishing Platform', 'label' ); ?>" rel="generator"><?php printf( esc_html__( 'Proudly powered by %s', 'label' ), 'WordPress' ); ?></a>
			<span class="sep"> | </span>
			<?php printf( esc_html__( 'Theme: %1$s by %2$s.', 'label' ), 'Label', '<a href="https://prothemedesign.com/" rel="designer">Pro Theme Design</a>' ); ?>
		</section>

<?php

	}

?>

	</footer>

</div>

<?php

	// Slide out menu.
	get_template_part( 'parts/slide-out-sidebar' );

	wp_footer();

?>

</body>
</html>
