<?php
/**
 * Template Name: Child Page Grid
 *
 * @package Label
 */

	get_header();

	get_template_part( 'parts/featured-content' );
?>

	<main role="main">

		<div class="main-content content-single">

<?php
	if ( have_posts() ) {

		while ( have_posts() ) {

			the_post();

			get_template_part( 'parts/content-single', get_post_type() );

		}
	}
?>

		</div>

<?php

	// List child pages.
	$child_pages = label_child_pages();

	if ( $child_pages->have_posts() ) {
?>

		<section class="entry-children content-single-extras">

<?php
		while ( $child_pages->have_posts() ) {

			$child_pages->the_post();

			get_template_part( 'parts/content-child-page' );

		}
?>

		</section>

<?php
	}

	wp_reset_postdata();
?>

	</main>

<?php
	get_footer();
