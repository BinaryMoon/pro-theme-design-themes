<?php
/**
 * Full width page template
 * Template Name: Full Width
 *
 * @package Label
 */

	get_header();
?>

	<main role="main" class="full-width">

		<div class="main-content content-single">

<?php
	if ( have_posts() ) {

		while ( have_posts() ) {

			the_post();

			get_template_part( 'parts/content-single', get_post_type() );

		}
	}
?>

		</div>

	</main>

<?php
	get_footer();
