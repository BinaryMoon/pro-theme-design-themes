<?php
/**
 * Generic search form template
 *
 * @package Label
 */

?>
<form method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>" role="search">

	<label>
		<span class="screen-reader-text"><?php esc_html_e( 'Search', 'label' ); ?></span>
		<input type="search" value="<?php echo esc_attr( get_search_query() ); ?>" name="s" class="search-field text" placeholder="<?php echo esc_attr_x( 'Search...', 'search input placeholder text', 'label' ); ?>" />
	</label>

	<button class="search-submit"><?php label_svg( 'search' ); ?><span class="screen-reader-text"><?php echo esc_html__( 'Search', 'label' ); ?></span></button>

</form>
