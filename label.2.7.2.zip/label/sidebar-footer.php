<?php
/**
 * Footer Sidebar template
 *
 * @package Label
 */

	if ( is_active_sidebar( 'sidebar-2' ) ) {
?>

<!-- Sidebar Footer (2) -->

<div class="container">

	<aside class="footer-widgets sidebar-footer sidebar" role="complementary">

<?php
	dynamic_sidebar( 'sidebar-2' );
?>

	</aside>

</div>

<?php
	}
