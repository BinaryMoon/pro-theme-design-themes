<?php
/**
 * Sidebar template
 *
 * @package Label
 */

	// Using a page template so let's skip the sidebar.
	if ( strlen( get_page_template() ) > 0 ) {
		return;
	}

	if ( is_singular() && is_active_sidebar( 'sidebar-1' ) ) {
?>

<!-- Sidebar Main (1) -->

<aside class="sidebar sidebar-main" role="complementary">

<?php
	do_action( 'before_sidebar' );
	dynamic_sidebar( 'sidebar-1' );
?>

</aside>

<?php
	}
