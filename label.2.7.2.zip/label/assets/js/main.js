/**
 * main.js v1
 * Created by Ben Gillbanks <https://prothemedesign.com/>
 * Available under GPL2 license
 */
/* global site_settings, wp */

; ( function( $ ) {

	var $grid = null;

	// js mobile detection

	var is_touch_device = function() {

		return ( ( 'ontouchstart' in window ) || ( navigator.MaxTouchPoints > 0 ) || ( navigator.msMaxTouchPoints > 0 ) );

	};


	// smooth scroll to # anchor

	var scroll_to_hash = function( e ) {

		var $target = $( e.hash );

		if ( $target.length ) {
			var targetOffset = $target.offset().top - parseInt( $( 'html' ).css( 'margin-top' ) );
			$( 'html,body' ).animate( { scrollTop: targetOffset }, 750 );
			focus_element( e.hash );
		}

		return false;

	};


	// set an elements focus
	// if required sets a tabindex for elements that can't normally be focused

	var focus_element = function( id ) {

		var element = document.getElementById( id.replace( '#', '' ) );

		if ( element ) {

			if ( !( /^(?:a|select|input|button|textarea)$/i.test( element.tagName ) ) ) {
				element.tabIndex = -1;
			}

			element.focus();
		}

	};


	// do all the stuffs

	$( document ).ready( function() {

		// Set default heights for social media widgets

		// Twitter
		$( 'a.twitter-timeline, iframe.twitter-timeline' ).each(
			function() {

				var thisHeight = $( this ).height();
				if ( thisHeight > 0 ) {
					$( this ).parent().css(
						{
							'min-height': thisHeight + 'px',
							'display': 'block'
						}
					);
				}

			}
		);

		// Facebook
		$( '.fb-page' ).each(
			function() {

				var $set_height = $( this ).data( 'height' );
				var $show_facepile = $( this ).data( 'show-facepile' );
				var $show_posts = $( this ).data( 'show-posts' ); // AKA stream
				var $min_height = $set_height; // set the default 'min-height'

				// These values are defaults from the FB widget.
				var $no_posts_no_faces = 130;
				var $no_posts = 220;

				if ( $show_posts ) {

					// Showing posts; may also be showing faces and/or cover - the latter doesn't affect the height at all.
					$min_height = $set_height;

				} else if ( $show_facepile ) {

					// Showing facepile with or without cover image - both would be same height.
					// If the user selected height is lower than the no_posts height, we'll use that instead
					$min_height = ( $set_height < $no_posts ) ? $set_height : $no_posts;

				} else {

					// Either just showing cover, or nothing is selected (both are same height).
					// If the user selected height is lower than the no_posts_no_faces height, we'll use that instead
					$min_height = ( $set_height < $no_posts_no_faces ) ? $set_height : $no_posts_no_faces;

				}

				// apply min-height to .fb-page container
				$( this ).css( 'min-height', $min_height + 'px' );
				$grid.masonry( 'layout' );

			}
		);


		// attachment page navigation

		if ( $( 'body' ).hasClass( 'attachment' ) ) {

			$( document ).keydown( function( e ) {

				if ( $( 'textarea, input' ).is( ':focus' ) ) {
					return;
				}

				var url = false;

				switch ( e.which ) {

					// left arrow key (previous attachment)
					case 37:
						url = $( '.image-previous a' ).attr( 'href' );
						break;

					// right arrow key (next attachment)
					case 39:
						url = $( '.image-next a' ).attr( 'href' );
						break;

				}

				if ( url.length ) {
					window.location = url;
				}

			} );

		}


		// masonry layout

		$( window ).on(
			'load',
			function() {

				if ( typeof $.fn.masonry === 'function' ) {

					// masonry grid sizer
					$( '#main-content, .sidebar-footer' ).prepend( '<div class="grid-sizer"></div>' );

					$grid = $( '#main-content' ).masonry(
						{
							itemSelector: 'article',
							columnWidth: '.grid-sizer',
							gutter: 0,
							isOriginLeft: !$( 'body' ).is( '.rtl' ),
							percentPosition: true
						}
					);

					$grid.imagesLoaded(
						function() {

							$grid.masonry( 'layout' );
							$grid.children().addClass( 'post-loaded' );

						}
					);

					$( 'body' ).on(
						'post-load jetpack-lazy-loaded-image',
						function() {

							// Make sure we are viewing a page that uses Masonry.
							if ( 'undefined' === typeof ( $grid ) || 0 === $grid.length ) {
								return;
							}

							var $new_articles = $( '#main-content' ).children().not( '.post-loaded, .infinite-loader' ).addClass( 'post-loaded' );

							$grid.masonry( 'appended', $new_articles );
							$grid.masonry( 'layout' );

							$grid.imagesLoaded(
								function() {

									$grid.masonry( 'layout' );

								}
							);

						}
					);


					// Add masonry reposition event after 600 milliseconds.
					// This accounts for Jetpacks responsive videos resizing 500 ms
					// after a resize event.

					var resize_orient = null;

					$( window ).on(
						'orientationchange resize jetpack-lazy-loaded-image',
						function() {

							clearTimeout( resize_orient );

							resize_orient = setTimeout(
								function() {
									$grid.masonry( 'layout' );
								},
								600
							);

						}
					);

					// footer widgets

					var $footer_widgets = null;

					$( '.sidebar-footer' ).imagesLoaded(
						function() {

							$footer_widgets = $( '.sidebar-footer' ).masonry(
								{
									itemSelector: '.widget',
									columnWidth: '.grid-sizer',
									gutter: 0,
									isOriginLeft: !$( 'body' ).is( '.rtl' ),
									percentPosition: true
								}
							);

						}
					);

					// Reflow widgets after 2 seconds to ensure the correct position
					// due to dynamic widgets like facebook and twitter loading.
					setTimeout(
						function() {
							$footer_widgets.masonry( 'layout' );
						},
						2000
					);

					// Reflow Footer Widgets if changed in the Customizer.
					if ( 'undefined' !== typeof wp && wp.customize && wp.customize.selectiveRefresh ) {

						wp.customize.selectiveRefresh.bind( 'sidebar-updated', function( sidebarPartial ) {
							if ( 'sidebar-2' === sidebarPartial.sidebarId ) {
								$footer_widgets.masonry( 'reloadItems' );
								$footer_widgets.masonry( 'layout' );
							}
						} );

					}

					// testimonials
					$( 'body.archive .testimonials' ).imagesLoaded(
						function() {

							$( 'body.archive .testimonials' ).masonry(
								{
									itemSelector: '.testimonial',
									gutter: 0,
									isOriginLeft: !$( 'body' ).is( '.rtl' )
								}
							);

						}
					);

				}

			}
		);


		// featured content slides

		if ( typeof $.fn.elementalSlides === 'function' ) {

			$( '.showcase' ).elementalSlides(
				{
					'nav_arrows': true,
					'autoplay': parseInt( site_settings.slider.autoplay )
				}
			);

		}


		// menu toggle

		$( '.menu-toggle' ).on(
			'click',
			function() {

				$( 'body, html' ).toggleClass( 'menu-on' );

				// If menu is displayed then focus it.
				if ( $( 'body' ).hasClass( 'menu-on' ) ) {

					focus_element( 'menu-drawer' );

				}

			}
		);


		// dropdown menu touch screen improvements

		$( '.menu' ).find( 'a' ).on( 'focus blur', function() {

			$( this ).parents().toggleClass( 'focus' );

		} );


		// add href to links without so that dropdowns work properly on touch devices.

		$( '.menu' ).find( 'a:not([href])' ).on(
			'click',
			function( e ) {

				e.preventDefault();

			}
		).attr( 'href', '#' ).addClass( 'menu-no-href' );


		// smooth scroll to element

		$( '.scroll-to' ).on(
			'click',
			function() {

				return scroll_to_hash( this );

			}
		);


		// Expandable Menus

		var expand_link = $( '<button class="menu-expand"><span class="screen-reader-text">' + site_settings.i18n.expand_menu + '</span></button>' );

		$( '.menu-drawer .menu ul.sub-menu' ).before( expand_link );

		$( '.menu-drawer .menu .menu-item-has-children' ).find( 'a:first' ).addClass( 'menu-has-children' );

		$( '.menu-expand, a.menu-has-children.menu-no-href' ).on(
			'click',
			function() {

				var $this = $( this );
				var $child = $this.parent().find( 'ul:first' );
				var $toggle = $this;
				var visible = $child.is( ':visible' );

				if ( $this.hasClass( 'menu-has-children' ) ) {
					$toggle = $this.parent().find( '.menu-expand:first' );
				}

				if ( visible ) {
					$child.slideUp( 250 );
					$toggle.removeClass( 'display' );
				} else {
					$child.slideDown( 250 );
					$toggle.addClass( 'display' );
				}

				return false;

			}
		);



		// mobile device detection

		$( 'body' ).addClass( is_touch_device() ? 'device-touch' : 'device-click' );


		// wrap select boxes

		$( 'select' ).wrap( '<div class="form-select"></div>' );


		// add author icon to comment author titles

		var user_icon = $( '.user-icon-container' ).html();
		$( '.bypostauthor > article .fn' ).append( user_icon );


		// skip link fix
		// https://github.com/Automattic/_s/blob/master/js/skip-link-focus-fix.js

		var isWebkit = navigator.userAgent.toLowerCase().indexOf( 'webkit' ) > -1,
			isOpera = navigator.userAgent.toLowerCase().indexOf( 'opera' ) > -1,
			isIe = navigator.userAgent.toLowerCase().indexOf( 'msie' ) > -1;

		if ( ( isWebkit || isOpera || isIe ) && document.getElementById && window.addEventListener ) {
			window.addEventListener( 'hashchange', function() {

				var id = location.hash.substring( 1 );

				if ( !( /^[A-z0-9_-]+$/.test( id ) ) ) {
					return;
				}

				focus_element( id );

			}, false );
		}

	} );

} )( jQuery );
