<?php
/**
 * Single post content
 *
 * @package Beacon
 */

?>
<div class="page-content">
	<section class="row clearfix article">
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<?php
	the_title( '<h1 class="entry-title">', '</h1>' );
?>
			<div class="meta-stuff">
				<?php get_template_part( 'inc/post-meta' );?>
			</div>

			<section class="entry entry-single">
<?php
	the_content();

	beacon_author_bio();

	wp_link_pages(
		array(
			'before' => '<div class="archive-pagination">' . __( 'Pages: ', 'beacon' ),
			'after'  => '</div>',
			'link_before' => '<span class="page">',
			'link_after'  => '</span>',
		)
	);

	get_template_part( 'inc/post-terms' );

	edit_post_link();
?>
			</section>

			<?php get_sidebar(); ?>

		</article>

	</section>

</div>

<nav class="postnav">
	<h1 class="screen-reader"><?php esc_html_e( 'Post navigation', 'beacon' ); ?></h1>
<?php
	previous_post_link( '<div class="left prev">' . __( '<h5>&lsaquo; Older</h5> %link', 'beacon' ) . '</div>', '<span class="title">%title</span>' );
	next_post_link( '<div class="next right">' . __( '<h5>Newer &rsaquo; </h5> %link', 'beacon' ) . '</div>', '<span class="title">%title</span>' );
?>
</nav>
