<?php
/**
 * Post meta data
 *
 * @package Beacon
 */

?>
	<div class="post-meta-data">

		<span class="author vcard">
			<span class="genericon genericon-user"></span>
			<a class="url grey fn n" href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" title="<?php echo esc_attr( sprintf( __( 'View all posts by %s', 'beacon' ), get_the_author() ) ); ?>" rel="author">
				<?php echo get_the_author(); ?>
			</a>
		</span>

		<span class="time-wrap">
			<span class="genericon genericon-month"></span>
			<a href="<?php echo esc_url( get_permalink() ); ?>" title="<?php echo esc_attr( get_the_time() ); ?>" rel="bookmark" class="grey">
				<time class="entry-date" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
					<?php echo beacon_human_time_diff(); ?>
				</time>
			</a>
		</span>

<?php
	if ( ! post_password_required() && ( comments_open() || '0' != get_comments_number() ) ) {
?>
	<span class="commentcount"><span class="genericon genericon-chat"></span> <?php comments_popup_link( __( 'Leave a Comment', 'beacon' ), __( '1 Comment', 'beacon' ), __( '% Comments', 'beacon' ) ); ?></span>
<?php
	}
?>

	</div>
