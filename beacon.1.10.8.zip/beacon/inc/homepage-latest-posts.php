<?php
/**
 * Homepage Latest Posts
 *
 * @package Beacon
 */

	if ( have_posts() ) {

?>
<section id="main-content" class="summary-latest summary-main">
<?php

		$beacon_post_count = 0;
		while ( have_posts() ) {
			the_post();
			$beacon_post_count ++;
			if ( 1 === $beacon_post_count ) {
				get_template_part( 'content-feature' );
			} else {
				get_template_part( 'content', get_post_format() );
			}
		}

?>
</section>
<?php

	} else {

		get_template_part( 'content-empty' );

	}

	wp_reset_postdata();
