<?php
/* Custom Colors: Beacon */

//Background
add_color_rule( 'bg', '#f4f5f6', array(
	array( '.content-comments, body.home, .main-tabs li.active, .main-tabs li.active:hover, body.archive, body.search', 'background-color' ),
) );

add_color_rule( 'txt', '#bf593c', array(
	array( 'a, a:visited, a.dark:hover, a.dark:active', 'color', 'bg' ),

	array( 'table a, table a:visited, .tab-home .beacon-archive-featured a, .tab-home .beacon-archive-featured a:visited', 'color', '#ffffff' ),

	array( 'ol.commentlist li.comment.bypostauthor > article, ol.commentlist li.trackback.bypostauthor > article, ol.commentlist li.pingback.bypostauthor > article', 'border-left-color' ),
	array(
		'.masthead .menu li.current_page_item > a, input[type=submit], .masthead .menu li.current-menu-item > a',
		'background-color'
	),
	array( '.main .contributor a.contributor-posts-link', 'background-color' ),
	array( '.main .contributor a.contributor-posts-link:hover, input[type=submit]:hover', 'background-color', '-0.5' ),
	array( '.main .contributor a.contributor-posts-link', 'border-color' ),
	array( '.main .contributor a.contributor-posts-link:hover', 'border-color', '-0.5' ),
),
__( 'Links' ) );

add_color_rule( 'link', '#e1552d', array(
	array( 'a:hover, a:active', 'color', 'bg' ),
	array( 'footer a:hover, footer a:active', 'color', 'bg' ),

	array( 'table a:active, table a:hover, .tab-home .beacon-archive-featured a:hover, .tab-home .beacon-archive-featured a:active, .summary-main .post-summary-1 a.dark:hover, .summary-main .post-summary-1 a.dark:active', 'color', '#ffffff' ),
),
__( 'Link Hover' ) );

add_color_rule( 'fg1', '#ffffff', array(

) );

add_color_rule( 'fg2', '#ffffff', array(

) );

add_color_rule(
	'extra',
	'#ffffff',
	array(
		array(
			'input[type=submit], input[type=submit]:hover, .masthead .menu li.current_page_item > a, .masthead .menu li.current-menu-item > a, .main .contributor a.contributor-posts-link, .main .contributor a.contributor-posts-link:hover',
			'color',
			'txt'
		),
	)
);

add_color_rule( 'extra', '#bed4df', array(
	array( 'footer', 'background-color', 0.1 ),
	array( '.page-title', 'background-color', 0.1 ),
) );

add_color_rule( 'extra', '#5b768a', array(
	array( 'footer a, footer a:visited', 'color', 'bg' ),
) );

add_color_rule( 'extra', '#292b2c', array(
	array( '.dark, .dark:visited, .commentcount a, .commentcount a:visited, .main-tabs li.active a, a.post-edit-link:before, .page-title span.genericon', 'color', 'bg' ),

	array( '.main .archive-pagination span.current', 'background-color', 0.3 ),
	array( '.sidebar .widget h3 span, .sidebar .widget h3.widgettitle:before', 'border-color', 0.3 ),

	array( 'a.post-edit-link:hover:before, .masthead .menu li ul li a, .masthead .menu li ul li a:visited, .masthead .menu li ul li a:hover, .masthead .menu li ul li a:active', 'color', '#ffffff' ),
) );

add_color_rule( 'extra', '#999999', array(
	array( 'blockquote p, .contact-form label span', 'color', 'bg' ),
) );

add_color_rule( 'extra', '#2d2d2d', array(
	array( 'body, caption', 'color', 'bg' ),

	array( 'table, td, th, ol.commentlist li.comment.bypostauthor > article, ol.commentlist li.trackback.bypostauthor > article, ol.commentlist li.pingback.bypostauthor > article, .tab-home .beacon-archive-featured', 'color', '#ffffff' ),
) );

add_color_rule( 'extra', '#b3b3b3', array(
	array( 'ol.commentlist li.comment .comment-meta .comment-metadata a, ol.commentlist li.trackback .comment-meta .comment-metadata a, ol.commentlist li.pingback .comment-meta .comment-metadata a', 'color', 'bg' ),
) );

add_color_rule( 'extra', '#d1d1d1', array(
	array( 'a.post-edit-link:hover', 'background-color', 0.3 ),
	array( 'table, td, th, .main .contributor-intro, a.post-edit-link, ol.commentlist li.comment, ol.commentlist li.trackback, ol.commentlist li.pingback, #respond, blockquote, .postnav, .postnav .left, .postnav, .sidebar .widget h3', 'border-color', 0.3 ),
) );

add_color_rule( 'extra', '#9e9e9e', array(
	array( '.grey, a.grey, a.grey:visited, .commentcount a, .commentcount a:visited, .main article .post-meta-data', 'color', 'bg' ),
) );

//Extra CSS
function beacon_extra_css() { ?>
	.main .contributor a.contributor-posts-link,
	.main .contributor a.contributor-posts-link:hover {
		background-image: none;
	}
<?php }
add_theme_support( 'custom_colors_extra_css', 'beacon_extra_css' );