<?php
/**
 * Homepage Most Popular posts
 * Uses jetpack stats to work out what is popular
 *
 * @package Beacon
 */

	$display_posts = false;

	// Quit early if the required function doesn't exist.
	if ( ! function_exists( 'stats_get_csv' ) ) {

		get_template_part( 'content-empty' );
		return;

	}

	$top_posts = stats_get_csv( 'postviews', 'days=7&limit=9' );

	// No posts to display so quit.
	if ( count( $top_posts ) <= 0 ) {

		get_template_part( 'content-empty' );
		return;

	}

	$popular_posts = array();

	foreach ( $top_posts as $p ) {
		$popular_posts[] = $p['post_id'];
	}

	$popular = new WP_Query(
		array(
			'post__in' => $popular_posts,
			'post_type' => array( 'post', 'attachment' ),
			'ignore_sticky_posts' => true,
			'post_status' => 'any',
			'orderby' => 'post__in',
		)
	);

	if ( $popular->have_posts() ) {

		$beacon_post_count = 0;
		while ( $popular->have_posts() ) {

			$popular->the_post();
			$beacon_post_count ++;
			if ( 1 === $beacon_post_count ) {
				get_template_part( 'content-feature' );
			} else {
				get_template_part( 'content', get_post_format() );
			}

		}

	} else {

		get_template_part( 'content-empty' );

	}

	wp_reset_postdata();
