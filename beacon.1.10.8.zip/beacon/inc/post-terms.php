<?php
/**
 * Post terms
 *
 * @package Beacon
 */

?>
		<div class="taxonomies">
<?php
	// Display categories (if there are any).
	/* translators: used between list items, there is a space after the comma */
	$categories_list = get_the_category_list( esc_html__( ', ', 'beacon' ) );
	if ( $categories_list ) {
?>
			<div class="tax-categories taxonomy grey">
				<span class="genericon genericon-category grey"></span> <?php echo $categories_list; // XSS ?>
			</div>
<?php
	}

	// Display tags (if there are any).
	if ( get_the_tags() ) {
		the_tags( '<div class="tax-tags"><span class="genericon genericon-tag grey"></span>  <span class="tax-tags taxonomy grey">', _x( ', ', 'Category/ Tag list seperator (includes a space after the comma)', 'beacon' ), '</span></div>' );
	}
?>
		</div>
