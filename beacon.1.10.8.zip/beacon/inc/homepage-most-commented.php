<?php
/**
 * Homepage Most Commented Posts Tab
 *
 * @package Beacon
 */

	$posts_per_page = 9;
	$posts_seen = array();

	$most_commented = new WP_Query(
		array(
			'ignore_sticky_posts' => true,
			'posts_per_page' => $posts_per_page,
			'orderby' => 'comment_count',
			'order' => 'DESC',
			'date_query' => array(
				array(
					'column' => 'post_date_gmt',
					'after' => '3 months ago',
				),
			),
		)
	);

	if ( $most_commented->have_posts() ) {

		while ( $most_commented->have_posts() ) {

			$most_commented->the_post();

			if ( 9 === $posts_per_page ) {
				get_template_part( 'content-feature' );
			} else {
				get_template_part( 'content', get_post_format() );
			}

			$posts_seen[] = get_the_ID();
			$posts_per_page --;

		}
	}

	wp_reset_postdata();

	// We've shown enough posts so lets quit.
	if ( $posts_per_page <= 0 ) {
		return;
	}

	// Fallback in case there's been no comments in the last 3 months.
	$most_commented = new WP_Query(
		array(
			'ignore_sticky_posts' => true,
			'posts_per_page' => $posts_per_page,
			'orderby' => 'comment_count',
			'order' => 'DESC',
			'post__not_in' => $posts_seen,
		)
	);

	if ( $most_commented->have_posts() ) {

		while ( $most_commented->have_posts() ) {
			$most_commented->the_post();
			if ( 9 === $posts_per_page ) {
				get_template_part( 'content-feature' );
			} else {
				get_template_part( 'content', get_post_format() );
			}

			$posts_per_page --;

		}
	} else {

		get_template_part( 'content-empty' );

	}

	wp_reset_postdata();
