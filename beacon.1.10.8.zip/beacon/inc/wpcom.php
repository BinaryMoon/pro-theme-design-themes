<?php
/**
 * WordPress.com specific functionality
 *
 * @package Beacon
 */


/**
 * theme colours for wp.com custom functionality
 *
 * @global string $themecolors
 */
function beacon_theme_colors() {

	global $themecolors;

	/**
	 * Set a default theme color array for WP.com.
	 *
	 * @global array $themecolors
	 */
	if ( ! isset( $themecolors ) ) {
		$themecolors = array(
			'bg'     => 'f4f5f6',
			'border' => 'bed4df',
			'text'   => '292b2c',
			'link'   => 'e1552d',
			'url'    => '696969',
		);
	}

}

add_action( 'after_setup_theme', 'beacon_theme_colors' );


/**
 * Dequeue Google Fonts if Custom Fonts are being used instead.
 */
function beacon_dequeue_fonts( $fonts ) {

	if ( class_exists( 'TypekitData' ) && class_exists( 'CustomDesign' ) && CustomDesign::is_upgrade_active() ) {
	    $custom_fonts = TypekitData::get( 'families' );

		if ( $custom_fonts && $custom_fonts['headings']['id'] ) {
			unset( $fonts['montserrat'] );
	    }

		if ( $custom_fonts && $custom_fonts['body-text']['id'] ) {
			unset( $fonts['source-sans'] );
		}
	}

	return $fonts;

}

add_action( 'beacon_fonts', 'beacon_dequeue_fonts', 11 );
