<?php
/**
 * Custom header codes
 *
 * @package Beacon
 */

/**
 * Custom header image
 */
function beacon_custom_header_support() {

	// Custom header image.
	$args = array(
		'default-text-color' => apply_filters( 'beacon_header_textcolor', 'ffffff' ),
		'random-default' => false,
		'width' => apply_filters( 'beacon_header_width', 1600 ),
		'height' => apply_filters( 'beacon_header_height', 250 ),
		'flex-height' => true,
		'header-text' => true,
		'uploads' => true,
		'wp-head-callback' => 'beacon_colour_styles',
		'admin-head-callback' => 'beacon_header_admin',
		'admin-preview-callback' => 'beacon_header_preview',
	);

	add_theme_support( 'custom-header', $args );

}

add_action( 'after_setup_theme', 'beacon_custom_header_support' );


/**
 * Print custom header styles
 *
 * @return array
 */
function beacon_colour_styles() {

?>
<style>
<?php
	if ( 'blank' === get_header_textcolor() ) {
?>
	.masthead .branding { display:none; }
<?php
	} else {
?>
	.masthead .branding h1.logo a,
	.masthead .branding h1.logo a:hover,
	.masthead .branding h2.description {
		color:#<?php echo get_header_textcolor(); ?>;
	}
<?php
	}

	// Second header for trending/ featured content area.
	$image_path = get_theme_mod( 'beacon_trending_background_image', '' );

	if ( $image_path ) {
?>
	.trending {
		background-image:url(<?php echo esc_url_raw( $image_path ); ?>);
	}
<?php
	}
?>
</style>
<?php

	return true;

}


/**
 * Preview header image in admin.
 */
function beacon_header_preview() {
?>
<div id="header-preview">
	<header class="masthead" role="banner">
		<div class="row clearfix">
			<div class="branding">
				<h1 class="logo">
					<a href="#" title="Home"><?php bloginfo( 'name' ); ?></a>
				</h1>
			</div>
		</div>
	</header>
<?php
	beacon_header();
?>
</div>
<?php
}


/**
 * Header admin css.
 */
function beacon_header_admin() {
?>
<link rel='stylesheet' id='beacon-slug-fonts-css'  href='https://fonts.googleapis.com/css?family=Montserrat%3A400%2C700%7CSource%2BSans%2BPro%3A400%2C700%2C400italic&#038;subset=latin%2Clatin-ext' type='text/css' media='all' />
<style type="text/css">
	#header-preview {
		background:#f5f5f5;
		border:1px solid #000;
	}
	#header-preview h1.logo {
		color:#fff;
		background:#2c3236;
		margin:0;
		font-family:'Montserrat',arial, sans-serif;
		font-size:14px;
		text-transform:uppercase;
		font-weight:normal;
		padding:15px;
	}
	#header-preview h1.logo a {
		color:#fff;
		text-decoration:none;
	}
	#header-preview a.header-image img {
		width:100%;
		height:auto;
		display:block;
	}
</style>
<?php

}
