<?php
/**
 * Homepage Magazine Style Category Summaries
 *
 * @package Beacon
 */

$categories = beacon_get_homepage_categories();

if ( $categories ) {

	foreach ( $categories as $category_id ) {

		$category = get_category( $category_id );

		if ( $category ) {
			$category_query = new WP_Query(
				array(
					'category__in' => array( $category_id ),
					'posts_per_page' => 5,
				)
			);

			if ( $category_query->have_posts() ) {
?>
<section class="summary-category summary-main">
	<h2><a href="<?php echo esc_url( get_category_link( $category_id ) ); ?>"><?php echo $category->name; ?> &rsaquo;</a></h2>
<?php
				while ( $category_query->have_posts() ) {
					$category_query->the_post();
					if ( 0 === $category_query->current_post ) {
						get_template_part( 'content-feature' );
					} else {
						get_template_part( 'content', get_post_format() );
					}
				}
?>
</section>
<?php
			}

			wp_reset_postdata();
		}
	}
}
