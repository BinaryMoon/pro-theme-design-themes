<?php
/**
 * Theme Customizer classes
 *
 * @package Beacon
 */

if ( ! class_exists( 'WP_Customize_Control' ) ) {
	return null;
}

/**
 * A reorderable list widget.
 */
class Beacon_DragDrop_List_Control extends WP_Customize_Control {

	/**
	 * Widget type - for use in javascript.
	 * @var string
	 */
	public $type = 'dragdrop-list';

	/**
	 * Construct control
	 *
	 * @param object $manager Customizer object.
	 * @param int    $id	  Widget ID.
	 * @param array  $args 	  Widget arguments.
	 */
	public function __construct( $manager, $id, $args = array() ) {
		parent::__construct( $manager, $id, $args );

		add_action( 'customize_controls_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
	}


	/**
	 * Display list of checkboxes for categories.
	 */
	 public function render_content() {

		// Displays checkbox heading.
		echo '<span class="customize-control-title">' . esc_html( $this->label ) . '</span>';

		$values = explode( ',', $this->value() );

		// Displays selected categories.
		echo '<ul class="beacon-sortable">';
		foreach ( get_categories() as $category ) {
			if ( in_array( $category->term_id, $values ) ) {
				echo '<li data-value="' . (int) $category->term_id . '">' . esc_html( $category->name ) . '</li>';
			}
		}
		echo '</ul>';

		// Displays selectable categories.
		echo '<select class="beacon-dragdrop-select">';
		echo '<option disabled selected value="default">' . esc_html__( 'Select a category to display +', 'beacon' ) . '</option>';
		foreach ( get_categories() as $category ) {
			if ( ! in_array( $category->term_id, $values ) ) {
				echo '<option value="' . (int) $category->term_id . '">' . esc_html( $category->name ) . '</option>';
			}
		}
		echo '</select>';

		// Hidden input field that stores the saved category list.
?>
		<input type="hidden" id="<?php echo esc_attr( $this->id ); ?>" class="beacon-hidden-categories" <?php $this->link(); ?> value="<?php echo esc_html( $this->value() ); ?>">
<?php
	}


	/**
	 * Enqueue javascript for customizer control.
	 */
	public function enqueue_scripts() {

		wp_enqueue_script( 'jquery-ui-sortable' );
		wp_enqueue_style( 'beacon-theme-customizer', get_template_directory_uri() . '/styles/css/customizer.css' );
		wp_enqueue_script( 'beacon-theme-customizer', get_template_directory_uri() . '/js/theme-customizer.js', array( 'jquery' ), '1.0', true );

	}
}
