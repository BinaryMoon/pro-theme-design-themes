<?php
/**
 * Jetpack Featured Content
 * See: http://jetpack.me/support/featured-content/
 *
 * @package Beacon
 */

	if ( beacon_has_featured_posts() ) {
		$featured_posts = beacon_get_featured_posts( 5 );
?>
	<ul class="blurbs row">
<?php
		foreach ( $featured_posts as $post ) {
			setup_postdata( $post );

			$thumbnail_size = 'beacon-archive-trending';
			$image = get_the_post_thumbnail( get_the_ID(), $thumbnail_size );

			// Placeholder.
			if ( ! $image ) {
				$image = get_stylesheet_directory_uri() . '/images/' . $thumbnail_size . '.png';
				$image = '<img src="' . esc_url( $image ) . '" alt="" />';
			}
?><li>
			<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
				<h3><?php the_title(); ?></h3>
				<?php echo $image; ?>
			</a>
		</li><?php
		}
?>
	</ul>
<?php
		wp_reset_postdata();
	}
