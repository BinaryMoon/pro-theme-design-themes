<?php
/**
 * Jetpack Compatibility File
 * See: http://jetpack.me/
 *
 * @package Beacon
 */

/**
 * Add theme support for Infinite Scroll.
 * See: http://jetpack.me/support/infinite-scroll/
 */
function beacon_jetpack_init() {

	add_theme_support(
		'infinite-scroll',
		array(
			'type' => 'click',
			'container' => 'main-content',
			'wrapper' => false,
		)
	);

	add_theme_support(
		'featured-content',
		array(
			'featured_content_filter' => 'beacon_get_featured_posts',
			'max_posts' => 5,
			'post_types' => array( 'post', 'page', 'jetpack-portfolio' ),
		)
	);

	add_theme_support( 'jetpack-responsive-videos' );

	add_theme_support(
		'site-logo',
		array(
			'size' => 'beacon-logo',
		)
	);

	add_theme_support(
		'jetpack-content-options',
		array(
			'author-bio'   => true,					// Display or not the author bio: true or false.
			'post-details' => array(
				'stylesheet' => 'beacon-style',		// Name of the theme's stylesheet.
				'date'       => '.post-meta-data .entry-date, .post-meta-data .time-wrap',		// A CSS selector matching the elements that display the post date.
				'categories' => '.tax-categories',	// A CSS selector matching the elements that display the post categories.
				'tags'       => '.tax-tags',		// A CSS selector matching the elements that display the post tags.
				'author'     => '.post-meta-data .author',	// A CSS selector matching the elements that display the post author.
			),
		)
	);

}

add_action( 'after_setup_theme', 'beacon_jetpack_init' );


/**
 * Display Content Options author bio.
 * Return early if Author Bio is not available.
 */
function beacon_author_bio() {

	if ( ! function_exists( 'jetpack_author_bio' ) ) {
		return;
	} else {
		jetpack_author_bio();
	}

}


/**
 * Get featured posts using Jetpack Featured content
 */
function beacon_get_featured_posts() {

	return apply_filters( 'beacon_get_featured_posts', array() );

}


/**
 * Check if Jetpack Featured Content has any featured posts available
 *
 * @param int $minimum Minimum number of posts to display.
 * @return boolean
 */
function beacon_has_featured_posts( $minimum = 1 ) {

	if ( ! is_home() && ! is_page() ) {
		return false;
	}

	if ( is_paged() ) {
		return false;
	}

	$minimum = absint( $minimum );
	$featured_posts = apply_filters( 'beacon_get_featured_posts', array() );

	if ( ! is_array( $featured_posts ) ) {
		return false;
	}

	if ( $minimum > count( $featured_posts ) ) {
		return false;
	}

	return true;

}


/**
 * Can Jetpack enable the auto loading infinite scroll.
 */
function beacon_can_infinite_scroll() {

	if ( function_exists( 'jetpack_is_mobile' ) && jetpack_is_mobile() ) {
		return true;
	}

	$homepage_categories = beacon_get_homepage_categories();
	if ( count( $homepage_categories ) > 0 ) {
		return true;
	}

	if ( is_active_sidebar( 'sidebar-2' ) ) {
		return true;
	}

	return false;

}
