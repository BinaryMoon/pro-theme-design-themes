<?php
/**
 * Theme Customizer
 *
 * @package Beacon
 */


/**
 * Theme customizer properties
 *
 * @param object $wp_customize WP Customize object.
 */
function beacon_customizer_settings( $wp_customize ) {

	// Beacon theme options section.
	$wp_customize->add_section(
		'beacon_options',
		array(
			'title' => esc_html__( 'Theme', 'beacon' ),
			'description' => esc_html__( 'Options for the Beacon theme.', 'beacon' ),
		)
	);

	$wp_customize->add_setting(
		'beacon_home_categories',
		array(
			'default' => '',
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'beacon_sanitize_categories',
		)
	);

	$wp_customize->add_control(
		new Beacon_DragDrop_List_Control(
			$wp_customize,
			'beacon_home_categories',
			array(
				'label' => esc_html__( 'Homepage Categories', 'beacon' ),
				'section' => 'beacon_options',
				'settings' => 'beacon_home_categories',
			)
		)
	);

	// Add trending header image.
	$wp_customize->add_setting(
		'beacon_trending_background_image',
		array(
			'default' => '',
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'esc_url_raw',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Image_Control(
			$wp_customize,
			'beacon_trending_background_image',
			array(
				'label' => esc_html__( 'Featured Content Background Image', 'beacon' ),
				'section' => 'beacon_options',
				'settings' => 'beacon_trending_background_image',
			)
		)
	);


	// Setting to edit the title for the Latest Posts tab.
	$wp_customize->add_setting(
		'beacon_tab_latest',
		array(
			'default' => esc_html__( 'Latest', 'beacon' ),
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'esc_html',
		)
	);

	$wp_customize->add_control(
		'beacon_tab_latest',
		array(
			'label' => esc_html__( 'Text for Latest Posts tab', 'beacon' ),
			'section' => 'beacon_options',
			'type' => 'text',
		)
	);


	// ---
	// Setting to edit the title for the Most Discussed Posts tab.
	$wp_customize->add_setting(
		'beacon_tab_most_discussed',
		array(
			'default' => esc_html__( 'Most Discussed', 'beacon' ),
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'esc_html',
		)
	);

	$wp_customize->add_control(
		'beacon_tab_most_discussed',
		array(
			'label' => esc_html__( 'Text for Most Discussed Posts tab', 'beacon' ),
			'section' => 'beacon_options',
			'type' => 'text',
		)
	);

	/**
	 * Setting to control whether the 'popular' tab displays on the hompage.
	 */

	// Make sure Jetpack stats are available else don't bother showing.
	if ( function_exists( 'stats_get_csv' ) ) {

		$wp_customize->add_setting(
			'beacon_display_popular_tab',
			array(
				'default' => true,
				'capability' => 'edit_theme_options',
				'sanitize_callback' => 'beacon_sanitize_checkboxes',
			)
		);

		$wp_customize->add_control(
			'beacon_display_popular_tab',
			array(
				'label' => esc_html__( 'Display Front Page Popular Posts Tab', 'beacon' ),
				'section' => 'beacon_options',
				'type' => 'checkbox',
			)
		);

	}

}

add_action( 'customize_register', 'beacon_customizer_settings' );


/**
 * Sanitize category list
 * list is comma separated
 * so loop through all categories and make sure they are ints then join them back together again
 *
 * @param string $setting Comma separated list of category ids to check.
 * @return string Clean comma separated list of category ids
 */
function beacon_sanitize_categories( $setting ) {

	$cats = explode( ',', $setting );
	$clean_cats = array();

	foreach ( $cats as $c ) {
		$c = (int) $c;

		if ( $c > 0 ) {
			$clean_cats[] = $c;
		}
	}

	return implode( ',', $clean_cats );

}


/**
 * Sanitize checkbox input
 *
 * @param boolean $setting Value to check and sanitize.
 * @return boolean
 */
function beacon_sanitize_checkboxes( $setting ) {

	return (bool) $setting;

}
