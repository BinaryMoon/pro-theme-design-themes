<?php
/**
 * Sidebar template
 *
 * @package Beacon
 */

	if ( is_active_sidebar( 'sidebar-1' ) && ! is_page_template( 'page-templates/full-width.php' ) ) {
?>
<div class="sidebar sidebar-main" role="complementary">
<?php
	do_action( 'before_sidebar' );
	dynamic_sidebar( 'sidebar-1' );
?>
</div>
<?php
	}
