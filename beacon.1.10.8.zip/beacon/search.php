<?php
/**
 * Search results template
 *
 * @package Beacon
 */

	get_header();
?>

	<header class="entry-archive-header page-title">
		<div class="row">
		<h1 class="entry-title entry-archive-title">
			<span class="genericon genericon-search"></span>
			<?php printf( __( 'Search results for &#8216;<em>%s</em>&#8217;', 'beacon' ), esc_html( get_search_query() ) ); ?>
		</h1>
	</header>

	<div class="row">
		<div id="main-content" class="main-content summary-main-content">
<?php
	if ( have_posts() ) {

		while ( have_posts() ) {

			the_post();
			get_template_part( 'content', get_post_format() );

		}

		beacon_numeric_pagination();

	} else {

		get_template_part( 'content-empty' );

	}

?>
		</div>
	</div>
<?php
	get_footer();
