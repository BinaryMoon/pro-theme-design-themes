<?php
/**
 * Index template
 *
 * @package Beacon
 */

	get_header(); ?>

	<div id="main-content" class="main-content row">
<?php
	if ( have_posts() ) {

		while ( have_posts() ) {
			the_post();

			get_template_part( 'content', get_post_format() );
		}
	} else {

		get_template_part( 'content-empty' );

	}

	beacon_numeric_pagination();
?>
	</div>
<?php
	get_footer();
