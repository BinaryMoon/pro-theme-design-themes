<?php
/**
 * Comments template.
 *
 * @package Beacon
 */

	if ( post_password_required() ) {
		return;
	}
?>
<section class="content-comments">
<?php
	if ( have_comments() ) {
?>
	<div class="row">
		<h3 id="comments">
<?php
		printf( _n( '1 Comment', '%1$s Comments', get_comments_number(), 'beacon' ), number_format_i18n( get_comments_number() ), '<span>' . get_the_title() . '</span>' );
?>
			<a href="#respond" title="<?php esc_attr_e( 'Leave a comment', 'beacon' ); ?>">&raquo;</a>
		</h3>
	</div>

	<ol class="commentlist" id="singlecomments">
<?php
		wp_list_comments(
			array(
				'avatar_size' => 48,
				'format' => 'html5',
				'short_ping' => true,
			)
		);
?>
	</ol>
<?php
		if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) {
?>
	<nav class="post-nav">
		<h1 class="screen-reader"><?php esc_html_e( 'Comment navigation', 'beacon' ); ?></h1>
		<div class="prev">
			<?php previous_comments_link( __( '<span>Older Comments</span>', 'beacon' ) ); ?>
		</div>
		<div class="next">
			<?php next_comments_link( __( '<span>Newer Comments</span>', 'beacon' ) ); ?>
		</div>
	</nav>
<?php
		}
	}
?>
	<div class="respond-wrapper">
<?php
	if ( 'open' === $post->comment_status ) {
		comment_form();
	}
?>
	</div>
</section>
