<?php
/**
 * Footer Template
 *
 * @package Beacon
 */
?>
	</div>
</div>

<footer class="site-footer" role="contentinfo" id="footer">
<?php
	if ( is_active_sidebar( 'sidebar-2' ) ) {
?>
	<div class="row foot-widgets clearfix">
		<aside class="footer-widgets sidebar-footer">
			<?php dynamic_sidebar( 'sidebar-2' ); ?>
		</aside>
	</div>
<?php
	}
?>

	<section class="footer-wrap">
		<div class="row">
<?php
	if ( function_exists( 'the_privacy_policy_link' ) ) {
		the_privacy_policy_link( '', '<span class="sep"> &bull; </span>' );
	}
?>
			<a href="http://wordpress.org/" title="<?php esc_attr_e( 'A Semantic Personal Publishing Platform', 'beacon' ); ?>" rel="generator"><?php printf( __( 'Proudly powered by %s', 'beacon' ), 'WordPress' ); ?></a>
			<span class="sep"> &bull; </span>
			<span class="theme-info"><?php printf( __( 'Theme: %1$s <span class="by">by</span> %2$s', 'beacon' ), 'Beacon', '<a href="https://prothemedesign.com/" rel="designer">Pro Theme Design</a>' ); ?></span>
		</div>
		<div class="row">
			<a href="#main-container"><?php esc_html_e( 'Top', 'beacon' ); ?></a>
		</div>
	</section>
</footer>

<?php wp_footer(); ?>

</body>
</html>
