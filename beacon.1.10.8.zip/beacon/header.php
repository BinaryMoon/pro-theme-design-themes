<?php
/**
 * Header Template
 *
 * @package Beacon
 */

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta http-equiv="Content-Type" content="<?php bloginfo( 'html_type' ); ?>; charset=<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div class="container hfeed" id="main-container">
	<a href="#main-content" class="screen-reader-shortcut"><?php esc_html_e( 'Skip to content', 'beacon' ); ?></a>
	<header class="masthead" role="banner">
		<div class="row clearfix">
			<div class="branding">
				<?php if ( function_exists( 'jetpack_the_site_logo' ) ) jetpack_the_site_logo(); ?>
				<h1 class="logo">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php esc_attr_e( 'Home', 'beacon' ); ?>">
						<?php bloginfo( 'name' ); ?>
					</a>
				</h1>
				<h2 class="site-desc">
					<?php bloginfo( 'description' ); ?>
				</h2>
			</div>
<?php
	// Social menu.
	if ( has_nav_menu( 'social_menu' ) ) {
?>
			<div class="menu-social-links">
<?php
	wp_nav_menu(
		array(
			'theme_location' => 'social_menu',
			'container' => 'social',
			'depth' => 1,
			'link_before' => '<span class="screen-reader">',
			'link_after' => '</span>',
			'fallback_cb' => '__return_false',
		)
	);
?>
			</div>
<?php
	}

	// Main menu.
	$menu = wp_nav_menu(
		array(
			'theme_location' => 'top_menu',
			'menu_id' => 'nav',
			'menu_class' => 'menu-wrap',
			'container' => '',
			'echo' => false,
		)
	);

	if ( $menu ) {
?>
			<nav class="menu" role="navigation">
				<h3 class="menu-toggle"><span class="genericon genericon-menu"></span><?php esc_html_e( 'Menu', 'beacon' ); ?></h3>
<?php
		echo $menu;
?>
			</nav>
<?php
	}
?>
		</div>
	</header>

	<div class="main clearfix">
<?php
	beacon_header();
?>
		<section class="trending">
			<div class="topics row clearfix">
				<?php beacon_top_categories(); ?>
			</div>
<?php
	get_template_part( 'inc/jetpack-featured-content' );

	if ( is_front_page() && ! is_page() ) {

		// Tab titles.
		$latest = get_theme_mod( 'beacon_tab_latest', esc_html__( 'Latest', 'beacon' ) );
		$most_discussed = get_theme_mod( 'beacon_tab_most_discussed', esc_html__( 'Most Discussed', 'beacon' ) );

?>
			<ul class="main-tabs clearfix">
				<li class="active tab-latest">
					<a href="#" data-tab="home"><?php echo esc_html( $latest ); ?></a>
				</li>
				<li class="tab-discussed">
					<a href="#" data-tab="comments"><?php echo esc_html( $most_discussed ); ?></a>
				</li>
<?php
		// Make sure Jetpack stats are available and the user has elected to
		// display the tab else don't bother showing.
		if ( beacon_display_popular_tab() ) {
?>
				<li class="tab-popular">
					<a href="#" data-tab="popular"><?php esc_html_e( 'Most Popular', 'beacon' ); ?></a>
				</li>
<?php
		}
?>
			</ul>
<?php
	}
?>
		</section>
<?php
	do_action( 'before' );
