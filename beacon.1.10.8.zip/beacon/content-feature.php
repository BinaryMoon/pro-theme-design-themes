<?php
/**
 * Generic content
 *
 * @package Beacon
 */

	$image = get_the_post_thumbnail( get_the_ID(), 'beacon-archive-featured' );

	if ( ! $image ) {
		$image = get_stylesheet_directory_uri() . '/images/beacon-archive-featured.png';
		$image = '<img src="' . esc_url( $image ) . '" alt="" />';
	}
?>
	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		<a href="<?php echo esc_url( get_permalink() ); ?>" class="thumb">
			<?php echo $image; ?>
		</a>
		<div class="details">
			<h3 class="entry-title">
				<a href="<?php the_permalink(); ?>" class="dark" rel="bookmark">
					<?php the_title(); ?>
				</a>
			</h3>
			<div class="excerpt">
				<a href="<?php the_permalink(); ?>" class="dark" rel="bookmark"><?php the_excerpt(); ?></a>
			</div>

			<?php get_template_part( 'inc/post-meta' ); ?>

		</div>
	</article>
