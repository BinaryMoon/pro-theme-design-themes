<?php
/**
 * No content
 *
 * @package Beacon
 */
?>
<article class="no-results not-found">
	<h1 class="entry-title"><?php _e( 'Nothing Found', 'beacon' ); ?></h1>

	<section class="entry">
<?php
	if ( is_home() && current_user_can( 'publish_posts' ) ) {
?>
		<p><?php printf( __( 'Ready to publish your first post? <a href="%1$s">Get started here</a>.', 'beacon' ), esc_url( admin_url( 'post-new.php' ) ) ); ?></p>
<?php
	} if ( is_search() ) {
?>
		<p><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'beacon' ); ?></p>
<?php
		get_search_form();
	} else {
?>
		<p><?php esc_html_e( 'It seems we can\'t find what you\'re looking for. Perhaps searching can help.', 'beacon' ); ?></p>
<?php
		get_search_form();
	}
?>
	</section>
</article>
