<?php
/**
 * Template Name: Contributor Page
 *
 * @package Beacon
 */

	get_header();

	if ( have_posts() ) {
?>
	<div class="main-content">
		<div class="page-content">
<?php
		while ( have_posts() ) {
			the_post();
?>
	<div class="page-title">
		<div class="row">
			<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
		</div>
	</div>
	<section class="row clearfix article">
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<section class="entry entry-single">
<?php
	the_content();

	get_template_part( 'content-contributors' );

	edit_post_link();

?>
			</section>

			<?php get_sidebar(); ?>

		</article>
	</section>
<?php
			if ( comments_open() || '0' != get_comments_number() ) {
				comments_template( '', true );
			}
		}
?>
		</div>
	</div>
<?php
	} else {
		get_template_part( 'content-empty' );
	}

	get_footer();
