=== Beacon ===

Contributors: binarymoon
Requires at least: 4.2
Tested up to: 4.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: blue, gray, red, one-column, two-columns, right-sidebar, responsive-layout, custom-background, custom-colors, custom-header, custom-menu, featured-images, featured-image-header, flexible-header, full-width-template, infinite-scroll, rtl-language-support, theme-options, translation-ready, blog, collaboration, food, gaming, magazine, music, news, sports, clean, contemporary, elegant, formal, industrial, modern, professional, site-logo

== Description ==

Beacon is a mobile-friendly showcase for viral content and community discussion.

[Theme documentation](https://prothemedesign.com/documentation/theme/beacon/)

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Beacon includes support for [Styleguide](https://wordpress.org/plugins/styleguide/) - a plugin that allows you to change fonts, and colours in WordPress themes.

Beacon includes support for most features in [Jetpack](https://wordpress.org/plugins/jetpack/), including Infinite Scroll, Featured Content, and Site Logo.

== Changelog ==

= 1.10.8 - 19th January 2021 =
* Improve mobile CSS.
* Fix issue with editor css on blocks like Verse, Code and any other blocks that use the `pre` element.
* Fix issue with alignleft and alignright on the front end.
* Make heading sizes consistent in the editor.

= 1.10.7 - 2nd January 2021 =
* Fix jQuery error since jquery migrate has been removed.

= 1.10.6 - 27th October 2020 =
* Add 'navigation-widgets' to supported html5 types.

= 1.10.5 - 5th October 2020 =
* Add support for wp_body_open

= 1.10.4 - 7th August 2020 =
* Improve rtl styles.
* Combine stylesheets (move responsive styles into main stylesheet).
* Change infinite scroll to always use 'click' mode since there's always content below the main posts.
* Tidy codes.
* Fix current menu item highlights.

= 1.10.3 - 9th July 2020 =
* Remove use of deprecated Jetpack function `is_ipad`.
* Add `beacon_tabs` action for users who want to add extra tabs through plugins (.org or business plan).
* Coding standards.

= 1.10.2 - 22nd April 2020 =
* Update site description styles.

= 1.10.1 - 4th April 2020 =
* Tweak button styles for consistency.

= 1.10 - 15th March 2020 =
* Update CSS gradient syntax to modern standards.
* Improve coding standards.
* Add support for Gutenberg.
* Tweak white space for improved clarity.
* Refer to footer as .site-footer to avoid clashing with plugins.

= 1.9.3 - 18th December 2019 =
* Improve layout of Jetpack recent comments widget.
* Add back to top link in footer.
* Add CSS based smooth scroll.

= 1.9.2 - 27th January 2019 =
* Make the popular posts tab display consistently with the other tabs.

= 1.9.1 - 17th October 2018 =
* Fix infinite scroll display.

= 1.9 - 10th October 2018 =
* Tweak page archive post listing layout to use flexbox. This allows for a more flexible layout with less hacks to make it work consistently.
* Make the search results and author page layouts design more consistent.
* Improve image attachment page layout.
* Increase the size of the featured images so they look better when sized responsively. Also reduces the number of external images required.
* Optimize png images for increased speed.
* Ensure category list does not show on single posts/ pages if there are none available.
* Add some nicer CSS animations on featured content titles.
* Increase allowed header image size to take into account larger screens.
* Make iframes and embeds scale more nicely.
* Improve rtl.css
* Fix browser prefixes.

= 1.8.1 - 9th October 2018 =
* Tweak trending topics so that it can display on all pages.

= 1.8 - 25th May 2018 =
* Add support for privacy policy link in the site footer.
* Fix display of the cookie consent checkbox in the comments form.

= 1.7.8 - 13th March 2018 =
* Make featured content show all posts on mobile views.
* Improve browser compatability for featured content.
* Change header profile to use https

= 1.7.7 - 19th February 2018 =
* Fix issue with top link of mobile menu being active when it is hidden.

= 1.7.6 - 17th February 2018 =
* Add CSS class to trending topics so that they can be more easily targeted with Custom CSS.
* Remove underlines from delete links in category customizer.
* Correct icons for Vimeo and Flickr in social menu.
* Format codes.

= 1.7.5 - 13th February 2018 =
* Improve support for pinterest in social menu
* Add support for Goodreads
* Improve css cross browser support

= 1.7.4 - 2nd January 2018 =
* Add css classes to homepage tabs to make it easier to target them with css.

= 1.7.3 - 28th September 2017 =
* Fix issues with responsive behaviour of default header menu (make the fallback page menu show and hide properly on small devices).

= 1.7.2 - 27th September 2017 =
* Ensure social links menu displays on small screen devices.

= 1.7.1 - 31st July 2017 =
* Tweak homepage responsive styles.

= 1.7 - 13th July 2017 =
* Remove include for inc/wpcom.php, since it's automatically included by WordPress.com sites

= 1.6 - 25th May 2017 =
* Fix style issues with the sharing options in the post summaries
* Add customizer option to hide popular tab (for non .com sites using Jetpack)
* Some extra escaping - just for fun (and security)
* Add support for WordPress custom logo (for self hosted sites)

= 1.5.2 - 24th April 2017 =
* Tweak default number of posts displayed on infinite scroll so that we don't have a weird space left

= 1.5.1 - 12th December 2016 =
* Improve rtl.css styles
* Tweak responsive styles
* Tidy codes some more

= 1.5 - 16th November 2016 =
* Add support for wordpress.com content options
* Set clearing on lists so that they don't wrap strangely in blog posts and pages
* Some code reformatting & escaping
* Standardize post meta display to prevent repeating code, and to simplify content options integration
* Tidy css

= 1.4.1 - 27th October 2016 =
* Add support for projects and pages in featured content.

= 1.4 - 15th September 2016 =
* Add customizer settings to change the text that appears on the latest, and most discussed tabs.

= 1.3.2 - 15th July 2016 =
* Remove gaps between featured content items to make sure they take up the correct amount of space
* Improve coding standards and improve security (escaping)
* Fix contributors template

= 1.3.1 =
* Correct localisation strings

= 1.3 =
* Move banner ad (word ads) position to a better location
* escape some translations

= 1.2 =
* Fix issue with image attachments
* Improve attachment page layout
* switch to add_theme_support( 'title-tag' );

= 1.1 =
* Make the archive pages and homepage layout match. This means the posts per page value set in the admin will produce consistent layouts across homepage and archives.

= 1.0 =
* Initial release

== Credits ==

* [Montserrat](https://www.google.com/fonts/specimen/Montserrat) Font from Google Fonts, licensed under [SIL Open Font License, 1.1](http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL)
* [Source Sans Pro](https://www.google.com/fonts/specimen/Source+Sans+Pro) Font from Google Fonts, licensed under [SIL Open Font License, 1.1](http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL)
* Genericons: font by Automattic (http://automattic.com/), licensed under [GPL2](https://www.gnu.org/licenses/gpl-2.0.html)
