<?php
/**
 * Author post listing
 *
 * @package Beacon
 */

	get_header();

	$user_id = get_query_var( 'author' );
?>
	<div class="page-title">
		<div class="row">
			<h1 class="entry-title entry-archive-title">
				<?php esc_html_e( 'Author Archives','beacon' ); ?>
			</h1>
		</div>
	</div>
	<div class="row">
		<div class="contributor">
			<?php echo get_avatar( get_the_author_meta( 'user_email', $user_id ), '80' ); ?>
			<h2><?php the_author_meta( 'display_name', $user_id ); ?></h2>
			<?php echo wpautop( get_the_author_meta( 'description', $user_id ) ); ?>
		</div>
	</div>

	<div class="row main-content">
		<div id="main-content" class="summary-main-content">
<?php
	if ( have_posts() ) {

		while ( have_posts() ) {

			the_post();
			get_template_part( 'content', get_post_format() );

		}

		beacon_numeric_pagination();

	} else {

		get_template_part( 'content-empty' );

	}
?>
		</div>
	</div>
<?php
	get_footer();
