<?php
/**
 * Archive Template
 *
 * @package Beacon
 */

	get_header();

	if ( have_posts() ) {
?>
	<header class="entry-archive-header page-title">
		<div class="row">
<?php
		the_archive_title( '<h1 class="entry-title entry-archive-title">', '</h1>' );
		the_archive_description( '<div class="category-description">', '</div>' );
?>
		</div>
	</header>

	<div class="row">
		<div id="main-content" class="summary-main">
<?php
		$beacon_post_count = 0;

		while ( have_posts() ) {
			the_post();

			$beacon_post_count ++;

			if ( 1 === $beacon_post_count ) {
				get_template_part( 'content-feature' );
			} else {
				get_template_part( 'content', get_post_format() );
			}

		}

		beacon_numeric_pagination();

	} else {

		get_template_part( 'content-empty' );

	}
?>
		</div>
	</div>

<?php
	get_footer();
