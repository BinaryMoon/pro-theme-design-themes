<?php
/**
 * Homepage Template
 *
 * @package Beacon
 */

	get_header();

?>
	<section class="page-content clearfix">
		<div class="row tab tab-home">
			<div class="magazine">
<?php
	get_template_part( 'inc/homepage-latest-posts' );
	get_template_part( 'inc/homepage-category-summaries' );
	do_action( 'beacon_tabs' );
?>
			</div>
<?php
	get_sidebar();
?>
		</div>

		<div class="row tab tab-comments">
			<div class="summary-main">
<?php
	get_template_part( 'inc/homepage-most-commented' );
?>
			</div>
		</div>
<?php
	// Make sure Jetpack stats are available else don't bother showing.
	if ( beacon_display_popular_tab() ) {
?>
		<div class="row tab tab-popular main-content">
			<div class="summary-main">
<?php
		get_template_part( 'inc/homepage-most-popular' );
?>
			</div>
		</div>
<?php
	}
?>
	</section>
<?php
	get_footer();
