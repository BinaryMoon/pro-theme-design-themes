<?php
/**
 * Page content
 *
 * @package Beacon
 */

?>
<div class="page-content">
	<div class="page-title">
		<div class="row">
			<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
		</div>
	</div>
	<section class="row clearfix article">
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<section class="entry entry-single">
<?php
	the_content();

	edit_post_link();

	wp_link_pages( array(
		'before' => '<div class="archive-pagination">' . __( 'Pages: ', 'beacon' ),
		'after'  => '</div>',
		'link_before' => '<span class="page">',
		'link_after'  => '</span>',
	) );
?>
			</section>

			<?php get_sidebar(); ?>

		</article>
	</section>
</div>
