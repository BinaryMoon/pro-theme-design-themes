<?php
/**
 * Reusable theme functions
 *
 * @package Beacon
 */

/**
 * This is the max width - it's the same on all pages
 *  keep in mind the theme is responsive so the width is likely to be narrower
 */
if ( ! isset( $content_width ) ) {
	$content_width = 1140;
}

/**
 * Adjust content width
 *
 * @global int $content_width
 */
function beacon_adjust_content_width() {

	global $content_width;

	if ( is_active_sidebar( 'sidebar-1' ) ) {
		$content_width = 878;
	}

}

add_action( 'template_redirect', 'beacon_adjust_content_width' );


/**
 * Enqueue all the styles
 *
 * @global type $wp_scripts
 */
function beacon_enqueue() {

	// Styles.
	wp_enqueue_style( 'beacon-style', get_template_directory_uri() . '/styles/css/style.css', null, '1.2' );
	wp_enqueue_style( 'genericons', get_template_directory_uri() . '/styles/genericons/genericons.css', array(), '3.0.3' );

	// Fonts.
	$fonts_url = beacon_fonts();
	if ( $fonts_url ) {
		wp_enqueue_style( 'beacon-fonts', $fonts_url, array(), '1.0' );
	}

	// Javascript.
	if ( is_active_sidebar( 'sidebar-2' ) ) {
		wp_enqueue_script( 'masonry' );
	}

	wp_enqueue_script( 'beacon-script-main', get_template_directory_uri() . '/js/main.js', array( 'jquery' ), '1.0', false );

	wp_localize_script(
		'beacon-script-main',
		'js_i18n',
		array(
			'next' => esc_html__( 'next', 'beacon' ),
			'prev' => esc_html__( 'previous', 'beacon' ),
		)
	);

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

}

add_action( 'wp_enqueue_scripts', 'beacon_enqueue' );


/**
 * Set up all the theme properties and extras
 */
function beacon_after_setup_theme() {

	add_theme_support( 'automatic-feed-links' );

	// Post thumbnails.
	add_theme_support( 'post-thumbnails' );

	// Title tag.
	add_theme_support( 'title-tag' );

	// Image sizes.
	add_image_size( 'beacon-attachment', 120, 120, true ); // Used for attachment (image.php) page links.
	add_image_size( 'beacon-header', 1710, 750, true );
	add_image_size( 'beacon-archive-trending', 402, 225, true );
	add_image_size( 'beacon-archive-featured', 630, 380, true );
	add_image_size( 'beacon-logo', 600, 80, false );

	// Custom background.
	$args = array(
		'default-color' => apply_filters( 'beacon-background-color', 'f4f5f6' ),
	);
	add_theme_support( 'custom-background', $args );

	// HTML5 ftw.
	add_theme_support(
		'html5',
		array(
			'navigation-widgets',
			'comment-list',
			'search-form',
			'comment-form',
		)
	);

	// Add support for full width images and other content such as videos.
	add_theme_support( 'align-wide' );

	// Disable custom font sizes, ensuring consistent vertical rhythm.
	add_theme_support( 'disable-custom-font-sizes' );

	// Make Gutenberg embeds responsive.
	add_theme_support( 'responsive-embeds' );

	// Add support for editor styles.
	add_theme_support( 'editor-styles' );

	// Editor Style.
	$fonts_url = beacon_fonts();

	if ( $fonts_url ) {
		add_editor_style( $fonts_url );
	}

	add_editor_style( 'styles/css/editor-styles.css' );

	register_nav_menus(
		array(
			'top_menu' => esc_html__( 'Top Menu', 'beacon' ),
			'social_menu' => esc_html__( 'Social Menu', 'beacon' ),
		)
	);

	load_theme_textdomain( 'beacon', get_template_directory() . '/languages' );

}

add_action( 'after_setup_theme', 'beacon_after_setup_theme' );


/**
 * Enqueue WordPress theme styles within Gutenberg.
 */
function beacon_editor_blocks_styles() {

	// Load the additional editor styles.
	// This covers things like the editor title that can't be styled with the normal editor styles.
	wp_enqueue_style( 'beacon-editor-blocks', get_theme_file_uri( '/styles/css/editor-blocks.css' ), null, '1' );

	/**
	 * Overwrite Core theme styles with empty styles.
	 *
	 * @see https://github.com/WordPress/gutenberg/issues/7776#issuecomment-406700703
	 */
	wp_deregister_style( 'wp-block-library-theme' );
	wp_register_style( 'wp-block-library-theme', '' );

}

add_action( 'enqueue_block_editor_assets', 'beacon_editor_blocks_styles' );
add_action( 'enqueue_block_assets', 'beacon_editor_blocks_styles' );



/**
 * Get url for Google fonts.
 */
function beacon_fonts() {

	/**
	 * Translators: If there are characters in your language that are not
	 * supported, translate this to 'off'. Do not translate into your
	 * own language.
	 */
	$montserrat = _x( 'on', 'Montserrat Font: on or off', 'beacon' );
	if ( 'off' !== $montserrat ) {
		$fonts['montserrat'] = 'Montserrat:400,700';
	}

	/**
	 * Translators: If there are characters in your language that are not
	 * supported, translate this to 'off'. Do not translate into your
	 * own language.
	 */
	$source_sans_pro = _x( 'on', 'Source Sans Pro Font: on or off', 'beacon' );
	if ( 'off' !== $source_sans_pro ) {
		$fonts['source-sans'] = 'Source+Sans+Pro:400,700,400italic';
	}

	$fonts = apply_filters( 'beacon_fonts', $fonts );

	if ( $fonts ) {

		$query_args = array(
			'family' => rawurlencode( implode( '|', $fonts ) ),
			'subset' => rawurlencode( 'latin,latin-ext' ),
			'display' => 'swap',
		);

		return add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );

	}

}


/**
 * Initialize Widgets
 */
function beacon_widgets_init() {

	// Sidebar.
	register_sidebar(
		array(
			'name' => __( 'Sidebar Widgets', 'beacon' ),
			'id' => 'sidebar-1',
			'description' => __( 'Widgets that display on the side of your website', 'beacon' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h3 class="widgettitle"><span>',
			'after_title' => '</span></h3>',
		)
	);

	// Footer widgets.
	register_sidebar(
		array(
			'name' => __( 'Footer Widgets', 'beacon' ),
			'id' => 'sidebar-2',
			'description' => __( 'Widgets that display at the bottom of your website. They are arranged in 4 columns and lined up automatically to make the best use of the space available.', 'beacon' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h3 class="widgettitle">',
			'after_title' => '</h3>',
		)
	);

}

add_action( 'widgets_init', 'beacon_widgets_init' );


/**
 * Custom excerpt length
 *
 * @param type $length The default excerpt length.
 * @return int
 */
function beacon_excerpt_length( $length ) {

	$length = 30;

	if ( is_active_sidebar( 'sidebar-1' ) && is_front_page() ) {
		$length = 20;
	}

	return $length;

}

add_filter( 'excerpt_length', 'beacon_excerpt_length', 18 );


/**
 * Add a default id to navigation
 *
 * @param string $ulclass The menu html.
 * @return string
 */
function beacon_add_menu_class( $ulclass ) {

	return preg_replace( '/<ul>/', '<ul id="nav">', $ulclass, 1 );

}

add_filter( 'wp_page_menu', 'beacon_add_menu_class' );


/**
 * Numeric pagination for custom queries
 * Much nicer than next and previous links :)
 *
 * @param  integer $page_count Number of pages to display.
 * @param  object  $query      WP_Query object.
 * @return null
 */
function beacon_numeric_pagination( $page_count = 3, $query = null ) {

	if ( null === $query ) {
		global $wp_query;
		$query = $wp_query;
	}

	if ( 1 >= $query->max_num_pages ) {
		return;
	}

	$big = 9999999999; // Need an unlikely integer.

	echo '<div class="archive-pagination pagination">';
	echo paginate_links(
		array(
			'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
			'format' => '?paged=%#%',
			'current' => max( 1, get_query_var( 'paged' ) ),
			'total' => $query->max_num_pages,
			'end_size' => 0,
			'mid_size' => $page_count,
			'next_text' => esc_html__( 'Older &rsaquo;', 'beacon' ),
			'prev_text' => esc_html__( '&lsaquo; Newer', 'beacon' ),
		)
	);
	echo '</div>';

}


/**
 * Add additional body classes that may be helpful
 *
 * @param array $styles List of body classes.
 * @return array
 */
function beacon_body_class( $styles ) {

	if ( is_singular() ) {
		$styles[] = 'singular';
	}

	if ( is_active_sidebar( 'sidebar-1' ) ) {
		$styles[] = 'themes-sidebar1-active';
	} else {
		$styles[] = 'themes-sidebar1-inactive';
	}

	if ( is_active_sidebar( 'sidebar-2' ) ) {
		$styles[] = 'themes-sidebar2-active';
	} else {
		$styles[] = 'themes-sidebar2-inactive';
	}

	if ( beacon_has_featured_posts() ) {
		$styles[] = 'themes-has-featured-posts';
	} else {
		$styles[] = 'themes-no-featured-posts';
	}

	if ( get_header_image() ) {
		$styles[] = 'has-custom-header';
	}

	return $styles;

}

add_filter( 'body_class', 'beacon_body_class' );


/**
 * Additional styles for post class
 *
 * @param array $styles List of post classes.
 * @return array
 */
function beacon_post_class( $styles ) {

	if ( is_singular() ) {
		$styles[] = 'post-singular';
	}

	if ( ! is_singular() ) {
		$styles[] = 'post-archive';
		$styles[] = 'clearfix';
		$styles[] = 'summary';
	}

	return $styles;

}

add_filter( 'post_class', 'beacon_post_class' );


/**
 * Display header image and link to homepage
 * On pages display featured image if it is large enough to fill the space
 */
function beacon_header() {

	$header_image = get_header_image();
	$header_image_width = get_theme_support( 'custom-header', 'width' );
	$header_image_actual_width = get_custom_header()->width;
	$header_image_actual_height = get_custom_header()->height;

	// Use custom headers on pages, but only if the image is large enough.
	if ( is_page() ) {
		$image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'beacon-header' );
		if ( ! empty( $image ) && $image[1] >= $header_image_width ) {
			$header_image = esc_url( $image[0] );
			$header_image_actual_width = (int) $image[1];
			$header_image_actual_height = (int) $image[2];
		}
	}

	if ( ! empty( $header_image ) ) {
?>
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home" class="header-image">
			<img src="<?php echo esc_url( $header_image ); ?>" width="<?php echo (int) $header_image_actual_width; ?>" height="<?php echo (int) $header_image_actual_height; ?>" alt="" />
		</a>
<?php
	}

}


/**
 * Display the time in a human readable format.
 *
 * @return type
 */
function beacon_human_time_diff() {

	$post_time = get_the_time( 'U' );
	$human_time = '';
	$time_now = gmdate( 'U' );

	// Use human time if less that 60 days ago.
	// 60 seconds * 60 minutes * 24 hours * 90 days.
	if ( $post_time > $time_now - ( 60 * 60 * 24 * 90 ) ) {
		// Translators: %s = Time ago.
		$human_time = sprintf( __( '%s ago', 'beacon' ), human_time_diff( $post_time, current_time( 'timestamp' ) ) );
	} else {
		$human_time = get_the_date();
	}

	return $human_time;

}


/**
 * Get post thumbnail url
 * If a thumbnail doesn't exist then use the first attachment
 * reduces user confusion since they don't always understand the featured image functionality
 *
 * @param  int    $post_id Post ID.
 * @param  string $thumbnail_size Thumbnail size.
 * @return array|false
 */
function beacon_archive_image_url( $post_id = null, $thumbnail_size = 'beacon-archive-trending' ) {

	if ( ! $post_id ) {
		$post_id = get_the_ID();
	}

	$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post_id ), $thumbnail_size );

	// If there's no featured image then grab an attachment image and use that instead.
	if ( ! $image[0] ) {

		$values = get_attached_media( 'image', $post_id );

		if ( $values ) {
			foreach ( $values as $child_id => $attachment ) {
				$image = wp_get_attachment_image_src( $child_id, $thumbnail_size );
				break;
			}
		}
	}

	if ( $image ) {
		return $image;
	} else {
		return false;
	}

}


/**
 * Fill empty post thumbnails with images from the first attachment added to a post
 *
 * @param string $html Thumbnail html.
 * @param int    $post_id Post ID for image to change.
 * @param int    $thumbnail_id Thumbnail ID.
 * @param string $size Thumbnail size.
 * @return string
 */
function beacon_post_thumbnail_html( $html, $post_id, $thumbnail_id, $size = '' ) {

	if ( empty( $html ) ) {

		$values = get_attached_media( 'image', $post_id );

		if ( $values ) {
			foreach ( $values as $child_id => $attachment ) {
				$html = wp_get_attachment_image( $child_id, $size );
				break;
			}
		}
	}

	return $html;

}

add_filter( 'post_thumbnail_html', 'beacon_post_thumbnail_html', 10, 4 );


/**
 * Display a list of the top categories on the site ordered by number of posts
 *
 * @param int $quantity Number of posts to display (appears to be unessecary but keeping it in case).
 */
function beacon_top_categories( $quantity = 5 ) {

	// Categories.
	$args = array(
		'number' => 5,
		'order' => 'DESC',
		'hierachical' => 0,
		'orderby' => 'count',
	);

	$categories = get_categories( $args );

	if ( $categories ) {

		$category_list = array();
		foreach ( $categories as $category ) {
			$category_list[] = '<a href="' . esc_url( get_category_link( $category->term_id ) ) . '" class="category-' . esc_attr( $category->term_id ) . '">' . $category->name . '</a>';
		}

		printf(
			// Translators: %s = list of categories.
			__( '<span class="trending-title">Trending Topics:</span> %s', 'beacon' ),
			implode( __( '<span class="sep">&bull;</span>', 'beacon' ), $category_list )
		);

	}

}


add_filter( 'use_default_gallery_style', '__return_false' );


/**
 * Get list of homepage categories.
 *
 * @return type
 */
function beacon_get_homepage_categories() {

	return explode( ',', get_theme_mod( 'beacon_home_categories' ) );

}


/**
 * Decide whether or not to display the popular posts tab on the homepage.
 *
 * @return boolean
 */
function beacon_display_popular_tab() {

	return function_exists( 'stats_get_csv' ) && get_theme_mod( 'beacon_display_popular_tab', true );

}


// Custom header settings.
require 'inc/custom-header.php';

// Jetpack specific functionality.
require 'inc/jetpack.php';

// Custom customizer controls.
require 'inc/class-custom-controls.php';

// Customizer controls for setting theme properties.
require 'inc/customizer.php';
