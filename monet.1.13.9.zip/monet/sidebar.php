<?php
/**
 * Sidebar template
 *
 * @package Monet
 */

	if ( monet_sidebar_menu_active() ) {
?>
<div class="sidebar sidebar-main" role="complementary">
	<div class="column-wrapper">
<?php
		if ( is_active_sidebar( 'sidebar-1' ) ) {
			echo '<div class="column">';
			dynamic_sidebar( 'sidebar-1' );
			echo '</div>';
		}

		if ( is_active_sidebar( 'sidebar-2' ) ) {
			echo '<div class="column">';
			dynamic_sidebar( 'sidebar-2' );
			echo '</div>';
		}

		if ( is_active_sidebar( 'sidebar-3' ) ) {
			echo '<div class="column">';
			dynamic_sidebar( 'sidebar-3' );
			echo '</div>';
		}
?>
	</div>
</div>
<?php
	}
