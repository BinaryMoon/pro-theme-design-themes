<?php
/**
 * Search results template
 *
 * @package Monet
 */

	get_header();
?>
	<header class="entry-archive-header">
		<h1 class="entry-title entry-archive-title">
<?php
			/* translators: %s = Search query */
			printf( esc_html__( 'Search results for &#8216;%s&#8217;', 'monet' ), get_search_query() );
?>
		</h1>
<?php
		if ( ! have_posts() ) {
?>
		<div class="category-description">
			<p><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'monet' ); ?></p>
		</div>
<?php
		}

		get_search_form();

?>
	</header>

	<div id="main-content" class="main-content post-archive">
<?php
	if ( have_posts() ) {
		while ( have_posts() ) {
			the_post();
			get_template_part( 'content', get_post_format() );
		}

		the_posts_pagination();
	}
?>
	</div>
<?php
	get_footer();
