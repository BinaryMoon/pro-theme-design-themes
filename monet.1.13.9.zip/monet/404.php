<?php
/**
 * Error - file not found
 *
 * @package Monet
 */

	get_header();
?>

	<article class="page-404 main-content post-singular">

		<div class="entry-single">

			<header class="entry-header">
				<h1 class="entry-title"><?php esc_html_e( 'Oops! That page can&rsquo;t be found.', 'monet' ); ?></h1>
			</header>

			<section class="entry">
				<p><?php esc_html_e( 'It looks like nothing was found at this location. Check out some recent posts below:', 'monet' ); ?></p>
<?php
	$args = array(
		'posts_per_page' => 5,
		'ignore_sticky_posts' => true,
	);
	$query = new WP_Query( $args );

	if ( $query->have_posts() ) {
?>
			<h3><?php esc_html_e( 'Recent Posts', 'monet' ); ?></h3>
			<ul>
<?php
		while ( $query->have_posts() ) {
			$query->the_post();
?>
				<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
<?php
		}

?>
			</ul>

			<h3><?php esc_html_e( 'Search', 'monet' ); ?><h3>
<?php
		get_search_form();

	} else {
		get_template_part( 'content-empty' );
	}
	wp_reset_postdata();
?>
			</section>

		</div>

	</article>
<?php
	get_footer();
