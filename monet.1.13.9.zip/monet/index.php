<?php
/**
 * Homepage Template
 *
 * @package Monet
 */

	get_header();

	get_template_part( 'inc/jetpack-featured-content' );

	if ( have_posts() ) {
?>
	<div id="main-content" class="post-archive">
<?php

		while ( have_posts() ) {
			the_post();
			get_template_part( 'content', get_post_format() );
		}

?>
	</div>
<?php
		the_posts_pagination();
	} else {
		get_template_part( 'content-empty' );
	}

	get_footer();
