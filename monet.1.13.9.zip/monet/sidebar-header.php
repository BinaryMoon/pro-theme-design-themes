<?php
/**
 * Header sidebar template
 *
 * @package Monet
 */

	if ( is_active_sidebar( 'sidebar-4' ) ) {
?>
<div class="sidebar sidebar-header" role="complementary">
	<?php dynamic_sidebar( 'sidebar-4' ); ?>
</div>
<?php
	}
