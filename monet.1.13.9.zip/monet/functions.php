<?php
/**
 * Reusable theme functions
 *
 * @package Monet
 */

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 * keep in mind the theme is responsive so the width is likely to be narrower
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function monet_content_width() {

	$GLOBALS['content_width'] = apply_filters( 'monet_content_width', 833 );

}

add_action( 'after_setup_theme', 'monet_content_width', 0 );


/**
 * Enqueue all the styles
 *
 * @global type $wp_scripts
 */
function monet_enqueue() {

	// Styles.
	wp_enqueue_style( 'monet-style', get_stylesheet_uri(), null, '1.0' );
	wp_enqueue_style( 'genericons', get_template_directory_uri() . '/styles/genericons/genericons.css', array(), '3.0.3' );

	// Fonts.
	$fonts_url = monet_fonts();

	if ( $fonts_url ) {
		wp_enqueue_style( 'monet-fonts', $fonts_url, array(), '1.0' );
	}

	// Javascript.
	wp_enqueue_script( 'masonry' );

	wp_enqueue_script( 'monet-script-main', get_template_directory_uri() . '/js/main.js', array( 'jquery' ), '1.0', false );
	wp_enqueue_script( 'monet-script-slider', get_template_directory_uri() . '/js/slider.js', array( 'jquery' ), '1.3', false );

	wp_localize_script(
		'monet-script-main',
		'js_i18n',
		array(
			'next' => esc_html__( 'next', 'monet' ),
			'prev' => esc_html__( 'previous', 'monet' ),
			'menu' => esc_html__( 'Menu', 'monet' ),
			'back' => esc_html__( 'Back', 'monet' ),
			'select_submenu' => ! is_front_page() && (bool) get_theme_mod( 'monet_highlight_submenu', false ),
		)
	);

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

}

add_action( 'wp_enqueue_scripts', 'monet_enqueue' );


/**
 * Set up all the theme properties and extras
 */
function monet_after_setup_theme() {

	load_theme_textdomain( 'monet', get_template_directory() . '/languages' );

	add_theme_support( 'automatic-feed-links' );

	// Post thumbnails.
	add_theme_support( 'post-thumbnails' );

	// Used for attachment (image.php) page links.
	add_image_size( 'monet-attachment', 120, 120, true );
	add_image_size( 'monet-logo', 400, 9999 );
	add_image_size( 'monet-archive', 550, 367, true );
	add_image_size( 'monet-featured', 1100, 550, true );
	add_image_size( 'monet-attachment-fullsize', 1100, 9999 );

	// Add selective refresh to widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );

	// Custom background.
	add_theme_support(
		'custom-background',
		apply_filters(
			'monet-custom-background',
			array(
				'default-color' => 'eeeeee',
				'default-image' => '',
			)
		)
	);

	// HTML5 ftw.
	add_theme_support(
		'html5',
		array(
			'navigation-widgets',
			'comment-list',
			'comment-form',
			'search-form',
			'gallery',
			'caption',
			'widgets',
		)
	);

	// Post formats.
	add_theme_support(
		'post-formats',
		array(
			'quote',
			'video',
			'audio',
			'aside',
			'link',
		)
	);

	// Title tag.
	add_theme_support( 'title-tag' );

	// Menus.
	register_nav_menus(
		array(
			'primary' => esc_html__( 'Primary Menu', 'monet' ),
			'social' => esc_html__( 'Social Links Menu', 'monet' ),
		)
	);

	load_theme_textdomain( 'monet', get_template_directory() . '/languages' );

	// Add support for full width images and other content such as videos.
	add_theme_support( 'align-wide' );

	// Disable custom font sizes, ensuring consistent vertical rhythm.
	add_theme_support( 'disable-custom-font-sizes' );

	// Make Gutenberg embeds responsive.
	add_theme_support( 'responsive-embeds' );

	// Editor font sizes.
	// Uses the default slugs to ensure consistency across themes.
	add_theme_support(
		'editor-font-sizes',
		array(
			array(
				'name' => esc_html__( 'small', 'monet' ),
				'size' => 12,
				'slug' => 'small',
			),
			array(
				'name' => esc_html__( 'normal', 'monet' ),
				'size' => 16,
				'slug' => 'normal',
			),
			array(
				'name' => esc_html__( 'medium', 'monet' ),
				'size' => 20,
				'slug' => 'medium',
			),
			array(
				'name' => esc_html__( 'large', 'monet' ),
				'size' => 24,
				'slug' => 'large',
			),
			array(
				'name' => esc_html__( 'huge', 'monet' ),
				'size' => 32,
				'slug' => 'huge',
			),
		)
	);

	// Add support for editor styles.
	add_theme_support( 'editor-styles' );

	// Editor Style.
	$fonts_url = monet_fonts();

	if ( $fonts_url ) {
		add_editor_style( $fonts_url );
	}

	add_editor_style( 'styles/css/editor-styles.css' );

}

add_action( 'after_setup_theme', 'monet_after_setup_theme' );


/**
 * Enqueue WordPress theme styles within Gutenberg.
 */
function monet_editor_blocks_styles() {

	// Load the additional editor styles.
	// This covers things like the editor title that can't be styled with the normal editor styles.
	wp_enqueue_style( 'monet-editor-blocks', get_theme_file_uri( '/styles/css/editor-blocks.css' ), null, '1' );

	/**
	 * Overwrite Core theme styles with empty styles.
	 *
	 * @see https://github.com/WordPress/gutenberg/issues/7776#issuecomment-406700703
	 */
	wp_deregister_style( 'wp-block-library-theme' );
	wp_register_style( 'wp-block-library-theme', '' );

}

add_action( 'enqueue_block_editor_assets', 'monet_editor_blocks_styles' );
add_action( 'enqueue_block_assets', 'monet_editor_blocks_styles' );


/**
 * Display social links
 *
 * @link http://kovshenin.com/2014/social-menus-in-wordpress-themes/
 * @param  boolean $echo True to display the links, false to return them.
 * @return string
 */
function monet_social_links( $echo = true ) {

	$menu = '';

	if ( has_nav_menu( 'social' ) ) {

		$args = array(
			'theme_location' => 'social',
			'echo' => false,
			'container' => false,
			'depth' => 1,
			'link_before' => '<span class="screen-reader">',
			'link_after' => '</span>',
			'fallback_cb' => '__return_false',
		);

		$menu = '<div class="menu-social-links">' . wp_nav_menu( $args ) . '</div>';

	}

	if ( $echo ) {
		echo $menu;
	} else {
		return $menu;
	}

}


/**
 * Initiate sidebars.
 */
function monet_widgets_init() {

	// Dropdown Widgets column 1.
	register_sidebar(
		array(
			'name' => esc_html__( 'Widgets Column 1', 'monet' ),
			'id' => 'sidebar-1',
			'description' => esc_html__( 'Widgets that are accessed through a button on the sidebar.', 'monet' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h3 class="widgettitle">',
			'after_title' => '</h3>',
		)
	);

	// Dropdown Widgets column 2.
	register_sidebar(
		array(
			'name' => esc_html__( 'Widgets Column 2', 'monet' ),
			'id' => 'sidebar-2',
			'description' => esc_html__( 'Widgets that are accessed through a button on the sidebar.', 'monet' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h3 class="widgettitle">',
			'after_title' => '</h3>',
		)
	);

	// Dropdown Widgets column 3.
	register_sidebar(
		array(
			'name' => esc_html__( 'Widgets Column 3', 'monet' ),
			'id' => 'sidebar-3',
			'description' => esc_html__( 'Widgets that are accessed through a button on the sidebar.', 'monet' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h3 class="widgettitle">',
			'after_title' => '</h3>',
		)
	);

	// Header Widgets.
	register_sidebar(
		array(
			'name' => esc_html__( 'Sidebar Widgets', 'monet' ),
			'id' => 'sidebar-4',
			'description' => esc_html__( 'Widgets that appear underneath the navigation and site title in the sidebar.', 'monet' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h3 class="widgettitle">',
			'after_title' => '</h3>',
		)
	);

}

add_action( 'widgets_init', 'monet_widgets_init' );


/**
 * Custom excerpt length
 *
 * @param type $length Excerpt length.
 * @return int
 */
function monet_excerpt_length( $length ) {

	return 20;

}

add_filter( 'excerpt_length', 'monet_excerpt_length', 999 );


/**
 * Fallback for navigation menu
 *
 * @param array $params Menu parameters.
 * @return string
 */
function monet_nav_menu( $params ) {

	$html = '';
	$echo = $params['echo'];

	$params['echo'] = false;
	$html = wp_page_menu( $params );

	if ( $params['container'] ) {
		$container_start = '<' . $params['container'] . ' id="' . $params['container_id'] . '" class="' . $params['container_class'] . '">';
		$container_end = '</' . $params['container'] . '>';

		$html = str_replace( '<div class="' . $params['menu_class'] . '">', $container_start, $html );
		$html = str_replace( '</div>', $container_end, $html );
	}

	if ( $echo ) {
		echo $html;
	} else {
		return $html;
	}

}


/**
 * Add additional body classes that may be helpful
 *
 * @param array $classes List of body classes.
 * @return array
 */
function monet_body_class( $classes ) {

	if ( is_singular() ) {
		$classes[] = 'singular';
	}

	if ( is_multi_author() ) {
		$classes[] = 'multi-author-true';
	} else {
		$classes[] = 'multi-author-false';
	}

	if ( is_active_sidebar( 'sidebar-1' ) ) {
		$classes[] = 'themes-sidebar1-active';
	} else {
		$classes[] = 'themes-sidebar1-inactive';
	}

	if ( is_active_sidebar( 'sidebar-2' ) ) {
		$classes[] = 'themes-sidebar2-active';
	} else {
		$classes[] = 'themes-sidebar2-inactive';
	}

	if ( is_active_sidebar( 'sidebar-3' ) ) {
		$classes[] = 'themes-sidebar3-active';
	} else {
		$classes[] = 'themes-sidebar3-inactive';
	}

	if ( monet_sidebar_menu_active() || has_nav_menu( 'social' ) ) {
		$classes[] = 'themes-minor-sidebar-active';
	} else {
		$classes[] = 'themes-minor-sidebar-inactive';
	}

	if ( monet_has_featured_posts() ) {
		$classes[] = 'themes-has-featured-posts';
	} else {
		$classes[] = 'themes-no-featured-posts';
	}

	return $classes;

}

add_filter( 'body_class', 'monet_body_class' );


/**
 * Additional styles for post class
 *
 * @param array $styles List of post classes.
 * @return array
 */
function monet_post_class( $styles ) {

	if ( get_the_post_thumbnail( get_the_ID() ) ) {
		$styles[] = 'post-has-thumbnail';
	} else {
		$styles[] = 'post-no-thumbnail';
	}

	return $styles;

}

add_filter( 'post_class', 'monet_post_class' );


/**
 * Display the post time in a human readable format
 *
 * @param boolean $echo Should we display the time or return it.
 * @return type
 */
function monet_human_time_diff( $echo = true ) {

	$post_time = get_the_time( 'U' );
	$human_time = '';

	$time_now = date( 'U' );

	// Use human time if less that 60 days ago
	// 60 seconds * 60 minutes * 24 hours * 90 days.
	$time_limit = apply_filters( 'monet_human_time_diff_range', ( 60 * 60 * 24 * 90 ) );
	if ( $post_time > $time_now - $time_limit ) {
		/* translators: %s = Human readable time. eg 2 hours 'ago' */
		$human_time = sprintf( esc_html__( '%s ago', 'monet' ), human_time_diff( $post_time, current_time( 'timestamp' ) ) );
	} else {
		$human_time = get_the_date();
	}

	$human_time = sprintf( '<span class="post-human-time">%s</span>', $human_time );

	if ( $echo ) {
		echo $human_time;
	}

	return $human_time;

}


/**
 * Get post thumbnail url
 * If a thumbnail doesn't exist then use the first attachment
 * reduces user confusion since they don't always understand the featured image functionality
 *
 * @param int $post_id ID of the post to retrieve the thumbnail image for.
 * @param int $thumbnail_size Thumbnail size for the returned image.
 * @return string $image
 */
function monet_archive_image_url( $post_id = null, $thumbnail_size = 'monet-archive' ) {

	if ( ! $post_id ) {
		$post_id = get_the_ID();
	}

	$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post_id ), $thumbnail_size );

	// If there's no featured image then grab an attachment image and use that instead.
	if ( ! $image[0] ) {

		$values = get_attached_media( 'image', $post_id );

		if ( $values ) {
			foreach ( $values as $child_id => $attachment ) {
				$image = wp_get_attachment_image_src( $child_id, $thumbnail_size );
				break;
			}
		}
	}

	if ( $image ) {
		return $image;
	} else {
		return false;
	}

}


/**
 * Fill empty post thumbnails with images from the first attachment added to a post.
 *
 * @param string $html         Thumbnail html.
 * @param int    $post_id      ID of post to check for thumbnail.
 * @param int    $thumbnail_id Thumbnail ID.
 * @param string $size         Thumbnail image size.
 * @return string
 */
function monet_post_thumbnail_html( $html, $post_id, $thumbnail_id, $size = '' ) {

	if ( empty( $html ) ) {

		$values = get_attached_media( 'image', $post_id );

		if ( $values ) {
			foreach ( $values as $child_id => $attachment ) {
				$html = wp_get_attachment_image( $child_id, $size );
				break;
			}
		}
	}

	return $html;

}

add_filter( 'post_thumbnail_html', 'monet_post_thumbnail_html', 10, 4 );


/**
 * Prints HTML with meta information for the current post-date/time
 *
 * @param boolean $human_time Should we display as human readable time or regular time format.
 */
function monet_post_time( $human_time = true ) {

	$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';

	if ( $human_time ) {

		$time_string = sprintf(
			$time_string,
			esc_attr( get_the_date( 'c' ) ),
			monet_human_time_diff( false )
		);

	} else {

		$time_string = sprintf(
			$time_string,
			esc_attr( get_the_date( 'c' ) ),
			esc_html( get_the_date() )
		);

	}

	$posted_on = '<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a>';

	echo '<span class="posted-on">' . $posted_on . '</span>';

}


/**
 * Prints HTML with the author meta data
 */
function monet_post_author() {

	$byline = sprintf(
		/* translators: %s = post author name */
		_x( 'by %s', 'post author', 'monet' ),
		'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>'
	);

	echo '<span class="byline"> ' . $byline . '</span>';

}


/**
 * Display a link to the Monet Comments
 */
function monet_comments_link() {

	if ( ! post_password_required() && ( comments_open() || get_comments_number() > 0 ) ) {
?>
		<span class="comment-count"><?php comments_popup_link( esc_html__( 'Leave a Comment', 'monet' ), esc_html__( '1 Comment', 'monet' ), esc_html__( '% Comments', 'monet' ) ); ?></span>
<?php
	}

}


/**
 * Get a list of children for the current page
 *
 * @return WP_Query
 */
function monet_child_pages() {

	return new WP_Query(
		array(
			'post_type'      => 'page',
			'orderby'        => 'menu_order',
			'order'          => 'ASC',
			'post_parent'    => get_the_ID(),
			'posts_per_page' => 999,
			'no_found_rows'  => true,
		)
	);

}


/**
 * Get the posts custom read more text and, if available, display it instead of 'read more'
 */
function monet_read_more_text() {

	// Default text value.
	$read_more = esc_html__( 'Read More &rarr;', 'monet' );

	// Get post data.
	$post = get_post();
	$custom_readmore = get_extended( $post->post_content );

	if ( ! empty( $custom_readmore['more_text'] ) ) {
		$read_more = $custom_readmore['more_text'];
	}

	echo esc_html( $read_more );

}


/**
 * Display a specific user and their contributor info
 *
 * @param int $user_id    Contributor user ID.
 * @param int $post_count Number of posts to display.
 */
function monet_contributor( $user_id = null, $post_count = null ) {

	if ( ! $user_id ) {
		$user_id = get_the_author_meta( 'ID' );
	}

?>
	<div class="contributor">
		<?php echo get_avatar( $user_id, 140 ); ?>
		<h2><a href="<?php echo esc_url( get_author_posts_url( $user_id ) ); ?>"><?php the_author_meta( 'display_name', $user_id ); ?></a></h2>
		<?php echo wpautop( get_the_author_meta( 'description', $user_id ) ); ?>
<?php
	if ( $post_count ) {
?>
	<a class="contributor-posts-link" href="<?php echo esc_url( get_author_posts_url( $user_id ) ); ?>">
<?php
		/* translators: %d = numbers of articles */
		printf( _n( '%d Article', '%d Articles', $post_count, 'monet' ), (int) $post_count );
?>
	</a>
<?php
	}
?>
	</div>
<?php

}


/**
 * Display the first category for the current post/ project
 */
function monet_the_main_category() {

	$term_type = 'category';
	if ( 'jetpack-portfolio' === get_post_type() ) {
		$term_type = 'jetpack-portfolio-type';
	}

	$category = get_the_terms( get_the_ID(), $term_type );

	if ( is_array( $category ) ) {
		$category = array_values( $category );
		$category = current( $category );

		if ( is_object( $category ) ) {
?>
	<span class="post-lead-category"><a href="<?php echo esc_url( get_category_link( $category, $term_type ) ); ?>"><?php echo esc_html( $category->name ); ?></a></span>
<?php
		}
	}

}


/**
 * Display a list of all of the project categories
 */
function monet_project_terms() {

	$terms = get_terms(
		'jetpack-portfolio-type',
		array(
			'number' => 16,
			'orderby' => 'count',
			'order' => 'DESC',
		)
	);

	if ( $terms ) {
?>
	<p class="projects-terms">
<?php
		foreach ( $terms as $t ) {
?>
		<a href="<?php echo esc_url( get_term_link( $t ) ); ?>"><?php echo esc_html( $t->name ); ?></a>
<?php
		}
?>
	</p>
<?php
	}

}


/**
 * Work out if the sidebar is active or not.
 *
 * @return boolean
 */
function monet_sidebar_menu_active() {

	if ( is_active_sidebar( 'sidebar-1' ) ) {
		return true;
	}

	if ( is_active_sidebar( 'sidebar-2' ) ) {
		return true;
	}

	if ( is_active_sidebar( 'sidebar-3' ) ) {
		return true;
	}

	return false;

}


/**
 * Custom comments layout
 *
 * @param type $comment Comment object.
 * @param type $args    Comment arguments.
 * @param type $depth   Comment depth.
 */
function monet_comments_layout( $comment, $args, $depth ) {

	if ( ( 'pingback' === $comment->comment_type || 'trackback' === $comment->comment_type ) && $args['short_ping'] ) {
		monet_comments_ping( $comment, $depth, $args );
	} else {
		monet_comments_comment( $comment, $depth, $args );
	}

}


/**
 * Custom pings layout
 * it's actually the same as the default pings html but but I can't see a way to reuse the one from the comments walker class
 *
 * @param type $comment Comment object.
 * @param type $depth   Comment depth.
 * @param type $args    Comment arguments.
 */
function monet_comments_ping( $comment, $depth, $args ) {

		$tag = ( 'div' === $args['style'] ) ? 'div' : 'li';
?>
		<<?php echo $tag; ?> id="comment-<?php comment_ID(); ?>" <?php comment_class(); ?>>
			<div class="comment-body">
<?php
	/* translators: %s = comment author link */
	printf( esc_html__( 'Pingback: %s', 'monet' ), get_comment_author_link() );

	edit_comment_link( esc_html__( 'Edit', 'monet' ), '<span class="edit-link">', '</span>' );
?>
			</div>
<?php

}


/**
 * Custom comments layout
 *
 * @param type $comment Comment object.
 * @param type $depth   Comment depth.
 * @param type $args    Comment arguments.
 */
function monet_comments_comment( $comment, $depth, $args ) {

	$tag = ( 'div' === $args['style'] ) ? 'div' : 'li';
?>
	<<?php echo $tag; ?> id="comment-<?php comment_ID(); ?>" <?php comment_class(); ?>>
		<article id="div-comment-<?php comment_ID(); ?>">
			<footer class="comment-meta">
				<div class="comment-author vcard">
					<a href="<?php echo esc_url( get_comment_author_url( $comment->comment_ID ) ); ?>" rel="external nofollow" class="url avatar-link">
<?php
						if ( 0 !== $args['avatar_size'] ) {
							echo get_avatar( $comment, $args['avatar_size'] );
						}
?>
					</a>
					<?php printf( '<b class="fn">%s</b>', get_comment_author_link() ); ?>
				</div>
			</footer>

			<div class="comment-body">
				<div class="comment-meta-data">
					<span class="author-link">
						<?php comment_author_link(); ?>
					</span>
					<span class="comment-link">
						<a href="<?php echo esc_url( get_comment_link( $comment->comment_ID, $args ) ); ?>" class="comment-link">
							<time datetime="<?php comment_time( 'c' ); ?>"><?php
								printf( _x( '%1$s at %2$s', '1: date, 2: time', 'monet' ), get_comment_date(), get_comment_time() );
							?></time>
						</a>
					</span>
<?php
	edit_comment_link( esc_html__( 'Edit', 'monet' ), '<span class="edit-link">', '</span>' );

	comment_reply_link(
		array_merge(
			$args,
			array(
				'add_below' => 'div-comment',
				'depth'     => $depth,
				'max_depth' => $args['max_depth'],
				'before'    => '<span class="reply">',
				'after'     => '</span>',
			)
		)
	);
?>
				</div>

				<div class="comment-content">
<?php
	comment_text();

	if ( '0' == $comment->comment_approved ) {
?>
					<p class="comment-awaiting-moderation"><?php esc_html_e( 'Your comment is awaiting moderation.', 'monet' ); ?></p>
<?php
	}
?>
				</div>
			</div>


		</article>
<?php

}


/**
 * Get url for google fonts.
 */
function monet_fonts() {

	/**
	 * Translators: If there are characters in your language that are not
	 * supported, translate this to 'off'. Do not translate into your
	 * own language.
	 */
	$font = _x( 'on', 'Open Sans: on or off', 'monet' );

	if ( 'off' !== $font ) {
		$fonts['open-sans'] = 'Open Sans:300,600,700';
	}

	/**
	 * Translators: If there are characters in your language that are not
	 * supported, translate this to 'off'. Do not translate into your
	 * own language.
	 */
	$font = _x( 'on', 'Amiri: on or off', 'monet' );

	if ( 'off' !== $font ) {
		$fonts['amiri'] = 'Amiri:400,700';
	}

	$fonts = apply_filters( 'monet_fonts', $fonts );

	if ( $fonts ) {
		$query_args = array(
			'family' => rawurlencode( implode( '|', $fonts ) ),
			'subset' => rawurlencode( 'latin,latin-ext' ),
			'display' => 'swap',
		);

		return add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
	}

}


/**
 * Admin init
 * add editor styles
 */
function monet_admin_init() {

	$fonts_url = monet_fonts();

	if ( $fonts_url ) {
		add_editor_style( $fonts_url );
	}

	add_editor_style( 'styles/css/editor-styles.css' );

}

add_action( 'admin_init', 'monet_admin_init' );


// Remove default gallery styles - the theme looks after these.
add_filter( 'use_default_gallery_style', '__return_false' );



// Custom header.
require 'inc/custom-header.php';


// Customizer.
require 'inc/customizer.php';


// Jetpack specific functionality.
require 'inc/jetpack.php';
