<?php
/**
 * Author post listing
 *
 * @package Monet
 */

	get_header();
	$user_id = get_query_var( 'author' );
?>
	<header class="entry-archive-header">
		<h1 class="entry-title entry-archive-title">
			<?php esc_html_e( 'Author Archives', 'monet' ); ?>
		</h1>
	</header>
<?php
	monet_contributor( $user_id );
?>
	<div id="main-content" class="main-content post-archive">
<?php

	if ( have_posts() ) {

		while ( have_posts() ) {
			the_post();
			get_template_part( 'content', get_post_format() );
		}

		the_posts_pagination();

	} else {
		get_template_part( 'content-empty' );
	}
?>
	</div>
<?php

	get_footer();
