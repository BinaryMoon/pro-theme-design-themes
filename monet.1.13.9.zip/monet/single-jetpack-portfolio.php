<?php
/**
 * Single portfolio template
 *
 * @package Monet
 */

	get_header();

?>
	<div class="main-content">
<?php

	if ( have_posts() ) {

		while ( have_posts() ) {
			the_post();
			get_template_part( 'content-single' );
			get_template_part( 'inc/comments' );
		}

		get_template_part( 'inc/jetpack-more-portfolio' );

	} else {

		get_template_part( 'content-empty' );

	}

?>
	</div>
<?php

	get_footer();
