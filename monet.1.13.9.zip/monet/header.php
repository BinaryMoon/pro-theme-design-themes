<?php
/**
 * Header Template
 *
 * @package Monet
 */

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a href="#main-content" class="screen-reader-shortcut"><?php esc_html_e( 'Skip to content', 'monet' ); ?></a>

<div class="container hfeed">

	<header class="masthead" role="banner">

		<a class="menu-close" href="<?php echo esc_url( home_url( '/' ) ); ?>">
			<span class="screen-reader-text"><?php esc_html_e( 'Close Menu', 'monet' ); ?></span>
		</a>

<?php
		if ( function_exists( 'jetpack_the_site_logo' ) ) {
			jetpack_the_site_logo();
		}
?>

		<div class="branding">
			<h1 class="site-title">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php esc_attr_e( 'Home', 'monet' ); ?>">
					<?php bloginfo( 'name' ); ?>
				</a>
			</h1>
			<p class="site-description">
				<?php bloginfo( 'description' ); ?>
			</p>
		</div>

		<nav class="menu" role="navigation">
<?php
	wp_nav_menu(
		array(
			'theme_location' => 'primary',
			'menu_id' => 'nav',
			'menu_class' => 'menu-wrap',
			'container' => false,
		)
	);
?>
		</nav>

		<?php get_sidebar( 'header' ); ?>

	</header>
<?php
	do_action( 'before' );
?>
	<div class="main">
<?php
	get_sidebar();
?>
		<header class="secondary-masthead" role="banner">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="menu-toggle">
				<span class="screen-reader-text"><?php esc_html_e( 'Menu', 'monet' ); ?></span>
			</a>
			<h1 class="site-title">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php esc_attr_e( 'Home', 'monet' ); ?>">
					<?php bloginfo( 'name' ); ?>
				</a>
			</h1>
		</header>
