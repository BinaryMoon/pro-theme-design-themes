<?php
/**
 * Template Name: Projects
 *
 * @package Monet
 */

	get_header();

?>
	<header class="entry-archive-header">
<?php
	the_title( '<h1 class="entry-title entry-archive-title">', '</h1>' );
?>
	</header>
<?php
	if ( have_posts() ) {
		while ( have_posts() ) {
			the_post();

			if ( get_the_content() ) {
?>
	<section class="entry-single">
<?php
		the_content();
?>
	</section>
<?php
			}
		}
	}

	monet_project_terms();

	$query = new WP_Query(
		array(
			'post_type' => 'jetpack-portfolio',
			'posts_per_page' => 99,
			'ignore_sticky_posts' => true,
		)
	);

	if ( $query->have_posts() ) {
?>
	<div id="main-content" class="main-content post-archive">
<?php
		while ( $query->have_posts() ) {
			$query->the_post();
			get_template_part( 'content', get_post_format() );
		}
?>
	</div>
<?php
	} else {
?>
	<div id="main-content" class="main-content">
<?php
		get_template_part( 'content-empty' );
?>
	</div>
<?php
	}

	wp_reset_postdata();

	get_footer();
