<?php
/**
 * Template Name: Contributor Page
 *
 * @package Monet
 */

	get_header();

	get_template_part( 'inc/featured-content' );

	if ( have_posts() ) {
?>
	<div class="main-content">
<?php
		while ( have_posts() ) {
			the_post();
?>
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

			<div class="entry-single">

				<header class="entry-header">
<?php
			the_title( '<h1 class="entry-title">', '</h1>' );
?>
				</header>

				<section class="entry">
<?php
			the_content();
			edit_post_link( '<span class="screen-reader-text">' . esc_html__( 'Edit This', 'monet' ) . '</span>' );
?>
				</section>

			</div>

		</article>
<?php
			get_template_part( 'content-contributors' );

			if ( comments_open() || get_comments_number() > 0 ) {
				comments_template( '', true );
			}
		}
?>
	</div>
<?php
	} else {
		get_template_part( 'content-empty' );
	} // End if().

	get_footer();
