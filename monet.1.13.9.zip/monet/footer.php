<?php
/**
 * Footer Template
 *
 * @package Monet
 */

?>
		<footer role="contentinfo" id="footer">
<?php

	/**
	 * Check to see if a custom credits option is set.
	 * If custom credits are set then the filter should output the credits and
	 * return a non false value. This will hide the default footer credits.
	 */
	if ( false === apply_filters( 'monet_credits', false ) ) {

?>
			<section class="footer-wrap">
<?php
		if ( function_exists( 'the_privacy_policy_link' ) ) {
			the_privacy_policy_link( '', '<span class="sep"> | </span>' );
		}
?>
				<a href="http://wordpress.org/" title="<?php esc_attr_e( 'A Semantic Personal Publishing Platform', 'monet' ); ?>" rel="generator"><?php printf( esc_html__( 'Proudly powered by %s', 'monet' ), 'WordPress' ); ?></a>
				<span class="sep"> | </span>
				<?php printf( esc_html__( 'Theme: %1$s by %2$s.', 'monet' ), 'Monet', '<a href="https://prothemedesign.com/" rel="designer">Pro Theme Design</a>' ); ?>
			</section>
<?php

	}

?>
		</footer>
	</div>

	<section id="minor-sidebar">
<?php
	if ( monet_sidebar_menu_active() ) {
?>
		<div class="sidebar-footer-toggle">
			<a href="#"><span class="screen-reader-text"><?php esc_html_e( 'Toggle Widgets', 'monet' ); ?></span></a>
		</div>
<?php
	}

	monet_social_links();
?>
	</section>

</div>


<?php wp_footer(); ?>

</body>
</html>
