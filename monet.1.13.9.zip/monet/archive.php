<?php
/**
 * Archive Template
 *
 * @package Monet
 */

	get_header();

	if ( have_posts() ) {
?>
	<header class="entry-archive-header">
<?php
		the_archive_title( '<h1 class="entry-title entry-archive-title">', '</h1>' );
		the_archive_description( '<div class="category-description">', '</div>' );
?>
	</header>
<?php
	if ( 'jetpack-portfolio' === get_post_type() ) {
		monet_project_terms();
	}
?>
	<div id="main-content" class="main-content post-archive">
<?php
		while ( have_posts() ) {
			the_post();
			get_template_part( 'content', get_post_format() );
		}

		the_posts_pagination();
?>
	</div>
<?php
	} else {
?>
	<div id="main-content" class="main-content">
<?php
		get_template_part( 'content-empty' );
?>
	</div>
<?php
	}

	get_footer();
