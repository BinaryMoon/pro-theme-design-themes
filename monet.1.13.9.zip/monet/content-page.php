<?php
/**
 * Page content
 *
 * @package Monet
 */

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<div class="entry-single">

		<header class="entry-header">
<?php
	the_title( '<h1 class="entry-title">', '</h1>' );
?>
		</header>

		<section class="entry">
<?php
	the_content();

	edit_post_link( '<span class="screen-reader-text">' . esc_html__( 'Edit This', 'monet' ) . '</span>' );

	wp_link_pages(
		array(
			'before' => '<div class="pagination">',
			'after'  => '</div>',
			'link_before' => '<span>',
			'link_after'  => '</span>',
		)
	);
?>
		</section>

	</div>

</article>
