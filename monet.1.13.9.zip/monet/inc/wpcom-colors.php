<?php
/* Custom Colors: Monet */

//Background
add_color_rule( 'bg', '#ffffff', array(
	// White
	array( 'table tr:nth-child(odd)', 'background-color' ),
	array( '#wp-calendar th,
			#wp-calendar caption', 'background-color'
	),
	array( 'ol.comment-list li.comment.bypostauthor,
			ol.comment-list li.trackback.bypostauthor,
			ol.comment-list li.pingback.bypostauthor', 'background-color'
	),
	array( '.masthead', 'background-color' ),
	array( '.secondary-masthead', 'background-color' ),
	array( '.content-comments ol.comment-list', 'border-bottom-color' ),
	array( '.content-comments ol.comment-list li.comment,
			.content-comments ol.comment-list li.trackback,
			.content-comments ol.comment-list li.pingback', 'border-top-color'
	),
	array( '.content-comments #respond p.comment-form-author input:active,
			.content-comments #respond p.comment-form-email input:active,
			.content-comments #respond p.comment-form-comment input:active,
			.content-comments #respond p.comment-form-url input:active,
			.content-comments #respond p.comment-form-author textarea:active,
			.content-comments #respond p.comment-form-email textarea:active,
			.content-comments #respond p.comment-form-comment textarea:active,
			.content-comments #respond p.comment-form-url textarea:active,
			.content-comments #respond p.comment-form-author input:focus,
			.content-comments #respond p.comment-form-email input:focus,
			.content-comments #respond p.comment-form-comment input:focus,
			.content-comments #respond p.comment-form-url input:focus,
			.content-comments #respond p.comment-form-author textarea:focus,
			.content-comments #respond p.comment-form-email textarea:focus,
			.content-comments #respond p.comment-form-comment textarea:focus,
			.content-comments #respond p.comment-form-url textarea:focus', 'background-color'
	),
	array( '.showcase .arrow.arrow-next:before', 'border-left-color' ),
	array( '.showcase .arrow.arrow-prev:before', 'border-right-color' ),
	array( '.showcase nav a.selected', 'background-color' ),
	array( '.showcase nav a:hover', 'background-color' ),
	array( '.testimonials-wrapper .testimonial .entry', 'background-color' ),
	array( '.testimonials-wrapper .testimonial .entry:after', 'border-top-color' ),
	array( '.sidebar-main .column', 'border-right-color' ),
	array( '#minor-sidebar', 'background-color' ),
	array( '.main .contributor', 'border-top-color' ),
	array( '.project-terms', 'border-top-color' ),
	array( 'table', 'border-top-color' ),
	array( 'table tr', 'border-bottom-color' ),

	// Off-White (#fcfcfc)
	array( 'table tr:nth-child(even)', 'background-color', '-0.5' ),
	array( '#minor-sidebar .sidebar-footer-toggle a.selected:before', 'background-color', '-0.4' ),
	array( '.sidebar-main', 'background-color', '-0.4' ),
	array( '.no-results .entry-single .post-meta-data,
			.single-attachment .entry-single .post-meta-data,
			.error404 .entry-single .post-meta-data,
			.singular .entry-single .post-meta-data', 'background-color'
	),

	// Light Grey (#7f7f7f)
	array( '.main .pagination span.current', 'background-color' ),
	array( 'form.search-form button.search-submit', 'color', 'bg' ),

	// Light Grey (#f2f2f2)
	array( 'q', 'background-color', '-0.7' ),
	array( 'blockquote', 'background-color', '-0.7' ),
	array( '.wp-caption', 'background-color', '-0.7' ),
	array( '#wp-calendar th', 'border-bottom-color', '-0.7' ),
	array( '.post-password-required form', 'background-color', '-0.7' ),
	array( 'a.post-edit-link', 'background-color', '-0.7' ),
	array( '.screen-reader-text:focus,
			.screen-reader:focus', 'background-color', '-0.7'
	),
	array( 'body', 'background-color', '-0.7' ),
	array( '.writer', 'background-color', '-0.7' ),
	array( '#minor-sidebar .menu-social-links a:before', 'border-bottom-color', '-0.7' ),
	array( '#minor-sidebar .sidebar-footer-toggle a:before', 'border-bottom-color', '-0.7' ),

	// Alt Light Grey (#adb1b4)
	array( '.main .post-archive article.format-video,
			.main .post-archive article.format-aside,
			.main .post-archive article.format-audio,
			.main .post-archive article.format-quote,
			.main .post-archive article.format-link', 'background-color', '-0.6'
	),
	array( '.main .post-archive article.format-video.post-no-thumbnail h2.entry-title:after,
			.main .post-archive article.format-aside.post-no-thumbnail h2.entry-title:after,
			.main .post-archive article.format-audio.post-no-thumbnail h2.entry-title:after,
			.main .post-archive article.format-quote.post-no-thumbnail h2.entry-title:after,
			.main .post-archive article.format-link.post-no-thumbnail h2.entry-title:after', 'background-color', '-0.6'
	),

	// Dark Grey (#5e5e5e)
	array( '.main .post-archive article', 'background-color', '-1' ),
	array( '.sidebar-main .widget:before', 'border-top-color', '-1' ),
),
__( 'Background' ) );

add_color_rule( 'txt', '#808080', array(
	// Borders & Backgrounds
	array( '.no-results .featured-image,
			.single-attachment .featured-image,
			.error404 .featured-image,
			.singular .featured-image', 'background-color'
	),
	array( 'a.post-edit-link:hover', 'background-color' ),

	// Text Colors
	array( 'body,
			html', 'color', 'bg'
	),
	array( '.wp-caption .wp-caption-text', 'color', 'bg' ),
	array( '.masthead .branding p.site-description', 'color', 'bg' ),
	array( 'a.post-edit-link:hover', 'color', 'bg' ),
	array( '.no-results .entry-single,
			.single-attachment .entry-single,
			.error404 .entry-single,
			.singular .entry-single', 'color', 'bg'
	),
	array( '.sidebar-main .widget', 'color', 'bg' ),
	array( '.main article .taxonomies', 'color', 'bg' ),
	array( '.main .post-archive article .post-meta-data', 'color', 'bg' ),

	// Site Description
	array( '.masthead h2.site-description', 'color', 'bg'),

	// Global Headers
	array( 'h1,
			h2,
			h3,
			h4,
			h5,
			h6', 'color', 'bg'
	),
),
__( 'Text' ) );

add_color_rule( 'link', '#000000', array(
	// Borders & Backgrounds
	array( '.masthead .menu ul a.menu-back:before,
			.masthead .menu ul a.menu-expand:before', 'border-left-color', 'bg'
	),
	array( '.masthead .menu ul a.menu-back:before', 'border-right-color', 'bg' ),
	array( '.masthead .menu ul a.menu-back:hover:before,
			.masthead .menu ul a.menu-expand:hover:before', 'border-left-color', '-0.7'
	),
	array( '.masthead .menu ul a.menu-back:hover:before', 'border-right-color', 'bg', '-0.7' ),

	// Text Colors
	array( 'a', 'color', 'bg' ),
	array( '.widget.widget_nav_menu .menu', 'background-color', 'bg' ),
	array( '.sidebar-main .widget h3.widgettitle', 'color', 'bg' ),
	array( '.masthead .menu a', 'color', 'bg' ),
	array( '#minor-sidebar .sidebar-footer-toggle a:before', 'color', 'bg' ),
	array( '.masthead .menu ul a.menu-back,
			.masthead .menu ul a.menu-expand', 'color', 'bg'
	),
	array( '.main .post-archive article h2.entry-title a', 'color', 'bg' ),
	array( '.sidebar-main .widget a,
			.sidebar .widget a,
			.sidebar .widget', 'color', 'bg' ),
	array( 'select', 'color', 'bg' ),
	array( '.main .post-archive article .post-meta-data a', 'color', 'bg', 0.8 ),
	array( '.post-meta-data a', 'color', 'bg' ),

	// Hover States
	array( '.masthead .menu a:hover', 'color', 'bg' ),
	array( '.masthead .menu ul a.menu-back:hover,
			.masthead .menu ul a.menu-expand:hover', 'color', 'bg'
	),
	array( '.masthead .menu ul a.menu-back:hover:before,
			.masthead .menu ul a.menu-expand:hover:before', 'color', 'bg'
	),
	array( '.masthead .menu ul a.menu-back:hover:before', 'color', 'bg' ),
	array( '.masthead .menu-close:hover:before', 'color', 'bg' ),
	array( '.secondary-masthead a.menu-toggle:hover:before', 'color', 'bg' ),
	array( '.showcase .arrow:hover', 'color', 'bg' ),
	array( '#minor-sidebar .menu-social-links a:hover:before', 'color', 'bg' ),
	array( '#minor-sidebar .menu-social-links a:before', 'color', 'bg' ),
	array( '#minor-sidebar .sidebar-footer-toggle a:hover:before', 'color', '-0.5' ),

	// Site Title
	array( '.masthead .branding h1.site-title a,
			.masthead .branding h1.site-title a:hover,
			.masthead .branding p.site-description,
			.sidebar .widget h3.widgettitle', 'color', 'bg'
	),

	//Contrast with dark post hover background
	array( '.main .post-archive article.post-has-thumbnail:hover .post-meta-data a', 'color', '#5E5E5E' ),
	array( '.main .post-archive article.post-has-thumbnail:hover h2.entry-title a', 'color', '#5E5E5E' ),
),
__( 'Links' ) );

add_color_rule( 'extra', '#ffffff', array(
	array( '::selection,
			::-moz-selection', 'color', '#7f7f7f'
	),
	array( 'input[type=submit]', 'color', 'bg' ),
	array( 'input[type=submit]:hover', 'color', '#7f7f7f' ),
	array( '.infinite-scroll #infinite-handle span', 'color', 'bg' ),
	array( '.infinite-scroll #infinite-handle span:hover', 'color', '#7f7f7f' ),
	array( '.widget.widget_nav_menu .menu .menu-toggle', 'color', '#000000' ),
	array( '.widget.widget_nav_menu .menu ul ul li a,
			.widget.widget_nav_menu .menu li ul li a,
			.widget.widget_nav_menu .menu ul li a,
			.widget.widget_nav_menu .menu li li a,
			.widget.widget_nav_menu .menu ul a,
			.widget.widget_nav_menu .menu li a', 'color', '#000000'
	),
	array( '.widget.widget_nav_menu .menu ul ul li a:hover,
			.widget.widget_nav_menu .menu li ul li a:hover,
			.widget.widget_nav_menu .menu ul li a:hover,
			.widget.widget_nav_menu .menu li li a:hover,
			.widget.widget_nav_menu .menu ul a:hover,
			.widget.widget_nav_menu .menu li a:hover', 'color', '#000000'
	),
	array( '.screen-reader-shortcut', 'color', '#7f7f7f' ),
	array( '.main .contributor a.contributor-posts-link', 'color', 'bg' ),
	array( '.main .contributor a.contributor-posts-link:hover', 'color', '#7f7f7f' ),
	array( 'ol.comment-list li.comment #respond #cancel-comment-reply-link,
			ol.comment-list li.trackback #respond #cancel-comment-reply-link,
			ol.comment-list li.pingback #respond #cancel-comment-reply-link', 'color', 'bg'
	),
	array( 'ol.comment-list li.comment #respond #cancel-comment-reply-link:hover,
			ol.comment-list li.trackback #respond #cancel-comment-reply-link:hover,
			ol.comment-list li.pingback #respond #cancel-comment-reply-link:hover', 'color', '#7f7f7f'
	),
	array( '#respond p.form-submit #submit', 'color', 'bg' ),
	array( '#respond p.form-submit #submit:hover', 'color', '#7f7f7f' ),
	array( '.main .pagination span.current', 'color', '#7f7f7f' ),
	array( '.main .comments-navigation .nav-previous a:before,
			.main .post-navigation .nav-previous a:before,
			.main .comments-navigation .nav-next a:before,
			.main .post-navigation .nav-next a:before', 'color', 'bg'
	),
	array( 'a.post-edit-link:before', 'color', '#b3b3b3' ),
) );

add_color_rule( 'extra', '#cccccc', array(
	array( '.main article .taxonomies, .post-meta-data', 'color', 'bg' ),
) );


//Additional palettes
add_color_palette( array(
    '#e0eff1',
    '#7db4b5',
    '#146362',
), 'Palette 1' );


add_color_palette( array(
    '#ecd078',
    '#d95b43',
    '#c02942',
), 'Palette 2' );

add_color_palette( array(
    '#805841',
    '#dcf7f3',
    '#fffcdd',
), 'Palette 3' );

//Extra CSS
function monet_extra_css() { ?>
	.main .comments-navigation,
	.main .post-navigation {
		background: rgba(255, 255, 255, 0.2);
	}
	.masthead .menu {
		background: transparent;
	}
	.masthead .menu ul a.menu-back:before,
	.masthead .menu ul a.menu-back:hover:before {
		border-left-color: transparent !important;
	}
	.main .post-archive article.has-post-thumbnail:hover h2.entry-title a {
		color: #e6e6e6;
	}
	.main .post-archive article.has-post-thumbnail:hover .post-meta-data {
		color: rgba(255, 255, 255, 0.5);
	}
	.sidebar .widget:before {
		border-top: 2px solid rgba(0, 0, 0, 0.05);
	}
<?php }
add_theme_support( 'custom_colors_extra_css', 'monet_extra_css' );
