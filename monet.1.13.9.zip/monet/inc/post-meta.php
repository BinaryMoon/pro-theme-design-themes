<?php
/**
 * Post meta data
 *
 * @package Monet
 */

?>
	<div class="post-meta-data">
<?php
	monet_post_time();

	monet_comments_link();

	monet_post_author();

	monet_the_main_category();
?>
	</div>
