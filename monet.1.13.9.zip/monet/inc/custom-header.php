<?php
/**
 * Custom header codes
 *
 * @package Monet
 */

/**
 * Custom header image
 */
function monet_custom_header_support() {

	// Custom header image.
	$args = array(
		'default-image' => '%s/images/background.jpg',
		'default-text-color' => '7f7f7f',
		'random-default' => false,
		'width' => 600,
		'height' => 800,
		'flex-height' => true,
		'header-text' => true,
		'uploads' => true,
		'wp-head-callback' => 'monet_colour_styles',
	);

	add_theme_support(
		'custom-header',
		apply_filters( 'monet_custom_header', $args )
	);

}

add_action( 'after_setup_theme', 'monet_custom_header_support' );


/**
 * Print custom header styles
 *
 * @return array
 */
function monet_colour_styles() {

?>
<style>
<?php
	if ( 'blank' === get_header_textcolor() ) {
?>
	.masthead h1.site-title,
	.masthead .site-description { display:none; }
<?php
	} else {
?>
	.masthead .branding h1.site-title a,
	.masthead .branding h1.site-title a:hover,
	.masthead .branding p.site-description {
		color:#<?php echo esc_attr( get_header_textcolor() ); ?>;
	}
<?php
	}

	$header_image = get_header_image();

	if ( $header_image ) {
?>
	.masthead {
		background-image:url(<?php echo esc_url( $header_image ); ?>);
	}
<?php
	}
?>
</style>
<?php

	return true;

}
