<?php
/**
 * Post terms
 *
 * @package Monet
 */

	if ( 'post' === get_post_type( get_the_ID() ) ) {
?>
		<p class="taxonomies">
<?php
	echo '<span class="tax tax-categories">';
	esc_html_e( 'Categories: ', 'monet' );
	echo get_the_category_list( _x( ', ', 'Category/ Tag list separator (includes a space after the comma)', 'monet' ) );
	echo '</span>';

	if ( get_the_tags() ) {
		echo '<span class="tax tax-tags">';
		echo get_the_tag_list( esc_html__( 'Tags: ', 'monet' ), _x( ', ', 'Category/ Tag list separator (includes a space after the comma)', 'monet' ), '' );
		echo '</span>';
	}
?>
		</p>
<?php
	}
