<?php
/**
 * Jetpack Compatibility File
 * See: http://jetpack.me/
 *
 * @package Monet
 */

/**
 * Add theme support for Infinite Scroll.
 * See: http://jetpack.me/support/infinite-scroll/
 */
function monet_jetpack_init() {

	add_theme_support(
		'infinite-scroll',
		array(
			'container' => 'main-content',
			'footer_widgets' => monet_can_infinite_scroll(),
			'footer' => false,
			'posts_per_page' => 16,
			'wrapper' => false,
		)
	);

	add_theme_support(
		'featured-content',
		array(
			'featured_content_filter' => 'monet_get_featured_posts',
			'max_posts' => 5,
			'post_types' => array( 'post', 'page', 'jetpack-portfolio' ),
		)
	);

	add_theme_support( 'jetpack-responsive-videos' );

	// Add support for Portfolio and Projects.
	add_theme_support( 'jetpack-portfolio' );

	add_theme_support(
		'site-logo',
		array(
			'size' => 'monet-logo',
		)
	);

	// Add support for Jetpack content options.
	add_theme_support(
		'jetpack-content-options',
		array(
			'author-bio' => true,
			'author-bio-default' => false,
			'masonry' => '#main-content',
			'post-details' => array(
				'stylesheet' => 'monet-style',
				'date' => '.posted-on',
				'categories' => '.tax-categories',
				'tags' => '.tax-tags',
				'author' => '.byline',
			),
		)
	);

}

add_action( 'after_setup_theme', 'monet_jetpack_init' );


/**
 * Get featured posts using Jetpack Featured content
 */
function monet_get_featured_posts() {

	return apply_filters( 'monet_get_featured_posts', array() );

}


/**
 * Check if Jetpack Featured Content has any featured posts available
 *
 * @param int $minimum Minimum number of posts that can be displayed.
 * @return boolean
 */
function monet_has_featured_posts( $minimum = 1 ) {

	if ( is_paged() ) {
		return false;
	}

	if ( ! is_home() ) {
		return false;
	}

	$minimum = absint( $minimum );
	$featured_posts = apply_filters( 'monet_get_featured_posts', array() );

	if ( ! is_array( $featured_posts ) ) {
		return false;
	}

	if ( $minimum > count( $featured_posts ) ) {
		return false;
	}

	return true;

}


/**
 * Can jetpack enable the auto loading infinite scroll
 */
function monet_can_infinite_scroll() {

	if ( function_exists( 'jetpack_is_mobile' ) && jetpack_is_mobile() ) {
		return true;
	}

	return false;

}


/**
 * Change default jetpack infinite scroll setttings
 *
 * @param array $settings List of infinite scroll settings.
 * @return array
 */
function monet_infinite_scroll_js_settings( $settings ) {

	$settings['text'] = esc_html__( 'More Posts', 'monet' );

	return $settings;

}

add_filter( 'infinite_scroll_js_settings', 'monet_infinite_scroll_js_settings' );


/**
 * The function to display Author Bio in a theme.
 */
function monet_author_bio() {

	$options = get_theme_support( 'jetpack-content-options' );
	$author_bio = null;

	if ( ! empty( $options[0]['author-bio'] ) ) {
		$author_bio = $options[0]['author-bio'];
	}

	// If the theme doesn't support "jetpack-content-options['author-bio']", don't continue.
	if ( true !== $author_bio ) {
		return;
	}

	// If "jetpack_content_author_bio" is false and we aren't in the customizer, don't continue.
	if ( ! get_option( 'jetpack_content_author_bio', 1 ) ) {
		return;
	}

	// If we aren't on a single post, don't continue.
	if ( ! is_single() ) {
		return;
	}

	// Display the author bio.
	monet_contributor();

}
