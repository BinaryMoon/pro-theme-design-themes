<?php
/**
 * Display more Jetpack Portfolio Items
 *
 * @package Monet
 */

	$projects = new WP_Query(
		array(
			'post_type' => 'jetpack-portfolio',
			'post__not_in' => array( get_the_ID() ),
			'posts_per_page' => 6,
			'order' => 'ASC',
		)
	);

	if ( $projects->have_posts() ) {
?>
	<header class="entry-header entry-header-portfolio">
		<h1 class="entry-title">
			<a href="<?php echo esc_url( site_url( '/portfolio/' ) ); ?>"><?php esc_html_e( 'More from Portfolio', 'monet' ); ?></a>
		</h1>
	</header>

	<div id="main-content" class="post-archive">
<?php
		while ( $projects->have_posts() ) {
			$projects->the_post();
			get_template_part( 'content', get_post_format() );
		}
?>
	</div>
<?php
	}

	wp_reset_postdata();
