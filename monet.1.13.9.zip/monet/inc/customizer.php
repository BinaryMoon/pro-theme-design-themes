<?php
/**
 * Theme Customizer
 *
 * @package Monet
 */

if ( ! class_exists( 'WP_Customize_Control' ) ) {
	return null;
}

/**
 * Theme customizer properties
 *
 * @param object $wp_customize Customizer object.
 */
function monet_customizer_settings( $wp_customize ) {

	// Monet theme options section.
	$wp_customize->add_section(
		'monet_options',
		array(
			'title' => esc_html__( 'Theme Options', 'monet' ),
			'description' => esc_html__( 'Options for the Monet theme.', 'monet' ),
		)
	);

	// ---
	// Setting to allow the categories under the header to be hidden
	$wp_customize->add_setting(
		'monet_blog_featured_image',
		array(
			'default' => false,
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'monet_sanitize_checkboxes',
		)
	);

	// Control for hiding the category list under the header.
	$wp_customize->add_control(
		'monet_blog_featured_image',
		array(
			'label' => esc_html__( 'Hide Featured Image on Blog Post', 'monet' ),
			'section' => 'monet_options',
			'type' => 'checkbox',
		)
	);

	// ---
	// Setting to select the current menu item when changing page.
	$wp_customize->add_setting(
		'monet_highlight_submenu',
		array(
			'default' => false,
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'monet_sanitize_checkboxes',
		)
	);

	// Control for hiding the category list under the header.
	$wp_customize->add_control(
		'monet_highlight_submenu',
		array(
			'label' => esc_html__( 'Highlight submenu item when visiting page on submenu.', 'monet' ),
			'section' => 'monet_options',
			'type' => 'checkbox',
		)
	);

}




/**
 * Update Theme Elements without refreshing content.
 *
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function monet_register_customize_refresh( WP_Customize_Manager $wp_customize ) {

	// Ensure selective refresh is enabled.
	if ( ! isset( $wp_customize->selective_refresh ) ) {

		return false;

	}

	// Update site title.
	$wp_customize->get_setting( 'blogname' )->transport = 'postMessage';

	$wp_customize->selective_refresh->add_partial(
		'blogname',
		array(
			'selector' => '.site-title',
			'render_callback' => function() {
				bloginfo( 'name' );
			},
		)
	);

	// Update site description.
	$wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';

	$wp_customize->selective_refresh->add_partial(
		'blogdescription',
		array(
			'selector' => '.site-description',
			'render_callback' => function() {
				bloginfo( 'description' );
			},
		)
	);

	// Show and hide header text.
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

}

add_action( 'customize_register', 'monet_register_customize_refresh' );


/**
 * Binds JS handlers to make the Customizer preview reload changes asynchronously.
 */
function monet_customize_preview_js() {

	wp_enqueue_script( 'monet-customize-preview', get_theme_file_uri( '/js/customize-preview.js' ), array( 'customize-preview' ), '1.0', true );

}

add_action( 'customize_preview_init', 'monet_customize_preview_js' );


/**
 * Sanitize checkbox
 *
 * @param int $setting Value to check.
 * @return boolean
 */
function monet_sanitize_checkboxes( $setting ) {

	return (bool) $setting;

}


add_action( 'customize_register', 'monet_customizer_settings' );
