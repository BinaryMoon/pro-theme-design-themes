<?php
/**
 * Jetpack Featured Content
 * See: http://jetpack.me/support/featured-content/
 *
 * @package Monet
 */

	if ( monet_has_featured_posts() ) {

		$featured_posts = monet_get_featured_posts( 5 );

?>
	<section class="showcase post-archive">
<?php
		foreach ( $featured_posts as $post ) {
			setup_postdata( $post );

			get_template_part( 'content-featured' );
		}
?>
	</section>
<?php
		wp_reset_postdata();

	}
