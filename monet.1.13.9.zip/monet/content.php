<?php
/**
 * Generic content
 *
 * @package Monet
 */

	$image = get_the_post_thumbnail( get_the_ID(), 'monet-archive' );
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<a href="<?php the_permalink(); ?>" class="permalink"><span class="screen-reader-text"><?php the_title(); ?></span></a>
<?php
	if ( $image ) {
?>
	<a href="<?php echo esc_url( get_permalink() ); ?>" class="thumbnail">
		<?php echo $image; ?>
	</a>
<?php
	}
?>
	<section class="entry entry-archive">

<?php
	get_template_part( 'inc/post-meta' );

	if ( get_the_title() ) {
?>
		<h2 class="entry-title">
			<a href="<?php the_permalink(); ?>" rel="bookmark">
				<?php the_title(); ?>
			</a>
		</h2>
<?php
	} else {
?>
		<h2 class="entry-title">
			<?php the_time(); ?>
		</h2>
<?php
	}
?>
		<div class="excerpt">
			<?php echo wpautop( get_the_excerpt() ); ?>
		</div>

	</section>

</article>
