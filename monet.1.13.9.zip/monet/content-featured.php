<?php
/**
 * Generic content
 *
 * @package Monet
 */

	$styles = array();
	$image = monet_archive_image_url( get_the_ID(), 'monet-featured' );
	if ( $image[0] ) {
		$styles = array(
			'background-image:url(' . esc_url( $image[0] ) . ');',
		);
	}
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<a href="<?php the_permalink(); ?>" class="permalink thumbnail" style="<?php echo esc_attr( implode( ' ', $styles ) ); ?>"><span class="screen-reader-text"><?php the_title(); ?></span></a>
	<section class="entry entry-archive">
<?php
	get_template_part( 'inc/post-meta' );

	if ( get_the_title() ) {
?>
		<h2 class="entry-title">
			<a href="<?php the_permalink(); ?>" rel="bookmark">
				<?php the_title(); ?>
			</a>
		</h2>
<?php
	}
?>
		<div class="excerpt">
			<?php echo wpautop( get_the_excerpt() ); ?>
		</div>

	</section>

</article>
