<?php
/**
 * Single post content
 *
 * @package Monet
 */

	if ( true !== get_theme_mod( 'monet_blog_featured_image' ) && get_the_post_thumbnail( get_the_ID(), 'monet-featured' ) ) {
		echo '<div class="featured-image">';
		the_post_thumbnail( 'monet-featured' );
		echo '</div>';
	}
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<div class="entry-single">

		<header class="entry-header">
<?php
	the_title( '<h1 class="entry-title">', '</h1>' );
	get_template_part( 'inc/post-meta' );
?>
		</header>

		<section class="entry">
<?php
	the_content();

	edit_post_link( '<span class="screen-reader-text">' . esc_html__( 'Edit This', 'monet' ) . '</span>' );

	wp_link_pages(
		array(
			'before' => '<div class="pagination">',
			'after'  => '</div>',
			'link_before' => '<span>',
			'link_after'  => '</span>',
		)
	);

	get_template_part( 'inc/post-terms' );

?>
		</section>

	</div>

</article>

<?php
	monet_author_bio();

	the_post_navigation(
		array(
			'prev_text' => '<span>%title</span>',
			'next_text' => '<span>%title</span>',
		)
	);
