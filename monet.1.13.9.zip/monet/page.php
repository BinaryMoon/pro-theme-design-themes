<?php
/**
 * Single page template
 *
 * @package Monet
 */

	get_header();

	get_template_part( 'inc/jetpack-featured-content' );

?>
	<div class="main-content">
<?php

	if ( have_posts() ) {

		while ( have_posts() ) {
			the_post();
			get_template_part( 'content-page' );
			get_template_part( 'inc/comments' );
		}
	} else {
		get_template_part( 'content-empty' );
	}

?>
	</div>
<?php

	get_footer();
