<?php
/**
 * Comments template.
 *
 * @package Monet
 */

	if ( post_password_required() ) {
		return;
	}
?>
<section class="content-comments">
<?php
	if ( have_comments() ) {
?>
	<h3 id="comments">
<?php
		printf(
			_n( '1 Comment', '%1$s Comments', get_comments_number(), 'monet' ),
			number_format_i18n( get_comments_number() ),
			'<span>' . get_the_title() . '</span>'
		);
?>
	</h3>

	<ol class="comment-list" id="singlecomments">
<?php
		wp_list_comments(
			array(
				'avatar_size' => 80,
				'short_ping' => true,
				'callback' => 'monet_comments_layout',
			)
		);
?>
	</ol>
<?php
		if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) {
?>
	<nav class="navigation comments-navigation">
		<h1 class="screen-reader"><?php esc_html_e( 'Comment navigation', 'monet' ); ?></h1>
		<div class="nav-links">
			<div class="nav-previous">
				<?php previous_comments_link( esc_html__( 'Older Comments', 'monet' ) ); ?>
			</div>
			<div class="nav-next">
				<?php next_comments_link( esc_html__( 'Newer Comments', 'monet' ) ); ?>
			</div>
		</div>
	</nav>
<?php
		}
	} // End if().

	if ( 'open' === $post->comment_status ) {
		comment_form();
	}
?>
</section>
