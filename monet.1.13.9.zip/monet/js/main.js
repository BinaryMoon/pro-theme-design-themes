/**
 * main.js v1
 * Created by Ben Gillbanks <http://www.binarymoon.co.uk/>
 * Available under GPL2 license
 */

; ( function( $ ) {

	function is_touch_device() {
		return ( ( 'ontouchstart' in window ) || ( navigator.MaxTouchPoints > 0 ) || ( navigator.msMaxTouchPoints > 0 ) );
	}

	$( document ).ready( function() {

		// attachment page navigation
		if ( $( 'body' ).hasClass( 'attachment' ) ) {

			$( document ).keydown(
				function( e ) {

					if ( $( 'textarea, input' ).is( ':focus' ) ) {
						return;
					}

					var url = false;

					switch ( e.which ) {
						// left arrow key (previous attachment)
						case 37:
							url = $( '.image-previous a' ).attr( 'href' );
							break;

						// right arrow key (next attachment)
						case 39:
							url = $( '.image-next a' ).attr( 'href' );
							break;

					}

					if ( url ) {
						window.location = url;
					}
				}
			);

		}

		$( window ).on(
			'load',
			function() {

				if ( typeof $.fn.masonry === 'function' ) {

					var $grid;

					$grid = $( '#main-content' ).masonry(
						{
							gutter: 0,
							itemSelector: 'article',
							isOriginLeft: !$( 'body' ).is( '.rtl' )
						}
					);

					$grid.imagesLoaded(
						function() {
							$grid.masonry( 'layout' );
							$grid.children().addClass( 'post-loaded' );
						}
					);

					$( 'body' ).on(
						'post-load',
						function() {

							var $new_articles = $( '#main-content' ).children().not( '.post-loaded' ).addClass( 'post-loaded' );
							$grid.masonry( 'appended', $new_articles );

							$grid.imagesLoaded(
								function() {
									$grid.masonry( 'layout' );
								}
							);

						}
					);
				}

			}
		);

		if ( typeof $.fn.elementalSlides === 'function' ) {

			$( '.showcase' ).elementalSlides(
				{
					'nav_arrows': true
				}
			);
		}

		// open and close sidebar menu on mobile devices
		$( '.menu-toggle' ).on(
			'click',
			function( e ) {
				e.preventDefault();
				$( 'body' ).addClass( 'menu-on' );
			}
		);

		$( '.menu-close' ).on(
			'click',
			function( e ) {
				e.preventDefault();
				$( 'body' ).removeClass( 'menu-on' );
			}
		);

		// expandable menus
		var expand_link = $( '<a class="menu-expand"><span class="screen-reader-text">' + js_i18n.next + '</span></a>' );
		var back_link = $( '<li><a class="menu-back">' + js_i18n.back + '</a></li>' );

		$( '.menu ul.menu-wrap' ).data( 'depth', 0 );
		$( '.menu ul.menu-wrap ul' ).data( 'depth', 1 );
		$( '.menu ul.menu-wrap ul ul' ).data( 'depth', 2 );
		$( '.menu ul.menu-wrap ul ul ul' ).data( 'depth', 3 );
		$( '.menu ul.menu-wrap ul ul ul ul' ).data( 'depth', 4 );
		$( '.menu ul.menu-wrap ul ul ul ul ul' ).data( 'depth', 5 );

		$( '.menu li.menu-item-has-children > a' ).after( expand_link );
		$( '.menu .sub-menu' ).prepend( back_link );
		$( '.menu .sub-menu' ).hide();


		// Check to see if we are on a page that has a menu item so that we can
		// automatically select the sub menu when the page loads.
		// Ignore the homepage. That should always use the default menu.
		// Only enabled if the option is checked in the Customizer.
		if ( '1' === js_i18n.select_submenu ) {

			menu_level_up( $( '.masthead #nav .current-menu-item' ).parent( 'ul' ) );

		}

		// Go up a menu level.
		$( 'a.menu-back' ).on(
			'click',
			function() {
				var parent_ul = $( this ).closest( 'ul' );
				menu_level_down( parent_ul );
				return false;
			}
		);

		// Go down a menu level.
		$( '.menu-item-has-children a:not([href], .menu-back), .menu-item-has-children a[href="#"]' ).on(
			'click',
			function() {
				var parent_ul = $( this ).parent().find( 'ul:first' );
				menu_level_up( parent_ul );
				return false;
			}
		);


		/**
		 * Move the menu to the next level.
		 */
		function menu_level_up( $parent_ul ) {

			var old_depth = $( '.menu ul.menu-wrap' ).data( 'depth' );
			var new_depth = $parent_ul.data( 'depth' );

			$parent_ul.show();

			// Ensure that all the parent menus are visible.
			var $parent = $parent_ul;
			for ( var i = 1; i < new_depth; i++ ) {
				$parent = $parent.parent( 'li' ).parent( 'ul' )
				$parent.show();
			}

			$( '.sidebar-header' ).addClass( 'disabled' );

			$( '.menu ul.menu-wrap' ).data( 'depth', new_depth )
				.addClass( 'depth-' + new_depth )
				.removeClass( 'depth-' + old_depth );

		}


		/**
		 * Move the menu down a level.
		 */
		function menu_level_down( parent_ul ) {

			var depth = $( '.menu ul' ).data( 'depth' );
			var old_depth = depth;
			var new_depth = depth - 1;

			parent_ul.hide( 250 );

			if ( new_depth <= 0 ) {
				new_depth = 0;
				$( '.sidebar-header' ).removeClass( 'disabled' );
			}

			$( '.menu ul.menu-wrap' ).data( 'depth', new_depth )
				.addClass( 'depth-' + new_depth )
				.removeClass( 'depth-' + old_depth );

		}

		// display widgets
		$( '.sidebar-footer-toggle a' ).on( 'click', function() {

			$( '.sidebar-main' ).slideToggle();
			$( '.sidebar-footer-toggle a' ).toggleClass( 'selected' );

			setTimeout(
				function() {

					// Remove any media elements currently initialised.
					$( '.sidebar-main .mejs-container' ).each(
						function( i, el ) {
							if ( mejs.players[ el.id ] ) {
								mejs.players[ el.id ].remove();
							}
						}
					);

					// Initialize overlay.
					if ( window.wp && window.wp.mediaelement ) {
						window.wp.mediaelement.initialize();
					}

					// Trigger window resize event to fix video size issues.
					// Don't use jqueries trigger event since that only triggers
					// methods hooked to events, and not the events themselves.
					if ( typeof ( Event ) === 'function' ) {
						window.dispatchEvent( new Event( 'resize' ) );
					} else {
						var event = window.document.createEvent( 'UIEvents' );
						event.initUIEvent( 'resize', true, false, window, 0 );
						window.dispatchEvent( event );
					}

				},
				250
			);

		} );

		$( 'body' ).addClass( is_touch_device() ? 'device-touch' : 'device-click' );

	} );

} )( jQuery );
