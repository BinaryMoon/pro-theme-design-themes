<?php
/**
 * Post terms
 *
 * @package Puzzle
 */
?>
		<div class="taxonomies">
			<p class="tax-categories taxonomy"><?php
	_e( 'Categories: ', 'puzzle' );
	the_category( _x( ', ', 'Category/ Tag list separator (includes a space after the comma)', 'puzzle' ) );
?>
			</p>
<?php

	// display tags (if there are any
	if ( get_the_tags() ) {
		the_tags( '<p class="tax-tags taxonomy">' . __( 'Tagged as: ', 'puzzle' ), _x( ', ', 'Category/ Tag list separator (includes a space after the comma)', 'puzzle' ), '</p>' );
	}
?>
		</div>