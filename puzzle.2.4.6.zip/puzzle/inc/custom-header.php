<?php
/**
 * Custom header codes
 *
 * @package Puzzle
 */

/**
 * Custom header image
 */
function puzzle_custom_header_support() {

	// Custom header image.
	add_theme_support(
		'custom-header',
		array(
			'default-text-color' => apply_filters( 'puzzle_header_textcolor', '1a1a1a' ),
			'random-default' => false,
			'width' => apply_filters( 'puzzle_header_width', 1140 ),
			'height' => apply_filters( 'puzzle_header_height', 150 ),
			'flex-height' => true,
			'header-text' => true,
			'uploads' => true,
			'wp-head-callback' => 'puzzle_colour_styles',
			'admin-head-callback' => 'puzzle_admin_head',
			'admin-preview-callback' => 'puzzle_admin_preview',
		)
	);

}

add_action( 'after_setup_theme', 'puzzle_custom_header_support' );


/**
 * Print custom header styles
 *
 * @return array
 */
function puzzle_colour_styles() {

?>
<style>
<?php
	if ( 'blank' == get_header_textcolor() ) {
?>
	.masthead .branding { display:none; }
<?php
	} else {
?>
	.masthead .branding h1.logo,
	.masthead .branding h1.logo a,
	.masthead .branding h1.logo a:hover,
	.masthead .branding h2.description {
		color:#<?php echo esc_attr( get_header_textcolor() ); ?>;
	}
<?php
	}

	if ( get_header_image() ) {
?>
	.masthead nav.menu {
		border-bottom:none;
	}
<?php
	}
?>
</style>
<?php

	return true;

}


/**
 * custom header admin styles
 */
function puzzle_admin_head() {

?>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alegreya+Sans:300,500,800" type="text/css" media="all" />
<style>
	.puzzle-header-wrapper {
		background:#fff;
		padding:20px 0;
		font-size:16px;
		line-height:1;
		text-align:center;
	}
	.puzzle-header-wrapper h1 {
		margin:0 0 5px 0;
		padding:0;
		font-size:323%;
		font-weight:800;
	}
	.puzzle-header-wrapper h1 a {
		text-decoration:none;
		font-family:'Alegreya Sans', sans-serif;
		font-weight:700;
		color:#<?php echo esc_attr( get_header_textcolor() ); ?>;
	}
	.puzzle-header-wrapper #desc {
		font-family:'Alegreya Sans', sans-serif;
		font-weight:400;
		text-transform:uppercase;
		font-size:113%;
		letter-spacing:1px;
		color:#<?php echo esc_attr( get_header_textcolor() ); ?>;
	}
	.appearance_page_custom-header #headimg {
		background-size:cover;
		background-position:center center;
		border:none;
	}
</style>
<?php
}


/**
 * Custom header admin preview
 */
function puzzle_admin_preview() {

?>
	<div class="puzzle-header-wrapper">
		<h1><a id="name" class="displaying-header-text" onclick="return false;" href="#"><?php bloginfo( 'name' ); ?></a></h1>
		<div id="desc" class="displaying-header-text"><?php bloginfo( 'description' ); ?></div>
	</div>
<?php
	if ( get_header_image() ) {
?>
	<div id="headimg" style="background-image:url(<?php echo get_header_image(); ?>);max-width:1600px;height:150px;"></div>
<?php
	}

}
