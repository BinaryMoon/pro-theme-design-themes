<?php
/**
 * Jetpack Compatibility File
 * See: http://jetpack.me/
 *
 * @package Puzzle
 */

/**
 * Add theme support for various Jetpack features.
 */
function puzzle_jetpack_init() {

	// See: http://jetpack.me/support/infinite-scroll/ .
	add_theme_support(
		'infinite-scroll',
		array(
			'container' => 'main-content',
			'footer_widgets' => 'sidebar-2',
			'footer' => 'footer-widgets',
			'posts_per_page' => 15,
			'wrapper' => false,
		)
	);

	add_theme_support( 'jetpack-testimonial' );

	// Add support for Portfolio and Projects.
	add_theme_support( 'jetpack-portfolio' );

	add_theme_support( 'jetpack-responsive-videos' );

	add_theme_support(
		'site-logo',
		array(
			'size' => 'puzzle-logo',
		)
	);

	// Add support for Jetpack content options.
	add_theme_support(
		'jetpack-content-options',
		array(
			'masonry' => '#main-content',
			'post-details' => array(
				'stylesheet' => 'puzzle-style',
				'date' => '.posted-on, .post-meta-data .sep',
				'categories' => '.tax-categories',
				'tags' => '.tax-tags',
			),
		)
	);

}

add_action( 'after_setup_theme', 'puzzle_jetpack_init' );


/**
 * Get Jetpack Testimonials Title
 */
function puzzle_testimonials_title() {

	$jetpack_options = get_theme_mod( 'jetpack_testimonials' );

	if ( ! empty( $jetpack_options['page-title'] ) ) {
		echo esc_html( $jetpack_options['page-title'] );
	} else {
		esc_html_e( 'Testimonials', 'puzzle' );
	}

}


/**
 * Retrieve and format jetpack testimonials description as set in theme customiser
 * @return type
 */
function puzzle_testimonials_description() {

	$jetpack_options = get_theme_mod( 'jetpack_testimonials' );
	$content = '';

	if ( ! empty( $jetpack_options['page-content'] ) ) {
		$content = $jetpack_options['page-content'];
		$content = addslashes( $content );
		$content = wp_kses_post( $content );
		$content = stripslashes( $content );
		$content = wptexturize( $content );
		$content = convert_smilies( $content );
		$content = convert_chars( $content );
	}

	return $content;

}


/**
 * Get Jetpack Testimonials Image
 *
 * @return type
 */
function puzzle_testimonials_image() {

	$jetpack_options = get_theme_mod( 'jetpack_testimonials' );
	$image = '';

	if ( ! empty( $jetpack_options['featured-image'] ) ) {
		$image = wp_get_attachment_image( (int) $jetpack_options['featured-image'], 'puzzle-page-thumbnail' );
	}

	return $image;

}


/**
 * Flush rewrite rules for CPT on setup and switch
 */
function puzzle_flush_rewrite_rules() {

	flush_rewrite_rules();

}

add_action( 'after_switch_theme', 'puzzle_flush_rewrite_rules' );
