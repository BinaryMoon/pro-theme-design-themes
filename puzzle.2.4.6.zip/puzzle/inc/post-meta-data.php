<?php
/**
 * Post meta data
 *
 * @package Puzzle
 */
?>
	<p class="post-meta-data">
		<span class="posted-on">
			<?php echo esc_html( get_the_date() ); ?>
		</span>
<?php
	if ( comments_open() || '0' != get_comments_number() ) {
?>
		<span class="sep">&bull;</span> <a href="#comments" class="comments-link"><?php echo get_comments_number(); ?></a>
<?php
	}
?>
	</p>
