<?php
/**
 * WordPress.com specific functionality
 *
 * @package Puzzle
 */


/**
 * theme colours for wp.com custom functionality
 *
 * @global string $themecolors
 */
function puzzle_theme_colors() {

	global $themecolors;

	/**
	 * Set a default theme color array for WP.com.
	 *
	 * @global array $themecolors
	 */
	if ( ! isset( $themecolors ) ) {
		$themecolors = array(
			'bg'     => 'FFFFFF',
			'border' => 'D5E2D4',
			'text'   => '666666',
			'link'   => '7BA37A',
			'url'    => 'E6E6E6',
		);
	}

}

add_action( 'after_setup_theme', 'puzzle_theme_colors' );


/**
 * Dequeue Google Fonts if Custom Fonts are being used instead.
 */
function puzzle_dequeue_fonts() {

	if ( class_exists( 'TypekitData' ) && class_exists( 'CustomDesign' ) && CustomDesign::is_upgrade_active() ) {
	    $custom_fonts = TypekitData::get( 'families' );

		if ( $custom_fonts && $custom_fonts['headings']['id'] ) {
			wp_dequeue_style( 'puzzle-font-alegrya' );
	    }

		if ( $custom_fonts && $custom_fonts['body-text']['id'] ) {
			wp_dequeue_style( 'puzzle-font-open-sans' );
		}
	}

}

add_action( 'wp_enqueue_scripts', 'puzzle_dequeue_fonts', 11 );