<?php

/**
 * Color annotation for Broadsheet, by Pro Theme Design.
 */

add_color_rule( 'bg', '#fff', array(
	array( 'body, .testimonials-wrapper header a.button, .testimonials-wrapper header a.button:hover, .menu-social-links a:before, .main .archive-pagination.pagination, .main h1.entry-archive-title, .main .main-content article.post-singular .entry, input[type=submit], input[type=submit]:hover, input[type=submit]:focus', 'background-color' ),
	array( '.infinite-scroll #infinite-handle span, .infinite-scroll #infinite-handle span:hover', 'background' ),
	array( '.masthead .menu', 'background-color' ),
), __( 'Background' ) );

//Green
add_color_rule( 'txt', '#2ecc71', array(
	//No Contrast
	array( '.main article.post-archive section, .main article.post-archive.sticky:before', 'background-color' ),
	array( '.main .archive-pagination span, .main .archive-pagination a', 'border-color' ),
	array( '.infinite-scroll #infinite-handle span', 'border-color' ),
	array( '.main .archive-pagination span.current', 'background-color' ),
	array( '.testimonials-wrapper .testimonial .entry', 'background-color' ),
	array( 'ol.commentlist li.comment .reply a, ol.commentlist li.trackback .reply a, ol.commentlist li.pingback .reply a', 'background-color' ),
	array( 'blockquote', 'border-color' ),
	array( '.testimonials-wrapper header a.button', 'border-color' ),

	//Contrast against white bg
	array( 'a, .main article p.post-meta-data a, .main article p.post-meta-data a:hover', 'color', 'bg' ),
	array( '.widget.widget_flickr #flickr_badge_uber_wrapper td a, .widget.widget_flickr #flickr_badge_wrapper td a', 'color', '#fff' ),
	array( 'a:hover, .menu-social-links a:hover:before', 'color', 'bg' ),
	array( '.main .postnav .next a:after, .main .postnav .prev a:before, .masthead nav.menu li.current-menu-item a', 'color', 'bg' ),
	array( '.widget h3.widgettitle, input[type="submit"], input[type="submit"]:hover, .infinite-scroll #infinite-handle span, .infinite-scroll #infinite-handle span:hover', 'color', 'bg' ),
	array( '.testimonials-wrapper header a.button, .testimonials-wrapper header a.button:hover', 'color', 'bg' ),
	array( '.masthead .menu .menu-toggle', 'color', 'bg' ),
	array( '.masthead .menu li', 'color', 'bg' ),
	array( '.masthead .menu li ul li a, .masthead .menu li li a, .masthead .menu li a', 'color', 'bg' ),
	array( '.masthead .menu li ul li a:hover, .masthead .menu li li a:hover, .masthead .menu li a:hover', 'color', 'bg' ),
	array( 'input[type="submit"], input[type="submit"]:hover, .infinite-scroll #infinite-handle span, .infinite-scroll #infinite-handle span:hover', 'border-color', 'bg' ),

	//Darker color
	array( 'ol.commentlist li.comment .reply a, ol.commentlist li.trackback .reply a, ol.commentlist li.pingback .reply a', 'border-color', '-0.2' ),
	array( '.menu-social-links a:hover:before', 'border-color', '-0.2' ),
	array( '.testimonials-wrapper header a.button:hover', 'border-color', '-1' ),
	array( '.masthead .menu li.page_item_has_children > a:after, .masthead .menu li.menu-item-has-children > a:after', 'border-top-color', '-0.2' ),

	//Contrast against dark background
	array( 'pre', 'color', '#333' ),
), __( 'Highlights' ) );

add_color_rule( 'fg2', '#f8fbfd', array(

) );

add_color_rule( 'link', '#2980b9', array(

) );

add_color_rule( 'fg1', '#ffffff', array(

) );

add_color_rule( 'extra', '#ffffff', array(
	array( '.testimonials-wrapper .testimonial .entry footer h3', 'color', 'txt' ),
	array( '.main article.post-archive section span.entry-title', 'color', 'txt' ),
	array( '.main article.post-archive section h2 a, .main article.post-archive.sticky:before', 'color', 'txt' ),
	array( '.main article.post-archive section .entry .post-meta-data,.main .archive-pagination span.current', 'color', 'txt' ),
) );

add_color_rule( 'extra', '#f2f2f2', array(
	array( '.main .postnav, a.post-edit-link, blockquote, table th, table caption, .content-comments, .wp-caption', 'background-color', 0.2 ),
	array( 'table, .masthead nav.menu, .singular.themes-sidebar1-active .sidebar .widget, ol.commentlist li.comment, ol.commentlist li.trackback, ol.commentlist li.pingback', 'border-color', 0.2 ),
) );

add_color_rule( 'extra', '#e6e6e6', array(
	array( 'a.post-edit-link:hover', 'background-color', 0.2 ),
) );

add_color_rule( 'extra', '#b3b3b3', array(
	array( 'ol.commentlist li.comment .comment-meta .comment-metadata a, ol.commentlist li.trackback .comment-meta .comment-metadata a, ol.commentlist li.pingback .comment-meta .comment-metadata a', 'color', 'bg' ),
) );

add_color_rule( 'extra', '#999999', array(
	array( '.main article .taxonomy', 'color', 'bg' ),
) );

add_color_rule( 'extra', '#cccccc', array(
	array( '.main article p.post-meta-data', 'color', 'bg' ),
) );

add_color_rule( 'extra', '#000000', array(
	array( '.masthead nav.menu a, .menu-social-links a:before', 'color', 'bg', 12 ),
	array( '.menu-social-links a:before', 'border-color', 0.2 ),
) );

add_color_rule( 'extra', '#666666', array(
	array( 'body', 'color', 'bg', 12 ),
) );

add_color_rule( 'extra', '#1a1a1a', array(
	array( 'h1, h2, h3, h4, h5, h6', 'color', 'bg', 12 ),
	array( '.testimonials-wrapper .testimonial .entry', 'color', 'txt' ),
	array( '.masthead .branding h1.logo a, .masthead .branding h1.logo a:hover, .masthead .branding h2.description', 'color', 'bg', 12 ),
) );

/* Additional color palettes */

add_color_palette( array(
	'#ebe5f0',
    '#855c93',
), 'Scheme 1' );

add_color_palette( array(
	'#122a35',
    '#1b6961',
), 'Scheme 2' );

add_color_palette( array(
	'#fad089',
    '#fd9a58',
), 'Scheme 3' );

add_color_palette( array(
	'#452632',
    '#91204d',
), 'Scheme 4' );

add_color_palette( array(
	'#e6e4df',
    '#807462',
), 'Scheme 5' );