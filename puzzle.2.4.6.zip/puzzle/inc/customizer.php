<?php
/**
 * Theme Customizer setup
 *
 * @package Puzzle
 */

/**
 * Theme customizer properties
 *
 * @param object $wp_customize WP Customize object.
 */
function puzzle_customizer_settings( $wp_customize ) {

	// Puzzle theme options section.
	$wp_customize->add_section(
		'puzzle_options',
		array(
			'title' => esc_html__( 'Theme', 'puzzle' ),
			'description' => esc_html__( 'Options for the Puzzle theme.', 'puzzle' ),
		)
	);

	// Setting to select a category to set as featured in the main site content.
	$wp_customize->add_setting(
		'puzzle_archive_layout',
		array(
			'default' => 0,
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'puzzle_sanitize_layout',
		)
	);

	$wp_customize->add_control(
		new Puzzle_Category_Dropdown_Custom_control(
			$wp_customize,
			'puzzle_archive_layout',
			array(
				'label' => esc_html__( 'Homepage and Archive Layout', 'puzzle' ),
				'section' => 'puzzle_options',
				'params' => array(
					0 => esc_html__( 'Puzzle Layout (default)', 'puzzle' ),
					1 => esc_html__( 'Brick Layout', 'puzzle' ),
					2 => esc_html__( '5 Column Grid', 'puzzle' ),
					5 => esc_html__( '3 Column Grid', 'puzzle' ),
					3 => esc_html__( '5 column Portrait Grid', 'puzzle' ),
					6 => esc_html__( '3 column Portrait Grid', 'puzzle' ),
					4 => esc_html__( 'Jumble Layout', 'puzzle' ),
				)
			)
		)
	);

	// Setting to display the homepage and archive images in the correct proportions.
	$wp_customize->add_setting(
		'puzzle_display_latest_content',
		array(
			'default' => true,
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'puzzle_sanitize_checkboxes',
		)
	);

	$wp_customize->add_control(
		'puzzle_display_latest_content',
		array(
			'label' => esc_html__( 'Display latest content on single posts', 'puzzle' ),
			'section' => 'puzzle_options',
			'type' => 'checkbox',
		)
	);

	// Setting to display the project categories in the archive templates.
	$wp_customize->add_setting(
		'puzzle_display_project_terms',
		array(
			'default' => false,
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'puzzle_sanitize_checkboxes',
		)
	);

	$wp_customize->add_control(
		'puzzle_display_project_terms',
		array(
			'label' => esc_html__( 'Display project categories on portfolio & project archive pages', 'puzzle' ),
			'section' => 'puzzle_options',
			'type' => 'checkbox',
		)
	);

}

add_action( 'customize_register', 'puzzle_customizer_settings' );


/**
 * Update Theme Elements without refreshing content.
 *
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function puzzle_register_customize_refresh( WP_Customize_Manager $wp_customize ) {

	// Ensure selective refresh is enabled.
	if ( ! isset( $wp_customize->selective_refresh ) ) {

		return false;

	}

	// Update site title.
	$wp_customize->get_setting( 'blogname' )->transport = 'postMessage';

	$wp_customize->selective_refresh->add_partial(
		'blogname',
		array(
			'selector' => '.branding .logo',
			'render_callback' => function() {
				bloginfo( 'name' );
			},
		)
	);

	// Update site description.
	$wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';

	$wp_customize->selective_refresh->add_partial(
		'blogdescription',
		array(
			'selector' => '.branding .description',
			'render_callback' => function() {
				bloginfo( 'description' );
			},
		)
	);

	// Show and hide header text.
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

	// Change the homepage layout.
	$wp_customize->get_setting( 'puzzle_archive_layout' )->transport = 'postMessage';

	// Display projects terms on the archive and portfolio projects homepage template.
	$wp_customize->get_setting( 'puzzle_display_project_terms' )->transport = 'postMessage';

	$wp_customize->selective_refresh->add_partial(
		'puzzle_display_project_terms',
		array(
			'selector' => '.projects-terms',
		)
	);

}

add_action( 'customize_register', 'puzzle_register_customize_refresh' );


/**
 * Binds JS handlers to make the Customizer preview reload changes asynchronously.
 */
function puzzle_customize_preview_js() {

	wp_enqueue_script( 'puzzle-customize-preview', get_theme_file_uri( '/js/customizer-preview.js' ), array( 'customize-preview' ), '1.0', true );

}

add_action( 'customize_preview_init', 'puzzle_customize_preview_js' );


/**
 * Sanitize alignment value
 * make sure it's an int
 *
 * @param type $setting
 * @return int
 */
function puzzle_sanitize_layout( $setting ) {

	return (int) $setting;

}


/**
 * Sanitize checkbox
 *
 * @param type $setting
 * @return int|string
 */
function puzzle_sanitize_checkboxes( $setting ) {

	if ( 1 == $setting ) {
		return 1;
	} else {
		return '';
	}

}
