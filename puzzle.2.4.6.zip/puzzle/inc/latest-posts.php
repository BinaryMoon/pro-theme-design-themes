<?php
/**
 * Latest posts to display under blog posts
 *
 * @package Puzzle
 */

	if ( get_theme_mod( 'puzzle_display_latest_content', true ) ) {

		$layout = get_theme_mod( 'puzzle_archive_layout', 0 );

		switch ( $layout ) {
			case 0:
				$count = 5;
				break;

			case 1:
			case 5:
				$count = 6;
				break;

			default:
				$count = 10;
				break;
		}


		$args = array(
			'ignore_sticky_posts' => true,
			'posts_per_page' => $count,
			'post__not_in' => array( get_the_ID() ),
		);
		$query = new WP_Query( $args );

		if ( $query->have_posts() ) {
?>
	<div class="main full-width">
		<div id="latest-content">
<?php
		while ( $query->have_posts() ) {
			$query->the_post();
			get_template_part( 'content' );
		}
?>
		</div>
	</div>
<?php
		}

	}