<?php
/**
 * Comments template.
 *
 * @package Puzzle
 */

	if ( post_password_required() ) {
		return;
	}
?>
<section class="content-comments">
<?php
	if ( have_comments() ) {
?>
	<h3 id="comments">
<?php
		printf( _n( '1 reply', '%1$s replies', get_comments_number(), 'puzzle' ), number_format_i18n( get_comments_number() ), '<span>' . get_the_title() . '</span>' );
?>
		<a href="#respond" title="<?php esc_attr_e( 'Leave a comment', 'puzzle' ); ?>">&raquo;</a>
	</h3>
	<ol class="commentlist" id="singlecomments">
<?php
		wp_list_comments( array(
			'avatar_size' => 48,
			'format' => 'html5',
			'short_ping' => true,
		));
?>
	</ol>
<?php
		if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) {
?>
	<nav class="postnav">
		<h1 class="screen-reader"><?php _e( 'Comment navigation', 'puzzle' ); ?></h1>
		<div class="prev">
			<?php previous_comments_link( __( 'Older Comments', 'puzzle' ) ); ?>
		</div>
		<div class="next">
			<?php next_comments_link( __( 'Newer Comments', 'puzzle' ) ); ?>
		</div>
	</nav>
<?php
		}
	}

	if ( 'open' == $post->comment_status ) {
		comment_form();
	}
?>
</section>