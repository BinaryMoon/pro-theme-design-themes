<?php
/**
 * Author post listing
 *
 * @package Puzzle
 */

	get_header();
	$user_id = get_query_var( 'author' );
?>
	<h1 class="entry-title entry-archive-title">
		<?php _e( 'Author Archives','puzzle' ); ?>
	</h1>
	<div class="contributor">
		<?php echo get_avatar( get_the_author_meta( 'user_email', $user_id ), '80' ); ?>
		<h2><?php the_author_meta( 'display_name', $user_id ); ?></h2>
		<?php echo wpautop( get_the_author_meta( 'description', $user_id ) ); ?>
	</div>
<?php
	if ( have_posts() ) {

		while ( have_posts() ) {
			the_post();
			get_template_part( 'content', get_post_format() );
		}
		puzzle_numeric_pagination();

	} else {
		get_template_part( 'content-empty' );
	}


	get_footer();