<?php
/**
 * Generic search form template
 *
 * @package Puzzle
 */
?>
<form method="get" class="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>" role="search">
	<label>
		<span class="screen-reader"><?php _e( 'Search for...', 'puzzle' ); ?></span>
		<input type="search" value="<?php echo esc_attr( get_search_query() ); ?>" name="s" class="searchfield text" placeholder="<?php echo esc_attr_x( 'Search...', 'search input placeholder text', 'puzzle' ); ?>" />
	</label>
	<button class="searchsubmit">&#62464;</button>
</form>