<?php
/**
 * Reusable theme functions
 *
 * @package Puzzle
 */

require_once 'inc/custom-header.php';
require_once 'inc/jetpack.php';
require_once 'inc/class-customizer.php';
require_once 'inc/customizer.php';

// This is the max width - it's the same on all pages.
// Keep in mind the theme is responsive so the width is likely to be narrower.
if ( ! isset( $content_width ) ) {
	$content_width = 720;
}

/**
 * Adjust the content_width variable
 *
 * @global int $content_width The current content_width.
 */
function puzzle_adjust_content_width() {

	global $content_width;

	if ( is_page_template( 'custom-templates/full-width.php' ) || ! is_active_sidebar( 'sidebar-1' ) ) {
		$content_width = 1100;
	}

}

add_action( 'template_redirect', 'puzzle_adjust_content_width' );


/**
 * Enqueue all the styles.
 *
 * @global type $wp_scripts
 */
function puzzle_enqueue() {

	wp_enqueue_style( 'puzzle-style', get_stylesheet_uri(), null, '1.8' );
	wp_enqueue_style( 'genericons', get_template_directory_uri() . '/styles/genericons/genericons.css', array(), '3.0.3' );

	// Fonts.
	$fonts_url = puzzle_fonts();

	if ( $fonts_url ) {
		wp_enqueue_style( 'puzzle-fonts', $fonts_url, array(), '1.0' );
	}

	wp_enqueue_script( 'puzzle-script-main', get_template_directory_uri() . '/js/main.js', array( 'jquery' ), '1.8', false );
	wp_enqueue_script( 'masonry' );

	wp_localize_script(
		'puzzle-script-main',
		'js_i18n',
		array(
			'menu' => esc_html__( 'Menu', 'puzzle' ),
		)
	);

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

}

add_action( 'wp_enqueue_scripts', 'puzzle_enqueue' );


/**
 * Set up all the theme properties and extras
 */
function puzzle_after_setup_theme() {

	load_theme_textdomain( 'puzzle', get_template_directory() . '/languages' );

	add_theme_support( 'automatic-feed-links' );

	add_theme_support( 'title-tag' );

	// Post thumbnails.
	add_theme_support( 'post-thumbnails' );

	// Used for attachment (image.php) page links.
	add_image_size( 'puzzle-attachment', 120, 120, true );

	// Used for post thumbnails on homepage and archives.
	add_image_size( 'puzzle-archive-square-large', 500, 500, true );
	add_image_size( 'puzzle-archive-square-small', 320, 320, true );
	add_image_size( 'puzzle-archive-portrait-small', 320, 400, true );
	add_image_size( 'puzzle-archive-portrait-large', 464, 538, true );
	add_image_size( 'puzzle-archive-rectangle', 450, 240, true );
	add_image_size( 'puzzle-logo', 9999, 240, false );

	// Custom background.
	$args = array(
		'default-color' => 'ffffff',
	);
	add_theme_support( 'custom-background', $args );

	// html5 FTW.
	add_theme_support(
		'html5',
		array(
			'comment-list',
			'search-form',
			'comment-form',
			'navigation-widgets',
		)
	);

	// Add selective refresh to widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );

	// Main menu.
	register_nav_menu( 'top_menu', __( 'Top Menu', 'puzzle' ) );

	// Menu in the footer for social links.
	register_nav_menu( 'social_menu', __( 'Social Footer Menu', 'puzzle' ) );


	// Add support for full width images and other content such as videos.
	add_theme_support( 'align-wide' );

	// Disable custom font sizes, ensuring consistent vertical rhythm.
	add_theme_support( 'disable-custom-font-sizes' );

	// Make Gutenberg embeds responsive.
	add_theme_support( 'responsive-embeds' );

	// Editor font sizes.
	// Uses the default slugs to ensure consistency across themes.
	add_theme_support(
		'editor-font-sizes',
		array(
			array(
				'name' => esc_html__( 'small', 'puzzle' ),
				'size' => 13.5,
				'slug' => 'small',
			),
			array(
				'name' => esc_html__( 'normal', 'puzzle' ),
				'size' => 15,
				'slug' => 'normal',
			),
			array(
				'name' => esc_html__( 'medium', 'puzzle' ),
				'size' => 17.5,
				'slug' => 'medium',
			),
			array(
				'name' => esc_html__( 'large', 'puzzle' ),
				'size' => 20,
				'slug' => 'large',
			),
			array(
				'name' => esc_html__( 'huge', 'puzzle' ),
				'size' => 30,
				'slug' => 'huge',
			),
		)
	);

	// Add support for editor styles.
	add_theme_support( 'editor-styles' );

	// Editor Style.
	$fonts_url = puzzle_fonts();

	if ( $fonts_url ) {
		add_editor_style( $fonts_url );
	}

	add_editor_style( 'styles/css/editor-styles.css' );

}


/**
 * Enqueue WordPress theme styles within Gutenberg.
 */
function puzzle_editor_blocks_styles() {

	// Load the additional editor styles.
	// This covers things like the editor title that can't be styled with the normal editor styles.
	wp_enqueue_style( 'puzzle-editor-blocks', get_theme_file_uri( '/styles/css/editor-blocks.css' ), null, '1' );

	/**
	 * Overwrite Core theme styles with empty styles.
	 * @see https://github.com/WordPress/gutenberg/issues/7776#issuecomment-406700703
	 */
	wp_deregister_style( 'wp-block-library-theme' );
	wp_register_style( 'wp-block-library-theme', '' );

}

add_action( 'enqueue_block_editor_assets', 'puzzle_editor_blocks_styles' );
add_action( 'enqueue_block_assets', 'puzzle_editor_blocks_styles' );


/**
 * Get url for google fonts.
 */
function puzzle_fonts() {

	/**
	 * Translators: If there are characters in your language that are not
	 * supported, translate this to 'off'. Do not translate into your
	 * own language.
	 */
	$font = _x( 'on', 'Google font Alegreya: on or off', 'puzzle' );

	if ( 'off' !== $font ) {
		$fonts['alegrya'] = 'Alegreya Sans:300,500,800';
	}

	/**
	 * Translators: If there are characters in your language that are not
	 * supported, translate this to 'off'. Do not translate into your
	 * own language.
	 */
	$font = _x( 'on', 'Google font Open Sans: on or off', 'puzzle' );

	if ( 'off' !== $font ) {
		$fonts['open-sans'] = 'Open Sans:400,700';
	}

	$fonts = apply_filters( 'puzzle_fonts', $fonts );

	if ( $fonts ) {
		$query_args = array(
			'family' => rawurlencode( implode( '|', $fonts ) ),
			'subset' => rawurlencode( 'latin,latin-ext' ),
			'display' => 'swap',
		);

		return add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
	}

}


/**
 * Initialize widgets.
 */
function puzzle_widgets_init() {

	// Sidebar.
	register_sidebar(
		array(
			'name' => esc_html__( 'Sidebar Widgets', 'puzzle' ),
			'id' => 'sidebar-1',
			'description' => esc_html__( 'Widgets that display on the right hand side of blog posts and pages.', 'puzzle' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h3 class="widgettitle">',
			'after_title' => '</h3>',
		)
	);

	// Footer widgets.
	register_sidebar(
		array(
			'name' => esc_html__( 'Footer Widgets', 'puzzle' ),
			'id' => 'sidebar-2',
			'description' => esc_html__( 'Widgets that display at the bottom of your website. They are arranged in 4 columns and lined up automatically to make the best use of the space available.', 'puzzle' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h3 class="widgettitle">',
			'after_title' => '</h3>',
		)
	);

}

add_action( 'widgets_init', 'puzzle_widgets_init' );


/**
 * Custom excerpt length
 *
 * @param type $length Current length of excerpt.
 *
 * @return int
 */
function puzzle_excerpt_length( $length ) {

	return 60;

}


/**
 * Add a class to menus to maintain consistency.
 *
 * @param type $ulclass
 * @return type
 */
function puzzle_add_menu_class( $ulclass ) {

	return preg_replace( '/<ul>/', '<ul id="nav">', $ulclass, 1 );

}


/**
 * Numeric pagination for custom queries
 * Much nicer than next and previous links :)
 *
 * @global type $wp_query
 * @param type $page_count
 * @param type $query
 * @return type
 */
function puzzle_numeric_pagination( $page_count = 9, $query = null ) {

	the_posts_pagination(
		array(
			'mid_size' => 2,
			'prev_text' => esc_html__( 'Newer', 'granule' ),
			'next_text' => esc_html__( 'Older', 'granule' ),
		)
	);

}


/**
 * Add additional body classes that may be helpful
 *
 * @param array $styles The existing array of body class names.
 * @return string
 */
function puzzle_body_class( $styles ) {

	if ( is_singular() ) {
		$styles[] = 'singular';
	}

	if ( is_active_sidebar( 'sidebar-1' ) && puzzle_sidebar_visible() ) {
		$styles[] = 'themes-sidebar1-active';
	} else {
		$styles[] = 'themes-sidebar1-inactive';
	}

	if ( is_active_sidebar( 'sidebar-2' ) ) {
		$styles[] = 'themes-sidebar2-active';
	} else {
		$styles[] = 'themes-sidebar2-inactive';
	}

	$layout = get_theme_mod( 'puzzle_archive_layout', 0 );
	$styles[] = 'themes-layout-' . ( (int) $layout );

	return $styles;

}


/**
 * Additional styles for post class
 *
 * @param string $styles Array of post styles.
 * @return string
 */
function puzzle_post_class( $styles ) {

	if ( is_singular() ) {
		$styles[] = 'post-singular';
	}

	return $styles;

}


/**
 * Display the site header
 */
function puzzle_header() {

	$header_image = get_header_image();

	if ( ! empty( $header_image ) ) {
?>
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home" class="header-image">
			<img src="<?php header_image(); ?>" width="<?php echo (int) get_custom_header()->width; ?>" height="<?php echo (int) get_custom_header()->height; ?>" alt="" />
		</a>
<?php
	}

}


/**
 * Grab attachment image if there's no featured image
 *
 * @param int    $post_id ID of current post.
 * @param string $thumbnail_size Image size for desired thumbnail.
 */
function puzzle_get_thumbnail( $post_id, $thumbnail_size = 'puzzle-archive-square-small' ) {

	$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post_id ), $thumbnail_size );

	// If there's no featured image then grab an attachment image and use that instead.
	if ( ! $image[0] ) {

		$values = get_attached_media( 'image', $post_id );

		if ( $values ) {
			foreach ( $values as $child_id => $attachment ) {
				$image = wp_get_attachment_image_src( $child_id, $thumbnail_size );
				break;
			}
		}
	}

	return $image;

}


/**
 * Change the length of posts_per_page based on the number of sticky posts so that the layout is consistant
 *
 * @param type $query The current WP_Query.
 */
function puzzle_combine_stickyposts( $query ) {

	// Only need to do this if it's the main query, needs to have 15 posts.
	// on the homepage in order to be nicely formatted in all layouts
	//
	// If not on the homepage then use default values.
	if ( $query->is_main_query() && is_home() ) {

		$sticky_count = 0;
		$posts_per_page = 15;

		// If first page.
		if ( ! $query->is_paged() ) {
			// Get sticky posts array.
			$sticky_posts = get_option( 'sticky_posts' );

			if ( is_array( $sticky_posts ) ) {
				$sticky_count = count( $sticky_posts );
			}
			if ( $sticky_count >= 1 ) {
				$sticky_count --;
			}
			if ( $sticky_count < $posts_per_page ) {
				$posts_per_page = $posts_per_page - $sticky_count;
			}
		}

		$query->set( 'posts_per_page', $posts_per_page );

	}

}

/**
 * Should the sidebar be visible?
 */
function puzzle_sidebar_visible() {

	if ( is_page_template( 'page-templates/full-width.php' ) ) {
		return false;
	}

	if ( is_page_template( 'page-templates/project-homepage.php' ) ) {
		return false;
	}

	return true;

}


/**
 * Get thumbnail size
 *
 * @global type $wp_query
 * @return string
 */
function puzzle_get_thumbnail_size() {

	global $wp_query;

	// Default.
	$thumbnail_size = 'puzzle-archive-square-large';

	$layout = (int) get_theme_mod( 'puzzle_archive_layout', 0 );

	// If using the puzzle layout.
	if ( 0 === $layout ) {
		$index = $wp_query->current_post % 10;

		switch ( $index ) {
			case 0:
			case 6:
				$thumbnail_size = 'puzzle-archive-square-large';
				break;

			case 1:
			case 4:
			case 7:
			case 9:
				$thumbnail_size = 'puzzle-archive-square-small';
				break;

			default:
				$thumbnail_size = 'puzzle-archive-rectangle';

		}
	}

	// If using the brick layout.
	if ( 1 === $layout ) {
		$index = $wp_query->current_post % 6;

		switch ( $index ) {
			case 0:
			case 5:
				$thumbnail_size = 'puzzle-archive-square-small';
				break;

			default:
				$thumbnail_size = 'puzzle-archive-rectangle';

		}
	}

	// Small grid layout.
	if ( 2 === $layout ) {
		$thumbnail_size = 'puzzle-archive-square-small';
	}

	// Portrait grid layout.
	if ( 3 === $layout ) {
		$thumbnail_size = 'puzzle-archive-portrait-small';
	}

	// Jumble layout.
	if ( 4 === $layout ) {
		$index = (int) $wp_query->current_post % 2;
		$thumbnail_size = 'puzzle-archive-square-small';

		if ( 0 === $index ) {
			$thumbnail_size = 'puzzle-archive-portrait-small';
		}
	}

	// 3 column grid.
	if ( 5 === $layout ) {
		$thumbnail_size = 'puzzle-archive-square-large';
	}

	// 3 column portrait.
	if ( 6 === $layout ) {
		$thumbnail_size = 'puzzle-archive-portrait-large';
	}

	return $thumbnail_size;

}

/**
 * Display a list of all of the project categories.
 */
function puzzle_project_terms() {

	// Should we show the project terms on the archive pages & projects template.
	// Default is to have them turned off.
	if ( ! get_theme_mod( 'puzzle_display_project_terms', false ) && ! is_customize_preview() ) {
		return;
	}

	// Get a list of the terms. Limited to 20 so we don't bloat the page.
	$terms = get_terms(
		'jetpack-portfolio-type',
		array(
			'number' => 20,
			'orderby' => 'count',
			'order' => 'DESC',
		)
	);

	// Highlight currently selected page.
	$class = 'current-page';

	// Get the term for the current page.
	$current_term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );

	// We're on a project category page, and not the main portfolio page, so reset the class.
	if ( $current_term ) {
		$class = '';
	}

	// Make sure the term exists and has some results.
	if ( is_wp_error( $terms ) || empty( $terms ) ) {
		return false;
	}

	// All clear - let's display the terms.
?>
	<p class="projects-terms">

		<span class="project-terms-intro">
			<?php esc_html_e( 'Categories:', 'puzzle' ); ?>
		</span>

		<a class="<?php echo esc_attr( $class ); ?>" href="<?php echo esc_url( home_url( '/portfolio/' ) ); ?>"><?php esc_html_e( 'All', 'puzzle' ); ?></a>

<?php
		foreach ( $terms as $t ) {
			$class = '';

			if ( $current_term && $current_term->term_id === (int) $t->term_id ) {
				$class = 'current-page';
			}
?>
		<a class="<?php echo esc_attr( $class ); ?>" href="<?php echo esc_url( get_term_link( $t ) ); ?>"><?php echo esc_html( $t->name ); ?></a>
<?php
		}
?>
	</p>
<?php

}

add_action( 'after_setup_theme', 'puzzle_after_setup_theme' );
add_action( 'pre_get_posts', 'puzzle_combine_stickyposts', 20 );

add_filter( 'body_class', 'puzzle_body_class' );
add_filter( 'post_class', 'puzzle_post_class' );
add_filter( 'use_default_gallery_style', '__return_false' );
add_filter( 'excerpt_length', 'puzzle_excerpt_length', 999 );
add_filter( 'wp_page_menu', 'puzzle_add_menu_class' );


/**
 * Load WooCommerce compatibility file.
 */
if ( class_exists( 'WooCommerce' ) ) {
	require 'inc/woocommerce.php';
}
