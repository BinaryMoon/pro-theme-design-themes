<?php
/**
 * Error - file not found
 *
 * @package Puzzle
 */

	get_header();
?>
<div class="main full-width">
<article class="page-404">
	<h1 class="entry-title"><?php _e( 'Error 404 - Not Found', 'puzzle' ); ?></h1>
	<div class="entry">
		<p class="page-404"><?php _e( 'Sorry, but the page you are looking for has not been found. Try checking the URL for errors, then hit the refresh button in your browser.', 'puzzle' ); ?></p>
<?php
	$args = array(
		'posts_per_page' => 5,
		'ignore_sticky_posts' => true,
	);
	$query = new WP_Query( $args );

	if ( $query->have_posts() ) {
?>
		<h3><?php _e( 'Recent Posts', 'puzzle' ); ?></h3>
		<ul>
<?php
		while ( $query->have_posts() ) {
			$query->the_post();
?>
			<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
<?php
		}
?>
		</ul>
<?php
	} else {
		get_template_part( 'content-empty' );
	}
	wp_reset_postdata();
?>
	</div>
</article>
</div>
<?php
	get_footer();