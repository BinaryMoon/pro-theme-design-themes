<?php
/**
 * Single post content
 *
 * @package Puzzle
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="post-title">
		<div class="post-title-wrapper">
<?php
	get_template_part( 'inc/post-meta-data' );
	the_title( '<h1 class="entry-title">', '</h1>' );
?>
		</div>
	</div>
	<section class="entry">
<?php
	the_content();

	edit_post_link();

	wp_link_pages( array(
		'before' => '<div class="archive-pagination">' . __( 'Pages: ', 'puzzle' ),
		'after'  => '</div>',
		'link_before' => '<span>',
		'link_after'  => '</span>',
	) );

	get_template_part( 'inc/post-terms' );
?>
	</section>
</article>
<nav class="postnav">
	<h1 class="screen-reader"><?php _e( 'Post navigation', 'puzzle' ); ?></h1>
	<div class="prev">
		<?php previous_post_link( __( '<span class="more-link">%link</span>', 'puzzle' ) ); ?>
	</div>
	<div class="next">
		<?php next_post_link( __( '<span class="more-link">%link</span>', 'puzzle' ) ); ?>
	</div>
</nav>