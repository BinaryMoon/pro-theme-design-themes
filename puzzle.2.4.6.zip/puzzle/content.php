<?php
/**
 * Generic content
 *
 * @package Puzzle
 */

	$thumbnail_size = puzzle_get_thumbnail_size();
	$image = puzzle_get_thumbnail( get_the_ID(), $thumbnail_size );
	$styles = '';
	$post_classes = array( 'post-archive' );

	if ( $image[0] ) {
		$post_classes[] = 'has-image';
		$styles = 'style="background-image:url(' . esc_url( $image[0] ) . ');"';
	} else {
		$post_classes[] = 'has-no-image';
	}

?>
<article id="post-<?php the_ID(); ?>" <?php post_class( $post_classes ); ?> >
	<section>
		<a href="<?php the_permalink(); ?>" class="link-image" <?php echo $styles; ?>></a>
		<div class="entry">
<?php
	if ( get_the_title() ) {
?>
			<h2 class="entry-title">
				<a href="<?php the_permalink() ?>" rel="bookmark">
					<?php the_title(); ?>
				</a>
			</h2>
<?php
	} else {
?>
		<span class="entry-title show-post"></span>
<?php
	}

	get_template_part( 'inc/post-meta-data' );
?>
		</div>
	</section>
</article>