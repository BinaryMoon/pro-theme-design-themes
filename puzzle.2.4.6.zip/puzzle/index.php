<?php
/**
 * Homepage Template
 *
 * @package Puzzle
 */

	get_header();

	if ( have_posts() ) {
?>
	<div id="main-content-wrapper">
		<div id="main-content">
<?php
		while ( have_posts() ) {
			the_post();
			get_template_part( 'content', get_post_format() );
		}
?>
		</div>
	</div>
<?php
		puzzle_numeric_pagination();
	} else {
		get_template_part( 'content-empty' );
	}

	get_template_part( 'inc/jetpack-testimonials' );

	get_footer();
