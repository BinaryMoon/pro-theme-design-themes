<?php
/**
 * Page content
 *
 * @package Puzzle
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( array( 'post-singular' ) ); ?>>
	<div class="post-title">
		<div class="post-title-wrapper">
			<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
		</div>
	</div>
	<section class="entry">
<?php
	the_content();

	edit_post_link();

	wp_link_pages( array(
		'before' => '<div class="archive-pagination">' . __( 'Pages: ', 'puzzle' ),
		'after'  => '</div>',
		'link_before' => '<span>',
		'link_after'  => '</span>',
	) );
?>
	</section>
</article>
