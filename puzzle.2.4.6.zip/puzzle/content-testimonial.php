<?php
/**
 * Individual Testimonial layout
 *
 * @package Puzzle
 */

?>
<article id="post-<?php the_ID(); ?>" class="testimonial">
	<div class="entry">
		<footer>
<?php
	the_post_thumbnail( 'puzzle-attachment' );
?>
			<h3><?php the_title(); ?></h3>
		</footer>
<?php
	the_content();
?>
	</div>
</article>