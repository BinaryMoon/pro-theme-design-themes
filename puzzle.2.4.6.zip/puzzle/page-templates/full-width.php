<?php
/**
 * Template Name: Full Width
 *
 * @package Puzzle
 */

	get_header();

	get_template_part( 'inc/jetpack-featured-content' );

?>
<div class="main-content full-width">
<?php
	if ( have_posts() ) {
		while ( have_posts() ) {
			the_post();
			get_template_part( 'content-page' );
		}
	}
?>
</div>
<?php
	get_footer();