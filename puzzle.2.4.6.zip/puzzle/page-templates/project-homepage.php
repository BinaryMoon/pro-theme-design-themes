<?php
/**
 * Template Name: Projects Homepage
 * A new homepage template that displays projects instead of blog posts
 *
 * @package Puzzle
 */

	get_header();

	puzzle_project_terms();
?>
	<div class="main-content main-content-project-homepage">
<?php
	if ( have_posts() ) {

		while ( have_posts() ) {
			the_post();
			the_title( '<h1 class="entry-title">', '</h1>' );
			the_content();
		}

	}
?>
	</div>
<?php
	if ( is_front_page() ) {
		$paged = get_query_var( 'page', 1 );
	} else {
		$paged = get_query_var( 'paged', 1 );
	}

	$query = new WP_Query(
		array(
			'post_type' => 'jetpack-portfolio',
			'posts_per_page' => 15,
			'ignore_sticky_posts' => true,
			'paged' => $paged,
		)
	);

	if ( $query->have_posts() ) {
?>
	<div id="main-content-wrapper">
		<div id="main-content">
<?php
		while ( $query->have_posts() ) {
			$query->the_post();
			get_template_part( 'content', get_post_format() );
		}
?>
		</div>
	</div>
<?php
		puzzle_numeric_pagination( 9, $query );

	} else {

		get_template_part( 'content-empty' );

	}

	wp_reset_postdata();

	get_footer();
