<?php
/**
 * Header Template
 *
 * @package Puzzle
 */

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta http-equiv="Content-Type" content="<?php bloginfo( 'html_type' ); ?>; charset=<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />

	<!--[if lt IE 9]>
	<script src="<?php echo get_template_directory_uri(); ?>/js/html5.js" type="text/javascript"></script>
	<![endif]-->

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a href="#main-content" class="screen-reader-shortcut"><?php esc_html_e( 'Skip to content', 'puzzle' ); ?></a>

<div class="container hfeed">

	<header class="masthead" role="banner">
<?php
		do_action( 'before' );
		if ( function_exists( 'jetpack_the_site_logo' ) ) {
			jetpack_the_site_logo();
		}
?>
		<div class="branding">
			<h1 class="logo">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php esc_attr_e( 'Home', 'puzzle' ); ?>">
					<?php bloginfo( 'name' ); ?>
				</a>
			</h1>
			<h2 class="description">
				<?php bloginfo( 'description' ); ?>
			</h2>
		</div>
<?php
	$menu = wp_nav_menu(
		array(
			'theme_location' => 'top_menu',
			'menu_id' => 'nav',
			'menu_class' => 'menu-wrap',
			'echo' => false,
			'container' => '',
		)
	);

	if ( $menu ) {
?>
		<nav class="menu" role="navigation">
			<h3 class="menu-toggle"><?php esc_html_e( 'Menu', 'puzzle' ); ?></h3>
			<?php echo $menu; ?>
		</nav>
<?php
	}
?>
	</header>
<?php
	puzzle_header();
	do_action( 'before' );
?>
	<div class="main">
