=== Puzzle ===

Contributors: binarymoon
Requires at least: 4.1
Tested up to: 4.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: black, green, white, two-columns, right-sidebar, responsive-layout, custom-background, custom-colors, custom-header, custom-menu, featured-images, flexible-header, full-width-template, infinite-scroll, rtl-language-support, sticky-post, theme-options, translation-ready, art, artwork, craft, design, food, gaming, lifestream, magazine, music, photoblogging, photography, portfolio, scrapbooking, clean, conservative, contemporary, earthy, faded, minimal, modern, natural, simple, sophisticated, site-logo

== Description ==

Puzzle is a visual oriented theme, great for photographers and artists who want to tell stories through their images.

[Theme documentation](https://prothemedesign.com/documentation/theme/puzzle/)

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Puzzle includes support for [Styleguide](https://wordpress.org/plugins/styleguide/) - a plugin that allows you to change fonts, and colours in WordPress themes.

Puzzle includes support for most features in [Jetpack](https://wordpress.org/plugins/jetpack/), including Infinite Scroll, Featured Content, and Site Logo.

== Changelog ==

= 2.7.6 - 2nd April 2021 =
* Fix text input width.

= 2.7.5 - 31st January 2021 =
* Clear html widget to prevent floated content from breaking the layout.

= 2.4.4 - 2nd January 2021 =
* Fix jQuery error since jquery migrate has been removed.
* Fix sub menu link colours on mobile devices.
* Update rtl.css
* Add 'navigation-widgets' to supported html5 types.

= 2.4.3 - 5th October 2020 =
* Add support for wp_body_open.

= 2.4.2 - 29th July 2020 =
* Make logo class generic (for 5.5 update).

= 2.4.1 - 11th July 2020 =
* Improve spacing for readability and consistency.
* Fix search form styles.
* Make links more obvious (to improve accessibility).

= 2.4 - 13th March 2020 =
* Add support for Gutenberg.
* Update rtl.css
* Make search results page pagination clickable. It was hidden behind the search results.

= 2.3 - 9th November 2018 =
* Improve coding standards.
* Make pagination use WordPress built in pagination functions to fix errors with moving through archives.

= 2.2 - 3rd September 2018 =
* Add support for customizable footer credits (.org only)

= 2.1 - 17th January 2018 =
* Improve spacing in layout to improve readability, and consistency.
* Update right to left styles.

= 2.0 - 29th October 2017 =
* Bump the version number to avoid an unfortunate compilation error that was causing issues with an incorrect version. Confusing but this is a simple fix for it.
* Add support for WooCommerce for all sites (including .com).
* Improve WooCommerce styles on archive pages.
* Disable Infinite Scroll on WooCommerce archives.

= 1.12 - 22nd September 2017 =
* Fix CSS bug with images displaying incorrectly on mobile versions of Safari.

= 1.11 - 13th September 2017 =
* Fix issue with projects custom template pagination when the page is used on the homepage. Actually will fix the issue for all custom pages, but projects was worst affected.

= 1.10 - 18th August 2017 =
* Add option to display project terms on portfolio and projects archive pages. This defaults to off so as not to change existing users sites unexpectedly.
* Escape more stuff

= 1.9.2 - 17th July 2017 =
* Enable Jetpack portfolio support by default. The theme was designed as a portfolio and includes a portfolio template so having this enabled allows users to get setup more quickly.
* Remove include for inc/wpcom.php, since it's automatically included by WordPress.com sites

= 1.9.1 - 3rd July 2017 =
* Fix PHP error happening due to WooCommerce integration.

= 1.9 - 18th June 2017 =
* Add support for WooCommerce.

= 1.8 - 25th May 2017 =
* Add support for Jetpack content options
* Tidy codes
* Improve customizer experience - add live updating components
* Make custom header colours work properly
* Add live updating for homepage layout in customizer

= 1.7.2 - 24th May 2017 =
* Improve social widgets responsiveness when in widgets
* Improve post title sizes on mobile devices
* Make WordPress custom logo work, replacing Jetpack site logo (self hosted only)
* Make sticky post styles look better on mobile devices

= 1.7.1 - 29th November 2016 =
* Fix links in testimonials.

= 1.7 - 28th July 2016 =
* Improve rtl.css

= 1.6.1 =
* Fix small issue with image attachment template

= 1.6 =
* Stop small content jump when page first loads
* Switch to `add_theme_support(title-tag)` for improved title tag support
* fix a bug in infinite scroll that occurs on self hosted sites when the site has footer widgets enabled
* Improve coding standards

= 1.5.3 =
* Add social link icons usable in menus with the addition of the icon class

= 1.5.2 =
* Move skip to content link outside of container
* Make container relative for easier css position modifications
* tidy some codes and add some sanitisation to strings
* link to https version of prothemedesign.com
* Fix some bugs in Jetpack Testimonials

= 1.5.1 =
* Fix undefined variable errors related to Testimonials

= 1.5 =
* Improve Masonry code to add some nice transitions
* Improve widget styles

= 1.4 =
* Add new custom page layout that displays Jetpack projects. Can be used as a homepage template

= 1.3.1 =
* Improve archive titles

= 1.3 =
* Spring clean the code - including adding Jetpack responsive video support, updating masonry and improving text domain support
* add another page layout
* make logo size proportional so that other ratios will work

= 1.2.1 =
* Tweak archive font sizes so that longer titles will fit in the smaller boxes
* Add some new archive page layout options

= 1.2 =
* Add Jetpack site logo support
* Tweak featured image sizes so they always look nice
* Improve touch screen usage so that titles are always visible on mobile devices

= 1.1 =
* Add support for Jetpack Testimonials to homepage
* Improve dropdown menu code, including support on mobile devices
* Add option for 'latest posts' on single posts to be hidden

= 1.0 =
* Initial release

== Credits ==

* [Alegreya Sans](https://www.google.com/fonts/specimen/Alegreya+Sans) Font from Google Fonts, licensed under [SIL Open Font License, 1.1](http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL)
* [Open Sans](https://www.google.com/fonts/specimen/Open+Sans) Font from Google Fonts, licensed under [Apache License, version 2.0](http://www.apache.org/licenses/LICENSE-2.0.html)
* Genericons: font by Automattic (http://automattic.com/), licensed under [GPL2](https://www.gnu.org/licenses/gpl-2.0.html)
