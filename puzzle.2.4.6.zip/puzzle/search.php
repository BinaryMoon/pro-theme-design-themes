<?php
/**
 * Search results template
 *
 * @package Puzzle
 */

	get_header();
?>
	<h1 class="entry-title entry-archive-title">
		<?php printf( __( 'Search results for &#8216;<em>%s</em>&#8217;', 'puzzle' ), get_search_query() ); ?>
	</h1>
	<div id="main-content-wrapper">
		<div id="main-content">
<?php
	if ( have_posts() ) {
		while ( have_posts() ) {
			the_post();
			get_template_part( 'content', get_post_format() );
		}
	} else {
		get_template_part( 'content-empty' );
	}
?>
		</div>
	</div>
<?php
	puzzle_numeric_pagination();

	get_footer();
