/**
 * Live-update changed settings in real time in the Customizer preview.
 *
 * Filename: customizer-preview.js v1
 *
 * Created by Ben Gillbanks <https://prothemedesign.com/>
 * Available under GPL2 license
 *
 * @link https://developer.wordpress.org/themes/advanced-topics/customizer-api/#javascript-driven-widget-support
 *
 * @package Puzzle
 */

/* global jQuery, document, wp */

;( function( $, document ) {

	$( document ).ready(
		function() {

			// Site title.
			wp.customize(
				'blogname',
				function( value ) {
					value.bind(
						function( to ) {
							$( '.branding .logo' ).text( to );
						}
					);
				}
			);

			// Site description.
			wp.customize(
				'blogdescription',
				function( value ) {
					value.bind(
						function( to ) {
							$( '.branding .description' ).text( to );
						}
					);
				}
			);

			// Header text color.
			wp.customize(
				'header_textcolor',
				function( value ) {

					value.bind(
						function( to ) {

							if ( 'blank' === to ) {

								$( '.masthead .branding' ).css(
									{
										'clip': 'rect(1px, 1px, 1px, 1px)',
										'position': 'absolute'
									}
								);

							} else {

								$( '.masthead .branding' ).css(
									{
										'clip': 'auto',
										'position': 'relative'
									}
								);

								$( '.masthead .branding h1.logo, .masthead .branding h1.logo a, .masthead .branding h1.logo a:hover, .masthead .branding h2.description' ).css(
									{
										'color': to
									}
								);

							}
						}
					);
				}
			);

			// Site layout.
			wp.customize(
				'puzzle_archive_layout',
				function( value ) {

					// Set up masonry.
					var $grid = $( '#main-content' ).masonry(
						{
							gutter: 0,
							itemSelector: 'article',
							columnWidth: '.grid-sizer',
							isOriginLeft: ! $( 'body' ).is( '.rtl' )
						}
					);

					value.bind(
						function( to ) {

							// Remove old body classes.
							$( 'body' ).removeClass( 'themes-layout-0 themes-layout-1 themes-layout-2 themes-layout-3 themes-layout-4 themes-layout-5 themes-layout-6' );

							// Add body class for new layout.
							$( 'body' ).addClass( 'themes-layout-' + to );

							// Refresh masonry layout.
							$grid.masonry( 'layout' );

						}
					);
				}
			);


			wp.customize(
				'puzzle_display_project_terms',
				function( value ) {

					if ( wp.customize.settings.values.puzzle_display_project_terms ) {
						$( '.projects-terms' ).show();
					} else {
						$( '.projects-terms' ).hide();
					}

					value.bind(
						function( to ) {
							if ( to ) {
								$( '.projects-terms' ).show();
							} else {
								$( '.projects-terms' ).hide();
							}
						}
					);
				}
			);

		}
	);

} )( jQuery, document );
