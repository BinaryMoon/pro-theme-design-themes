/**
 * main.js v1
 * Created by Ben Gillbanks <http://www.binarymoon.co.uk/>
 * Available under GPL2 license
 */

; ( function( $ ) {

	function is_touch_device() {
		return ( ( 'ontouchstart' in window )
			|| ( navigator.MaxTouchPoints > 0 )
			|| ( navigator.msMaxTouchPoints > 0 ) );
	}

	$( document ).ready( function() {

		if ( typeof $.fn.responsiveNavigation === 'function' ) {
			$( 'ul#nav' ).responsiveNavigation( {
				breakpoint: 549
			} );
		}

		// attachment page navigation
		if ( $( 'body' ).hasClass( 'attachment' ) ) {

			$( document ).keydown( function( e ) {

				if ( $( 'textarea, input' ).is( ':focus' ) ) {
					return;
				}

				var url = false;

				switch ( e.which ) {
					// left arrow key (previous attachment)
					case 37:
						url = $( '.image-previous a' ).attr( 'href' );
						break;

					// right arrow key (next attachment)
					case 39:
						url = $( '.image-next a' ).attr( 'href' );
						break;

				}

				if ( url ) {
					window.location = url;
				}
			} );

		}

		if ( typeof $.fn.elementalSlides === 'function' ) {
			$( '.showcase-wrapper' ).elementalSlides();
		}

		$( window ).on(
			'load',
			function() {
				// Arrange footer widgets vertically.
				if ( typeof $.fn.masonry === 'function' ) {

					// add grid-sizer element
					$( '#main-content, #latest-content' ).prepend( '<div class="grid-sizer"></div>' );

					var $grid = $( '#main-content' ).masonry( {
						gutter: 0,
						itemSelector: 'article',
						columnWidth: '.grid-sizer',
						isOriginLeft: !$( 'body' ).is( '.rtl' )
					} );

					$grid.children().addClass( 'post-loaded' );

					$( 'body' ).on( 'post-load', function() {
						var $new_articles = $( '#main-content' ).children().not( '.post-loaded' ).addClass( 'post-loaded' );
						$grid.masonry( 'appended', $new_articles );
						$grid.masonry( 'layout' );
					} );

					$( '.testimonials' ).masonry( {
						itemSelector: '.testimonial',
						gutter: 0,
						isOriginLeft: !$( 'body' ).is( '.rtl' )
					} );

					var footer_widgets = $( '#footer .footer-widgets' ).masonry( {
						itemSelector: '.widget',
						gutter: 0,
						isOriginLeft: !$( 'body' ).is( '.rtl' )
					} );

					// Reflow Footer Widgets if changed in the Customizer.
					if ( 'undefined' !== typeof wp && wp.customize && wp.customize.selectiveRefresh ) {

						wp.customize.selectiveRefresh.bind( 'sidebar-updated', function( sidebarPartial ) {
							if ( 'sidebar-2' === sidebarPartial.sidebarId ) {
								footer_widgets.masonry( 'reloadItems' );
								footer_widgets.masonry( 'layout' );
							}
						} );

					}

				}

			}
		);

		// responsive navigation
		$( '.menu-toggle' ).on( 'click', function() {
			$( this ).parent().toggleClass( 'menu-on' );
		} );


		// menu
		$( '.menu' ).find( 'a' ).on( 'focus blur', function() {
			$( this ).parents().toggleClass( 'focus' );
		} );

		// mobile body class
		$( 'body' ).addClass( is_touch_device() ? 'device-touch' : 'device-click' );

	} );

} )( jQuery );
