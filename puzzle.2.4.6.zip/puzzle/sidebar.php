<?php
/**
 * Sidebar template
 *
 * @package Puzzle
 */

	if ( is_singular() && is_active_sidebar( 'sidebar-1' ) ) {
?>
<div class="sidebar sidebar-main" role="complementary">
<?php
	do_action( 'before_sidebar' );
	dynamic_sidebar( 'sidebar-1' );
?>
</div>
<?php
	}
