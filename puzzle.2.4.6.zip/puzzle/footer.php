<?php
/**
 * Footer Template
 *
 * @package Puzzle
 */
?>
	</div>
<?php
	if ( puzzle_sidebar_visible() ) {
		get_sidebar();
	}

	if ( is_single() ) {
		get_template_part( 'inc/latest-posts' );
	}
?>
</div>

<footer role="contentinfo" id="footer" class="container">
<?php
	if ( is_active_sidebar( 'sidebar-2' ) ) {
?>
	<aside class="footer-widgets sidebar-footer">
		<?php dynamic_sidebar( 'sidebar-2' ); ?>
	</aside>
<?php
	}

	$menu = wp_nav_menu(
		array(
			'theme_location' => 'social_menu',
			'echo' => false,
			'container' => '',
			'depth' => 1,
			'link_before' => '<span class="screen-reader">',
			'link_after' => '</span>',
			'fallback_cb' => '__return_false',
		)
	);

	if ( $menu ) {
?>
		<div class="menu-social-links">
			<?php echo $menu; ?>
		</div>
<?php
	}

	/**
	 * Check to see if a custom credits option is set.
	 * If custom credits are set then the filter should output the credits and
	 * return a non false value. This will hide the default footer credits.
	 */
	if ( false === apply_filters( 'puzzle_credits', false ) ) {

?>
	<section class="footer-wrap">
<?php
		if ( function_exists( 'the_privacy_policy_link' ) ) {
			the_privacy_policy_link( '', '<span class="sep"> | </span>' );
		}
?>
		<a href="http://wordpress.org/" title="<?php esc_attr_e( 'A Semantic Personal Publishing Platform', 'puzzle' ); ?>" rel="generator"><?php printf( __( 'Proudly powered by %s', 'puzzle' ), 'WordPress' ); ?></a>
		<span class="sep"> | </span>
		<?php printf( __( 'Theme: %1$s by %2$s.', 'puzzle' ), 'Puzzle', '<a href="https://prothemedesign.com/" rel="designer">Pro Theme Design</a>' ); ?>
	</section>

<?php
	}
?>

</footer>

<?php

	wp_footer();
?>

</body>
</html>