<?php
/**
 * Single page template
 *
 * @package Puzzle
 */

	get_header();
?>
	<div class="main-content">
<?php

	if ( have_posts() ) {

		while ( have_posts() ) {
			the_post();
			get_template_part( 'content-page' );
			if ( comments_open() || '0' != get_comments_number() ) {
				comments_template( '', true );
			}
		}

	} else {
		get_template_part( 'content-empty' );
	}

?>
	</div>
<?php

	get_footer();