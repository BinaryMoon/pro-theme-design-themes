<?php
/**
 * Footer Template
 *
 * @package Carmack
 */

	get_sidebar();
?>

	</div>

	<footer id="footer">

<?php
	get_sidebar( 'footer' );
?>

		<a href="#header" class="scroll-to scroll-to-top">
			<?php carmack_svg( 'navigate-top' ); ?>
			<span class="screen-reader-text"><?php esc_html_e( 'Back to Top', 'carmack' ); ?></span>
		</a>

<?php
	carmack_social_links();
?>

		<section class="footer-wrap" role="contentinfo">
<?php
	if ( function_exists( 'the_privacy_policy_link' ) ) {
		the_privacy_policy_link( '', '<span class="sep" role="separator" aria-hidden="true"> | </span>' );
	}
?>
			<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'carmack' ) ); ?>" title="<?php esc_attr_e( 'A Semantic Personal Publishing Platform', 'carmack' ); ?>" rel="generator"><?php printf( esc_html__( 'Proudly powered by %s', 'carmack' ), 'WordPress' ); ?></a>
			<span class="sep" role="separator" aria-hidden="true"> | </span>
			<?php printf( esc_html__( 'Theme: %1$s by %2$s.', 'carmack' ), 'Carmack', '<a href="https://prothemedesign.com/" rel="designer">Pro Theme Design</a>' ); ?>
		</section>

	</footer>

</div>

<?php
	if ( carmack_overlay_visible() ) {
?>

<section class="menu-overlay" id="menu-overlay" aria-expanded="false">

	<div class="container container-close">

		<button class="close-overlay">
			<?php carmack_svg( 'close' ); ?>
			<span class="screen-reader-text"><?php esc_html_e( 'Close Menu Overlay', 'carmack' ); ?></span>
		</button>

	</div>

	<div class="container container-nav-sidebar">

<?php
	if ( has_nav_menu( 'primary' ) ) {
?>

		<nav role="navigation" class="nav-primary" aria-label="<?php esc_attr_e( 'Primary Menu', 'carmack' ); ?>">

<?php
		// Hidden on wide screen, displayed on mobile.
		wp_nav_menu(
			array(
				'theme_location' => 'primary',
				'menu_id' => 'nav',
				'menu_class' => 'menu-wrap',
				'container' => false,
				'fallback_cb' => false,
			)
		);
?>

		</nav>

<?php

	}

	if ( has_nav_menu( 'secondary' ) ) {

?>

		<nav role="navigation" class="nav-secondary" aria-label="<?php esc_attr_e( 'Secondary Menu', 'carmack' ); ?>">

<?php
		wp_nav_menu(
			array(
				'theme_location' => 'secondary',
				'menu_id' => 'nav',
				'menu_class' => 'menu-wrap',
				'container' => false,
				'fallback_cb' => false,
			)
		);
?>

		</nav>

<?php

	}

	get_sidebar( 'overlay' );

?>

	</div>

</section>

<?php
	}

	get_template_part( 'parts/single-popup' );

	wp_footer();
?>

</body>
</html>
