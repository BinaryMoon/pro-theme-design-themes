<?php
/**
 * Homepage Template
 *
 * @package Carmack
 */

	get_header();
?>

	<main role="main">

<?php
	if ( have_posts() ) {

?>

		<div id="main-content" class="main-content content-posts">

			<span class="divider"><span class="carmack_news_section_title"><?php carmack_news_section_title(); ?></span></span>

<?php
		while ( have_posts() ) {

			the_post();
			get_template_part( 'parts/content', 'format-' . get_post_format() );

		}
?>

		</div>

<?php
		the_posts_pagination(
			array(
				'mid_size' => 2,
				'prev_text' => esc_html__( 'Previous Page', 'carmack' ),
				'next_text' => esc_html__( 'Next Page', 'carmack' ),
			)
		);

	} else {
?>

		<div class="main-content">

<?php
		get_template_part( 'parts/content-empty' );
?>

		</div>

<?php
	}
?>

	</main>

<?php
		get_footer();
