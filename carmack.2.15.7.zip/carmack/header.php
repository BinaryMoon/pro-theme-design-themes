<?php
/**
 * Header Template
 *
 * @package Carmack
 */

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<?php carmack_include_svg_icons(); ?>

<div class="webpage">

	<a href="#site-content" class="screen-reader-shortcut"><?php esc_html_e( 'Skip to content', 'carmack' ); ?></a>

	<header class="masthead" id="header" role="banner">

		<div class="menu-wrapper">

<?php
	the_custom_logo();
?>

			<nav class="menu container" role="navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'carmack' ); ?>">

				<button class="menu-toggle" aria-controls="menu-overlay" aria-expanded="false">

<?php
		carmack_svg( 'menu-rows' );
		esc_html_e( 'Menu', 'carmack' );
?>

				</button>

<?php
	wp_nav_menu(
		array(
			'theme_location' => 'primary',
			'menu_id' => 'nav',
			'menu_class' => 'menu-wrap',
			'container' => false,
			'fallback_cb' => false,
		)
	);
?>

			</nav>

		</div>

		<div class="branding-wrapper container">

			<div class="branding">

<?php
	if ( carmack_overlay_visible() ) {
?>

				<button class="open-overlay">
					<?php carmack_svg( 'menu-rows' ); ?>
					<span class="screen-reader-text"><?php esc_html_e( 'Open Menu Overlay', 'carmack' ); ?></span>
				</button>

<?php
	}

	if ( is_front_page() ) {
?>
				<h1 class="site-title">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
				</h1>
<?php
	} else {
?>
				<p class="site-title">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
				</p>
<?php
	}

	// Get site description.
	$carmack_description = get_bloginfo( 'description', 'display' );

	if ( $carmack_description || is_customize_preview() ) {
?>
			<p class="site-description">
				<?php echo $carmack_description; /* WPCS: xss ok. */ ?>
			</p>
<?php
	}
?>
			</div>

		</div>

	</header>

<?php

	carmack_header();

	get_template_part( 'parts/jetpack-featured-content' );

	do_action( 'before' );

?>

	<div class="container" id="site-content">
