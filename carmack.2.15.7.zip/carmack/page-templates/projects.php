<?php
/**
 * Template Name: Projects
 *
 * @package Carmack
 */

	get_header();

?>

	<main role="main">

		<header class="entry-header">
<?php
			if ( is_front_page() ) {

				the_title( '<h2 class="entry-title">', '</h2>' );

			} else {

				the_title( '<h1 class="entry-title">', '</h1>' );

			}
?>
		</header>

<?php
	if ( have_posts() ) {
		while( have_posts() ) {

			the_post();

			if ( get_the_content() ) {
?>

		<section class="entry-single">

<?php
		the_content();
?>

		</section>

<?php
			}
		}
	}

	carmack_project_terms();

	$query = new WP_Query(
		array(
			'post_type' => 'jetpack-portfolio',
			'posts_per_page' => 999,
			'ignore_sticky_posts' => true,
		)
	);

	if ( $query->have_posts() ) {
?>

		<div id="main-content" class="main-content content-posts">

<?php
		while ( $query->have_posts() ) {

			$query->the_post();

			get_template_part( 'parts/content', 'format-' . get_post_format() );

		}
?>

		</div>

<?php
	} else {
?>

		<div class="main-content">

<?php
		get_template_part( 'content-empty' );
?>

		</div>

<?php
	}

	wp_reset_postdata();
?>

	</main>

<?php
	get_footer();
