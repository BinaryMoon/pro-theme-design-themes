<?php
/**
 * Full width page template
 * Template Name: Full Width
 *
 * @package Carmack
 */

	get_header();

?>

	<main role="main" class="full-width">

		<div class="main-content">

<?php
	if ( have_posts() ) {

		while ( have_posts() ) {

			the_post();

			get_template_part( 'parts/content-single', get_post_type() );
			get_template_part( 'parts/comments' );

		}
	}
?>

		</div>

	</main>

<?php
	get_footer();
