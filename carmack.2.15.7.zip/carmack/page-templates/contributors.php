<?php
/**
 * Template Name: Contributor Page
 *
 * @package Carmack
 */

	get_header();

	get_template_part( 'parts/featured-content' );
?>

	<main role="main">

<?php
	if ( have_posts() ) {

		while ( have_posts() ) {

			the_post();
?>

		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

			<header class="entry-header">
<?php
			if ( is_front_page() ) {

				the_title( '<h2 class="entry-title">', '</h2>' );

			} else {

				the_title( '<h1 class="entry-title">', '</h1>' );

			}
?>
			</header>

			<section class="entry entry-single">

<?php
			the_content();

			get_template_part( 'parts/edit-post' );
?>

			</section>

			<section class="entry-contributors">

<?php
			get_template_part( 'parts/content-contributors' );
?>

			</section>

		</article>

<?php
		}
	}
?>

	</main>

<?php
	get_footer();
