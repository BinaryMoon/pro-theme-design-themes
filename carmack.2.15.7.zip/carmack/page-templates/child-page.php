<?php
/**
 * Template Name: Child Page Grid
 *
 * @package Carmack
 */

	get_header();

	get_template_part( 'parts/featured-content' );
?>

	<main role="main">

<?php
	if ( have_posts() ) {

		while ( have_posts() ) {

			the_post();
?>

		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

			<header class="entry-header">
<?php
			if ( is_front_page() ) {

				the_title( '<h2 class="entry-title">', '</h2>' );

			} else {

				the_title( '<h1 class="entry-title">', '</h1>' );

			}
?>
			</header>

			<section class="entry entry-single">

<?php
			the_content();

			get_template_part( 'parts/edit-post' );
?>

			</section>

<?php
		}
	}

	// List child pages.
	$child_pages = carmack_child_pages();

	if ( $child_pages->have_posts() ) {
?>

			<section class="entry-children">

<?php
		while ( $child_pages->have_posts() ) {

			$child_pages->the_post();

			get_template_part( 'parts/content-child-page' );

		}
?>

			</section>

<?php
	}

	wp_reset_postdata();
?>

		</article>

	</main>

<?php
	get_footer();
