<?php
/**
 * Footer Sidebar Template
 *
 * @package Carmack
 */

	if ( is_active_sidebar( 'sidebar-2' ) ) {
?>

<!-- Sidebar Footer (2) -->

<aside class="footer-widgets sidebar-footer sidebar" role="complementary">

	<div class="container">
		<?php dynamic_sidebar( 'sidebar-2' ); ?>
	</div>

</aside>

<?php
	}
