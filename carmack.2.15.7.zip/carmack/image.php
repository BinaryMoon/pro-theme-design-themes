<?php
/**
 * Image Attachment template
 *
 * @package Carmack
 */

	get_header();

	while ( have_posts() ) {

		the_post();
?>

	<main class="main-content" role="main">

		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

			<header class="entry-header">

<?php
		get_template_part( 'parts/post-meta' );
		the_title( '<h1 class="entry-title">', '</h1>' );
?>

			</header>

			<section class="entry">

				<div class="attachment-image">
					<?php echo wp_get_attachment_link( get_the_ID(), 'carmack-attachment-fullsize' ); ?>
				</div>

<?php
		if ( has_excerpt() ) {
?>
				<div class="attachment-caption">
					<?php the_excerpt(); ?>
				</div>
<?php
		}

		the_content();

		if ( $post->post_parent ) {
?>

				<nav id="image-navigation" class="navigation image-navigation" role="navigation">
					<div class="nav-links">
						<span class="nav-parent"><a href="<?php echo esc_url( get_permalink( $post->post_parent ) ); ?>" rev="attachment" class="attachment-parent"><?php esc_html_e( '&lsaquo; Return to post', 'carmack' ); ?></a></span>
						<span class="nav-previous"><?php previous_image_link( false, esc_html__( 'Previous Image', 'carmack' ) ); ?></span>
						<span class="nav-next"><?php next_image_link( false, esc_html__( 'Next Image', 'carmack' ) ); ?></span>
					</div>
				</nav>

<?php
		}
?>

			</section>
		</article>

<?php
		get_template_part( 'parts/comments' );
?>

	</main>

<?php
	}

	get_footer();
