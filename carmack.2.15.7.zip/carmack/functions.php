<?php
/**
 * Reusable theme functions
 *
 * @package Carmack
 */

/**
 * Color scheme - https://coolors.co/app/ffffff-000000-ffee00-2480cc
 */

// WordPress specific functionality (actions and filters).
require 'inc/wordpress.php';

// Custom header.
require 'inc/custom-header.php';

// Reusable Template Functions.
require 'inc/template-tags.php';

// Jetpack specific functionality.
require 'inc/jetpack.php';

// Customizer controls for setting theme properties.
require 'inc/customizer.php';

// Customizer auto update controls without full page refresh.
require 'inc/customizer-refresh.php';

/**
 * Load WooCommerce compatibility file.
 */
if ( class_exists( 'WooCommerce' ) ) {
	require 'inc/woocommerce.php';
}
