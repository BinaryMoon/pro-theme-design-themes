<?php
/**
 * Comments template.
 * Displays the comments, and the comment form.
 *
 * @package Carmack
 */

	// Ignore comments if a password is required.
	if ( post_password_required() ) {
		return;
	}

	// Ensure the current post type supports comments.
	if ( ! post_type_supports( get_post_type(), 'comments' ) ) {
		return;
	}

?>

	<section class="content-comments">

<?php
	if ( have_comments() ) {
?>

		<h2 id="comments" class="comments-title">

<?php

		$carmack_comment_count = (int) get_comments_number();

		if ( 1 === $carmack_comment_count ) {

			printf(
				/* Translators: %1$s: Post title */
				esc_html__( 'One thought on &ldquo;%1$s&rdquo;', 'carmack' ),
				'<span>' . get_the_title() . '</span>'
			); // WPCS: XSS OK.

		} else {

			printf(
				esc_html(
					/* Translators: %1$s: Comment count, %2$s: Post title */
					_nx(
						'%1$s thought on &ldquo;%2$s&rdquo;',
						'%1$s thoughts on &ldquo;%2$s&rdquo;',
						$carmack_comment_count,
						'comments title',
						'carmack'
					)
				),
				number_format_i18n( $carmack_comment_count ),
				'<span>' . get_the_title() . '</span>'
			); // WPCS: XSS OK.

		}

?>

			<a href="#respond" class="scroll-to">
				<span class="screen-reader-text"><?php esc_html_e( 'Leave a comment', 'carmack' ); ?></span>
				<?php esc_html_e( '&rsaquo;', 'carmack' ); ?>
			</a>

		</h2>

		<ol class="comment-list" id="singlecomments">
<?php
		wp_list_comments(
			array(
				'avatar_size' => 80,
				'short_ping' => true,
				'reply_text' => carmack_svg( 'reply', false ) . '<span class="screen-reader-text">' . esc_html__( 'Reply', 'carmack' ) . '</span>',
			)
		);
?>
		</ol>
<?php
		the_comments_navigation();

	}

	if ( 'open' === $post->comment_status ) {

		comment_form(
			array(
				'title_reply_before' => '<h2 class="comment-reply-title">',
				'title_reply_after'  => '</h2>',
				'cancel_reply_before' => '',
				'cancel_reply_after' => '',
				'cancel_reply_link' => carmack_svg( 'close', false ) . '<span class="screen-reader-text">' . esc_html__( 'Cancel Reply', 'carmack' ) . '</span>',
			)
		);

	}
?>

		<div class="user-icon-container">
			<?php carmack_svg( 'user' ); ?>
		</div>

	</section>
