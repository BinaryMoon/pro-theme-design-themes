<?php
/**
 * Error - file not found
 *
 * @package Carmack
 */

	get_header();
?>

	<main role="main">

		<div class="header-404">
			<?php carmack_svg( '404' ); ?>
		</div>

		<?php get_template_part( 'parts/content-empty' ); ?>

	</main>

<?php
	get_footer();
