<?php
/**
 * Testimonials Archive Template
 * Testimonials display at: http://website.com/testimonial/
 *
 * @package Carmack
 */

	get_header();
?>

	<main role="main">

<?php

	if ( have_posts() ) {

		if ( $carmack_image = carmack_testimonials_image() ) {

			$carmack_image_allowed_properties = array(
				'src' => array(),
				'width' => array(),
				'height' => array(),
				'class' => array(),
			);
?>

	<div class="header-image">

		<?php echo wp_kses( $carmack_image, array( 'img' => $carmack_image_allowed_properties ) ); ?>

	</div>

<?php
		}
?>

		<header class="entry-archive-header">
			<h1 class="entry-title entry-archive-title"><?php carmack_testimonials_title(); ?></h1>
<?php
		carmack_testimonials_description( '<div class="category-description">', '</div>' );
?>
		</header>

		<div id="main-content" class="main-content testimonials content-testimonials">
<?php
		while ( have_posts() ) {

			the_post();
			get_template_part( 'parts/content-single', 'testimonial' );

		}
?>
		</div>

<?php
	} else {
?>

		<div class="main-content">

<?php
		get_template_part( 'parts/content-empty' );
?>

		</div>

<?php
	}
?>

	</main>

<?php
	get_footer();
