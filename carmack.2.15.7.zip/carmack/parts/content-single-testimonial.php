<?php
/**
 * Individual Testimonial layout
 *
 * @package Carmack
 */

	$image = get_the_post_thumbnail( get_the_ID(), 'carmack-attachment', array( 'class' => 'avatar' ) );
?>

<article id="post-<?php the_ID(); ?>" class="testimonial">

	<div class="entry">

<?php
	the_content(
		sprintf(
			/* Translators: %s = post name */
			esc_html__( 'Read more %s', 'carmack' ),
			the_title( '<span class="screen-reader-text">', '</span>', false )
		)
	);
?>

	</div>

	<div class="entry-meta">

<?php
	if ( $image ) {
		echo $image; // WPCS: XSS OK.
	}
?>

		<h3><?php the_title(); ?></h3>

	</div>

</article>
