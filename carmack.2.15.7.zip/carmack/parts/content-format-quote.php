<?php
/**
 * Quote content
 *
 * @package Carmack
 */

	$content = get_the_content();

	preg_match( '/<blockquote.*>(.*)<\/blockquote>/siU', $content, $quotes );

	if ( ! empty( $quotes[1] ) ) {

		$content = $quotes[1];

	}

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<?php carmack_sticky(); ?>

	<blockquote>

		<?php echo wp_kses_post( wpautop( $content ) ); ?>

	</blockquote>

	<span class="permalink">
		<a href="<?php the_permalink(); ?>">
			<?php carmack_svg( 'post-quote' ); ?>
			<span class="screen-reader-text"><?php printf( esc_html__( 'Permanent link to %s', 'carmack' ), get_the_title() ); ?></span>
		</a>
	</span>

</article>
