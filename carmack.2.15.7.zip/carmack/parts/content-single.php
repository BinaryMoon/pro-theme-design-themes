<?php
/**
 * Single post content
 *
 * @package Carmack
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<header class="entry-header">

<?php
	get_template_part( 'parts/post-meta' );
	the_title( '<h1 class="entry-title">', '</h1>' );

	if ( get_theme_mod( 'carmack_display_featured_image_on_single', false ) || is_customize_preview() ) {
		the_post_thumbnail( 'carmack-slider' );
	}
?>

	</header>

	<section class="entry entry-single">

<?php
	the_content(
		sprintf(
			/* Translators: %s = post name */
			esc_html__( 'Read more %s', 'carmack' ),
			the_title( '<span class="screen-reader-text">', '</span>', false )
		)
	);

	get_template_part( 'parts/edit-post' );

	wp_link_pages(
		array(
			'before' => '<div class="pagination">',
			'after'  => '</div>',
			'link_before' => '<span>',
			'link_after'  => '</span>',
		)
	);

	if ( is_single() ) {

		carmack_author_bio();

	}
?>

	</section>

</article>

<?php
	the_post_navigation(
		array(
			'next_text' => '<span class="meta-nav" aria-hidden="true">' . esc_html__( 'Next', 'carmack' ) . '</span> ' .
				'<span class="screen-reader-text">' . esc_html__( 'Next post:', 'carmack' ) . '</span> ' .
				'<span class="post-title">%title</span>',
			'prev_text' => '<span class="meta-nav" aria-hidden="true">' . esc_html__( 'Previous', 'carmack' ) . '</span> ' .
				'<span class="screen-reader-text">' . esc_html__( 'Previous post:', 'carmack' ) . '</span> ' .
				'<span class="post-title">%title</span>',
		)
	);
