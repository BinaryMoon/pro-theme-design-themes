<?php
/**
 * Page content
 *
 * @package Carmack
 */

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<header class="entry-header">

<?php
	carmack_breadcrumbs();

	// If the page is being used as the static homepage then.
	if ( is_front_page() ) {

		the_title( '<h2 class="entry-title">', '</h2>' );

	} else {

		the_title( '<h1 class="entry-title">', '</h1>' );

	}

	if ( get_theme_mod( 'carmack_display_featured_image_on_single', false ) || is_customize_preview() ) {
		the_post_thumbnail( get_the_ID(), 'carmack-slider' );
	}

?>

	</header>

	<section class="entry entry-single">

<?php
	the_content(
		sprintf(
			/* Translators: %s = post name */
			esc_html__( 'Read more %s', 'carmack' ),
			the_title( '<span class="screen-reader-text">', '</span>', false )
		)
	);

	get_template_part( 'parts/edit-post' );

	wp_link_pages(
		array(
			'before' => '<div class="pagination">',
			'after'  => '</div>',
			'link_before' => '<span>',
			'link_after'  => '</span>',
		)
	);
?>

	</section>

</article>
