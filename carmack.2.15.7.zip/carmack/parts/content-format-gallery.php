<?php
/**
 * Gallery content
 *
 * @package Carmack
 */

	$gallery = get_post_gallery( get_the_ID() );

	// No gallery so use default layout.
	if ( ! $gallery ) {

		get_template_part( 'parts/content' );
		return;

	}
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<?php carmack_sticky(); ?>

	<div class="post-gallery">
		<?php echo $gallery; ?>
	</div>

	<section class="entry entry-archive">

<?php
	get_template_part( 'parts/post-meta' );

	if ( get_the_title() ) {
?>

		<h2 class="entry-title">
			<a href="<?php the_permalink() ?>" rel="bookmark">
				<?php the_title(); ?>
			</a>
		</h2>

<?php
	}
?>

		<div class="excerpt"><?php the_excerpt(); ?></div>

	</section>

</article>
