<?php
/**
 * Post meta data
 *
 * @package Carmack
 */

?>

	<div class="post-meta-data">

<?php
	carmack_svg( 'post-' . esc_html( get_post_format() ) );

	carmack_post_time();

	carmack_post_author();

	carmack_comments_link();

	carmack_the_main_category();
?>

	</div>
