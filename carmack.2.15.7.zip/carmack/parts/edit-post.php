<?php
/**
 * Edit post link
 *
 * @package Carmack
 */

	edit_post_link(
		sprintf(
			/* translators: %s: Name of current post */
			esc_html__( 'Edit %s', 'carmack' ),
			the_title( '<span class="screen-reader-text">', '</span>', false )
		),
		'<span class="edit-link">',
		'</span>'
	);
