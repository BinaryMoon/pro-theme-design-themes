<?php
/**
 * Audio content
 *
 * @package Granule
 */

	$content = apply_filters( 'the_content', get_the_content() );
	$audio = get_media_embedded_in_content( $content, array( 'audio' ) );
	$image = get_the_post_thumbnail( get_the_ID(), 'carmack-archive' );

	if ( ! $audio ) {

		get_template_part( 'parts/content' );
		return;

	}

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<div class="entry-audio">
		<?php echo $audio[0]; /* WPCS: xss ok. */ ?>
	</div>

<?php
	carmack_sticky();

	if ( $image ) {
?>

	<a href="<?php echo esc_url( get_permalink() ); ?>" class="thumbnail">
		<?php echo $image; ?>
	</a>

<?php
	}
?>

	<section class="entry entry-archive">

<?php
	get_template_part( 'parts/post-meta' );

	if ( get_the_title() ) {
?>

		<h2 class="entry-title">
			<a href="<?php the_permalink() ?>" rel="bookmark">
				<?php the_title(); ?>
			</a>
		</h2>

<?php
	}
?>

		<div class="excerpt"><?php the_excerpt(); ?></div>

	</section>

</article>
