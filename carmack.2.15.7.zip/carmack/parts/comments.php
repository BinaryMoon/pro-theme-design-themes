<?php
/**
 * Reusable code for adding comments to a page
 *
 * @package Carmack
 */

	if ( comments_open() || get_comments_number() ) {

		comments_template( '', true );

	}
