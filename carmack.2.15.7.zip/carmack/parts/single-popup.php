<?php
/**
 * Single page/ post popup
 * Appears at the top of the page when a user scrolls down
 * Not visible on mobile sites (hidden with CSS)
 * Bar is hidden from screen readers since it duplicates content that's already visible
 *
 * @package Carmack
 */

if ( ! is_singular() ) {

	return;

}

?>

<div class="single-nav" aria-hidden="true">

	<div class="single-nav-wrapper">

		<div class="single-info">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
			<span class="post-title"><?php the_title(); ?></span>
		</div>

		<?php carmack_social_links(); ?>

	</div>

</div>
