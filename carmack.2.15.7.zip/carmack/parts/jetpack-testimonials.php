<?php
/**
 * List Testimonials on a page
 *
 * @package Carmack
 */

	$testimonials = new WP_Query(
		array(
			'post_type' => 'jetpack-testimonial',
			'orderby' => 'rand',
			'posts_per_page' => 2,
			'no_found_rows' => true,
		)
	);

	// Only display if there are some testimonials to display.
	if ( $testimonials->have_posts() ) {
?>

	<section class="content-testimonials">

		<header class="entry-header">
			<h2 class="entry-title"><?php carmack_testimonials_title(); ?></h2>
			<a href="<?php echo esc_url( home_url( 'testimonial/' ) ); ?>" class="button"><?php esc_html_e( 'View All &rsaquo;', 'carmack' ); ?></a>
		</header>

		<div class="testimonials">

<?php

		while ( $testimonials->have_posts() ) {

			$testimonials->the_post();
			get_template_part( 'parts/content-testimonial' );

		}

?>

		</div>

	</section>

<?php
	}

	wp_reset_postdata();
