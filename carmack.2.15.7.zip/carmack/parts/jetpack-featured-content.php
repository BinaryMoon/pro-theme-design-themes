<?php
/**
 * Jetpack Featured Content
 * See: https://jetpack.me/support/featured-content/
 *
 * @package Carmack
 */

	/**
	 * Will only display posts on the homepage, whatever page type is used
	 * (static front page or blog post list).
	 */
	if ( carmack_has_featured_posts() ) {

		$featured_posts_grid = array();
		$featured_posts = carmack_get_featured_posts();
		// If you filter this value to a higher number (such as 50), then the
		// slider will always be used.
		$featured_slider_minimum = apply_filters( 'carmack_slider_minimum', 3 );

		// There's enough featured posts to show the slider and a row of posts underneath.
		// If there's <= 3 posts then they will all display in the slider.
		if ( count( $featured_posts ) > $featured_slider_minimum ) {

			// Split the last 3 posts off the list so they can be added under the slider.
			$featured_posts_grid = array_slice( $featured_posts, count( $featured_posts ) - 3, 3 );

			// Remove the last 3 posts from the featured posts list so they aren't shown twice.
			$featured_posts = array_slice( $featured_posts, 0, count( $featured_posts ) - 3 );

		}

		// Display the slider.
		if ( $featured_posts ) {

?>

	<section class="showcase">

<?php

		foreach ( $featured_posts as $post ) {

			setup_postdata( $post );

			$styles = array();
			$image = carmack_archive_image_url( get_the_ID(), 'carmack-slider' );

			if ( $image ) {

				$styles = array(
					'background-image:url(' . esc_url( $image ) . ');'
				);

			}
?>

		<article class="item post-archive" style="<?php echo implode( ' ', $styles ); ?>">

			<!-- a large link that makes the image clickable -->
			<a href="<?php the_permalink(); ?>" aria-hidden="true" class="click" title="<?php the_title_attribute(); ?>"></a>

			<div class="container">
				<h2 class="entry-title">
					<a href="<?php the_permalink(); ?>" class="entry" rel="bookmark"><?php the_title(); ?></a>
				</h2>
			</div>


		</article>

<?php
		}
?>

	</section>

<?php
		}

		// Display 3 posts under the slider.
		if ( $featured_posts_grid ) {

?>

	<div class="featured-posts featured-posts-banner container">

<?php

			foreach ( $featured_posts_grid as $post ) {

				setup_postdata( $post );

				// Always use the standard post format for featured posts.
				get_template_part( 'parts/content' );

			}

?>

	</div>

<?php
		}

		wp_reset_postdata();

	}
