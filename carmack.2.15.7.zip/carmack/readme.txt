=== Carmack ===

Contributors: binarymoon
Requires at least: 4.5
Tested up to: 4.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: black, white, yellow, dark, light, one-column, two-columns, right-sidebar, responsive-layout, accessibility-ready, author-bio, blog-excerpts, breadcrumb-navigation, classic-menu, custom-background, custom-colors, custom-header, custom-menu, editor-style, featured-content-with-pages, featured-images, featured-image-header, flexible-header, full-width-template, infinite-scroll, post-formats, post-slider, rtl-language-support, site-logo, sticky-post, testimonials, theme-options, threaded-comments, translation-ready, blog, business, design, fashion, gaming, journal, lifestream, magazine, music, news, sports, tumblelog, bright, clean, colorful, conservative, contemporary, elegant, formal, geometric, light, modern, professional, simple, sophisticated, tech

== Description ==

Carmack is a magazine theme, designed primarily for car magazines - but equally usable for Video Games, Movies, Music or any other visual magazine style site. Carmack support featured content and post formats to allow you to create the perfect website.

[Theme documentation](https://prothemedesign.com/documentation/theme/carmack/)

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Carmack includes support for [Styleguide](https://wordpress.org/plugins/styleguide/) - a plugin that allows you to change fonts, and colours in WordPress themes.

Carmack includes support for most features in [Jetpack](https://wordpress.org/plugins/jetpack/), including Infinite Scroll, Featured Content, and Site Logo.

== Changelog ==

= 2.15.7 - 20th January 2021 =
* Fix issue with editor css on blocks like Verse, Code and any other blocks that use the `pre` element.
* Fix image alignments in post content.
* Fix wordwrap on post summaries.

= 2.15.6 - 2nd January 2021 =
* Update rtl.css
* Fix jQuery error since jquery migrate has been removed.

= 2.15.5 - 5th October 2020 =
* Add support for wp_body_open

= 2.15.4 - 12th August 2020 =
* Add support for 'no link logo' on homepage: https://make.wordpress.org/core/2020/07/28/themes-changes-related-to-get_custom_logo-in-wordpress-5-5/

= 2.15.3 - 13th July 2020 =
* Add support for accessible widget lists: https://make.wordpress.org/core/2020/07/09/accessibility-improvements-to-widgets-outputting-lists-of-links-in-5-5/
* Add 'navigation-widgets' to supported html5 types.

= 2.15.2 - 12th March 2020 =
* Improve Gutenberg styles.
* Improve editor styles.

= 2.15.1 - 6th February 2020 =
* Fix problem with WooCommerce change.

= 2.15 - 5th February 2020 =
* Add support for WooCommerce category images

= 2.14.4 - 30th September 2019 =
* Improve default search input styles.

= 2.14.3 - 1st July 2019 =
* Add resource hints for Google fonts.

= 2.14.2 - 21st May 2019 =
* Improve dropdown menu behaviour on touch devices.

= 2.14.1 - 14th May 2019 =
* Update Gutenberg style dequeue code since the hook has changed.

= 2.14 - 13th May 2019 =
* Add font display swap to Google Font loading, to increase font display speed.

= 2.13 - 14th March 2019 =
* Improve localisation abilities of comments title.
* Prefix some variables to avoid collisions.

= 2.12.12 - 13th March 2019 =
* Improve mobile styles for classic editor single posts & pages.

= 2.12.11 - 20th January 2019 =
* Ensure there is > 0 featured posts when using carmack_has_featured_posts().

= 2.12.10 - 8th November 2018 =
* Display excerpts on all post formats. These are hidden with css but can be enabled in the additional css area of the customizer.

= 2.12.9 - 26th October 2018 =
* Add custom font size support.
* More Gutenberg style improvements.

= 2.12.8 - 18th October 2018 =
* Fix issue with overlay (secondary) menu not displaying unless there is a primary menu set.
* Remove value passed to carmack_get_featured_posts since it is not used (not even a function parameter).

= 2.12.7 - 11th October 2018 =
* Make the minimum slider count value filterable.
* Remove the minimum value from carmack_has_featured_posts since it's not actually used.

= 2.12.6 - 7th October 2018 =
* Tweak the featured content display slightly so that the posts under the slider show up earlier.

= 2.12.5 - 6th October 2018 =
* Increase size of featured images to account for larger/ higher resolution screens. Proportions are maintained.
* Fix blockquote regex so that it works properly with Gutenberg quote blocks.
* Update rtl styles.

= 2.12.4 - 4th September 2018 =
* Ensure the overlay menus are active before adding them. Removes empty elements.
* Improve the styles of overlay menus so that elements are laid out more nicely when some are disabled.

= 2.12.3 - 2nd September 2018 =
* Improve layout of full width page template.

= 2.12.2 - 19th August 2018 =
* Replace gutenberg_has_blocks with has_blocks to match Gutenberg changes.
* Update editor theme slug so we can dequeue it to wp-block-library-theme to match Gutenberg changes.

= 2.12.1 - 28th July 2018 =
* Remove a var_dump that was outputting some test content. Apologies if you got caught with this.

= 2.12 - 27th July 2018 =
* Much better support for Gutenberg! Still a few things to add but it's looking really good now.
* Fix issue with svg compression for self hosted users.

= 2.11.4 - 22nd July 2018 =
* Increase the size of the Jetpack 'top posts' widget images so that they fill the space and don't sit there looking pathetic and tiny.

= 2.11.3 - 27th June 2018 =
* Correct the_post_thumbnail parameter on single post header images.

= 2.11.2 - 25th June 2018 =
* Make sure Gutenberg custom colours display correctly.
* Add support for styling Gutenberg button block so that button styles are consistant across the site.

= 2.11.1 - 3rd June 2018 =
* Add live customizer preview support for featured image setting.
* Fix incorrect function name.

= 2.11 - 27th May 2018 =
* Add support for displaying featured images on single posts & pages. Defaults to off, enable it through the customizer.
* Support for Gutenberg custom colours.
* Add basic support for Gutenberg editor styles. It's not perfect but it's a start.
* Improve coding standards errors.

= 2.10 - 20th May 2018 =
* Add support for privacy policy link in the site footer.
* Fix display of the cookie consent checkbox in the comments form.
* Make site title (with menu button) more flexible so that it will always look good.
* Improve display of Jetpack cookie widget, and Akismet GDPR notice.

= 2.9.8 - 12th May 2018 =
* Fix issue with category dropdown widgets not changing category.
* Tidy javascript formatting.

= 2.9.7 - 24th April 2018 =
* Improve display of next and prev post on blog posts on small screens.
* Improve display of post author info on small screens.

= 2.9.6 - 21st April 2018 =
* Ensure links in lists in the post content have underlines and so are accessible.

= 2.9.5 - 7th March 2018 =
* Switch content width to use rems, instead of ems for a more consistant appearance.

= 2.9.4 - 1st March 2018 =
* Ensure links in body content have underlines and so are accessible.

= 2.9.3 - 28th January 2018 =
* Optimize CSS.

= 2.9.2 - 12th January 2018 =
* Fix small bug with content positioning in post content

= 2.9.1 - 20th December 2017 =
* Further improvements to WooCommerce support

= 2.9 - 31st October 2017 =
* WooCommerce for all (.com and .org)
* Disable infinite-scroll on WooCommerce archive pages.

= 2.8.2 - 13th July 2017 =
* Remove include for inc/wpcom.php, since it's automatically included by WordPress.com sites
* Fix bug with slider js that was creating malformed html

= 2.8.1 - 3rd July 2017 =
* Fix PHP errors due to WooCommerce integration.

= 2.8 - 18th June 2017 =
* Add support for WooCommerce

= 2.7.1 - 10th June 2017 =
* Improve compatability with new media widgets in WP 4.8
* Update rtl styles

= 2.7 - 9th April 2017 =
* Add support for Jetpack content options

= 2.6.5 - 28th March 2017 =
* Fix clearing issue with post author information
* Improve responsive behaviour of iframes in sidebars (social widgets)

= 2.6.4 - 13th March 2017 =
* Remove js that is not used
* Update rtl styles

= 2.6.3 - 9th December 2016 =
* Improve the editor-styles.css
* Update rtl.css
* Simplify form styles

= 2.6.2 - 4th December 2016 =
* Show and hide site title and description in customizer without full page refresh
* Update rtl.css

= 2.6.1 - 27th November 2016 =
* Fix issue with gap between header and content when the site title is hidden and there's no menu overlay

= 2.6 - 21st November 2016 =
* Add live customizer preview for site title, and site description
* Add live customizer preview for theme properties (background triangle and latest news title)
* Fix customizer icon display on branding buttons where border radius was being removed

= 2.5.1 - 7th November 2016 =
* Fix related posts margin
* Fix gap between comment submit button and comment subscribe buttons
* Update print styles

= 2.5 - 31st October 2016 =
* Improve image attachment page to display description and captions
* Update rtl.css styles

= 2.4.7 - 8 October 2016 =
* Tweak styles of select boxes so they use browser defaults

= 2.4.6 - 7 September 2016 =
* Update editor-style.css

= 2.4.5 - 27 August 2016 =
* Only load slider javascript if on a page with featured posts.
* Fix post author comment highlighting so that it doesn't highlight commenters who reply to the post author.

= 2.4.4 - 21 August 2016 =
* Add support for wp-post-series plugin (self hosted version only)
* Add other bold italic font style for body font

= 2.4.3 - 14 August 2016 =
* Tweak margin size on .intro class so that content is spaced better
* Tweak related posts thumbnail sizes so that the image proportions more closely match the proportions used on featured image thumbnails to reduce instances of thumbnails being cropped.
* Add a 'compress' class to the pre tag that sets a max height. This means long pre tags will scroll.

= 2.4.2 - 3 August 2016 =
* Fix issue with responsive menu showing the second menu when it's not actually in use
* Tweaked overlay menu margins to better line things up on small screens
* Tweak link colours to make them stand out more
* Tweak text ligatures so that they are less imposing
* Improve styles

= 2.4.1 - 31st July 2016 =
* Improve menu rtl styles

= 2.4 - 30th July 2016 =
* Set up theme auto updates (self hosted only)
* Hide post date on sticky posts
* Make it clearer which menu goes in which location
* Tweak css for post embeds to reduce instances of them overlapping other content
* Change style deregister to dequeue since it seems to work better with WP4.6 not creating php errors
* Update rtl.css

= 2.3.3 - 19th July 2016 =
* Make the background triangle flip when viewing in rtl mode
* bump scripts and styles versions
* Add a generic button css class to allow links to be turned into buttons

= 2.3.1 - 17th July 2016 =
* Add 'All' link to projects list so that visitors can get back to the portfolio homepage easily

= 2.3 - 10th July 2016 =

Various accessibility Improvements including:
* improve focus styles of overlay hamburger
* improve focus styles on slider buttons
* change slider nav to use buttons instead of links
* improve aria landmark roles
* move role="contentinfo" to more appropriate place (footer credits rather than entire footer)
* make slider navigation more descriptive for screen reader users
* improve descriptive text on post pagination
* make keyboard focus jump to overlay when overlay is opened
* restrict keyboard focus to overlay when it is open
* improve contrast on sidebar links
* fix skip to content button so that it's visible again
* make back to top link set focus correctly
* improve aria roles on overlay toggles
* add option to disable autoplay on the slider
* Improve heading hierarchy when using a static front page

= 2.2.1 - 9th July 2016 =
* Update slider.js to the latest version (in preparation for improving accessibility of slider.js)

= 2.2 - 6th July 2016 =
* Fix issue with some post formats not displaying if they didn't have the required properties
* Fix issue with infinite scroll footer getting covered up.
* Improve rtl.css

= 2.1.1 - 4th July 2016 =
* Make sure the header image is centered on large displays

= 2.1 - 29th June 2016 =
* make the_posts_pagination display more pages

= 2.0 =
* wordpress.com release

= 1.0 =
* Initial release

== Credits ==

* [Merriweather Sans](https://www.google.com/fonts/specimen/Merriweather+Sans) Font from Google Fonts, licensed under [SIL Open Font License, 1.1](http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL)
