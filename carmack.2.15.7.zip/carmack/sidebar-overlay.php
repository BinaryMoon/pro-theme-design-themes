<?php
/**
 * Overlay Sidebar template
 *
 * @package Carmack
 */

	if ( is_active_sidebar( 'sidebar-3' ) ) {
?>

<!-- Sidebar Overlay (3) -->

<aside class="sidebar sidebar-overlay" role="complementary">

<?php
	dynamic_sidebar( 'sidebar-3' );
?>

</aside>

<?php
	}
