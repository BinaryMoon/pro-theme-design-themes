/**
 * Live-update changed settings in real time in the Customizer preview.
 */
/* global jQuery, document, wp */

;( function( $, document ) {

	$( document ).ready(
		function() {

			// Site background triangle.
			wp.customize(
				'carmack_display_triangle',
				function( value ) {
					value.bind(
						function( to ) {

							if ( to ) {
								$( 'body' ).addClass( 'carmack-display-triangle' )
									.removeClass( 'carmack-hide-triangle' );
							} else {
								$( 'body' ).removeClass( 'carmack-display-triangle' )
									.addClass( 'carmack-hide-triangle' );
							}

						}
					);
				}
			);

			// Show/ Hide featured image on single psots.
			wp.customize(
				'carmack_display_featured_image_on_single',
				function( value ) {

					var $image = $( '.entry-header img' );

					$image.hide();

					if ( value._value ) {
						$image.show();
					}

					value.bind(
						function( to ) {

							if ( to ) {
								$image.show();
							} else {
								$image.hide();
							}

						}
					);
				}
			);

			// Latest News Title.
			wp.customize(
				'carmack_latest_news_section_title',
				function( value ) {
					value.bind(
						function( to ) {
							$( '.carmack_news_section_title' ).text( to );
						}
					);
				}
			);

			// Site title.
			wp.customize(
				'blogname',
				function( value ) {
					value.bind(
						function( to ) {
							$( '.site-title a' ).text( to );
						}
					);
				}
			);

			// Site description.
			wp.customize(
				'blogdescription',
				function( value ) {
					value.bind(
						function( to ) {
							$( '.site-description' ).text( to );
						}
					);
				}
			);

			// Header text color.
			wp.customize(
				'header_textcolor',
				function( value ) {
					value.bind(
						function( to ) {
							if ( 'blank' === to ) {
								$( '.masthead .branding .site-title' ).css(
									{
										'clip': 'rect(1px, 1px, 1px, 1px)',
										'position': 'absolute'
									}
								);
							} else {
								$( '.masthead .branding .site-title' ).css(
									{
										'clip': 'auto',
										'position': 'relative'
									}
								);
								$( '.masthead .branding .site-title a, .masthead .branding .site-title a:hover, .masthead .branding p.site-description' ).css(
									{ 'color': to }
								);
							}
						}
					);
				}
			);

		}
	);

} )( jQuery, document );
