<?php
/**
 * Add support for WooCommerce.
 *
 * @see https://wordpress.org/plugins/woocommerce/
 * @package carmack
 */

/**
 * Add support for woocommerce
 */
function carmack_wc_support() {

	add_theme_support( 'woocommerce' );

	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );

}

add_action( 'after_setup_theme', 'carmack_wc_support' );


/**
 * Cart Link
 * Displayed a link to the cart including the number of items present and the cart total
 *
 * @return string Cart link html.
 */
function carmack_wc_cart_link() {

	if ( is_cart() ) {
		$class = 'current-menu-item';
	} else {
		$class = '';
	}

	// Capture the theme cart button.
	ob_start();

?>
	<li class="woocommerce-cart-button <?php echo esc_attr( $class ); ?>">

		<a class="cart-contents" href="<?php echo esc_url( wc_get_cart_url() ); ?>" title="<?php esc_attr_e( 'View your shopping cart', 'carmack' ); ?>">
			<span class="amount"><?php echo wp_kses_data( WC()->cart->get_cart_subtotal() ); ?></span> <span class="count">
<?php
	/* translators: %d = number of items in a WooCommerce cart */
	echo wp_kses_data( sprintf( _n( '%d item', '%d items', WC()->cart->get_cart_contents_count(), 'carmack' ), WC()->cart->get_cart_contents_count() ) );
?>
			</span>
		</a>

<?php

	// Don't output this in the cart since it will be empty.
	if ( ! is_cart() ) {

?>
		<ul class="woocommerce-cart-widget">
			<li>
				<?php the_widget( 'WC_Widget_Cart', array( 'title' => '' ) ); ?>
			</li>
		</ul>
<?php

	}

?>
	</li>

<?php

	return ob_get_clean();

}


/**
 * Remove Jetpack related posts from WooCommerce products
 *
 * @param  array $options Related posts options.
 * @return array
 */
function carmack_wc_remove_related_posts( $options ) {

	if ( ! class_exists( 'WooCommerce' ) ) {
		return $options;
	}

	if ( is_product() ) {
		$options['enabled'] = false;
	}

	return $options;

}

add_filter( 'jetpack_relatedposts_filter_options', 'carmack_wc_remove_related_posts' );


/**
 * Check to see if the current page is a WooCommerce page or not.
 *
 * @return boolean
 */
function carmack_is_woocommerce() {

	if ( ! class_exists( 'WooCommerce' ) ) {
		return false;
	}

	if ( is_woocommerce() ) {
		return true;
	}

	if ( is_account_page() ) {
		return true;
	}

	if ( is_checkout() || is_cart() ) {
		return true;
	}

	return false;

}


/**
 * Remove default WooCommerce actions
 */

remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );


/**
 * WooCommerce theme wrapper start.
 */
function carmack_wc_theme_wrapper_start() {
?>

	<main role="main">

		<div class="main-content content-woocommerce">

<?php
}

add_action( 'woocommerce_before_main_content', 'carmack_wc_theme_wrapper_start' );


/**
 * WooCommerce theme wrapper end.
 */
function carmack_wc_theme_wrapper_end() {
?>

		</div>

	</main>

<?php
}

add_action( 'woocommerce_after_main_content', 'carmack_wc_theme_wrapper_end' );


/**
 * Disable sidebar on WooCommerce pages
 *
 * @param  boolean $is_active_sidebar Current value of sidebar visibility.
 * @param  boolean $index             Sidebar to test.
 * @return boolean                    Whether to display the sidebar or not.
 */
function carmack_wc_is_sidebar_active( $is_active_sidebar, $index ) {

	if ( ! class_exists( 'WooCommerce' ) ) {
		return $is_active_sidebar;
	}

	if ( 'sidebar-1' === $index ) {

		// Not WooCommerce so return default.
		if ( ! carmack_is_woocommerce() ) {
			return $is_active_sidebar;
		}

		return false;

	}

	return $is_active_sidebar;

}

add_filter( 'is_active_sidebar', 'carmack_wc_is_sidebar_active', 10, 2 );


/**
 * Add cart link to navigation
 *
 * @param  string $html Menu html.
 * @param  object $args Menu arguments.
 * @return string       New menu html.
 */
function carmack_wc_nav_cart( $html, $args ) {

	if ( ! class_exists( 'WooCommerce' ) ) {
		return $html;
	}

	if ( 'primary' === $args->theme_location ) {

		$html = $html . carmack_wc_cart_link();

	}

	return $html;

}

add_filter( 'wp_nav_menu_items', 'carmack_wc_nav_cart', 10, 2 );


/**
 * Remove support for Jetpack infinite scroll for WooCommerce products since it
 * uses a different html structure.
 *
 * @param  WP_Query $query The current archive object.
 */
function carmack_cpt_archives_settings( $query ) {

	// Define the context.
	// Not on dashboard pages when inside the main query only on cpt archives.
	if ( ! is_admin() && $query->is_main_query() && is_post_type_archive( 'product' ) ) {

		// Remove infinite scroll inside this context.
		remove_theme_support( 'infinite-scroll' );

	}

}

add_action( 'pre_get_posts', 'carmack_cpt_archives_settings' );


/**
 * Set the category image.
 *
 * @param string $image The current header image.
 * @return string
 */
function carmack_wc_category_image( $image ) {

	if ( function_exists( 'is_product_category' ) && is_product_category() ) {

		global $wp_query;
		$cat = $wp_query->get_queried_object();
		$thumbnail_id = get_term_meta( $cat->term_id, 'thumbnail_id', true );
		$new_image = wp_get_attachment_image_src( $thumbnail_id, 'broadsheet-header' );

		if ( ! empty( $new_image[0] ) ) {
			$image = $new_image[0];
		}
	}

	return $image;

}

add_filter( 'carmack_header_image', 'carmack_wc_category_image' );


