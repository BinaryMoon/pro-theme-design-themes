<?php
/**
 * Jetpack Compatibility File
 *
 * @link https://jetpack.com/
 *
 * @package Carmack
 */

/**
 * Add theme support for Jetpack
 *
 * @link: https://jetpack.me/support/infinite-scroll/
 */
function carmack_jetpack_init() {

	add_theme_support(
		'infinite-scroll',
		apply_filters(
			'carmack_infinite_scroll',
			array(
				'container' => 'main-content',
				'footer_widgets' => 'sidebar-2',
				'footer' => 'footer-widgets',
				'posts_per_page' => 16,
				'render' => 'carmack_infinite_scroll_render',
				'wrapper' => false,
			)
		)
	);

	add_theme_support(
		'featured-content',
		apply_filters(
			'carmack_featured_content',
			array(
				'featured_content_filter' => 'carmack_get_featured_posts',
				'max_posts' => 8,
				'post_types' => array( 'post', 'page', 'jetpack-portfolio' ),
			)
		)
	);

	add_theme_support( 'jetpack-testimonial' );

	add_theme_support( 'jetpack-portfolio' );

	add_theme_support( 'jetpack-responsive-videos' );

	add_theme_support( 'jetpack-social-menu' );

	// Add support for Jetpack content options.
	add_theme_support(
		'jetpack-content-options',
		array(
			// The default setting of the theme: 'content', 'excerpt' or array( 'content, 'excerpt', ).
			'blog-display' => 'excerpt',
			'author-bio' => true,
			'author-bio-default' => false,
			'post-details' => array(
				'stylesheet' => 'carmack-style',
				'date' => '.posted-on',
				'categories' => '.tax-categories, .tax-title-categories, .post-lead-category',
				'tags' => '.tax-tags, .tax-title-tags',
				'author' => '.byline',
			),
		)
	);

}

add_action( 'after_setup_theme', 'carmack_jetpack_init' );


/**
 * Render infinite scroll content using template parts
 */
function carmack_infinite_scroll_render() {

	global $wp_query;

	carmack_get_more_featured_posts( $wp_query->query['paged'] );

	while ( have_posts() ) {

		the_post();

		if ( 'jetpack-testimonial' === get_post_format() ) {

			get_template_part( 'parts/content', 'testimonial' );

		} else {

			get_template_part( 'parts/content', 'format-' . get_post_format() );

		}
	}

}


/**
 * Get featured posts using Jetpack Featured content
 *
 * @return array List of featured posts.
 */
function carmack_get_featured_posts() {

	return apply_filters( 'carmack_get_featured_posts', array() );

}


/**
 * Get a list of featured posts using the Jetpack featured tag
 *
 * @param int $page Page Number.
 * @return object|false
 */
function carmack_get_more_featured_posts( $page = 1 ) {

	// Quit if user is has disabled IS featured posts.
	if ( ! get_theme_mod( 'carmack_display_is_featured_posts', true ) ) {
		return;
	}

	// Make sure Jetpack Featured Content is available.
	if ( ! class_exists( 'Featured_Content' ) ) {
		return;
	}

	// Only display posts featured posts on the homepage and not archives/ single post pages.
	if ( ! is_home() ) {
		return;
	}

	$tag_name = Featured_Content::get_setting( 'tag-name' );

	// Return if no featured tag is set.
	if ( empty( $tag_name ) ) {
		return;
	}

	// There are a max of 8 featured posts displayed at the top of the site. So the page count starts on 3.
	$page_number = 4 + $page;

	$query = new WP_Query(
		array(
			'tag' => $tag_name,
			'posts_per_page' => 2,
			'paged' => $page_number,
			'post_types' => array( 'post', 'page', 'jetpack-portfolio' ),
		)
	);

	if ( $query->have_posts() ) {

?>

		<span class="divider"><span class="carmack_featured_section_title"><?php carmack_featured_section_title(); ?></span></span>

		<div class="featured-posts featured-posts-is">

<?php
		while ( $query->have_posts() ) {

			$query->the_post();

			// Always use the standard post format for featured posts.
			get_template_part( 'parts/content' );

		}
?>

		</div>

<?php

	}

	wp_reset_postdata();

}


/**
 * Check if Jetpack Featured Content has any featured posts available
 *
 * @return boolean True if has featured posts, otherwise false.
 */
function carmack_has_featured_posts() {

	/**
	 * If is the front page of the site. Doesn't matter what template/ type of
	 * front page is being used.
	 */
	if ( ! is_front_page() ) {
		return false;
	}

	if ( is_paged() ) {
		return false;
	}

	$featured_posts = apply_filters( 'carmack_get_featured_posts', array() );

	if ( ! is_array( $featured_posts ) ) {
		return false;
	}

	if ( count( $featured_posts ) <= 0 ) {
		return false;
	}

	return true;

}


/**
 * Change default jetpack infinite scroll setttings
 *
 * @param array $settings Default infinite scroll settings.
 * @return array Modified infinite scroll settings.
 */
function carmack_infinite_scroll_js_settings( $settings ) {

	$settings['text'] = carmack_svg( 'refresh', false ) . esc_html__( 'More Posts', 'carmack' );

	return $settings;

}

add_filter( 'infinite_scroll_js_settings', 'carmack_infinite_scroll_js_settings' );


/**
 * Get Jetpack Testimonials Title
 */
function carmack_testimonials_title() {

	$jetpack_options = get_theme_mod( 'jetpack_testimonials' );

	if ( ! empty( $jetpack_options['page-title'] ) ) {
		echo esc_html( $jetpack_options['page-title'] );
	} else {
		esc_html_e( 'Testimonials', 'carmack' );
	}

}


/**
 * Retrieve and format jetpack testimonials description as set in theme customiser
 *
 * @param string $before html to display before testimonials description.
 * @param string $after html to display after testimonials description.
 * @return boolean|string Testimonials description, or false if no description exists.
 */
function carmack_testimonials_description( $before = '', $after = '' ) {

	$jetpack_options = get_theme_mod( 'jetpack_testimonials' );
	$content = '';

	if ( ! empty( $jetpack_options['page-content'] ) ) {
		$content = $jetpack_options['page-content'];
		$content = addslashes( $content );
		$content = wp_kses_post( $content );
		$content = stripslashes( $content );
		$content = wptexturize( $content );
		$content = convert_smilies( $content );
		$content = convert_chars( $content );
	}

	if ( $content ) {
		echo $before . $content . $after; // WPCS: XSS ok.
	}

	return false;

}


/**
 * Get Jetpack Testimonials Image
 *
 * @return string Testimonials image.
 */
function carmack_testimonials_image() {

	$jetpack_options = get_theme_mod( 'jetpack_testimonials' );
	$image = '';

	if ( '' !== $jetpack_options['featured-image'] ) {

		$image = wp_get_attachment_image( (int) $jetpack_options['featured-image'], 'carmack-header' );

	}

	return $image;

}


/**
 * Flush rewrite rules for CPT on setup and switch
 */
function carmack_flush_rewrite_rules() {

	flush_rewrite_rules();

}

add_action( 'after_switch_theme', 'carmack_flush_rewrite_rules' );


/**
 * Add breadcrumbs to a page (not blog post)
 */
function carmack_breadcrumbs() {

	if ( function_exists( 'jetpack_breadcrumbs' ) ) {

		jetpack_breadcrumbs();

	}

}


/**
 * Display social links using a custom menu
 */
function carmack_social_links() {

	if ( function_exists( 'jetpack_social_menu' ) ) {

		jetpack_social_menu();

	}

}


/**
 * Remove styles for contact form
 */
function carmack_remove_jetpack_stylesheets() {

	// Remove contact form styles.
	wp_dequeue_style( 'grunion.css' );

	// Remove infinite scroll styles.
	wp_dequeue_style( 'the-neverending-homepage' );

	// Remove related posts styles.
	wp_dequeue_style( 'jetpack_related-posts' );

	// Remove subscription widget styles.
	wp_dequeue_style( 'jetpack-subscriptions' );

}

add_action( 'wp_enqueue_scripts', 'carmack_remove_jetpack_stylesheets', 100 );


/**
 * Stop Jetpack from concatenating CSS.
 * We dequeue a number of the Jetpack styles so this stops them from being loaded
 */
add_filter( 'jetpack_implode_frontend_css', '__return_false' );


/**
 * Use the Jetpack Video Embed HTML to make sure the video post types are responsive
 * Has a simple fallback in case Jetpack is not available.
 *
 * @param string $html Video html.
 * @return string html wrapper with the video wrapper.
 */
function carmack_video_wrapper( $html ) {

	if ( function_exists( 'jetpack_responsive_videos_embed_html' ) ) {

		return jetpack_responsive_videos_embed_html( $html );

	} else {

		return '<div class="jetpack-video-wrapper">' . $html . '</div>';

	}

}


/**
 * Change the size of the Related Posts thumbnail images
 *
 * @param array $thumbnail_size Default thumbnail properties.
 * @return array
 */
function carmack_related_posts_thumbnail_size( $thumbnail_size ) {

	$thumbnail_size['width'] = 500;
	$thumbnail_size['height'] = 330;

	return $thumbnail_size;

}

add_filter( 'jetpack_relatedposts_filter_thumbnail_size', 'carmack_related_posts_thumbnail_size' );


/**
 * The function to display Author Bio in a theme.
 */
function carmack_author_bio() {

	$options = get_theme_support( 'jetpack-content-options' );
	$author_bio = null;

	if ( ! empty( $options[0]['author-bio'] ) ) {
		$author_bio = $options[0]['author-bio'];
	}

	// If the theme doesn't support "jetpack-content-options['author-bio']", don't continue.
	if ( true !== $author_bio ) {
		return;
	}

	// If "jetpack_content_author_bio" is false and we aren't in the customizer, don't continue.
	if ( ! get_option( 'jetpack_content_author_bio', 1 ) ) {
		return;
	}

	// If we aren't on a single post, don't continue.
	if ( ! is_single() ) {
		return;
	}

	// Display the author bio.
	carmack_contributor();

}


/**
 * Filter the top posts widget image properties.
 *
 * @param [array] $attr A list of image properties for the top posts widget thumbnails.
 * @return array
 */
function carmack_top_posts_widget_image_options( $attr ) {

	/**
	 * Only change the size if it's small.
	 * If it's larger then we are looking at the grid layout.
	 */
	if ( $attr['avatar_size'] > 40 ) {
		return $attr;
	}

	/**
	 * Who knows why the thumbnail size property is avatar_size and not
	 * image_size or, simply, size?
	 */
	$attr['avatar_size'] = 100;

	return $attr;

}

add_filter( 'jetpack_top_posts_widget_image_options', 'carmack_top_posts_widget_image_options' );
