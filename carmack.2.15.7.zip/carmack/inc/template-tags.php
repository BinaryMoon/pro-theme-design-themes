<?php
/**
 * Reusable template functions
 *
 * @package Carmack
 */

/**
 * Display header image and link to homepage
 * On pages display featured image if it is large enough to fill the space
 */
function carmack_header() {

	$header_image = get_header_image();
	$header_image_width = get_theme_support( 'custom-header', 'width' );
	$header_image_actual_width = get_custom_header()->width;
	$header_image_actual_height = get_custom_header()->height;

	$header_image = apply_filters( 'carmack_header_image', $header_image );

	if ( ! empty( $header_image ) ) {
?>
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home" class="header-image">
			<img src="<?php echo esc_url( $header_image ); ?>" width="<?php echo (int) $header_image_actual_width; ?>" height="<?php echo (int) $header_image_actual_height; ?>" alt="" />
		</a>
<?php
	}

}


/**
 * Display the post time in a human readable format
 *
 * @return string
 */
function carmack_human_time_diff() {

	$post_time = get_the_time( 'U' );
	$time_now = date( 'U' );

	// Use human time if less that 90 days ago, otherwise display the date
	// Uses the WordPress internal function human_time_diff
	// 60 seconds * 60 minutes * 24 hours * 90 days.
	if ( $post_time > $time_now - ( 60 * 60 * 24 * 90 ) ) {
		$human_time = sprintf( esc_html__( '%s ago', 'carmack' ), human_time_diff( $post_time, current_time( 'timestamp' ) ) );
	} else {
		$human_time = get_the_date();
	}

	$human_time = sprintf( '<span class="post-human-time">%s</span>', $human_time );

	return $human_time;

}


/**
 * Get post thumbnail url
 * If a thumbnail doesn't exist then use the first attachment
 * reduces user confusion since they don't always understand the featured image functionality
 *
 * @param integer $post_id ID for the post that you want to get the thumbnail url for.
 * @param string  $thumbnail_size Size of the thumbnail image. Defaults to 'carmack-archive'.
 * @return boolean
 */
function carmack_archive_image_url( $post_id = null, $thumbnail_size = 'carmack-archive' ) {

	if ( ! $post_id ) {

		$post_id = get_the_ID();

	}

	$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post_id ), $thumbnail_size );

	// If there's no featured image then grab an attachment image and use that instead.
	if ( ! $image[0] ) {

		$values = get_attached_media( 'image', $post_id );

		if ( $values ) {
			foreach ( $values as $child_id => $attachment ) {

				$image = wp_get_attachment_image_src( $child_id, $thumbnail_size );
				break;

			}
		}
	}

	if ( is_array( $image ) ) {

		$image = $image[0];

	}

	if ( $image ) {

		return $image;

	} else {

		return false;

	}

}


/**
 * Fill empty post thumbnails with images from the first attachment added to a post
 *
 * @param string  $html Current html for thumbnail image.
 * @param integer $post_id ID for specified post.
 * @param integer $thumbnail_id ID for thumbnail image.
 * @param string  $size expected thumbnail size.
 * @return string
 */
function carmack_post_thumbnail_html( $html, $post_id, $thumbnail_id, $size = '' ) {

	if ( empty( $html ) ) {

		$values = get_attached_media( 'image', $post_id );

		if ( $values ) {
			foreach ( $values as $child_id => $attachment ) {

				$html = wp_get_attachment_image( $child_id, $size );
				break;

			}
		}
	}

	return $html;

}

add_filter( 'post_thumbnail_html', 'carmack_post_thumbnail_html', 10, 4 );


/**
 * Prints HTML with meta information for the current post-date/time
 */
function carmack_post_time() {

	$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';

	$time_string = sprintf(
		$time_string,
		esc_attr( get_the_date( 'c' ) ),
		carmack_human_time_diff()
	);

	$posted_on = sprintf(
		esc_html_x( 'Posted %s', 'post date', 'carmack' ),
		'<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a>'
	);

	echo '<span class="posted-on meta">' . $posted_on . '</span>';

}


/**
 * Prints HTML with the author meta data
 */
function carmack_post_author() {

	if ( ! is_single() || is_attachment() ) {
		return;
	}

	$byline = sprintf(
		esc_html_x( 'by %s', 'post author', 'carmack' ),
		'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>'
	);

	echo '<span class="byline meta"> ' . $byline . '</span>';

}


/**
 * Display a link to the Carmack Comments
 */
function carmack_comments_link() {

	if ( ! post_password_required() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) {

		$class = '';

		if ( is_singular() ) {
			$class = 'scroll-to';
		}

		echo '<span class="comment-count meta">';

		/* translators: %s: post title */
		comments_popup_link(
			sprintf(
				wp_kses(
					__( 'Leave a Comment<span class="screen-reader-text"> on %s</span>', 'carmack' ),
					array(
						'span' => array( 'class' => array() ),
					)
				),
				get_the_title()
			),
			false,
			false,
			$class
		);

		echo '</span>';

	}

}


/**
 * Get the posts custom read more text and, if available, display it instead of 'read more'
 */
function carmack_read_more_text() {

	// Default text value.
	$read_more = sprintf(
		esc_html__( 'Read more %s', 'carmack' ),
		the_title( '<span class="screen-reader-text">', '</span>', false )
	);

	// Get post data.
	$post = get_post();
	$custom_readmore = get_extended( $post->post_content );

	if ( ! empty( $custom_readmore['more_text'] ) ) {
		$read_more = esc_html( $custom_readmore['more_text'] );
	}

	echo $read_more;

}


/**
 * Get a list of children for the current page
 *
 * @return WP_Query
 */
function carmack_child_pages() {

	return new WP_Query(
		array(
			'post_type' => 'page',
			'orderby' => 'menu_order',
			'order' => 'ASC',
			'post_parent' => get_the_ID(),
			'posts_per_page' => 99,
			'no_found_rows' => true,
		)
	);

}


/**
 * Display a specific user and their contributor info
 *
 * @param integer $user_id ID of current contributor.
 * @param integer $post_count Optional post could for current user.
 */
function carmack_contributor( $user_id = null, $post_count = null ) {

	if ( ! $user_id ) {
		$user_id = get_the_author_meta( 'ID' );
	}

?>
	<div class="contributor">
		<?php echo get_avatar( $user_id, 140 ); ?>
		<h2>
			<a href="<?php echo esc_url( get_author_posts_url( $user_id ) ); ?>">
				<?php the_author_meta( 'display_name', $user_id ); ?>
				<small><?php esc_html_e( 'View All', 'carmack' ); ?></small>
			</a>
		</h2>
<?php
	echo wpautop( esc_html( get_the_author_meta( 'description', $user_id ) ) );

	if ( $post_count ) {
?>
		<p>
			<a class="contributor-posts-link" href="<?php echo esc_url( get_author_posts_url( $user_id ) ); ?>">
				<?php printf( esc_html( _nx( '%d Article', '%d Articles', absint( $post_count ), 'contributor article count', 'carmack' ) ), $post_count ); ?>
			</a>
		</p>
<?php
	}
?>
	</div>
<?php

}


/**
 * Display the first category for the current post/ project
 */
function carmack_the_main_category() {

	$term_type = 'category';
	if ( 'jetpack-portfolio' === get_post_type() ) {
		$term_type = 'jetpack-portfolio-type';
	}

	$category = get_the_terms( get_the_ID(), $term_type );

	if ( is_array( $category ) ) {
		$category = current( array_values( $category ) );

		if ( is_object( $category ) ) {
?>
	<span class="post-lead-category meta"><a href="<?php echo esc_url( get_category_link( $category, $term_type ) ); ?>"><?php echo esc_html( $category->name ); ?></a></span>
<?php
		}
	}

}


/**
 *  Display a list of all of the project categories.
 */
function carmack_project_terms() {

	$terms = get_terms(
		'jetpack-portfolio-type',
		array(
			'number' => 20,
			'orderby' => 'count',
			'order' => 'DESC',
		)
	);

	// Highlight currently selected page.
	$class = 'current-page';

	// Get the term for the current page.
	$current_term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );

	// We're on a project category page, and not the main portfolio page, so reset the class.
	if ( $current_term ) {
		$class = '';
	}

	// Make sure the term exists and has some results.
	if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
?>
	<p class="projects-terms">

		<span class="project-terms-intro">
			<?php esc_html_e( 'Categories:', 'carmack' ); ?>
		</span>

		<a class="<?php echo esc_attr( $class ); ?>" href="<?php echo esc_url( home_url( '/portfolio/' ) ); ?>"><?php esc_html_e( 'All', 'carmack' ); ?></a>

<?php
		foreach ( $terms as $t ) {
			$class = '';

			if ( $current_term && $current_term->term_id === (int) $t->term_id ) {
				$class = 'current-page';
			}
?>
		<a class="<?php echo esc_attr( $class ); ?>" href="<?php echo esc_url( get_term_link( $t ) ); ?>"><?php echo esc_html( $t->name ); ?></a>
<?php
		}
?>
	</p>
<?php
	}

}


/**
 * Wrapper for embedding an svg in the theme
 *
 * @param string  $name icon name.
 * @param boolean $echo Should the svg be printed or returned.
 * @return string
 */
function carmack_svg( $name, $echo = true ) {

	$path = get_template_directory() . '/assets/svg/' . $name . '.svg';

	if ( $echo ) {

		// Return early if file does not exist.
		if ( ! file_exists( $path ) ) {
			return false;
		}

		// Output existing svg file.
		include( $path );

	} else {

		// Generate svg 'use' tag to display the svg.
		// Ensure svg can be found in assets/svg/svg.svg or it will not display.
		$svg = '<svg class="icon icon-' . esc_attr( $name ) . '" aria-hidden="true" role="img">';
		$svg .= '<use xlink:href="#' . esc_attr( $name ) . '"></use>';
		$svg .= '</svg>';

		return $svg;

	}

}


/**
 * Add a stylable element for sticky posts.
 */
function carmack_sticky() {

	if ( is_sticky() && is_home() && ! is_paged() ) {

?>

	<span class="sticky-post">
		<?php carmack_svg( 'star-full' ); ?>
	</span>

<?php

	}

}


/**
 * Include svg symbols.
 */
function carmack_include_svg_icons() {

	// Define SVG sprite file.
	$svg_icons = get_parent_theme_file_path( '/assets/svg/svg.svg' );

	// If it exsists, include it.
	if ( file_exists( $svg_icons ) ) {

		echo '<span class="svg-defs">';
		require_once( $svg_icons );
		echo '</span>';

	}

}


/**
 * Display news section title loaded from the Customizer.
 */
function carmack_news_section_title() {

	$title = get_theme_mod( 'carmack_latest_news_section_title', esc_html__( 'Latest', 'carmack' ) );
	echo esc_html( $title );

}


/**
 * Display news section title loaded from the Customizer.
 */
function carmack_featured_section_title() {

	$title = get_theme_mod( 'carmack_featured_section_title', esc_html__( 'Featured', 'carmack' ) );
	echo esc_html( $title );

}
