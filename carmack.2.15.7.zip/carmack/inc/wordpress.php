<?php
/**
 * Actions and Filters that customize WordPress
 *
 * @package Carmack
 */

/**
 * Enqueue all the styles
 *
 * @global type $wp_scripts
 */
function carmack_enqueue() {

	// Styles.
	wp_enqueue_style( 'carmack-style', get_stylesheet_uri(), null, '1.29' );

	// Fonts.
	$fonts_url = carmack_fonts();

	if ( $fonts_url ) {
		wp_enqueue_style( 'carmack-fonts', $fonts_url, array(), null );
	}

	// Javascript.
	// Always loaded in customizer for cases where widgets are added to an empty sidebar.
	if ( is_active_sidebar( 'sidebar-2' ) || ! is_singular() || is_customize_preview() ) {
		wp_enqueue_script( 'masonry' );
	}

	wp_enqueue_script( 'carmack-script-main', get_theme_file_uri( '/assets/js/main.js' ), array( 'jquery' ), '1.4', false );

	if ( carmack_has_featured_posts() ) {
		wp_enqueue_script( 'carmack-script-slider', get_theme_file_uri( '/assets/js/slider.js' ), array( 'jquery' ), '1.6', false );
	}

	// Localized Javascript strings.
	wp_localize_script(
		'carmack-script-main',
		'site_settings',
		array(
			'i18n' => array(
				'slide_next' => esc_html__( 'Next Slide', 'carmack' ),
				'slide_prev' => esc_html__( 'Previous Slide', 'carmack' ),
				/* translators: # is the slide number, it will be replaced with 1/ 2/ 3 etc */
				'slide_number' => esc_html__( 'Slide #', 'carmack' ),
				'slide_controls_label' => esc_html__( 'Slider Buttons', 'carmack' ),
				'menu' => esc_html__( 'Menu', 'carmack' ),
			),
			'slider_autoplay' => ( get_theme_mod( 'carmack_autoplay_slider', true ) ) ? 1 : 0,
		)
	);

	// Comments Javascript.
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

}

add_action( 'wp_enqueue_scripts', 'carmack_enqueue' );


/**
 * Enqueue WordPress theme styles within Gutenberg.
 */
function carmack_editor_blocks_styles() {

	// Load the additional editor styles.
	// This covers things like the editor title that can't be styled with the normal editor styles.
	wp_enqueue_style( 'carmack-editor-blocks', get_theme_file_uri( '/assets/css/editor-blocks.css' ), null, '1.2' );

	/**
	 * Overwrite Core theme styles with empty styles.
	 * @see https://github.com/WordPress/gutenberg/issues/7776#issuecomment-406700703
	 */
	wp_deregister_style( 'wp-block-library-theme' );
	wp_register_style( 'wp-block-library-theme', '' );

}

add_action( 'enqueue_block_editor_assets', 'carmack_editor_blocks_styles' );
add_action( 'enqueue_block_assets', 'carmack_editor_blocks_styles' );


/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 * Keep in mind the theme is responsive so the width is likely to be narrower.
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function carmack_content_width() {

	// Default size without sidebar.
	$width = 1360;

	// Homepage and archive with sidebar.
	if ( is_archive() || is_home() ) {

		if ( is_active_sidebar( 'sidebar-1' ) ) {

			$width = 880;

		}

	}

	// Single blog post.
	if ( is_single() ) {

		$width = 964;

		if ( is_active_sidebar( 'sidebar-1' ) ) {

			$width = 624;

		}
	}

	// Single page.
	if ( is_page() ) {

		$width = 1360;

		if ( is_active_sidebar( 'sidebar-1' ) && ! is_page_template( 'page-templates/full-width.php' ) ) {

			$width = 880;

		}
	}

	$GLOBALS['content_width'] = apply_filters( 'carmack_content_width', $width );

}

add_action( 'after_setup_theme', 'carmack_content_width', 0 );


/**
 * Get url(s) for Google fonts
 *
 * @return string|boolean font url or false if there are no fonts
 */
function carmack_fonts() {

	$fonts = array();

	/* translators: If there are characters in your language that are not supported by Merriweather Sans, translate this to 'off'. Do not translate into your own language. */
	if ( 'off' !== esc_html_x( 'on', 'Merriweather Sans: on or off', 'carmack' ) ) {
		$fonts['merriweather-sans'] = 'Merriweather Sans:300,700,800,300italic,800italic';
	}

	$fonts = apply_filters( 'carmack_fonts', $fonts );

	if ( $fonts ) {
		$query_args = array(
			'family' => rawurlencode( implode( '|', $fonts ) ),
			'subset' => rawurlencode( 'latin,latin-ext' ),
			'display' => 'swap',
		);

		return add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
	}

	return false;

}


/**
 * Add preconnect for Google Fonts.
 *
 * @param array  $urls          URLs to print for resource hints.
 * @param string $relation_type The relation type the URLs are printed.
 * @return array URLs to print for resource hints.
 */
function carmack_resource_hints( $urls, $relation_type ) {

	if ( wp_style_is( 'carmack-fonts', 'queue' ) && 'preconnect' === $relation_type ) {

		$urls[] = array(
			'href' => 'https://fonts.gstatic.com',
			'crossorigin',
		);

	}

	return $urls;

}

add_filter( 'wp_resource_hints', 'carmack_resource_hints', 10, 2 );


/**
 * Set up all the theme properties and extras
 */
function carmack_after_setup_theme() {

	load_theme_textdomain( 'carmack', get_template_directory() . '/languages' );

	add_theme_support( 'automatic-feed-links' );

	// Post thumbnails.
	add_theme_support( 'post-thumbnails' );

	// Attachment (image.php) page links.
	add_image_size( 'carmack-attachment', 250, 250, true );

	// Ideal header image size.
	add_image_size( 'carmack-header', 1800, 480, true );

	// Archive/ homepage thumbnails.
	add_image_size( 'carmack-archive', 700, 476, true );

	// Featured Content.
	add_image_size( 'carmack-slider', 1800, 720, true );

	// Add selective refresh to widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );

	// Full size attachment.
	add_image_size( 'carmack-attachment-fullsize', 1800, 9999 );

	// Add support for full width images and other content such as videos.
	add_theme_support( 'align-wide' );

	// Disable custom font sizes, ensuring consistent vertical rhythm.
	add_theme_support( 'disable-custom-font-sizes' );

	// Make Gutenberg embeds responsive.
	add_theme_support( 'responsive-embeds' );

	// Custom background.
	add_theme_support(
		'custom-background',
		apply_filters(
			'carmack_custom_background',
			array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		)
	);

	// Custom colours for use in the editor. A nice way to provide consistancy
	// in user editable content.
	add_theme_support(
		'editor-color-palette',
		array(
			array(
				'name' => esc_html__( 'White', 'carmack' ),
				'slug' => 'carmack-white',
				'color' => '#ffffff',
			),
			array(
				'name' => esc_html__( 'Light Gray', 'carmack' ),
				'slug' => 'carmack-light-gray',
				'color' => '#e2e4e7',
			),
			array(
				'name' => esc_html__( 'Black', 'carmack' ),
				'slug' => 'carmack-black',
				'color' => '#000000',
			),
			array(
				'name' => esc_html__( 'Yellow', 'carmack' ),
				'slug' => 'carmack-yellow',
				'color' => '#ffee00',
			),
			array(
				'name' => esc_html__( 'Blue', 'carmack' ),
				'slug' => 'carmack-blue',
				'color' => '#006194',
			),
		)
	);

	// Editor font sizes.
	// Uses the default slugs to ensure consistency across themes.
	add_theme_support(
		'editor-font-sizes',
		array(
			array(
				'name' => esc_html__( 'small', 'carmack' ),
				'size' => 12,
				'slug' => 'small',
			),
			array(
				'name' => esc_html__( 'normal', 'carmack' ),
				'size' => 16,
				'slug' => 'normal',
			),
			array(
				'name' => esc_html__( 'medium', 'carmack' ),
				'size' => 20,
				'slug' => 'medium',
			),
			array(
				'name' => esc_html__( 'large', 'carmack' ),
				'size' => 28,
				'slug' => 'large',
			),
			array(
				'name' => esc_html__( 'huge', 'carmack' ),
				'size' => 40,
				'slug' => 'huge',
			),
		)
	);

	// HTML5 FTW.
	add_theme_support(
		'html5',
		array(
			'navigation-widgets',
			'comment-list',
			'comment-form',
			'gallery',
			'caption',
		)
	);

	// Post Formats.
	add_theme_support(
		'post-formats',
		array(
			'quote',
			'video',
			'image',
			'gallery',
			'audio',
		)
	);

	// Custom Logo.
	add_theme_support(
		'custom-logo',
		array(
			'height' => 500,
			'width' => 800,
			'flex-height' => true,
			'flex-width' => true,
			'unlink-homepage-logo' => true,
		)
	);

	// Title Tag.
	add_theme_support( 'title-tag' );

	// Menus.
	register_nav_menus(
		array(
			'primary' => esc_html__( 'Header', 'carmack' ),
			'secondary' => esc_html__( 'Overlay', 'carmack' ),
		)
	);

	// Add support for editor styles.
	add_theme_support( 'editor-styles' );

	// Editor Style.
	$fonts_url = carmack_fonts();

	if ( $fonts_url ) {
		add_editor_style( $fonts_url );
	}

	// Classic editor styles.
	add_editor_style( 'assets/css/editor-styles.css' );

}

add_action( 'after_setup_theme', 'carmack_after_setup_theme' );


/**
 * Intitiate sidebars
 *
 * @link https://developer.wordpress.org/reference/functions/register_sidebar/
 */
function carmack_widgets_init() {

	// Sidebar.
	register_sidebar(
		array(
			'name' => esc_html__( 'Sidebar Widgets', 'carmack' ),
			'id' => 'sidebar-1',
			'description' => esc_html__( 'Widgets that display on the side of your website', 'carmack' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h2 class="widget-title">',
			'after_title' => '</h2>',
		)
	);

	// Footer Widgets.
	register_sidebar(
		array(
			'name' => esc_html__( 'Footer Widgets', 'carmack' ),
			'id' => 'sidebar-2',
			'description' => esc_html__( 'Widgets that display at the bottom of your website. They are arranged in 3 columns and lined up automatically to make the best use of the space available.', 'carmack' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h2 class="widget-title">',
			'after_title' => '</h2>',
		)
	);

	// Overlay Widgets.
	register_sidebar(
		array(
			'name' => esc_html__( 'Overlay Widgets', 'carmack' ),
			'id' => 'sidebar-3',
			'description' => esc_html__( 'Widgets that on the menu overlay found next to the site name in the header.', 'carmack' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h2 class="widget-title">',
			'after_title' => '</h2>',
		)
	);

}

add_action( 'widgets_init', 'carmack_widgets_init' );


/**
 * Custom excerpt length
 * WP default excerpt length is 55
 *
 * @param type $length length of excerpt.
 * @return int
 */
function carmack_excerpt_length( $length ) {

	return 30;

}

add_filter( 'excerpt_length', 'carmack_excerpt_length', 18 );


/**
 * Fallback for navigation menu
 *
 * @param array $params list of menu parameters.
 * @return string
 */
function carmack_nav_menu( $params ) {

	$echo = $params['echo'];

	$params['echo'] = false;
	$html = wp_page_menu( $params );

	if ( $params['container'] ) {

		$container_start = '<' . esc_attr( $params['container'] ) . ' id="' . esc_attr( $params['container_id'] ) . '" class="' . esc_attr( $params['container_class'] ) . '">';
		$container_end = '</' . esc_attr( $params['container'] ) . '>';

		$html = str_replace( '<div class="' . esc_attr( $params['menu_class'] ) . '">', $container_start, $html );
		$html = str_replace( '</div>', $container_end, $html );

	}

	if ( $echo ) {
		echo $html;
	}

	return $html;

}


/**
 * Add additional body classes that may be helpful
 *
 * @param array $classes array of body classes.
 * @return string
 */
function carmack_body_class( $classes ) {

	if ( is_singular() ) {
		$classes[] = 'singular';
	}

	if ( is_multi_author() ) {
		$classes[] = 'multi-author-true';
	} else {
		$classes[] = 'multi-author-false';
	}

	if ( is_active_sidebar( 'sidebar-1' ) ) {
		$classes[] = 'themes-sidebar1-active';
	} else {
		$classes[] = 'themes-sidebar1-inactive';
	}

	if ( is_active_sidebar( 'sidebar-2' ) ) {
		$classes[] = 'themes-sidebar2-active';
	} else {
		$classes[] = 'themes-sidebar2-inactive';
	}

	if ( is_active_sidebar( 'sidebar-3' ) ) {
		$classes[] = 'themes-sidebar3-active';
	} else {
		$classes[] = 'themes-sidebar3-inactive';
	}

	if ( carmack_has_featured_posts() ) {
		$classes[] = 'themes-has-featured-posts';
	} else {
		$classes[] = 'themes-no-featured-posts';
	}

	// Check these individually rather than using carmack_overlay_visible so
	// that we can exclude the check for the top nav. If we include that check
	// then the button may be visible when the overlay data is empty.
	if ( is_active_sidebar( 'sidebar-3' ) || has_nav_menu( 'secondary' ) ) {
		$classes[] = 'themes-overlay-visible';
	}

	if ( display_header_text() ) {
		$classes[] = 'has-site-title';
	}

	if ( get_header_image() ) {
		$classes[] = 'has-custom-header';
	}

	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	if ( is_singular() ) {

		global $post;

		if ( function_exists( 'has_blocks' ) && has_blocks( $post->post_content ) ) {
			$classes[] = 'editor-block';
		} else {
			$classes[] = 'editor-classic';
		}
	}

	if ( get_theme_mod( 'carmack_display_triangle', true ) ) {
		$classes[] = 'carmack-display-triangle';
	} else {
		$classes[] = 'carmack-hide-triangle';
	}

	return $classes;

}

add_filter( 'body_class', 'carmack_body_class' );


/**
 * Adjust styles for post class
 *
 * @param array $classes array of post classes.
 * @return string
 */
function carmack_post_class( $classes ) {

	if ( get_the_post_thumbnail( get_the_ID() ) ) {

		$classes[] = 'post-has-thumbnail';

	} else {

		$classes[] = 'post-no-thumbnail';

	}

	/**
	 * Removes hentry class from the array of post classes.
	 * Currently, having the class on pages is not correct use of hentry.
	 * hentry requires more properties than pages typically have.
	 * Core is not likely to remove class because of backward compatibility.
	 * See: https://core.trac.wordpress.org/ticket/28482
	 */
	if ( 'page' === get_post_type() ) {

		$classes = array_diff( $classes, array( 'hentry' ) );

	}

	return $classes;

}

add_filter( 'post_class', 'carmack_post_class' );


/**
 * Replaces "[...]" (appended to automatically generated excerpts) with ... and a 'Continue reading' link.
 *
 * @return string 'Continue reading' link prepended with an ellipsis.
 */
function carmack_excerpt_more() {

	$link = sprintf( '<a href="%1$s" class="read-more">%2$s</a>',
		esc_url( get_permalink( get_the_ID() ) ),
		sprintf( esc_html_x( 'Continue Reading %s', 'Name of current post', 'carmack' ), '<span class="screen-reader-text">' . esc_html( get_the_title( get_the_ID() ) ) . '</span>' )
	);

	return ' &hellip; ' . $link;

}

add_filter( 'excerpt_more', 'carmack_excerpt_more' );


/**
 * Add post terms (categories and tags) to the_content
 * Using this through the_content filter places it before the related posts, social sharing, and other jetpack content
 *
 * @param string $content The original post content.
 * @return string The modified post content.
 */
function carmack_post_terms( $content = '' ) {

	if ( ! is_single() ) {
		return $content;
	}

	if ( 'post' !== get_post_type( get_the_ID() ) ) {
		return $content;
	}

	$terms = '';

	$terms .= '<p class="taxonomy-title tax-title-categories">' . esc_html__( 'Categories', 'carmack' ) . '</p>';
	$terms .= '<p class="taxonomy tax-categories">' . get_the_category_list( esc_html_x( ', ', 'Category/ Tag list separator (includes a space after the comma)', 'carmack' ) ) . '</p>';

	if ( get_the_tags( get_the_ID() ) ) {
		$terms .= '<p class="taxonomy-title tax-title-tags">' . esc_html__( 'Tags', 'carmack' ) . '</p>';
		$terms .= '<p class="taxonomy tax-tags">' . get_the_tag_list( '', esc_html_x( ', ', 'Category/ Tag list separator (includes a space after the comma)', 'carmack' ), '' ) . '</p>';
	}

	$content .= '<div class="taxonomies">' . $terms . '</div>';

	return $content;

}

add_filter( 'the_content', 'carmack_post_terms' );


/**
 * Wrap post content with a standard div that can be styled in any way.
 * This means the content can be customized without affecting other things that get appended/ prepended to the_content such as Jetpack related posts.
 *
 * @param string $content The content to be wrapped.
 * @return string Modified content with html wrapper.
 */
function carmack_wrapper_content( $content ) {

	if ( ! is_singular() ) {

		return $content;

	}

	// Includes some new line characters so that paragraphs tags are properly applied to all paragraphs.
	return '<div class="the-content">' . "\n\n" . $content . "\n\n" . '</div>';

}

add_filter( 'the_content', 'carmack_wrapper_content', 9 );


/**
 * Add a span around the title prefix so that the prefix can be hidden with CSS if desired.
 *
 * @param string $title Archive title.
 * @return string Archive title with inserted span around prefix.
 */
function carmack_wrap_the_archive_title( $title ) {

	// Skip if the site isn't LTR, this is visual, not functional.
	// Should try to work out an elegant solution that works for both directions.
	if ( is_rtl() ) {
		return $title;
	}

	$title_parts = explode( ': ', $title, 2 );

	if ( ! empty( $title_parts[1] ) ) {
		$title = '<span class="divider"><span>' . esc_html( $title_parts[0] ) . '</span></span>' . wp_kses( $title_parts[1], array( 'span' => array( 'class' => array() ) ) );
	}

	return $title;

}

add_filter( 'get_the_archive_title', 'carmack_wrap_the_archive_title' );


/**
 * Add a span to the category and tag listings
 *
 * @param string $cat_list Html containing list of categories/ tags.
 * @return string
 */
function carmack_add_span_category_list( $cat_list ) {

	$cat_list = str_replace( 'tag">', 'tag"><span>', $cat_list );
	$cat_list = str_replace( '</a>', '</span></a>', $cat_list );

	return $cat_list;

}

add_filter( 'the_category', 'carmack_add_span_category_list' );
add_filter( 'the_tags', 'carmack_add_span_category_list' );


/**
 * Standardize menu classes.
 *
 * @param string $menu_html Page menu list.
 * @return type
 */
function carmack_change_menu( $menu_html = '' ) {

	$menu_html = str_replace( 'page_item_has_children', 'menu-item-has-children', $menu_html );

	return $menu_html;

}

add_filter( 'wp_page_menu', 'carmack_change_menu' );


/**
 * Change the colour of the Google url bar to match the background colour of the site
 *
 * @link https://developers.google.com/web/updates/2014/11/Support-for-theme-color-in-Chrome-39-for-Android
 */
function carmack_theme_colour() {

	$colour = get_background_color();

	if ( ! empty( $colour ) ) {
?>
		<meta name="theme-color" content="#<?php echo esc_attr( $colour ); ?>">
<?php
	}

}

add_filter( 'wp_head', 'carmack_theme_colour' );


/**
 * Check to see if the menu & widget overlay should be displayed or not
 *
 * @return boolean
 */
function carmack_overlay_visible() {

	// Overlay sidebar.
	if ( is_active_sidebar( 'sidebar-3' ) ) {
		return true;
	}

	// Overlay menu.
	if ( has_nav_menu( 'secondary' ) ) {
		return true;
	}

	// Top nav - is needed for responsive navigation.
	if ( has_nav_menu( 'primary' ) ) {
		return true;
	}

	return false;

}
