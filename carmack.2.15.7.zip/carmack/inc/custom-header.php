<?php
/**
 * Custom header codes
 *
 * @package Carmack
 */

/**
 * Custom header image
 */
function carmack_custom_header_support() {

	add_theme_support(
		'custom-header',
		apply_filters(
			'carmack_custom_header',
			array(
				'default-text-color' => '000000',
				'random-default' => false,
				'width' => 1500,
				'height' => 400,
				'flex-height' => true,
				'header-text' => true,
				'uploads' => true,
				'wp-head-callback' => 'carmack_colour_styles',
			)
		)
	);

}

add_action( 'after_setup_theme', 'carmack_custom_header_support' );


/**
 * Print custom header styles
 *
 * @return array
 */
function carmack_colour_styles() {

?>
<style>
<?php
	if ( ! display_header_text() ) {
?>
	.masthead .branding .site-title,
	.masthead .branding .site-description {
		clip: rect( 1px, 1px, 1px, 1px );
		position: absolute;
	}
<?php
	} else {
?>
	.masthead .branding .site-title a,
	.masthead .branding .site-title a:hover,
	.masthead .branding p.site-description {
		color: #<?php echo esc_attr( get_header_textcolor() ); ?>;
	}
<?php
	}
?>
</style>
<?php

	return true;

}
