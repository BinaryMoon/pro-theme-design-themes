<?php
/* Custom Colors: Carmack */

//Background
add_color_rule( 'bg', '#ffffff', array(

	array( 'body,
		.divider span,
		.single-nav', 'background-color' ),

) );

add_color_rule( 'txt', '#ffee00', array(

	//No contrast needed
	array( '.content-comments ol.comment-list li.comment.bypostauthor .fn,
			.content-posts article.format-quote .permalink a,
			.masthead .branding .site-title,
			.menu-overlay .close-overlay,
			.pagination span.current,
			.projects-terms a.current-page,
			.showcase .item h2 a.entry,
			.sticky-post,
			.the-content .button,
			.widget.jetpack_subscription_widget,
			button,
			input[type=submit],
			.masthead .branding,
			.showcase nav .tab:focus,
			.showcase nav .tab:hover', 'background-color' ),

	array( '::-moz-selection', 'background-color' ),

	array( '::selection', 'background-color' ),

	//Contrast with black background
	array( '.sidebar-footer .widget .widget-title,
			.sidebar-overlay .widget .widget-title,
			.the-content .button:focus,
			.the-content .button:hover,
			.widget.jetpack_subscription_widget input[type=submit],
			a.post-edit-link:focus,
			a.post-edit-link:hover,
			button:focus,
			button:hover,
			input[type=submit]:focus,
			input[type=submit]:hover', 'color', '#000000' ),

	//Contrast with body bg


),
__( 'Main Accent' ) );

add_color_rule( 'link', '#0075b3', array(

	//Contrast with body bg
	array( '.widget.widget_flickr #flickr_badge_uber_wrapper td a,
			.widget.widget_flickr #flickr_badge_wrapper td a,
			a', 'color', 'bg' ),
),
__( 'Links' ) );

add_color_rule( 'fg1', '#000000', array(

	//Contrast with body bg
	array( 'h1,
			h1 a,
			h2,
			h2 a,
			h3,
			h3 a,
			h4,
			h4 a,
			h5,
			h5 a,
			h6,
			h6 a', 'color', 'bg' ),
),
__( 'Headings' ) );

add_color_rule( 'fg2', '#ffffff', array(

	//Contrast with body bg
	array( 'a:focus, a:hover', 'color', 'bg' ),

	//Contrast with black footer bg
	array( '#footer .jetpack-social-navigation a:focus,
			#footer .jetpack-social-navigation a:hover,
			.single-nav .jetpack-social-navigation a:focus,
			.single-nav .jetpack-social-navigation a:hover', 'color', '#000' ),
),
__( 'Link Hover' ) );


//Extra rules

//Main body font color
add_color_rule( 'extra', '#333333', array(
	array( 'body', 'color', 'bg' ),
) );

//Borders
add_color_rule( 'extra', '#1a1a1a', array(
	array( '.divider:before,
			.infinite-scroll #infinite-handle button,
			blockquote,
			.contributor,
			.widget input[type=text]:focus,
			.widget input[type=text]:hover,
			.widget input[type=search]:focus,
			.widget input[type=search]:hover,
			.widget .form-select:focus,
			.widget .form-select:hover,
			table th', 'border-color', 0.3 ),
) );

add_color_rule( 'extra', '#000000', array(

	//Contrast with body bg
	array( '#footer .jetpack-social-navigation a,
			#footer .scroll-to-top,
			.comment-navigation a,
			.content-comments ol.comment-list li.comment .fn a,
			.content-comments ol.comment-list li.comment .reply a,
			.content-posts article.format-quote .permalink a,
			.image-navigation a,
			.infinite-scroll #infinite-handle button,
			.infinite-scroll #infinite-handle button:focus,
			.infinite-scroll #infinite-handle button:hover,
			.single-nav .jetpack-social-navigation a,
			.post-navigation a,
			.projects-terms a,
			a.post-edit-link,
			table th', 'color', 'bg' ),

	//Contrast with yellow txt
	array( '.menu-overlay .close-overlay,
			.pagination span.current,
			.sticky-post,
			.the-content .button,
			.widget.jetpack_subscription_widget,
			.widget.jetpack_subscription_widget .widget-title,
			button', 'color', 'txt' ),
	array( '::-moz-selection', 'color', 'txt' ),
	array( '::selection', 'color', 'txt' ),
	array( '.showcase .item h2 a.entry,
			.masthead .branding .site-title a,
			.masthead .branding .site-title a:hover,
			.masthead .branding p.site-description', 'color', 'txt' ),
) );

add_color_rule( 'extra', '#f2f2f2', array(
	array( 'a.post-edit-link', 'background-color', 0.15 ),
) );

//Additional palettes
add_color_palette( array(
 '#f2e9e1',
 '#b7b79e',
 '#89a9cc',
 '#b79e9e',
 '#b79e9e',
), 'Neutral' );

add_color_palette( array(
 '#686868',
 '#cbe86b',
 '#4dbce9',
 '#eeeeee',
 '#eeeeee',
), 'Business Blues' );

add_color_palette( array(
 '#44749d',
 '#e0eff1',
 '#e0eff1',
 '#e0eff1',
 '#e0eff1',
), 'Light Blues' );

add_color_palette( array(
 '#fdf1cc',
 '#c6d6b8',
 '#987f69',
 '#e3ad40',
 '#fcd036',
), 'Vintage Peach' );

add_color_palette( array(
 '#515151',
 '#fcd036',
 '#eeeeee',
 '#ffffff',
 '#fcd036',
), 'Dark Gray' );

add_color_palette( array(
 '#efefef',
 '#b83928',
 '#44749d',
 '#b83928',
 '#bdb8ad',
), 'Red' );