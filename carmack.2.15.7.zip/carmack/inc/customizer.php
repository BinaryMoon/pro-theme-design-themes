<?php
/**
 * Theme Customizer
 *
 * @package Carmack
 */

if ( ! class_exists( 'WP_Customize_Control' ) ) {

	return null;

}

/**
 * Theme customizer properties
 *
 * @param type $wp_customize WP Customize object.
 */
function carmack_customize_register( $wp_customize ) {

	// Carmack theme options section.
	$wp_customize->add_section(
		'carmack_options',
		array(
			'title' => esc_html__( 'Theme Options', 'carmack' ),
			'description' => esc_html__( 'Options for the Carmack theme.', 'carmack' ),
		)
	);

	// Setting to control whether featured posts are displayed within infinite scroll or not.
	$wp_customize->add_setting(
		'carmack_display_is_featured_posts',
		array(
			'default' => true,
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'carmack_sanitize_checkboxes',
		)
	);

	$wp_customize->add_control(
		'carmack_display_is_featured_posts',
		array(
			'label' => esc_html__( 'Display Featured Posts in Infinite Scroll', 'carmack' ),
			'section' => 'carmack_options',
			'type' => 'checkbox',
		)
	);

	// Setting that allows users to set the title of the featured content section.
	$wp_customize->add_setting(
		'carmack_featured_section_title',
		array(
			'default' => esc_html__( 'Featured', 'carmack' ),
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'esc_html',
		)
	);

	$wp_customize->add_control(
		'carmack_featured_section_title',
		array(
			'label' => esc_html__( 'Featured Post Area Title', 'carmack' ),
			'section' => 'carmack_options',
			'type' => 'text',
		)
	);

	// Setting that allows users to set the title of the latest new section on the homepage.
	$wp_customize->add_setting(
		'carmack_latest_news_section_title',
		array(
			'default' => esc_html__( 'Latest', 'carmack' ),
			'capability' => 'edit_theme_options',
			'transport' => 'postMessage',
			'sanitize_callback' => 'esc_html',
		)
	);

	$wp_customize->add_control(
		'carmack_latest_news_section_title',
		array(
			'label' => esc_html__( 'Latest News Title', 'carmack' ),
			'section' => 'carmack_options',
			'type' => 'text',
		)
	);

	// Setting to control whether the triangular background overlay appears or not.
	$wp_customize->add_setting(
		'carmack_display_triangle',
		array(
			'default' => true,
			'capability' => 'edit_theme_options',
			'transport' => 'postMessage',
			'sanitize_callback' => 'carmack_sanitize_checkboxes',
		)
	);

	$wp_customize->add_control(
		'carmack_display_triangle',
		array(
			'label' => esc_html__( 'Display triangular background overlay', 'carmack' ),
			'section' => 'carmack_options',
			'type' => 'checkbox',
		)
	);

	// Setting to control whether featured posts slider autoplays or not.
	$wp_customize->add_setting(
		'carmack_autoplay_slider',
		array(
			'default' => true,
			'capability' => 'edit_theme_options',
			'transport' => 'postMessage',
			'sanitize_callback' => 'carmack_sanitize_checkboxes',
		)
	);

	$wp_customize->add_control(
		'carmack_autoplay_slider',
		array(
			'label' => esc_html__( 'Autoplay the Featured Content Slider', 'carmack' ),
			'section' => 'carmack_options',
			'type' => 'checkbox',
		)
	);

	// Setting to control whether featured image displays on single posts/ pages or not.
	$wp_customize->add_setting(
		'carmack_display_featured_image_on_single',
		array(
			'default' => false,
			'capability' => 'edit_theme_options',
			'transport' => 'postMessage',
			'sanitize_callback' => 'carmack_sanitize_checkboxes',
		)
	);

	$wp_customize->add_control(
		'carmack_display_featured_image_on_single',
		array(
			'label' => esc_html__( 'Display the Feature image on single blog posts and pages', 'carmack' ),
			'section' => 'carmack_options',
			'type' => 'checkbox',
		)
	);

}

add_action( 'customize_register', 'carmack_customize_register' );


/**
 * Sanitize checkbox
 *
 * @param type $setting Value to sanitize.
 * @return int|string
 */
function carmack_sanitize_checkboxes( $setting ) {

	if ( true === $setting ) {

		return true;

	} else {

		return false;

	}

}


/**
 * Binds JS handlers to make the Customizer preview reload changes asynchronously.
 */
function carmack_customize_preview_js() {

	wp_enqueue_script( 'carmack-customize-preview', get_template_directory_uri() . '/assets/js/customizer-preview.js', array( 'customize-preview' ), '1.0', true );

}

add_action( 'customize_preview_init', 'carmack_customize_preview_js' );
