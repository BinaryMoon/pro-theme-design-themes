<?php
/**
 * Sidebar template
 *
 * @package Carmack
 */

	if ( is_active_sidebar( 'sidebar-1' ) && ! is_page_template( 'page-templates/full-width.php' ) ) {
?>

<!-- Sidebar Main (1) -->

<aside class="sidebar sidebar-main" role="complementary">

<?php
	do_action( 'before_sidebar' );
	dynamic_sidebar( 'sidebar-1' );
?>

</aside>

<?php
	}
