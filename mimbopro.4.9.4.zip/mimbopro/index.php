<?php
/**
 * Homepage Template
 *
 * @package MimboPro
 */

	get_header();

	get_template_part( 'includes/featured_content' );
	get_template_part( 'includes/carousel' );
?>
<section class="stripes clearfloat">
<?php
	get_sidebar();

	$content_class = array(
		'column',
		(int) is_active_sidebar( 'sidebar-1' ),
		(int) is_active_sidebar( 'sidebar-2' )
	);

?>
	<section id="content" class="<?php echo esc_attr( implode( '-', $content_class ) ); ?>">
<?php
	get_template_part( 'includes/category_summaries' );
?>
	</section>
<?php
	// Sidebar Right.
	if ( is_active_sidebar( 'sidebar-2' ) ) {
?>
	<aside id="rightbar">
<?php
		bm_resetIgnorePost();
		dynamic_sidebar( 'sidebar-2' );
?>
	</aside>
<?php
	}
?>
</section><!--END STRIPES-->
<?php
	get_footer();
