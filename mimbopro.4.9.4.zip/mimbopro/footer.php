<?php
/**
 * Footer Template
 *
 * @package MimboPro
 */

	if ( is_active_sidebar( 'sidebar-3' ) ) {
?>
	<section id="meta" class="clearfloat">
<?php
		dynamic_sidebar( 'sidebar-3' );
?>
	</section>
<?php
	}
?>
	<footer>
		<div class="left">
<?php
	if ( function_exists( 'the_privacy_policy_link' ) ) {
		the_privacy_policy_link( '', '<span class="sep"> | </span>' );
	}
?>
			<a href="http://wordpress.org/" title="<?php esc_attr_e( 'A Semantic Personal Publishing Platform', 'mimbopro' ); ?>" rel="generator"><?php printf( esc_html__( 'Proudly powered by %s', 'mimbopro' ), 'WordPress' ); ?></a>
			<span class="sep"> | </span>
			<?php printf( esc_html__( 'Theme: %1$s by %2$s.', 'mimbopro' ), 'Mimbo Pro', '<a href="https://prothemedesign.com/" rel="designer">Pro Theme Design</a>' ); ?>
		</div>
	</footer>
</section><!--END PAGE-->
<?php wp_footer(); ?>
</body>
</html>
