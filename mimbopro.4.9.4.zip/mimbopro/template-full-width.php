<?php
/**
 * Custom Full Width Page Template
 * Template Name: Full Width
 *
 * @package MimboPro
 */

	get_header();
?>
<section class="clearfloat stripes">

	<section id="content" class="fullwidth">
<?php
	if ( have_posts() ) {
		while ( have_posts() ) {
			the_post();
?>
		<section class="post">
			<h1 id="pagetitle"><?php the_title(); ?></h1>
			<article class="entry clearfloat">
			<?php the_content();?>

<?php
		}
	}
?>
			</article><!--END ENTRY-->
		</section><!--END POST-->
	</section><!--END CONTENT-->
</section><!--END STRIPES-->
<?php
	get_footer();
