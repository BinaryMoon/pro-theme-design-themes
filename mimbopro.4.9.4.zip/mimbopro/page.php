<?php
/**
 * Single Page Template
 *
 * @package MimboPro
 */

	get_header();
?>
<section class="clearfloat stripes">
<?php
	get_sidebar();
?>
	<section id="content" class="<?php bm_content_class(); ?>">
<?php
	if ( have_posts() ) {
		while ( have_posts() ) {
			the_post();
?>
			<section class="post">
				<h1 id="pagetitle"><?php the_title(); ?></h1>
				<article class="entry clearfloat">
<?php
			mimbo_singlePostWidgets( 'sidebar-6' );
			the_content();
			edit_post_link();
		}
	}
?>
			</article><!--END ENTRY-->
		</section><!--END POST-->
		<?php comments_template(); ?>
	</section><!--END CONTENT-->
</section>
<?php
	get_footer();
