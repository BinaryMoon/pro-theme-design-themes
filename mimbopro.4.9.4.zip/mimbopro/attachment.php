<?php
/**
 * Attachment Template
 *
 * @package MimboPro
 */

	get_header();
?>
<section class="clearfloat stripes">
<?php
	get_sidebar();
?>
	<section id="content" class="<?php bm_content_class(); ?>">
<?php
	if ( have_posts() ) {
		while ( have_posts() ) {
			the_post();
			$attachment_link = wp_get_attachment_link( $post->ID, array( 450, 800 ) );
?>
		<section class="post">
<?php
			if ( $post->post_parent ) {
?>
			<h4 id="pagetitle"><a href="<?php echo esc_url( get_permalink( $post->post_parent ) ); ?>" rev="attachment">&laquo;<?php echo get_the_title( $post->post_parent ); ?></a></h4>
<?php
			}
?>
			<h1><?php the_title(); ?></h1>
			<section class="entry clearfloat attachment"><?php echo $attachment_link; ?></section>
			<p id="caption"><?php the_excerpt(); ?></p>
			<?php the_content(); ?>
		</section>
<?php
			if ( $post->parent ) {
?>
		<nav id="image-navigation">
			<span class="left"><?php previous_image_link( false, esc_html__( '&laquo; Previous', 'mimbopro' ) ); ?></span>
			<span class="right"><?php next_image_link( false, esc_html__( 'Next &raquo;', 'mimbopro' ) ); ?></span>
		</nav>
<?php
			}

			comments_template();
		}
	} else {
?>
		<p><?php esc_html_e( 'Sorry, no posts matched your criteria.','mimbopro' ); ?></p>
<?php
	}
?>
	</section>
</section>
<?php
	get_footer();
