<?php
/**
 * Theme Functions
 *
 * @package MimboPro
 */

$singlePostId = array();
$bm_crumbLinks = array();
$singlePostSidebar = '';


/**
 * Define a property if it hasn't been defined already
 *
 * @param <type> $name
 * @param <type> $value
 * @return <type>
 */
function bm_define( $name = '', $value = '' ) {

	if ( empty( $name ) || empty( $value ) ) {
		return false;
	}

	if ( ! defined( $name ) ) {
		define( $name, $value );
	}

	return true;

}


/**
 * Get a list of the featured category as specified in the control panel
 *
 * @return <type>
 */
function getFeaturedCategory() {

	$query = array();
	$query['posts_per_page'] = 1;

	$mim_feature = get_option( 'mim_feature' );

	if ( $mim_feature !== 0 ) {
		$query['cat'] = $mim_feature;
	}

	return apply_filters( 'bm_featuredCategory', $query );

}


/**
 * calculate the carousel properties
 * returns an array containing the query to get the carousel items and the quantity specified in the control panel
 *
 * @return <type>
 */
function getCarouselDetails() {

	bm_resetIgnorePost();

	$query = '';
	$count = 12;

	$tempCategory = get_option( 'mim_carousel' );

	// Make sure things work if the admin settings have not been altered.
	if ( ! empty( $tempCategory ) ) {

		if ( is_array( $tempCategory ) ) {
			$category = implode( ',', $tempCategory );
		} else {
			$category = $tempCategory;
		}

		// Get more than we need in case there's posts that don't have images included.
		$query = 'posts_per_page=' . ceil( $count * 1.5 );
		if ( $category != '0' ) {
			$query .= '&cat=' . $category;
		}
}

	$ret['query'] = $query;
	$ret['count'] = $count;

	$ret = apply_filters( 'bm_carouselDetails', $ret );

	return $ret;

}


/**
 * get a list of all the categories to display on the homepage
 *
 * @global <type> $bm_categories
 * @return <type>
 */
function getCategorySummaries() {

	$ret = array();

	$ret['category'] = get_option( 'mim_homeCat' );

	if ( empty( $ret['category'] ) ) {
		$ret['category'] = array();
	}

	$ret['colour'] = array( 'catcolor1', 'catcolor2', 'catcolor3' );

	return apply_filters( 'bm_categorySummaryDetails', $ret );

}


/**
 *
 */
function bm_body_id() {

	if ( is_home() ) {
		echo 'id="home"';
	} else {
		echo 'id="interior"';
	}

}


/**
 * get other posts from the current category
 *
 * @param int postAmount the amount of posts to display
 * @global <type> $singlePostId
 * @param <type>                                        $args
 */
function bm_categoryPosts( $args = array(), $postAmount = 4 ) {

	// make sure it's a single post
	if ( is_single() ) {

		global $singlePostId;

		extract( $args );

		$bm_cats = get_the_category( $singlePostId['id'] );

		foreach ( $bm_cats as $bm_c ) {

			$wpq = new WP_Query();
			$query = 'posts_per_page=' . $postAmount . '&cat=' . $bm_c->term_id;
			$wpq->query( $query );

			if ( $wpq->have_posts() ) {

				echo $before_widget;
?>
		<h3><?php esc_html_e( 'More in','mimbopro' ); ?> <?php echo esc_html( $bm_c->name ); ?></h3>
		<ul>
<?php
				while ( $wpq->have_posts() ) {
	$wpq->the_post();
	bm_ignorePost( $wpq->post->ID );
?>
<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
<?php
				}

				wp_reset_query();

				echo $after_widget;
?>
		</ul>
<?php
			}
		}
	}// End if().
}

wp_register_sidebar_widget( 'More from this category', 'bm_categoryPosts', '' );


/**
 * get other posts from the current category
 *
 * @param int postAmount the amount of posts to display
 */
function bm_authorPosts( $args = array(), $postAmount = 4 ) {

	// make sure it's a single post
	if ( is_single() ) {

		extract( $args );
		echo $before_widget;

		global $wp_query;
		$postAuthor = $wp_query->post->post_author;

		$wpq = new WP_Query();
		$query = 'posts_per_page=' . $postAmount . '&author=' . $postAuthor;
		$wpq->query( $query );

		if ( $wpq->have_posts() ) {
?>
		<h3><?php esc_html_e( 'More from','mimbopro' ); ?> <?php echo esc_html( ucwords( get_the_author_meta( 'nickname' ) ) ); ?></h3>
		<ul>
<?php
			while ( $wpq->have_posts() ) {
	$wpq->the_post();
	bm_ignorePost( $wpq->post->ID );
?>
<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
<?php
			}

			wp_reset_query();
?>
		</ul>
<?php
		}

		echo $after_widget;

	}

}

wp_register_sidebar_widget( 'More Posts by this Author', 'bm_authorPosts', '' );


/**
 * theme header initialisation
 * load javascript and css files, and sort out meta tags
 */
function bm_head() {

	global $singlePostId, $post, $id;

	if ( is_single() || is_archive() ) {
		$singlePostId['id'] = $post->ID;
		$singlePostId['post'] = $post;
	}

}


/**
 *
 */
function bm_excerpt( $length = 50, $stripTags = false ) {

	// grab the content and remove [shortcodes]
	$content = get_the_content( '', 0, '' );
	$content = strip_shortcodes( $content );

	// split content into array
	$words = explode( ' ', $content, $length + 1 );

	// remove last element (which contains all content > than specified length)
	if ( count( $words ) > $length ) {
		array_pop( $words );
		$words[] = '...';
	}

	// stick everything back together again
	$content = implode( ' ', $words );

	// make it all look good and remove unwelcome html
	if ( $stripTags ) {
		$content = strip_tags( $content );
		$content = str_replace( "\n", ' ', $content );
		$content = str_replace( "\r", ' ', $content );
		$content = str_replace( "\t", '', $content );
		$content = trim( $content );
	} else {
		$content = apply_filters( 'the_content', $content );
		$content = strip_tags( $content, '<p>' );
	}

	echo $content;

}


/**
 * display header javascript content
 */
function bm_scripts() {

	$scrollSpeed = absint( get_option( 'mim_carouselSpeed' ) );
?>
	<script type="text/javascript">
		if (window == window.top) {
			jQuery(document).ready(function() {

				jQuery('#nav, #nav-secondary').responsiveNavigation ( {
					min_menu_size: 0
				});
<?php
			if ( is_home() ) {
?>
jQuery('#carousel').elementalCarousel({ interval: <?php echo intval( $scrollSpeed * 1000 ); ?> });
<?php
			}
?>
				jQuery("ul.nav").superfish({
					animation:   {opacity:"show",height:"show"},
					speed:       "normal",
					dropShadows: false
				});
			});
		}
	</script>
<?php
}


/**
 *
 */
function bm_searchform() {

	$imagepath = get_template_directory_uri() . '/images/magnify.png';
	$imagepath = apply_filters( 'bm_searchimage', $imagepath );

?>
	<form method="get" class="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
		<label><?php esc_html_e( 'Search', 'mimbopro' ); ?></label>
		<input type="text" value="<?php echo esc_attr( get_search_query() ); ?>" name="s" id="s" placeholder="<?php esc_attr_e( 'Search...', 'mimbopro' ); ?>" />
		<input type="image" src="<?php echo esc_url( $imagepath ); ?>" id="searchsubmit" alt="search" />
	</form>
<?php
}


/**
 * Calculate breadcrumbs for any page on the site
 *
 * @param boolean $display display or return the results as an array?
 * @param string  $seperator the text to place between the crumbs when returned as a string
 * @return array list of name, url pairs to use to create breadcrumbs
 */
function bm_simpleBreadcrumbs( $display = true, $separator = '<b>&rsaquo;</b>' ) {

	// don't display breadcrumbs on the homepage
	if ( is_front_page() ) {
		return false;
	}

	global $wp_query, $post, $bm_crumbLinks, $bm_postMeta;

	// Always a home link.
	$bm_crumbLinks[] = array(
		esc_html__( 'Home', 'mimbopro' ),
		esc_url( home_url( '/' ) ),
	);

	// Add breadcrumbs for custom post types.
	$post_type = get_post_type( $post );

	if ( ! in_array( $post_type, array( 'post', 'page', 'attachment', '' ), true ) ) {
		$post_type_object = get_post_type_object( $post_type );
		if ( isset( $post_type_object->labels->name ) ) {
			$bm_crumbLinks[] = array(
				$post_type_object->labels->name,
				get_post_type_archive_link( $post_type ),
			);
		}
	}

	// Is it the front page?
	if ( is_home() || is_front_page() ) {

		// turn off url on home link to keep it as text
		$links[0][1] = '';

		// a page?
	} elseif ( is_page() ) {

		$post = $wp_query->get_queried_object();
		if ( 0 < $post->post_parent ) {

			$bm_crumbLinks[] = array(
				get_the_title(),
				get_permalink(),
			);

		} else {

			// Reverse the order so it's oldest to newest
			if ( isset( $post->ancestors ) ) {
				$ancestors = array_reverse( $post->ancestors );
			} else {
				$ancestors[] = $post->post_parent;
			}

			// Add the current Page to the ancestors list (as we need it's title too)
			$ancestors[] = $post->ID;

			foreach ( $ancestors as $ancestor ) {
				$bm_crumbLinks[] = array(
					strip_tags( get_the_title( $ancestor ) ),
					get_permalink( $ancestor ),
				);
			}
		}
	} else {

		if ( is_attachment() ) {
			$bm_crumbLinks[] = array(
				get_the_title( $post->post_parent ),
				get_permalink( $post->post_parent ),
			);
			} elseif ( is_single() ) {
			$cats = get_the_category();
			if ( isset( $cats[0] ) ) {
				$cat = $cats[0];
				bm_get_category_parents( $cat->term_id );
				}
			}

			if ( is_category() ) {
			$cat = (int) get_query_var( 'cat' );
			bm_get_category_parents( $cat );
			} elseif ( is_tag() ) {
			$bm_crumbLinks[] = array(
			single_cat_title( '', false ),
			);
			} elseif ( is_date() ) {
			$day = (int) $wp_query->query_vars['day'];
			$month = (int) $wp_query->query_vars['monthnum'];
			$year = (int) $wp_query->query_vars['year'];

			if ( $month != 0 ) {
				$title = single_month_title( ' ', false );
				} else {
				$title = $year;
				}

			$bm_crumbLinks[] = array(
			$title,
			bm_getDateArchiveLink( $year, $month, $day ),
			);
			} elseif ( is_post_type_archive() ) {
			// do nothing - it was taken care of earlier
			} elseif ( is_author() ) {
			$curauth = $wp_query->get_queried_object();
			$bm_crumbLinks[] = $curauth->display_name;
			} elseif ( is_search() ) {
			$bm_crumbLinks[] = sprintf( __( 'Search', 'mimbopro' ), get_search_query() );
			} elseif ( is_404() ) {
			$bm_crumbLinks[] = esc_html__( '404 Page not found', 'mimbopro' );
			} else {
			$title = get_the_title();
			if ( ! empty( $bm_postMeta['seo_breadcrumbTitle'] ) ) {
				$title = $bm_postMeta['seo_breadcrumbTitle'];
				}
			$bm_crumbLinks[] = array(
			$title,
			get_permalink(),
			);
			}// End if().
}// End if().

	if ( ! empty( $wp_query->query_vars['paged'] ) ) {
		$bm_crumbLinks[] = sprintf( esc_html__( 'Page %d', 'mimbopro' ), $wp_query->query_vars['paged'] );
	}

	if ( ! empty( $wp_query->query_vars['page'] ) ) {
		$bm_crumbLinks[] = sprintf( esc_html__( 'Page %d', 'mimbopro' ), $wp_query->query_vars['page'] );
	}

	$bm_crumbLinks = apply_filters( 'bm_crumbLinks', $bm_crumbLinks );

	$count = 0;
	$crumbs = array();

	foreach ( $bm_crumbLinks as $link ) {
		$count ++;
		$link = (array) $link;

		$htmlClass = 'breadcrumbLevel_' . $count;

		if ( ! empty( $link[0] ) ) {
			if ( $count != count( $bm_crumbLinks ) ) {
				// Ensure there is a link to display.
				if ( isset( $link[1] ) ) {
					$crumbs[] = '<a href="' . esc_url( $link[1] ) . '" class="' . esc_attr( $htmlClass ) . '">' . wp_kses_data( $link[0] ) . '</a>';
				} else {
					$crumbs[] = '<strong>' . $link[0] . '</strong>';
				}
			} else {
				$crumbs[] = '<strong class="' . esc_attr( $htmlClass ) . '">' . wp_kses_data( $link[0] ) . '</strong>';
			}
		}
	}

	if ( $crumbs ) {
		if ( $display ) {
			echo implode( ' ' . $separator . ' ', $crumbs );
		} else {
			return $crumbs;
		}
	}

	return false;

}


/**
 * Get the parents of a category and update the bm_crumblinks array with the result
 *
 * @param int $id the id of the category
 */
function bm_get_category_parents( $id ) {

	global $bm_crumbLinks;

	$parent = get_category( $id );

	if ( ! is_wp_error( $parent ) ) {
		if ( $parent->parent && ($parent->parent != $parent->term_id) ) {
			bm_get_category_parents( $parent->parent );
		}
	}

	$bm_crumbLinks[] = array( $parent->name, get_category_link( $parent->term_id ) );

	return true;

}



/**
 *
 * @global <type> $bm_options
 * @param <type> $position
 */
function bm_navigation() {

	$args = array(
		'theme_location' => 'main-menu',
		'menu_class' => 'left clearfloat nav',
		'menu_id' => 'nav',
		'container' => false,
		'fallback_cb' => false,
		'echo' => 0,
	);

	$menu = wp_nav_menu( $args );

	if ( empty( $menu ) ) {
?>

		<ul id="nav" class="left clearfloat nav">
			<li<?php if ( is_home() ) { ?> class="current-cat"<?php } ?>><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home','mimbopro' ); ?></a></li>
<?php
		$args = array(
			'title_li' => '',
			'orderby' => 'count',
			'number' => 6,
			'order' => 'DESC',
		);
		wp_list_categories( $args );
		echo '</ul>';
	} else {
		echo $menu;
	}

}


/**
 *
 * @global <type> $bm_options
 * @param <type> $position
 */
function bm_secondary_navigation() {

	$args = array(
		'theme_location' => 'secondary-menu',
		'menu_class' => 'clearfloat nav',
		'menu_id' => 'nav-secondary',
		'fallback_cb' => false,
		'echo' => true,
		'container' => false,
	);

	wp_nav_menu( $args );

}


/**
 *
 */
function bm_searchTitle() {

	$title = get_the_title();
	$keys = implode( '|', explode( ' ', get_search_query() ) );
	$title = preg_replace( '/(' . $keys . ')/iu', '<strong class="search-excerpt">\0</strong>', $title );

	echo $title;

}


/**
 * set default arguments for widgets
 *
 * @param type $args
 * @param type $defaults
 * @return type
 */
function bm_defaultArgs( $args, $defaults = array() ) {

	if ( $args == array() ) {
		$args = array(
			'before_widget' => '',
			'before_title' => '<h4 class="widgettitle">',
			'after_title' => '</h4>',
			'after_widget' => '',
		);
	}

	if ( $defaults != array() ) {
		foreach ( $defaults as $key => $value ) {
			if ( ! isset( $args[ $key ] ) || $args[ $key ] == '' ) {
				$args[ $key ] = $value;
			}
		}
	}

	return apply_filters( 'bm_widgetDefaultArguments', $args );

}


/**
 *
 * @global <type> $wp_rewrite
 * @param <type> $year
 * @param <type> $month
 * @param <type> $day
 * @return <type>
 */
function bm_getDateArchiveLink( $year = 0, $month = 0, $day = 0 ) {

	global $wp_rewrite;

	if ( $day == 0 && $month == 0 ) {
		$link = $wp_rewrite->get_year_permastruct();
	} elseif ( $day == 0 ) {
		$link = $wp_rewrite->get_month_permastruct();
	} else {
		$link = $wp_rewrite->get_day_permastruct();
	}

	if ( ! empty( $link ) ) {
		$link = str_replace( '%year%', $year, $link );
		$link = str_replace( '%monthnum%', zeroise( intval( $month ), 2 ), $link );
		$link = str_replace( '%day%', zeroise( intval( $day ), 2 ), $link );
		$link = user_trailingslashit( $link, 'day' );
	} else {
		$link = '/?m=' . $year . zeroise( $month, 2 ) . zeroise( $day, 2 );
	}

	return apply_filters( 'bm_getDateArchiveLink', esc_url( home_url( '/' ) . $link, $year, $month, $day ) );

}
