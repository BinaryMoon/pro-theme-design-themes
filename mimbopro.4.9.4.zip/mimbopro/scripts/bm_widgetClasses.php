<?php
/**
 * Extra Custom Widgets
 *
 * @package MimboPro
 */

/**
 * List popular posts sorted by comment count
 */
class bm_widget_popularPosts extends WP_Widget {

	/**
	 * Construct popular posts widgets.
	 */
	function __construct() {

		parent::__construct(
			false,
			esc_html__( 'Mimbo Pro Popular Posts', 'mimbopro' ),
			array(
				'description' => esc_html__( 'Posts listed by comment count', 'mimbopro' ),
			)
		);

	}

	/**
	 * Display popular posts widget.
	 * @param  array $args     Widget properties.
	 * @param  array $instance Widget instance.
	 */
	function widget( $args, $instance ) {

		if ( isset( $instance['title'] ) ) {
			$args['title'] = esc_html( $instance['title'] );
		}

		bm_popularPosts( $args );

	}

	/**
	 * Update popular posts widget properties.
	 * @param  array $new_instance Widget user settings.
	 * @param  array $old_instance Original widget settings.
	 * @return array
	 */
	function update( $new_instance, $old_instance ) {

		return $new_instance;

	}

	/**
	 * Popular posts widget form.
	 * @param  object $instance Default widget object.
	 */
	function form( $instance ) {

		$title = '';

		if ( isset( $instance['title'] ) ) {
			$title = esc_attr( $instance['title'] );
		}
?>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'mimbopro' ); ?> <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" /></label></p>
<?php

	}

}

/**
 * Display related posts by category
 */
class bm_widget_relatedPosts extends WP_Widget {

	/**
	 * Construct Related posts widget.
	 */
	function __construct() {

		parent::__construct(
			false,
			esc_html__( 'Mimbo Pro Related Posts (by category)', 'mimbopro' ),
			array( 'description' => esc_html__( 'Posts grouped by the categories they are assigned to', 'mimbopro' ) )
		);

	}

	/**
	 * Display Related Posts widget.
	 * @param  array $args     Widget properties.
	 * @param  array $instance Widget instance.
	 */
	function widget( $args, $instance ) {

		if ( isset( $instance['title'] ) ) {
			$args['title'] = esc_html( $instance['title'] );
		}

		bm_relatedPosts( $args );

	}

	/**
	 * Update related posts widget properties.
	 * @param  array $new_instance Widget user settings.
	 * @param  array $old_instance Original widget settings.
	 * @return array
	 */
	function update( $new_instance, $old_instance ) {

		return $new_instance;

	}

	/**
	 * Display related posts widget.
	 * @param  object $instance Default widget object.
	 */
	function form( $instance ) {

		$title = '';
		if ( isset( $instance['title'] ) ) {
			$title = esc_attr( $instance['title'] );
		}
?>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'mimbopro' ); ?> <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" /></label></p>
<?php

	}

}

/**
 * Display post author information.
 */
class bm_widget_postDetails extends WP_Widget {

	/**
	 * Construct widget.
	 */
	function __construct() {

		parent::__construct(
			false,
			esc_html__( 'Mimbo Pro Post Author Details', 'mimbopro' ),
			array( 'description' => esc_html__( 'Info about the author of the current post', 'mimbopro' ) )
		);

	}

	/**
	 * Display post details widget.
	 * @param  array  $args		Widget arguments.
	 * @param  object $instance Widget instance.
	 */
	function widget( $args, $instance ) {

		if ( isset( $instance['title'] ) ) {
			$args['title'] = esc_html( $instance['title'] );
		}

		if ( isset( $instance['showDate'] ) ) {
			$args['showDate'] = $instance['showDate'];
		}

		bm_postDetails( $args );

	}

	/**
	 * Update post details widget settings.
	 * @param  array $new_instance Widget user settings.
	 * @param  array $old_instance Original widget settings.
	 * @return array
	 */
	function update( $new_instance, $old_instance ) {

		$new_instance['showDate'] = (bool) $new_instance['showDate'];

		return $new_instance;

	}

	/**
	 * Post details widget form.
	 * @param  object $instance Default widget object.
	 */
	function form( $instance ) {

		$title = '';
		if ( isset( $instance['title'] ) ) {
			$title = esc_attr( $instance['title'] );
		}

		$showDate = false;
		if ( isset( $instance['showDate'] ) ) {
			$showDate = (bool) $instance['showDate'];
		}

		$showDateExtra = '';
		if ( true === $showDate || 1 === $showDate ) {
			$showDateExtra = 'checked="true"';
		}
?>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'mimbopro' ); ?> <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" /></label></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id( 'showDate' ) ); ?>"><?php esc_html_e( 'Display date:', 'mimbopro' ); ?> <input type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'showDate' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'showDate' ) ); ?>" <?php echo esc_attr( $showDateExtra ); ?> /></label></p>
<?php

	}

}

/**
 * Display list of upcoming posts.
 */
class bm_widget_upcomingPosts extends WP_Widget {

	/**
	 * Construct upcoming posts widget.
	 */
	function __construct() {

		parent::__construct(
			false,
			esc_html__( 'Mimbo Pro Upcoming Posts', 'mimbopro' ),
			array(
				'description' => esc_html__( 'Lists the posts that are scheduled for the future', 'mimbopro' ),
			)
		);

	}

	/**
	 * Display Upcoming Posts widget.
	 * @param  array $args     Widget properties.
	 * @param  array $instance Widget instance.
	 */
	function widget( $args, $instance ) {

		if ( isset( $instance['title'] ) ) {
			$args['title'] = esc_html( $instance['title'] );
		}

		bm_upcomingPosts( $args );

	}

	/**
	 * Update upcoming posts widget settings.
	 * @param  array $new_instance Widget user settings.
	 * @param  array $old_instance Original widget settings.
	 * @return array
	 */
	function update( $new_instance, $old_instance ) {

		return $new_instance;

	}

	/**
	 * Upcoming posts widget form.
	 * @param  object $instance Default widget object.
	 */
	function form( $instance ) {

		$title = '';
		if ( isset( $instance['title'] ) ) {
			$title = esc_attr( $instance['title'] );
		}
?>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'mimbopro' ); ?> <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" /></label></p>
<?php

	}

}


/**
 * Register widgets
 */
function mimbopro_widgets_init() {

	register_widget( 'bm_widget_popularPosts' );
	register_widget( 'bm_widget_relatedPosts' );
	register_widget( 'bm_widget_postDetails' );
	register_widget( 'bm_widget_upcomingPosts' );

}

add_action( 'widgets_init', 'mimbopro_widgets_init' );
