<?php
/**
 * Reusable Helper Functions
 *
 * @package MimboPro
 */

// helper functions
// ----------------

/**
 *
 * @param type $var
 * @param type $type
 * @param type $description
 * @param type $value
 * @param type $selected
 * @param type $onchange
 */
function bm_input( $var, $type, $description = '', $value = '', $selected = '', $onchange = '' ) {

	// ------------------------
	// add a form input control
	// ------------------------

	$extra = '';

	echo "\n";

	switch ( $type ) {

		case 'text':

			echo '<input name="' . esc_attr( $var ) . '" id="' . esc_attr( $var ) . '" type="' . esc_attr( $type ) . '" style="width: 70%;" class="regular-text" value="' . esc_attr( $value ) .'" onchange="' . $onchange . '"/>';
			if ( '' !== $description ) {
				echo '<p style="font-size:0.9em; color:#999; margin:0;">' . esc_html( $description ) . '</p>';
			}

			break;

		case 'submit':

			echo '<p class="submit"><input name="' . esc_attr( $var ) . '" type="' . esc_attr( $type ) . '" value="' . esc_attr( $value ) . '" class="button-primary"/></p>';

			break;

		case 'option':

			if ( $selected === $value ) {
				$extra = 'selected="true"';
			}

			echo '<option value="' . esc_attr( $value ) . '" ' . esc_attr( $extra ) . '>' . esc_html( $description ) . '</option>';

			break;

		case 'radio':

			echo '<label><input name="' . esc_attr( $var ) . '" id="' . esc_attr( $var ) . '" type="' . esc_attr( $type ) . '" value="' . esc_attr( $value ) . '" ' . checked( $selected ) . '/> ' . esc_html( $description ) . '</label><br/>';

  			break;

		case 'checkbox':

			echo '<label><input name="' . esc_attr( $var ) .'" id="' . esc_attr( $var ) . '" type="' . esc_attr( $type ) . '" value="' . esc_attr( $value ) . '" ' . checked( $selected ) . ' /> ' . esc_html( $description ) . '</label><br/>';

			break;

		case 'textarea':

			echo '<textarea name="' . esc_attr( $var ) . '" id="' . esc_attr( $var ) . '" style="width: 70%; height: 10em;" class="code">' . esc_textarea( $value ) . '</textarea>';

			break;

	}

}

/**
 *
 * @param type $var
 * @param type $arrValues
 * @param type $selected
 * @param type $label
 */
function bm_select ( $var, $arrValues = array(), $selected = '', $label = '' ) {

	$arrValues = (array) $arrValues;

	if ( '' !== $label ) {
		echo '<label for="'. esc_attr( $var ) . '">' . esc_html( $label ) . '</label>';
	}

	if ( count( $arrValues ) > 0 ) {
		echo '<select name="' . esc_attr( $var ) . '" id="' . esc_attr( $var ) . '">\n';

		foreach ( $arrValues as $arr ) {

			$extra = '';
			if ( $selected == $arr[0] ) {
				$extra = ' selected="true"';
			}

			echo '<option value="' . esc_attr( $arr[0] ) . '"' . esc_attr( $extra ) . '>' . esc_html( $arr[1] ) . '</option>\n';

		}

		echo '</select>';

	} else {

		echo 'no array values specified for ' . esc_html( $var );

	}

}

/**
 *
 * @param type $var
 * @param type $arrValues
 * @param type $selected
 * @param type $label
 */
function bm_multiSelect ( $var, $arrValues = array(), $selected = '', $label = '' ) {

	$arrValues = (array) $arrValues;

	if ( '' !== $label ) {
		echo '<label for="' . esc_attr( $var ) . '">' . esc_html( $label ) . '</label>';
	}

	if ( count( $arrValues ) > 0 ) {
		echo '<select name="' . esc_attr( $var ) . '" id="' . esc_attr( $var ) . '" size="7" multiple="true" style="height:150px;">\n';

		foreach ( $arrValues as $arr ) {

			$extra = '';
			if ( in_array( $arr[0], $selected, true ) ) {
				$extra = ' selected="true"';
			} else {
				$extra = '';
			}

			echo '<option value="' . esc_attr( $arr[0] ) . '"' . esc_attr( $extra ) . '>' . esc_html( $arr[1] ) . '</option>\n';

		}

		echo '</select>';
	} else {

		printf( esc_html__( 'no array values specified for %s', 'mimbopro' ), esc_attr( $var ) );

	}

}

/**
 *
 * @param type $var
 * @param type $arrValues
 * @param type $selected
 * @param type $error
 */
function bm_multiCheckbox ( $var, $arrValues = array(), $selected = array(), $error = '' ) {

	$arrValues = (array) $arrValues;

	if ( count( $arrValues ) > 0) {

		echo '<fieldset>';

		echo '<a href="" class="multicheck_all">' . esc_html__('Check All', 'mimbopro') . '</a> | ';
		echo '<a href="" class="multicheck_none">' . esc_html__('Deselect All', 'mimbopro') . '</a>';
		echo '<br />';

		foreach ( $arrValues as $arr ) {

			$extra = '';
			// make sure something is $selected.
			if ( is_array( $selected ) ) {
				if ( in_array( $arr[0], $selected ) ) {
					$extra = ' checked="checked"';
				}
			}
			echo '<label class="category-list">';
			echo '<input type="checkbox" name="' . esc_attr( $var ) . '" value="' . esc_attr( $arr[0] ) . '"' . esc_attr( $extra ) .' />';
			echo ' ' . $arr[1] . '</label>';

		}

		echo '</fieldset>';

	} else {
		if ( $error == '' ) {
			$error = sprintf( esc_html__( 'no array values specified for %s', 'mimbopro' ), esc_attr( $var ) );
		}
		echo $error;
	}

}

/**
 *
 * @param type $var
 * @param type $possible
 * @param type $selected
 * @param type $description
 */
function bm_sortable( $var, $possible = array(), $selected = array(), $description = '' ) {

	$selected = (array) $selected;

	if ( ! empty( $description ) ) {
		echo '<p class="description">' . wp_kses_data( $description ) . '</p>';
	}
?>
	<input id="sortable_val" name="<?php echo esc_attr( $var ); ?>" value="<?php echo esc_attr( implode( ',', $selected ) ); ?>" type="hidden" class="hidden" />
	<div class="connectedSortContainer">
		<strong><?php esc_html_e( 'Active', 'mimbopro' ); ?></strong>
		<ul id="sortable_active" class="connectedSort connectedSort_<?php echo esc_attr( $var ); ?> clearfix">
<?php
	foreach ( $selected as $s ) {
		$i = array();
		foreach ( $possible as $p ) {
			if ( $p[0] == $s ) {
				$i = $p;
			}
		}

		if ( ! empty( $i ) ) {
			echo '<li cat="' . esc_attr( $i[0] ) . '">' . esc_html( $i[1] ) . '</li>';
		}
	}
?>
		</ul>
	</div>

	<div class="connectedSortContainer">
		<strong><?php esc_html_e( 'Inactive', 'mimbopro' ); ?></strong>
		<ul id="sortable_inactive" class="connectedSort connectedSort_<?php echo esc_attr( $var ); ?> connected_big clearfix">
<?php
	foreach ( $possible as $p ) {
		if ( ! in_array( $p[0], $selected ) ) {
			echo '<li cat="' . esc_attr( $p[0] ) . '">' . esc_html( $p[1] ) . '</li>';
		}
	}
?>
		</ul>
	</div>
<?php

}

/**
 *
 * @param type $var
 * @param type $arrValues
 * @param type $selected
 * @param type $label
 */
function bm_imageSelect( $var, $arrValues, $selected, $label ) {

	if ( '' !== $label ) {
		echo '<label for="' . esc_attr( $var ) . '">' . esc_html( $label ) . '</label>';
	}

	foreach ( $arrValues as $arr ) {

		$extra = '';
		if ( is_array( $selected ) ) {
			if ( in_array( $arr[0], $selected ) ) {
				$extra = ' selected="true"';
			}
		}
?>
		<div class="imageSelect">
			<label>
				<img src="<?php echo esc_url( $arr[2] ); ?>" width="100" height="100" alt="<?php echo esc_attr( $arr[ 1 ] ); ?>" />
				<input name="<?php echo esc_attr( $var ); ?>" type="radio" value="<?php echo esc_attr( $arr[ 0 ] ); ?>" <?php echo esc_attr( $extra ); ?>>
					<?php echo esc_attr( $arr[ 1 ] ); ?>
				</input>
			</label>
		</div>
<?php

	}

}

/**
 *
 * @param type $title
 */
function bm_th( $title ) {

	// ------------------
	// add a table header
	// ------------------

	echo '<tr valign="top">';
	echo '<th scope="row"><label>' . esc_html( $title ) . '</label></th>';
	echo '<td>';

}

/**
 *
 * @param type $description
 */
function bm_cth( $description = '' ) {

	if ( ! empty( $description ) ) {
		echo '<br /><span class="description">' . esc_html( $description ) . '</span>';
	}

	echo '</td></tr>';

}
