<?php
/**
 * Functions used by custom widgets
 *
 * @package MimboPro
 */

/**
 * Calculate the posts with the most comments from the last 4 months
 * @param array $args Previously specified arguments.
 */
function bm_popularPosts( $args = array() ) {

	$query = array(
		'posts_per_page' => 5,
		'post_status' => 'publish',
		'ignore_sticky_posts' => 1,
		'orderby' => 'comment_count',
		'order' => 'DESC',
		'date_query' => array(
			array(
				'after' => '4 months ago',
			),
		),
	);

	$bmWp = new WP_Query( $query );

	if ( $bmWp->have_posts() ) {

		$defaults = array(
			'title' => esc_html__( 'Popular Posts', 'mimbopro' ),
		);

		$args = bm_defaultArgs( $args, $defaults );

		echo wp_kses_post( $args['before_widget'] ) . wp_kses_post( $args['before_title'] ) . esc_html( $args['title'] ) . wp_kses_post( $args['after_title'] );
?>
	<div class="widgetInternalWrapper">
		<ol class="popularPosts postsList">
<?php
		$listClass = '';

		while ( $bmWp->have_posts() ) {
			$bmWp->the_post();

			if ( 'odd' === $listClass ) {
				$listClass = 'even';
			} else {
				$listClass = 'odd';
			}
?>
			<li class="<?php echo esc_attr( $listClass ); ?>">
				<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
			</li>
<?php
		}
?>
		</ol>
	</div>
<?php
		echo wp_kses_post( $args['after_widget'] );

	}

	wp_reset_postdata();

}


/**
 * Display related posts.
 * @param  array $args related posts arguments.
 */
function bm_relatedPosts ( $args = array() ) {

	if ( ! is_single() ) {
		return false;
	}

	$cats = wp_get_post_categories( get_the_ID() );

	if ( $cats ) {

		$query = array(
			'category__in' => $cats,
			'post__not_in' => array( get_the_ID() ),
			'posts_per_page' => 5,
			'ignore_sticky_posts' => 1,
		);

		$bmWp = new WP_Query( $query );

		if ( $bmWp->have_posts() ) {

			$defaults = array(
				'title' => esc_html__( 'Related Posts', 'mimbopro' ),
			);

			$args = bm_defaultArgs( $args, $defaults );

			echo wp_kses_post( $args['before_widget'] ) . wp_kses_post( $args['before_title'] ) . esc_html( $args['title'] ) . wp_kses_post( $args['after_title'] );
?>
		<ul class="relatedPosts postsList">
<?php
			while ( $bmWp->have_posts() ) {
				$bmWp->the_post();
?>
			<li><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php esc_attr_e( 'Permanent Link to', 'mimbopro' ); ?> <?php the_title_attribute(); ?>"><?php the_title(); ?></a></li>
<?php
			}
?>
		</ul>
<?php
			echo wp_kses_post( $args['after_widget'] );

		}

		wp_reset_postdata();

	}

}

/**
 * Display author details for the current post
 *
 * @param array $args Previously specified arguments.
 */
function bm_postDetails( $args = array() ) {

	// Make sure it's a single post.
	if ( is_single() ) {

		$args = bm_defaultArgs( $args );

		echo wp_kses_post( $args['before_widget'] );

		global $post;

?>
	<div id="postDetails">
<?php
		if ( ! empty( $args['title'] ) ) {
			echo wp_kses_post( $args['before_title'] ) . esc_html( $args['title'] ) . wp_kses_post( $args['after_title'] );
		}
?>
		<a href="<?php echo esc_url( get_author_posts_url( $post->post_author ) ); ?>" class="authorLink"><?php echo get_avatar( $post->post_author, 45 ); ?></a>
		<ul>
			<li class="postDetailsAuthor"><?php printf( esc_html__( 'Posted by', 'mimbopro' ) . ' <a href="%s">%s</a>', esc_url( get_author_posts_url( $post->post_author ) ), esc_attr( get_the_author_meta( 'display_name', $post->post_author ) ) ); ?></li>
<?php
		if ( isset( $args['showDate'] ) && true === $args['showDate'] ) {
?>
			<li class="postDetailsDate"><?php esc_html( bm_theDate() ); ?></li>
<?php
		}
?>
			<li class="postDetailsCommentsFeed"><?php post_comments_feed_link(); ?></li>
<?php
		the_tags( '<li class="postDetailsTags">' . esc_html__( 'Tags', 'mimbopro' ) . ': ', ', ', '</li>' );
?>
		</ul>
	</div>
<?php
		echo wp_kses_post( $args['after_widget'] );

	}
}


/**
 * List posts tagged as set to publish in the future
 *
 * @param array $args Previously specified arguments.
 * @param int 	$postAmount The amount of posts to display.
 */
function bm_upcomingPosts( $args = array(), $postAmount = 5 ) {

	$query = array(
		'post_status' => 'future',
		'posts_per_page' => (int) $postAmount,
		'order_by' => 'post_date',
	);

	$bmWp = new WP_Query( $query );

	if ( $bmWp->have_posts() ) {

		$defaults = array(
			'title' => esc_html__( 'Upcoming Posts', 'mimbopro' ),
		);

		$args = bm_defaultArgs( $args, $defaults );

		echo $args['before_widget'] . $args['before_title'] . $args['title'] . $args['after_title'];
?>
	<ul class="upcomingPosts postsList">
<?php
		while ( $bmWp->have_posts() ) {
			$bmWp->the_post();
?>
		<li><?php the_title(); ?></li>
<?php
		}
?>
	</ul>
<?php

		echo $args['after_widget'];

	}

	wp_reset_postdata();

}


/**
 * Output the date in the user specified time format.
 */
function bm_theDate() {

	the_time( get_option( 'date_format' ) );

}
