<?php
/**
 * Admin Functions
 *
 * @package MimboPro
 */

$bmIgnorePosts = array();

/**
 * add posts to array to ignore them from future wp queries
 */
function bm_ignorePost($id) {
	global $bmIgnorePosts;
	$bmIgnorePosts[] = $id;
}

/**
 * clear "ignore list"
 */
function bm_resetIgnorePost() {
	global $bmIgnorePosts;
	$bmIgnorePosts = array();
}

/**
 * remove ignored posts from query_post
 */
function bm_postStrip($where) {

	global $bmIgnorePosts, $wpdb;

	if(count($bmIgnorePosts) > 0) {
		$where .= " AND $wpdb->posts.ID not in(" . implode(",", $bmIgnorePosts) . ") ";
	}

	return $where;

}

add_filter("posts_where", "bm_postStrip");