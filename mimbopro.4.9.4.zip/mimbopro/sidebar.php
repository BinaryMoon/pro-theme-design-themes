<?php
/**
 * Sidebar Template
 *
 * @package MimboPro
 */

	$sidebar_name = bm_get_sidebar();

	if ( ! empty( $sidebar_name ) ) {
		echo '<div id="sidebar">';
		dynamic_sidebar( $sidebar_name );
		echo '</div>';
	}
