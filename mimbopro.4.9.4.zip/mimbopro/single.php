<?php
/**
 * Single Blog Post Template
 *
 * @package MimboPro
 */

	get_header();

	// Ignore post from related posts in sidebar.
	bm_ignorePost( $post->ID );
?>
		<section class="clearfloat stripes">
<?php
	get_sidebar();

	if ( have_posts() ) {
		while ( have_posts() ) {
			the_post();
?>
		<section id="content" class="<?php bm_content_class(); ?>">
			<section id="post-<?php the_ID(); ?>" <?php post_class( 'style' ); ?>>

				<h1 id="posttitle"><?php the_title(); ?></h1>

				<section class="postmetadata">
					<em><?php esc_html_e( 'By','mimbopro' ); ?></em> <?php the_author_posts_link(); ?> &bull; <?php the_date( get_option( 'date_format' ) ); ?>
				</section>
				<article class="entry clearfloat">
<?php
			mimbo_singlePostWidgets();
			the_content();
			edit_post_link();

			wp_link_pages();

			if ( get_the_tags() ) {
				the_tags( '<p><span class="tags"><strong>' . esc_html__( 'Tagged as: ','mimbopro' ) . '</strong> ', ', ', '</span></p>' );
			}

			// Only display if there's more than one category. If there's just 1 category then the breadcrumbs will suffice.
			if ( count( get_the_category() ) > 1 ) {
				echo '<p><span class="tags"><strong>' . esc_html__( 'Categorised in: ', 'mimbopro' ) . '</strong>';
				the_category( ', ' );
				echo '</p>';
			}
?>
				</article>
<?php
			previous_post_link( '<div class="postnav left">&laquo; %link</div>' );
			next_post_link( '<div class="postnav right">%link &raquo;</div>' );
?>
			</section>
<?php
			comments_template();

		} // End while().
	} else {
?>
				<p><?php esc_html_e( 'Sorry, no posts matched your criteria.', 'mimbopro' ); ?></p>
<?php
	} // End if().
?>
		</section><!--END CONTENT-->
	</section><!--END FLOATS-->
<?php
	get_footer();
