<?php
/**
 * 404 Template
 *
 * @package MimboPro
 */

	get_header();
?>
<section class="clearfloat stripes">
<?php
	get_sidebar();
?>
	<section id="content">
		<h1 id="pagetitle"><?php esc_html_e( 'Error 404: Page Not Found', 'mimbopro' ); ?></h1>
		<div class="cat-excerpt clearfloat subfeature">
			<p><?php esc_html_e( "Oh no - something has gone wrong. The page you're looking for can't be found", 'mimbopro' ); ?></p>
		</div>
		<?php bm_searchform(); ?>
	</section>
</section>
<?php
	get_footer();
