<?php
/**
 * Custom Archives Page Template
 * Template Name: Archives
 *
 * @package MimboPro
 */

	get_header();
?>
<section class="clearfloat stripes">
<?php
	get_sidebar();
?>
	<section id="content" class="entry <?php bm_content_class(); ?>">
		<h1 id="pagetitle"><?php esc_html_e( 'Archives', 'mimbopro' ); ?></h1>
<?php
	add_filter( 'post_limits', 'mimbo_post_limit' );

	global $myOffset, $postsperpage;

	$postsperpage = 30;

	$archive_query = new WP_Query(
		array(
			'ignore_sticky_posts' => 1,
			'orderby' => 'post_date',
			'order' => 'DESC',
			'offset' => $myOffset,
			'posts_per_page' => $postsperpage,
			'paged' => $paged,
		)
	);

	$previous_year = 0;
	$previous_month = 0;
	$ul_open = false;

	if ( $archive_query->have_posts() ) {
		while ( $archive_query->have_posts() ) {
			$archive_query->the_post();
			setup_postdata( $post );
			$year = mysql2date( 'Y', $post->post_date );
			$month = mysql2date( 'n', $post->post_date );

			if ( $year !== $previous_year || $month !== $previous_month ) {
				if ( true === $ul_open ) {
?>
		</ul>
<?php
				}
?>
		<h3 class="pagetitle"><?php the_time( 'F Y' ); ?></h3>
		<ul class="fullarchive">
<?php
				$ul_open = true;
			}

			$previous_year = $year;
			$previous_month = $month;
?>
			<li><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></li>
<?php
		}
	}
?>
		</ul>
		<section class="clearfloat pagination">
			<div class="left"><?php next_posts_link( esc_html__( '&laquo; Older Posts', 'mimbopro' ), $archive_query->max_num_pages ); ?></div>
			<div class="right"><?php previous_posts_link( esc_html__( 'Newer Posts &raquo;', 'mimbopro' ), $archive_query->max_num_pages ); ?></div>
		</section>
<?php
	remove_filter( 'post_limits', 'mimbo_post_limit' );
?>
	</section>
</section><!--END FLOATS-->
<?php
	get_footer();
