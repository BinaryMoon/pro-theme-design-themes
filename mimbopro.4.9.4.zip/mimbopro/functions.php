<?php
/**
 * Reusable theme functions
 *
 * @package MimboPro
 */

// Basic theme properties.
define( 'BM_THEMENAME', 'Mimbo Pro' );

// Path based settings.
define( 'BM_BLOGPATH', get_template_directory_uri() );
define( 'BM_LIB', get_template_directory() . '/scripts/' );
define( 'BM_SITEURL', get_option( 'siteurl' ) );
define( 'BM_EDIT_OPTIONS', 'edit_theme_options' );
define( 'BM_EDITTHEME', 'edit_theme_options' );

require BM_LIB . 'bm_widgets.php';
require BM_LIB . 'csscolor.php';
require BM_LIB . 'bm_widgetClasses.php';
require BM_LIB . 'theme_functions.php';
require BM_LIB . 'admin_functions.php';

register_nav_menus(
	array(
		'main-menu' => esc_html__( 'Main Menu - below the header', 'mimbopro' ),
		'secondary-menu' => esc_html__( 'Secondary Menu - above the header', 'mimbopro' ),
	)
);

load_theme_textdomain( 'mimbopro', get_template_directory() . '/languages' );


/**
 * Set content width for galleries and images.
 */
if ( ! isset( $content_width ) ) {
	$content_width = 610;
}


/**
 * Set content width
 *
 * @global type $content_width
 */
function mimbo_set_content_width() {

	global $content_width;

	if ( ( is_singular() && 'fullwidth' === bm_content_class( false ) ) || is_page_template( 'template-full-width.php' ) ) {
		$content_width = 900;
	}

}

add_action( 'template_redirect', 'mimbo_set_content_width' );


/**
 * Add a theme page for theme options
 *
 * @global type $bmTheme
 */
function mimbo_addThemePage() {

	$hook = add_theme_page( esc_html__( 'Theme Options', 'mimbopro' ), esc_html__( 'Theme Options', 'mimbopro' ), BM_EDIT_OPTIONS, basename( __FILE__ ), 'bm_themePage' );
	add_action( 'admin_enqueue_scripts', 'bm_admin_scripts' );
	add_action( 'admin_footer-' . $hook, 'bm_adminCss' );

}

add_action( 'admin_menu', 'mimbo_addThemePage' );


/**
 * Enqueue admin scripts
 *
 * @param  string $hook_suffix The name of the hook being called.
 */
function bm_admin_scripts( $hook_suffix ) {

	if ( 'appearance_page_functions' !== $hook_suffix ) {
		return;
	}

	wp_enqueue_script( 'jquery' );
	wp_enqueue_script( 'jquery-ui-sortable' );
	wp_enqueue_script( 'mimbo-jquery-ui-touch-punch', get_template_directory_uri() . '/js/jquery.ui.touch.punch.js', array( 'jquery', 'jquery-ui-sortable' ), '0.2.2' );

}


/**
 * Initialize theme options admin page.
 */
function bm_admin_init() {

	if ( isset( $_GET['page'] ) && basename( __FILE__ ) === $_GET['page'] ) {

		// Save settings.
		if ( current_user_can( BM_EDIT_OPTIONS ) && isset( $_REQUEST['action'] ) && 'save' === $_REQUEST['action'] ) {

			if ( check_admin_referer( 'mimbo-theme-settings' ) ) {

				$mim_carousel = array();
				if ( isset( $_REQUEST['mim_carousel'] ) ) {
					$mim_carousel = $_REQUEST['mim_carousel'];
				}

				$mim_homeCat = array();
				if ( ! empty( $_REQUEST['mim_homeCat'] ) && strlen( $_REQUEST['mim_homeCat'] ) > 0 ) {
					foreach ( explode( ',', $_REQUEST['mim_homeCat'] ) as $c ) {
						$mim_homeCat[] = (int) $c;
					}
				}

				update_option( 'mim_homeCat', $mim_homeCat );
				update_option( 'mim_carouselSpeed', (int) $_REQUEST['mim_carouselSpeed'] );
				update_option( 'mim_carousel', $mim_carousel );
				update_option( 'mim_feature', (int) $_REQUEST['mim_feature'] );

				// Goto theme edit page.
				header( 'Location: themes.php?page=functions.php&saved=true' );
				die();

			}
		}
	}

}

add_action( 'admin_init', 'bm_admin_init' );


/**
 *
 */
function mimbo_singlePostWidgets( $sidebar = 'sidebar-5' ) {

	if ( is_singular() ) {

		if ( is_active_sidebar( $sidebar ) ) {
?>
	<div id="widget-single-right">
		<?php dynamic_sidebar( $sidebar ); ?>
	</div>
<?php
		}

		wp_reset_postdata();

	}

}


/**
 *
 * @global type $bmTheme
 */
function bm_themePage() {

	global $bmTheme;

	include( 'scripts/bm_helpers.php' );

	if ( isset( $_REQUEST['saved'] ) ) {
		echo '<div id="message" class="updated fade"><p><strong>' . esc_html__( 'Settings saved', 'mimbopro' ) . '</strong></p></div>';
	}
	if ( isset( $_REQUEST['reset'] ) ) {
		echo '<div id="message" class="updated fade"><p><strong>' . esc_html__( 'Settings reset', 'mimbopro' ) . '</strong></p></div>';
	}

?>
<div class="wrap">
	<div class="icon32" id="icon-options-general"><br /></div>
	<h2><?php esc_html_e( 'Theme Options', 'mimbopro' ); ?></h2>

	<form method="post">
		<table class="form-table">
<?php
	wp_nonce_field( 'mimbo-theme-settings' );

	$bm_cat = array();
	$bm_categories = get_categories( 'hide_empty=1' );
	foreach ( $bm_categories as $b ) {
		$bm_cat[$b->term_id] = array( $b->term_id, $b->cat_name );
	}

	$bm_speed = array();
	for( $i = 0; $i <= 15; $i ++ ) {
		$bm_speed[] = array( $i, $i );
	}

	$lead_category = array();
	$lead_category[0] = array(0, esc_html__( 'All categories (default)', 'mimbopro' ) );
	$lead_category += $bm_cat;

	bm_th( esc_html__( 'Lead/ Featured Category', 'mimbopro' ) );
	bm_select( 'mim_feature', $lead_category, get_option( 'mim_feature' ), '' );
	bm_cth( esc_html__( 'Category to use for the featured post at the top of the homepage.', 'mimbopro' ) );

	bm_th( esc_html__( 'Carousel Categories', 'mimbopro' ) );
	bm_multiCheckbox( 'mim_carousel[]', $bm_cat, get_option( 'mim_carousel' ), esc_html__( 'In order for the categories to display, and be selected, blog posts must first be assigned to them.', 'mimbopro' ) );
	bm_cth( esc_html__( 'Categories to use in the scrolling carousel.', 'mimbopro' ) );

	bm_th( esc_html__( 'Carousel Scroll Speed', 'mimbopro' ) );
	bm_select( 'mim_carouselSpeed', $bm_speed, get_option( 'mim_carouselSpeed' ), '' );
	bm_cth( esc_html__( 'Use 0 for no auto scrolling, any other integer will be the number of seconds to pause.', 'mimbopro' ) );

	bm_th( esc_html__( 'Category Summaries', 'mimbopro' ) );
	bm_sortable( 'mim_homeCat', $bm_cat, get_option( 'mim_homeCat' ), esc_html__( 'Categories to list on the homepage in the center column.', 'mimbopro' ) );
	bm_cth();
?>
		</table>
		<input type="hidden" name="action" value="save" />
		<p class="submit">
<?php
	bm_input( esc_html__( 'save', 'mimbopro' ), 'submit', '', esc_html__( 'Save Settings', 'mimbopro' ) );
?>
		</p>
	</form>
</div>
<?php
}


/**
 *
 */
function bm_adminCss() {
?>
<style type="text/css">
	.category-list {
		float:left;
		width:300px;
	}

	.category-list em {
		color:#ccc;
	}

	.bm_fieldset {
		margin-top:20px;
		border:1px solid #e1e1e1;
		-moz-border-radius-topleft:6px;
		-moz-border-radius-topright:6px;
		background:#f1f1f1;
	}
	.bm_fieldset p {
		padding:15px 10px;
		font-size:13px;
		margin:0;
		clear:both;
		font-family:Georgia,"Times New Roman","Bitstream Charter",Times,serif;
		color:#333;
	}
	.bm_fieldset .form-table {
		border-top:1px solid #e1e1e1;
		margin:0;
	}
	.bm_fieldset .form-table tr {
		background:#fff;
		border-bottom:1px solid #f1f1f1;
	}
	.bm_fieldset .form-table td, .bm_fieldset .form-table th {
		border-bottom-width:2px;
		padding:15px 10px;
		font-size:11px;
	}
	.bm_fieldset .form-table p {
		background:transparent;
		padding:0;
	}
	.bm_fieldset .imageSelect {
		padding:10px;
		background:#fff;
		border:1px solid #C6D9E9;
		width:100px;
		float:left;
		margin:0 10px 0 0;
	}
	.bm_fieldset .imageSelect:hover {
		border:1px solid #bcd;
	}

	.bm_fieldset .bm_tdsmall {
		width:250px;
	}
	.connectedSortContainer {
		float:left;
		width:252px;
	}
	.connectedSortContainer ul {
		min-height:40px;
		background:#f5f5f5;
		padding:10px;
		width:212px;
	}
	.connectedSortContainer li {
		width:200px;
		border:1px solid #f1f1f1;
		padding:5px;
		background:#fff;
	}
	.connectedSortContainer li:hover {
		cursor:move;
	}
	.connectedSortContainer li.bm_highlight {
		width:200px;
		border:1px solid #f1f1f1;
		padding:5px;
		height:20px;
		background:#f1f1f1;
	}
</style>

<script>

jQuery(document).ready(function(){
	jQuery( '.multicheck_all' ).click(function(){
		$this = jQuery(this);
		$this.parent().find( 'input' ).each(function(){
			jQuery(this).attr( 'checked', 'checked' );
		});
		return false;
	});
	jQuery( '.multicheck_none' ).click(function(){
		$this = jQuery(this);
		$this.parent().find( 'input' ).each(function(){
			jQuery(this).attr( 'checked', false);
		});
		return false;
	});
	jQuery( '.connectedSort' ).sortable({
		connectWith: '.connectedSort',
		placeholder: 'bm_highlight',
		update: function(event, ui) {
			var list_order = [];
			jQuery('#sortable_active li').each(function() {
				list_order.push(jQuery(this).attr( 'cat' ));
			});
			jQuery( '#sortable_val' ).val(list_order.join( ',' ));
		}
	});
});

</script>
<?php
}


/**
 * Init scripts and styles
 */
function bm_setup_scripts () {

	// Javascript.
	wp_enqueue_script( 'mimbopro-script-bm_superfish', BM_BLOGPATH . '/js/superfish.js', array( 'jquery' ), '1.5.5' );
	wp_enqueue_script( 'mimbopro-script-responsiveNavigation', BM_BLOGPATH . '/js/responsiveNavigation.js', array( 'jquery' ) );

	wp_localize_script(
		'mimbopro-script-responsiveNavigation',
		'js_i18n',
		array(
			'menu' => esc_html__( 'Menu', 'mimbopro' ),
		)
	);

	// Stylesheets.
	wp_enqueue_style( 'mimbopro-style', get_stylesheet_directory_uri() . '/style.css', null, '1.2', 'all' );

	if ( is_home() ) {
		wp_enqueue_style( 'mimbopro-style-home', get_template_directory_uri() . '/css/home.css', null, '1.0', 'all' );
	}

	wp_enqueue_style( 'mimbopro-style-nav', get_template_directory_uri() . '/css/nav.css', null, '1.0', 'all' );
	wp_enqueue_style( 'mimbopro-style-responsive', get_template_directory_uri() . '/css/responsive.css', null, '1.0', 'all' );
	wp_enqueue_style( 'mimbopro-style-print', get_template_directory_uri() . '/css/print.css', null, '1.0', 'print' );

	/***
	 * Translators: If there are characters in your language that are not
	 * supported by Bitter, translate this to 'off'. Do not translate into your
	 * own language.
	 */
	$font = _x( 'on', 'Google font: on or off', 'mimbopro' );

	if ( 'off' !== $font ) {
		wp_enqueue_style( 'mimbopro-style-font-bitter', 'https://fonts.googleapis.com/css?family=Bitter:400', null, '1.0', 'all' );
	}

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	if ( is_home() ) {
		wp_enqueue_script( 'carousel', BM_BLOGPATH . '/js/carousel.js', array( 'jquery' ), '1.0.01' );
	}

}

add_action( 'wp_enqueue_scripts', 'bm_setup_scripts' );


/**
 * Callback functions for comment output
 * @param type $comment
 * @param type $args
 * @param type $depth
 */
function mytheme_comment( $comment, $args, $depth ) {

	$GLOBALS['comment'] = $comment;
?>
	<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
		<div id="comment-<?php comment_ID(); ?>">
			<div class="comment-author vcard clearfloat">
				<?php echo get_avatar( $comment, 42 ); ?>
				<div class="commentmetadata">
					<?php printf( '<cite class="fn">%s</cite>', get_comment_author_link() ); ?>
					<div class="comment-date">
						<a href="<?php echo htmlspecialchars( get_comment_link( $comment->comment_ID ) ); ?>">
							<?php printf( esc_html__( '%1$s &bull; %2$s', 'mimbopro' ), get_comment_date(), get_comment_time() ); ?>
						</a>
						<?php edit_comment_link( esc_html__( 'Edit', 'mimbopro' ) ); ?>
					</div>
				</div>
			</div>
<?php
	if ( '0' == $comment->comment_approved ) {
?>
			<p class="comment-mod"><em><?php esc_html_e( 'Your comment is awaiting moderation.', 'mimbopro' ); ?></em></p>
<?php
	}

	comment_text();
?>
			<div class="reply">
<?php
	comment_reply_link(
		array_merge(
			$args,
			array(
				'depth' => $depth,
				'reply_text' => esc_html__( 'Reply &darr;', 'mimbopro' ),
				'login_text' => esc_html__( 'Log in to reply', 'mimbopro' ),
				'max_depth' => $args['max_depth'],
			)
		)
	);
?>
			</div>
		</div>
<?php
}


/**
 * Add a microid to all the comments
 *
 * @param string $classes
 * @return string
 */
function mimbo_comment_add_microid( $classes ) {

	$c_email = get_comment_author_email();
	$c_url = get_comment_author_url();

	if ( ! empty( $c_email ) && ! empty( $c_url ) ) {
		$microid = 'microid-mailto+http:sha1:' . sha1( sha1( 'mailto:' . $c_email ) . sha1( $c_url ) );
		$classes[] = $microid;
	}

	return $classes;

}

add_filter( 'comment_class', 'mimbo_comment_add_microid' );


/**
 * Replace the excerpt 'more' link with something custom
 *
 * @param type $content
 * @return type
 */
function replace_excerpt( $content ) {

	return str_replace(
		'[...]',
		'<a class="ellipses" href="' . esc_url( get_permalink() ) . '">...</a>',
		$content
	);

}


/**
 * Custom pagination links for custom page templates (outside standard WordPress next and previous link functions)
 *
 * @global int $paged
 * @global type $myOffset
 * @global type $postsperpage
 * @param string $limit
 * @return string
 */
function mimbo_post_limit( $limit ) {

	global $paged, $myOffset, $postsperpage;

	if ( empty( $paged ) ) {
		$paged = 1;
	}

	$pgstrt = ( ( ( intval( $paged ) - 1 ) * $postsperpage ) + $myOffset ) . ', ';
	$limit = 'LIMIT ' . $pgstrt . $postsperpage;

	return $limit;

}


/**
 * Set the length of custom excerpts
 *
 * @param type $length
 * @return type
 */
function mimbo_excerpt_length( $length ) {

	return 55;

}

add_filter( 'excerpt_length', 'mimbo_excerpt_length' );


/**
 * Register Sidebars
 */
function mimbo_widgets_init() {

	// Sidebars.
	register_sidebar(
		array(
			'name' => esc_html__( 'Sidebar Left', 'mimbopro' ),
			'id' => 'sidebar-1',
			'description' => '',
			'before_widget' => '<section id="%1$s" class="widget %2$s clearfloat"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h3 class="widgettitle">',
			'after_title' => '</h3>',
		)
	);

	register_sidebar(
		array(
			'name' => esc_html__( 'Sidebar Right', 'mimbopro' ),
			'id' => 'sidebar-2',
			'description' => esc_html__( 'Homepage Right Sidebar', 'mimbopro' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s clearfloat">',
			'after_widget' => '</div>',
			'before_title' => '<h3 class="widgettitle">',
			'after_title' => '</h3>',
		)
	);

	register_sidebar(
		array(
			'name' => esc_html__( 'Bottom Widgets', 'mimbopro' ),
			'id' => 'sidebar-3',
			'description' => esc_html__( 'Footer Widgets', 'mimbopro' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s clearfloat">',
			'after_widget' => '</div>',
			'before_title' => '<h3 class="widgettitle">',
			'after_title' => '</h3>',
		)
	);

	register_sidebar(
		array(
			'name' => esc_html__( 'Sidebar Single Post Left', 'mimbopro' ),
			'id' => 'sidebar-4',
			'description' => esc_html__( 'Left Sidebar displayed on single post pages. If empty will use Sidebar Left.', 'mimbopro' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s" clearfloat"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h3 class="widgettitle">',
			'after_title' => '</h3>',
		)
	);

	register_sidebar(
		array(
			'name' => esc_html__( 'Sidebar Single Post Right', 'mimbopro' ),
			'id' => 'sidebar-5',
			'description' => esc_html__( 'Optional sidebar, displayed within the post content. Leave it empty to hide.', 'mimbopro' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s clearfloat">',
			'after_widget' => '</div>',
			'before_title' => '<h3 class="widgettitle">',
			'after_title' => '</h3>',
		)
	);

	register_sidebar(
		array(
			'name' => esc_html__( 'Sidebar Single Page Right', 'mimbopro' ),
			'id' => 'sidebar-6',
			'description' => esc_html__( 'Optional sidebar, displayed on pages (not blog posts) within the post content. Leave it empty to hide.', 'mimbopro' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s clearfloat">',
			'after_widget' => '</div>',
			'before_title' => '<h3 class="widgettitle">',
			'after_title' => '</h3>',
		)
	);
}

add_action( 'widgets_init', 'mimbo_widgets_init' );


/**
 * Add 'theme support' for theme functionality and setup theme properties.
 */
function bm_after_setup_theme() {

	add_theme_support( 'menus' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'post-thumbnails', array( 'post' ) );
	add_theme_support( 'title-tag' );

	// Support for post thumbnails.
	add_image_size( 'archive-small', 110, 110, true );
	add_image_size( 'homepage-featured', 500, 450, true );
	add_image_size( 'homepage-carousel', 165, 82, true );
	add_image_size( 'image-gallery', 105, 80, true );
	add_image_size( 'category-master', 150, 175, true );

	// Default thumbnail size.
	set_post_thumbnail_size( 70, 70, true );

	// Custom header.
	$args = array(
		'default-image' => apply_filters( 'mimbo_header_image', '%s/images/bg_masthead.jpg' ),
		'default-text-color' => apply_filters( 'mimbo_header_textcolor', 'ffffff' ),
		'width' => 960,
		'height' => 108,
		'admin-head-callback' => 'mimbo_admin_header',
		'wp-head-callback' => 'mimbo_header_style',
	);

	add_theme_support( 'custom-header', $args );

	register_default_headers(
		array(
			'no_bird' => array(
				'url' => '%s/images/headers/no_bird.jpg',
				'thumbnail_url' => '%s/images/headers/no_bird.thumbnail.jpg',
				'description' => esc_html__( 'Abstract 1', 'mimbopro' ),
			),
			'abstract_1' => array(
				'url' => '%s/images/headers/abstract_1.jpg',
				'thumbnail_url' => '%s/images/headers/abstract_1.thumbnail.jpg',
				'description' => esc_html__( 'Abstract 1', 'mimbopro' ),
			),
			'abstract_2' => array(
				'url' => '%s/images/headers/abstract_2.jpg',
				'thumbnail_url' => '%s/images/headers/abstract_2.thumbnail.jpg',
				'description' => esc_html__( 'Abstract 2', 'mimbopro' ),
			),
			'lightrays_1' => array(
				'url' => '%s/images/headers/lightrays_1.jpg',
				'thumbnail_url' => '%s/images/headers/lightrays_1.thumbnail.jpg',
				'description' => esc_html__( 'Light Rays 1', 'mimbopro' ),
			),
			'lightrays_2' => array(
				'url' => '%s/images/headers/lightrays_2.jpg',
				'thumbnail_url' => '%s/images/headers/lightrays_2.thumbnail.jpg',
				'description' => esc_html__( 'Light Rays 2', 'mimbopro' ),
			),
			'bubbles' => array(
				'url' => '%s/images/headers/bubbles.jpg',
				'thumbnail_url' => '%s/images/headers/bubbles.thumbnail.jpg',
				'description' => esc_html__( 'Bubbles', 'mimbopro' ),
			),
			'planet' => array(
				'url' => '%s/images/headers/planet.jpg',
				'thumbnail_url' => '%s/images/headers/planet.thumbnail.jpg',
				'description' => esc_html__( 'Planet', 'mimbopro' ),
			),
			'stars' => array(
				'url' => '%s/images/headers/stars.jpg',
				'thumbnail_url' => '%s/images/headers/stars.thumbnail.jpg',
				'description' => esc_html__( 'Stars', 'mimbopro' ),
			),
		)
	);

	// Custom background.
	$args = array(
		'default-color' => '143347',
		'default-image' => apply_filters( 'mimbo_background_image', get_template_directory_uri() . '/images/bg_body.png' ),
	);

	// Custom Logo.
	add_theme_support(
		'custom-logo',
		apply_filters(
			'mimbopro_custom_logo_args',
			array(
				'height' => 500,
				'width' => 1000,
				'flex-height' => true,
				'flex-width' => true,
			)
		)
	);

	add_theme_support( 'custom-background', apply_filters( 'mimbo_custom_background', $args ) );

}

add_action( 'after_setup_theme', 'bm_after_setup_theme' );


/**
 *
 */
function mimbo_admin_header() {
?>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400" type="text/css" media="all" />
<style type="text/css">
#headimg h1 {
	text-align:center;
	margin-top:34px;
	font-size:28px;
	line-height:28px;
	margin-bottom:0;
	text-decoration:none;
	border:none;
	font-family: 'Bitter',Georgia,serif;
	font-weight:normal;
	text-shadow:0 -1px 0 #000;
}
#headimg h1 a {
	text-decoration:none;
}
#headimg #desc {
	text-align:center;
	filter: alpha(opacity=70);
	-ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=70)";
	opacity:0.7;
	font-family: 'Bitter',Georgia,serif;
	font-size:10px;
	margin:2px 30px 0 30px;
	letter-spacing:1px;
	text-transform:uppercase;
}
</style>
<?php
}


/**
 *
 */
function mimbo_header_style() {

?>
<style type="text/css">
<?php
	if ( get_header_image() ) {
?>
#masthead {
	background-image: url( <?php header_image(); ?> );
}
<?php
	}
?>
#masthead #logo, #masthead #logo a, #masthead #description {
<?php
	if ( 'blank' === get_header_textcolor() ) {
		echo 'text-indent:-9999em;';
	} else {
		echo 'color:#' . esc_attr( get_header_textcolor() ) . ';';
	}
?>
}
</style>
<?php
}


/**
 *
 * @param type $title
 * @return type
 */
function bm_empty_title( $title ) {

	if ( in_the_loop() && empty( $title ) && ! is_singular() ) {
		$title = esc_html__( '[read post]', 'mimbopro' );
	}
	return $title;

}

add_filter( 'the_title', 'bm_empty_title' );



global $themecolors;

$themecolors = array(
	'bg' => 'ffffff',
	'border' => 'eeeeee',
	'text' => '1B1B1B',
	'link' => '3399CC',
	'url' => '59BCED',
);


/**
 * fill empty post thumbnails with images from the first attachment added to a post
 *
 * @param type $html
 * @param type $post_id
 * @param type $thumbnail_id
 * @param type $size
 * @return type
 */
function bm_post_thumbnail_html( $html, $post_id, $thumbnail_id, $size = '' ) {

	if ( empty( $html ) ) {

		$values = get_attached_media( 'image', $post_id );

		if ( $values ) {
			foreach ( $values as $childId => $attachment ) {
				$html = wp_get_attachment_image( $childId, $size );
				break;
			}
		}
	}

	return $html;

}

add_filter( 'post_thumbnail_html', 'bm_post_thumbnail_html', 10, 4 );


/**
 *
 * @return string
 */
function bm_get_sidebar() {

	$sidebar_name = '';

	// Sidebar Left.
	if ( is_active_sidebar( 'sidebar-1' ) ) {
		$sidebar_name = 'sidebar-1';
	}

	// Sidebar Single Post Left.
	if ( is_single() && is_active_sidebar( 'sidebar-4' ) ) {
		$sidebar_name = 'sidebar-4';
	}

	return $sidebar_name;

}


/**
 *
 * @param type $wp_customize
 */
function bm_customize_register( $wp_customize ) {

	$colors = array();
	$colors[] = array(
		'slug' => 'content_bg_color',
		'default' => '#3399cc',
		'label' => esc_html__( 'Primary Color', 'mimbopro' ),
	);
	$colors[] = array(
		'slug' => 'content_link_color',
		'default' => '#9CD6F3',
		'label' => esc_html__( 'Link Color', 'mimbopro' ),
	);

	foreach ( $colors as $color ) {

		$wp_customize->add_setting(
			$color['slug'],
			array(
				'default' => $color['default'],
				'type' => 'option',
				'capability' => BM_EDITTHEME,
				'sanitize_callback' => 'sanitize_hex_color',
			)
		);

		$wp_customize->add_control(
			new WP_Customize_Color_Control(
				$wp_customize,
				$color['slug'],
				array(
					'label' => $color['label'],
					'section' => 'colors',
					'settings' => $color['slug'],
				)
			)
		);
	}

}

add_action( 'customize_register', 'bm_customize_register' );


/**
 *
 */
function bm_custom_styles() {

	$featured = new CSS_Color( get_option( 'content_bg_color', '#3399cc' ) );
	$featured_link = new CSS_Color( get_option( 'content_bg_color', '#3399cc' ), get_option( 'content_link_color', '#9CD6F3' ) );
	$page_link = new CSS_Color( '#ffffff', get_option( 'content_link_color', '#9CD6F3' ) );

?>
<style>
	a, a:visited { color:#<?php echo esc_attr( $page_link->fg['0'] ); ?>; }
	a:hover { color:#<?php echo esc_attr( $page_link->fg['-1'] ); ?>; }
	#navbar {
		<?php echo bm_css_gradient( $featured->bg['-1'], $featured->bg['-2'] ); ?>
		border-top-color:#<?php echo esc_attr( $featured->bg['0'] ); ?>;
		border-bottom-color:#<?php echo esc_attr( $featured->bg['-3'] ); ?>;
	}
	#navbar #s {
		background:#<?php echo esc_attr( $featured->bg['0'] ); ?>;
		border-color:#<?php echo esc_attr( $featured->bg['-2'] ); ?>;
	}
	#navbar #s:focus { background:#fff; }
	#nav .current-cat a, #nav .current-cat a:visited, #nav .current_page_item a, #nav .current_page_item a:visited {
		background-color:#<?php echo esc_attr( $featured->bg['-3'] ); ?>;
		color:#<?php echo esc_attr( $featured->fg['-3'] ); ?>;
	}
	#nav li:hover, #nav a:focus, #nav a:hover, #nav a:active, #nav .current-cat .children a:hover,#nav .current-cat .children, #nav li li {
		background:#<?php echo esc_attr( $featured->bg['0'] ); ?>;
		color:#<?php echo esc_attr( $featured->fg['0'] ); ?>;
	}
	#nav a, #nav a:visited { color:#<?php echo esc_attr( $featured->fg['-2'] ); ?> ; }
	#upper {
		background-color: #<?php echo esc_attr( $featured->bg['0'] ); ?>;
		color:#<?php echo esc_attr( $featured->fg['0'] ); ?>;
		border-color: #<?php echo esc_attr( $featured->bg['-1'] ); ?>;
	}
	#upper a, #upper a:visited { color: #<?php echo esc_attr( $featured_link->fg['0'] ); ?>; }
	#upper a:hover { color: #<?php echo esc_attr( $featured_link->fg['-1'] ); ?>; }
	#lead {
		background-color: #<?php echo esc_attr( $featured->bg['-1'] ); ?>;
		color:#<?php echo esc_attr( $featured->fg['-1'] ); ?>;
	}
	#lead img { border-color: #<?php echo esc_attr( $featured->bg['-2'] ); ?>; }
	#lead img:hover { border-color: #<?php echo esc_attr( $featured->bg['-3'] ); ?>; }
	#lead a, #lead a:visited { color: #<?php echo esc_attr( $featured_link->fg['-1'] ); ?>; }
	#lead a:hover { color: #<?php echo esc_attr( $featured_link->fg['-2'] ); ?>; }
	#lead .date { color: #<?php echo esc_attr( $featured_link->fg['-2'] ); ?>; }
	#recent h3 { color:#<?php echo esc_attr( $featured->fg['+1'] ); ?>; }
	#recent li { border-color:#<?php echo esc_attr( $featured_link->bg['+2'] ); ?>; }
	.whitebox h3.catcolor1, .whitebox h3.catcolor2, .whitebox h3.catcolor3 {
		<?php echo bm_css_gradient( $featured->bg['-3'], $featured->bg['-2'] ); ?>
		color:#<?php echo esc_attr( $featured->fg['-2'] ); ?>;
		border-bottom-color:#<?php echo esc_attr( $featured->bg['-4'] ); ?>;
	}
	#breadcrumbs {
		background-color: #<?php echo esc_attr( $featured->bg['-3'] ); ?>;
		color:#<?php echo esc_attr( $featured->fg['-3'] ); ?>;
		border-color:#<?php echo esc_attr( $featured->bg['-4'] ); ?>;
	}
	#breadcrumbs a, #breadcrumbs a:visited { color:#<?php echo esc_attr( $featured_link->fg['-3'] ); ?>; }
	.subfeature {
		background-color: #<?php echo esc_attr( $featured->bg['+5'] ); ?>;
		color:#<?php echo esc_attr( $featured->fg['+5'] ); ?>;
		border-bottom-color:#<?php echo esc_attr( $featured->bg['+4'] ); ?>;
	}
	.subfeature a, .subfeature a:visited { color:#<?php echo esc_attr( $featured_link->fg['+5'] ); ?>; }
	#meta {
		background-color:#<?php echo esc_attr( $featured->bg['-3'] ); ?>;
		color:#<?php echo esc_attr( $featured->fg['-3'] ); ?>;
	}
	#meta a, #meta a:visited { color:#<?php echo esc_attr( $featured_link->fg['-3'] ); ?>; }
	#meta h3 { border-color:#<?php echo esc_attr( $featured->bg['0'] ); ?>; }
	#nav-secondary, footer {
		<?php echo bm_css_gradient( $featured->bg['-4'], $featured->bg['-5'] ); ?>
		color:#<?php echo esc_attr( $featured->fg['-4'] ); ?>;
	}
	#nav-secondary a, #nav-secondary a:visited, footer a, footer a:visited { color:#<?php echo esc_attr( $featured_link->fg['-4'] ); ?>; }
	#nav-secondary a:hover, footer a:hover { color:#<?php echo esc_attr( $featured_link->fg['-5'] ); ?>; }
	#nav-secondary li li { background:#<?php echo esc_attr( $featured_link->bg['-4'] ); ?>; }
	#s,
	select {
		background: #<?php echo esc_attr( $featured->bg['+5'] ); ?>;
		border-color: #<?php echo esc_attr( $featured->bg['+2'] ); ?>;
		color: #<?php echo esc_attr( $featured->fg['+5'] ); ?>;
	}
	#nav-secondary a.sf-with-ul:after, #nav a.sf-with-ul:after {
		border-top-color: #<?php echo esc_attr( $featured->bg['+3'] ); ?>;
	}
</style>
<?php

}

add_action( 'wp_head', 'bm_custom_styles', 9 ); // changed priority so that it fires before the custom wp.com colours


/**
 * Generate a css gradient.
 *
 * @param type $from
 * @param type $to
 */
function bm_css_gradient( $from, $to ) {

	$style = '';

	$style .= 'background: #' . esc_attr( $to ) . ';';
	$style .= 'background: linear-gradient(to bottom, #' . esc_attr( $from ) . ' 0%, #' . esc_attr( $to ) . ' 100%);';

	return $style;

}


/**
 *
 */
function bm_content_class( $echo = true ) {

	$sidebar_name = bm_get_sidebar();
	$content_class = '';

	if ( '' === $sidebar_name ) {
		$content_class = 'fullwidth';
	}

	if ( $echo ) {
		echo $content_class;
	} else {
		return $content_class;
	}

}


/**
 * Customise excerpt
 *
 * @param type $content
 * @return type
 */
function bm_replace_excerpt( $content ) {

	$link = wp_kses(
		/* Translators: %s = url to blog post. */
		__( '... <a href="%s" class="read-more">Read More &rsaquo;</a>', 'mimbopro' ),
		array( 'a' => array( 'href' => array(), 'class' => array() ) )
	);

	return sprintf( $link, esc_url( get_permalink() ) );

}

add_filter( 'excerpt_more', 'bm_replace_excerpt' );
add_filter( 'the_excerpt', 'replace_excerpt' );



remove_filter( 'wp_head', 'wp_widget_recent_comments_style' );
