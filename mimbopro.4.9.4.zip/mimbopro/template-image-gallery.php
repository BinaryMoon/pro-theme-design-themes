<?php
/**
 * Custom Image Gallery Page Template
 * Template Name: Image Gallery
 *
 * @package MimboPro
 */

	get_header();
?>
<section class="clearfloat stripes">
<?php
	get_sidebar();
?>
	<section id="content" class="<?php bm_content_class(); ?>">
<?php
	if ( have_posts() ) {
		while ( have_posts() ) {
			the_post();
?>
		<h1 id="pagetitle"><?php the_title(); ?></h1>
<?php
			the_content();
		}
	}

	// Gets the last 16 images and paginates them.
	$page = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;

	$query = array(
		'posts_per_page' => 50,
		'post_mime_type' => 'image',
		'post_type' => 'attachment',
		'post_status' => 'inherit',
		'paged' => $page,
	);
	$query_object = new WP_Query( $query );

	if ( $query_object->have_posts() ) {
?>
		<section class="clearfloat" id="image-gallery">
<?php
		while ( $query_object->have_posts() ) {
			$query_object->the_post();
			$image = wp_get_attachment_image( get_the_ID(), 'image-gallery' );
?>
			<div class="image-gallery-item">
				<a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php echo $image; ?></a>
			</div>
<?php
		}
?>
		</section>
		<section class="clearfloat pagination">
			<div class="left"><?php next_posts_link( esc_html__( '&laquo; Older', 'mimbopro' ) ); ?></div>
			<div class="right"><?php previous_posts_link( esc_html__( 'Newer &raquo;', 'mimbopro' ) ); ?></div>
		</section>
<?php
	}
?>
	</section>
</section>
<?php
	get_footer();
