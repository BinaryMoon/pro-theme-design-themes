<?php
/**
 * Header Template
 *
 * @package MimboPro
 */

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<?php bm_head(); ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<?php
	wp_head();
	bm_scripts();
?>
	<!--[if lt IE 9]><script src="<?php echo get_template_directory_uri(); ?>/js/html5.js" type="text/javascript"></script><![endif]-->
</head>
<body <?php body_class(); ?> <?php echo bm_body_id(); ?>>
<?php
	wp_body_open();
	do_action( 'bm_head' );
?>
	<section id="page">
<?php
	bm_secondary_navigation();
?>
		<header id="masthead">
<?php
	the_custom_logo();

	if ( is_home() && ! is_paged() ) {
?>
			<div id="logo"><?php bloginfo( 'name' ); ?></div>
			<h1 id="description"><?php bloginfo( 'description' ); ?></h1>
<?php
	} else {
?>
			<div id="logo">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php esc_attr_e( 'Home', 'mimbopro' ); ?>"><?php bloginfo( 'name' ); ?></a>
			</div>
			<div id="description"><?php bloginfo( 'description' ); ?></div>
<?php
	}

	do_action( 'mimbopro-header' );
?>
		</header>
		<nav id="navbar" class="clearfloat">
<?php
	bm_navigation();
	bm_searchform();
?>
		</nav>
<?php
	if ( ! is_home() ) {
?>
		<section id="breadcrumbs"><?php bm_simpleBreadcrumbs(); ?></section>
<?php
	}
