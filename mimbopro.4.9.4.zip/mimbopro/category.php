<?php
/**
 * Category Template
 *
 * @package MimboPro
 */

	get_header();

	$bm_page = $wp_query->query_vars["paged"];
	if($bm_page == null) {
		$bm_page = 1;
	}
	$postcount = 0;
	$imageQuantity = 3;
?>
	<section class="clearfloat stripes">
<?php
	get_sidebar();
?>
		<section id="content" class="<?php bm_content_class(); ?>">
			<h1 id="pagetitle"><?php single_cat_title(); ?> <a href="<?php echo get_category_feed_link($wp_query->queried_object->term_id); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/rss.gif" alt="rss" /></a></h1>
<?php
	$description = category_description();
	if ( ! empty( $description ) ) {
		echo '<div class="category_description">' . $description . '</div>';
	}

	if (have_posts()) {
		global $post;
		while(have_posts()) {
			the_post();

			if($postcount == 0 && $bm_page == 1 ) {
				$image = get_the_post_thumbnail( $post->ID, 'category-master' );
?>
			<div id="lead" class="clearfloat">
<?php
				if($image != "") {
?>
				<div class="left">
					<a href="<?php the_permalink() ?>" rel="bookmark"><?php echo $image; ?></a>
				</div>
				<div class="right">
<?php
				}
?>
					<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
<?php
	if ( ! post_password_required() && ( comments_open() || '0' != get_comments_number() ) ) {
?>
					<span class="commentcount">(<?php comments_popup_link( '0', '1', '%', 'comments_link', '' ); ?>)</span>
<?php
	}
?>
					<div class="date"><?php the_date(); ?></div>
					<?php the_excerpt(); ?>
					<!--<a href="<?php the_permalink() ?>" rel="bookmark" id="fullstory"><?php _e('Full Story&raquo;','mimbopro'); ?></a>-->
<?php
				if($image != "") {
?>
				</div><!--END RIGHT-->
<?php
				}
?>
			</div><!--END LEAD-->
<?php
			} elseif ($postcount > 0 && $postcount <= $imageQuantity  && $bm_page == 1) {
				$image = get_the_post_thumbnail( $post->ID, 'archive-small' );
?>
			<div class="cat-excerpt clearfloat subfeature">
<?php
				if($image != "") {
?>
				<a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php echo $image; ?></a>
<?php
				}
?>
				<h4><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h4>
				<?php the_excerpt(); ?>
			</div>
<?php
			} else {
				$image = get_the_post_thumbnail( $post->ID, 'archive-small' );
?>
		<div class="cat-excerpt clearfloat" id="post-<?php the_ID(); ?>">
<?php
			if ($image != false) {
?>
			<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php echo $image; ?></a>
<?php
			}
?>
			<h4><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h4>
			<?php the_excerpt(); ?>
		</div>
<?php
			}

			$postcount ++;
		}

	}

	get_template_part('pagination');
?>
        </section>
	</section>
<?php
	get_footer();
