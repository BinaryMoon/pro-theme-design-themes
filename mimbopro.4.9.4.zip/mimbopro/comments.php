<?php
/**
 * Comments Template
 *
 * @package MimboPro
 */

	// Do not delete these lines.
	if ( ! empty( $_SERVER['SCRIPT_FILENAME'] ) && 'comments.php' == basename( $_SERVER['SCRIPT_FILENAME'] ) ) {
		die( esc_html__( 'Please do not load this page directly. Thanks!', 'mimbopro' ) );
	}

	if ( post_password_required() ) {
?>
	<p class="nocomments"><?php esc_html_e( 'This post is password protected. Enter the password to view comments.','mimbopro' ); ?></p>
<?php
		return;
	}

	// Show the comments.
	if (have_comments()) {
?>
	<h4 id="comments">
<?php
		comments_number( __( '0 Responses', 'mimbopro' ), __( '1 Response', 'mimbopro' ), __( '% Responses', 'mimbopro' ) );

		if (comments_open()) {
?>
		<a href="#respond" title="<?php esc_attr_e( 'Leave a comment', 'mimbopro' ); ?>">&raquo;</a>
<?php
		}
?>
	</h4>
	<ol class="commentlist" id="singlecomments">
		<?php wp_list_comments( 'type=comment&callback=mytheme_comment' ); ?>
	</ol>
	<section class="clearfloat" id="comment-pagination">
<?php
		previous_comments_link( esc_html__( '&lsaquo; Older Comments', 'mimbopro' ) );
		next_comments_link( esc_html__( 'Newer Comments &rsaquo;', 'mimbopro' ) );
?>
	</section>
<?php
		$runonce = false;

		// Begin Trackbacks.
		foreach ( $comments as $comment ) {
			if ( 'trackback' === $comment->comment_type || 'pingback' === $comment->comment_type ) {
				if ( ! $runonce ) {
					$runonce = true;
?>
	<h3 id="trackbacks"><?php esc_html_e( 'Trackbacks', 'mimbopro' ); ?></h3>
	<ol id="trackbacklist">
<?php
				}
?>
		<li id="comment-<?php comment_ID() ?>">
			<cite><?php comment_author_link() ?></cite>
		</li>
<?php
			}
		}

		if ( $runonce ) {
?>
	</ol>
<?php
		}
	}

	// If comments open show reply form.
	if ( 'open' === $post->comment_status ) {
		comment_form();
	}
