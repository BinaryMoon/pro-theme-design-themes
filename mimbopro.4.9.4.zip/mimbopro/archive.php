<?php
/**
 * Archive Template
 *
 * @package MimboPro
 */

	get_header();
?>
<div class="clearfloat stripes">

<?php
	get_sidebar();
?>
	<section id="content" class="<?php bm_content_class(); ?>">
<?php
	if ( have_posts() ) {
		the_archive_title( '<h1 id="pagetitle">', '</h1>' );

		while ( have_posts() ) {
			the_post();
			$image = get_the_post_thumbnail( get_the_ID(), 'archive-small' );
?>
		<div class="cat-excerpt clearfloat" id="post-<?php the_ID(); ?>">
<?php
			if ( $image ) {
?>
			<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php echo $image; ?></a>
<?php
			}
?>
			<h4><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h4>
			<?php the_excerpt(); ?>
		</div>
<?php
		}

		get_template_part( 'pagination' );

	} else {
?>
	<h3 class="center"><?php esc_html_e( 'Not Found', 'mimbopro' ); ?></h3>
<?php
	}
?>
	</section>
</div>
<?php
	get_footer();
