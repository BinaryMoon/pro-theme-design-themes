=== Mimbo Pro ===

Contributors: binarymoon
Requires at least: 4.1
Tested up to: 4.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: black, clean, contemporary, professional, dark, blue, magazine, elegant, modern, sophisticated, two-columns, left-sidebar, fixed-layout, custom-colors, custom-background, custom-header, custom-menu, full-width-template, rtl-language-support, theme-options, translation-ready

== Description ==

A classically designed magazine theme, with flexible widget sidebars, custom header and background images, and custom footer widgets.

[Theme documentation](https://prothemedesign.com/documentation/theme/mimbopro/)

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Mimbo Pro includes support for Styleguide - a plugin that allows you to change fonts, and colours in WordPress themes.

Mimbo Pro includes support for most features in Jetpack, including Infinite Scroll, Featured Content, and Site Logo.

== Changelog ==

= 4.9.4 - 4th January 2023 =
* Minor bump to fix compile error.

= 4.9.3 - 14th April 2021 =
* Fix widget sizes to prevent/ reduce content overflow.

= 4.9.2 - 17th March 2021 =
* Fix settings bug with PHP 8+.

= 4.9.1 - 30th October 2020 =
* Simplify category summaries code.
* Improve spacing in widgets with forms (archives and categories dropdowns).
* Tidy codes.

= 4.9 - 8th October 2020 =
* Make CSS more resilient.
* Add wp_body_open.
* Improve custom colours.

= 4.8.1 - 24th February 2019 =
* Add an action (mimbopro-header) in the header so that things like adverts can be inserted there.

= 4.8 - 30th December 2018 =
* Improve responsive navigation. It now works on both header menus, and it has a new 'menu' option that makes it easier to select the first menu item.

= 4.7 - 5th June 2018 =
* Add support for custom logos.
* Simplify custom css gradient code since the prefixes are largely not needed now.
* Tidy codes and escape all the things.

= 4.6 - 25th May 2018 =
* Add support for privacy policy link in the site footer.
* Fix display of the cookie consent checkbox in the comments form.

= 4.5.4 - 9th June 2017 =
* Improve code escaping (security) and coding standards

= 4.5.3 - 11th January 2017 =
* Add word-wrap to widgets to prevent long text from breaking the layout

= 4.5.2 - 24th September 2016 =

* Fix incorrect text domains

= 4.5.1 - 15th July 2016 =

* Improve rtl Styles
* Fix carousel sizes

= 4.5 - 4th July 2016 =

* Make theme fully responsive
* tidy up styles

= 4.4 - 28th May 2016 =

* Refactor widget related code. Includes:
	* ensuring wp_reset_postdata is run after queries
	* converting sql queries into WP_Query
	* Adding doc blocks
	* tidying code formatting
* Improve display of widgets in small right sidebar on single posts
* Fix bug with breadcrumbs on search results page

= 4.3.1 =

* Fix image attachment issue

= 4.3 =

* update widgets for WP 4.3
* improved security and multiple small bug fixes and improvements

= 4.0 > 4.3 =

Unfortunately I don't have a record of which versions these changes came under - but the changes between 4.1 and 4.3 include:
* improve RTL styles
* change thumbnails sizes so they work better in responsive views and remove blurriness
* make widgets display in mobile view
* improve category responsive behavior
* add 'edit posts' link to single blog posts and pages
* update theme so it passes the wp.com theme review checks
* use add_theme_support(title-tag)
* add support for other jetpack features (eg responsive videos)
* improve security
* update 3rd party js
* fix issues with home_url
* change comment counts so they only appear if comments are enabled on a post
* remove search highlighting since it breaks the search results page in some situations
* make featured category ordering work better on tablet devices

= 4.0 =
* Rebuild the theme for wordpress.com

= 1.0 =
* Initial release

== Credits ==

* [Bitter](https://www.google.com/fonts/specimen/Bitter) Font from Google Fonts, licensed under [SIL Open Font License, 1.1](http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL)
