<?php
/**
 * Search Form Template
 *
 * @package MimboPro
 */

bm_searchform();
