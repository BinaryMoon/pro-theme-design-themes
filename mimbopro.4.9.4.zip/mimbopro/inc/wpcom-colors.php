<?php
/**
 * Theme: Mimbo Pro
 */

/**
 * Background
 */
add_color_rule( 'bg', '#143347', array(
 	array( 'body.custom-background.custom-colors', 'background-color' ),
) );

/**
 * Headings
 */
add_color_rule( 'txt', '#313228', array(
	array( 'h1, .entry h3, h4, .entry h4, .entry h5, h3.widgettitle, .catnewsMainStory a, .catnewsMainStory a:visited, #respond h3', 'color', '#fff', 5 ),
) );

/**
 * Accent #1
 */
add_color_rule( 'fg1', '#f5f5f5', array(
	array( '#interior #sidebar h3.widgettitle, #carousel', 'background-color', '+1' ),
	array( '#carousel', 'border-color', '+1' ),
	array( '#interior #sidebar h3.widgettitle, #carousel a:hover, #carousel a:active', 'color', '-7' ),
	array( '#interior #sidebar .widget', 'background', '+1' ),
	array( '#interior #sidebar .widget-wrap', 'border-color', '+1' ),
	array( '.postmetadata', 'border-top-color', '#fff', 2 ),
	array( '.postmetadata', 'border-bottom-color', '#fff', 1.4 ),
	array( '#sidebar .widget li, #rightbar .widget li', 'border-bottom-color', '#fff', 2 ),
	array( 'h3.widgettitle', 'border-color', '#fff', 2 ),
	array( '#widget-single-right, div.sharedaddy div.sd-block', 'border-color', '#fff', 1.2 ),
	array( '.commentlist li.comment', 'border-color', '#fff', 1.3 ),
	array( '.commentlist', 'background-color', '#fff', 1.1 ),
) );

/**
 * Links
 */
add_color_rule( 'link', '#3399CC', array(
	array( '#upper, #navbar #s, #nav li:hover, #nav a:focus, #nav a:hover, #nav a:active, #nav .current-cat .children a:hover, #nav .current-cat .children, #nav li li', 'background-color', '+1' ),
	array( '#upper', 'border-bottom-color', '#fff', 5 ),
	array( '#navbar #s, select', 'border-color', '#fff', 5 ),
	array( '#navbar', 'border-top-color', '#fff', 3 ),
	array( '#navbar', 'border-bottom-color', '#fff', 7 ),
	array( '#navbar', 'background-color', '#fff', 5 ),
	array( '#lead', 'background-color', '#fff', 4 ),
	array( 'a, a:visited, #sidebar .widget #postDetails a, #sidebar .widget #postDetails a:visited', 'color', '#fff', 3 ),
	array( '#recent li', 'border-color', '#fff', 2.25 ),
	array( '#nav .current-cat a, #nav .current-cat a:visited, #nav .current_page_item a, #nav .current_page_item a:visited', 'color', 'link' ),
	array( '.whitebox h3.catcolor1, .whitebox h3.catcolor2, .whitebox h3.catcolor3', 'background-color', '#fff', 5 ),
	array( '.whitebox h3.catcolor1, .whitebox h3.catcolor2, .whitebox h3.catcolor3', 'border-bottom-color', '#fff', 7 ),
	array( 'footer', 'color', '#000', 4 ),
	array( 'footer a, footer a:visited, footer a:hover', 'color', '#000' ),
	array( '#breadcrumbs', 'background-color', '+1' ),
	array( '#lead img', 'border-color', '#fff', 5 ),
	array( '#lead img:hover', 'border-color', '#fff', 6.5 ),
	array( '#meta', 'background-color', '#fff', 9 ),
	array( '#meta h3', 'border-color', '#fff', 3 ),
	array( '#meta', 'color', '#fff', 1.6 ),
	array( '.subfeature', 'background-color', '+1' ),
	array( '.subfeature', 'color', 'link', 15 ),
	array( '.subfeature a, .subfeature a:visited', 'color', 'link', 15 ),
	array( '.subfeature', 'border-bottom-color', '+1' ),
	
	array( '#nav a:focus, #nav a:hover, #nav a:active, #nav .current-cat .children a:hover,#nav li li,#nav .current-cat a, #nav .current-cat a:visited, #nav .current_page_item a, #nav .current_page_item a:visited', 'color', 'link' ),
	array( '#nav .current-cat a, #nav .current-cat a:visited, #nav .current_page_item a, #nav .current_page_item a:visited', 'background-color', '-0.5' ),
	array( '#nav .current-cat a, #nav .current-cat a:visited, #nav .current_page_item a, #nav .current_page_item a:visited', 'border-top-color', '-0.5' ),
	array( '#nav .current-cat a, #nav .current-cat a:visited, #nav .current_page_item a, #nav .current_page_item a:visited', 'border-bottom-color', '-0.5' ),
) );

/**
 * Accent #2, unused by theme
 */
add_color_rule( 'fg2', '#f2f2f2', array(

) );

add_theme_support( 'custom_colors_extra_css', 'mimbopro_extra_css' );
function mimbopro_extra_css() { ?>
	#navbar,
	.whitebox h3.catcolor1,
	.whitebox h3.catcolor2,
	.whitebox h3.catcolor3 {
		background-image: none;
	}
	#nav a,
	#nav a:visited,
	#lead,
	#lead a,
	#lead a:visited,
	#lead a:hover,
	#lead .date,
	#breadcrumbs,
	#breadcrumbs a,
	#breadcrumbs a:visited,
	#upper a,
	#upper a:visited,
	#recent h3 {
		color: #fff;
	}
	#tags {
		background-color: #fff;
	}
	footer {
		background-color: #000;
	}
<?php
}