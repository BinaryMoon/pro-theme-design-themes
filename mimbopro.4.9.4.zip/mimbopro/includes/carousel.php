<?php
/**
 * Homepage Carousel Include
 *
 * @package MimboPro
 */

	$carousel_query = getCarouselDetails();
	$count = 0;
	$carousel_html = '';
	if ( '' != $carousel_query["query"] ) {
		$query = new WP_Query( $carousel_query["query"] );
		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();
				if ( $count < $carousel_query["count"] ) {
					$image = get_the_post_thumbnail( $query->post->ID, 'homepage-carousel' );

					if ( "" != $image ) {
						$count ++;
						$carousel_html .= '<li><a href="' . get_permalink() . '">' . $image . get_the_title() . '</a></li>';
					}
				}
			}
		}
	}

	// only show the carousel if there is stuff to display
	if ( '' != $carousel_html ) {
?>
<section id="carousel">
	<ul><?php echo $carousel_html; ?></ul>
</section>
<?php
	}

	wp_reset_postdata();
