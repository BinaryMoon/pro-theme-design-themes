<?php
/**
 * Homepage Category Summaries
 *
 * @package MimboPro
 */

	$bm_current_color = -1;
	$bm_cat_sum = getCategorySummaries();

	foreach ( $bm_cat_sum['category'] as $bm_pC ) {
		$bm_current_color ++;
		if ( $bm_current_color >= count( $bm_cat_sum['colour'] ) ) {
			$bm_current_color = 0;
		}

		$query = new WP_Query(
			array(
				'posts_per_page' => 4,
				'cat' => (int) $bm_pC,
			)
		);

		if ( $query->have_posts() ) {
			$cat_details = get_term( $bm_pC );
?>
		<div class="whitebox catnews">
			<h3 class="<?php echo esc_attr( $bm_cat_sum['colour'][ $bm_current_color ] ); ?>">
				<a href="<?php echo esc_url( get_category_link( $cat_details->term_id ) ); ?>"><?php echo esc_html( $cat_details->name ); ?> &raquo;</a>
			</h3>
<?php
			$count = 0;
			$quantity = 1;
			while ( $query->have_posts() ) {
				$query->the_post();
				bm_ignorePost( $query->post->ID );

				if ( $count < $quantity ) {
					$image = get_the_post_thumbnail( $query->post->ID, 'archive-small' ); // Defines height and width.
?>
			<div class="clearfloat catnewsMainStory">
				<div class="catnewsHeader">

					<h4>
						<a href="<?php echo esc_url( get_the_permalink() ); ?>" rel="bookmark" class="thumbnail">
							<?php the_title(); ?>
						</a>
					</h4>
<?php
					if ( ! post_password_required() && ( comments_open() || '0' != get_comments_number() ) ) {
?>
					<span class="commentcount">(<?php comments_popup_link( '0', '1', '%', 'comments_link', '' ); ?>)</span>
<?php
					}
?>
				</div>
<?php
					if ( $image ) {
?>
				<a href="<?php echo esc_url( get_the_permalink() ); ?>" rel="bookmark"><?php echo $image; ?></a>
<?php
					}
					the_excerpt();
?>
			</div>
<?php
					if ( ( $quantity - 1 ) === $count && $query->post_count > $quantity ) {
?>
			<ul class="headlines">
<?php
					}
				} else {
?>
				<li><a href="<?php echo esc_url( get_the_permalink() ); ?>" rel="bookmark"><?php the_title(); ?></a></li>
<?php
				}

				$count ++;
			}

			if ( $count > 0 ) {
				echo '</ul>';
			}
?>
		</div>
<?php
		}

		wp_reset_postdata();

	}
