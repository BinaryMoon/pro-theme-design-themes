<?php
/**
 * Homepage Featured Content
 *
 * @package MimboPro
 */

?>
<section id="upper" class="clearfloat">
<?php

	$query = new WP_Query( getFeaturedCategory() );

	if ( $query->have_posts() ) {
		while ( $query->have_posts() ) {
			$query->the_post();
			bm_ignorePost( $query->post->ID );
			$image = get_the_post_thumbnail( $query->post->ID, 'homepage-featured' );
?>
	<div id="lead" class="clearfloat">
<?php
			if ( '' != $image ) {
?>
		<div class="left">
			<a href="<?php the_permalink(); ?>" rel="bookmark"><?php echo $image; ?></a>
		</div>
		<div class="right">
<?php
			}
?>
			<h2><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
<?php
	if ( ! post_password_required() && ( comments_open() || '0' != get_comments_number() ) ) {
?>
			<span class="commentcount">(<?php comments_popup_link( '0', '1', '%', 'comments_link', '' ); ?>)</span>
<?php
	}
?>
			<div class="date"><?php the_date( get_option( 'date_format' ) ); ?> &bull; <?php the_category( ', ' ); ?></div>
			<div class="bigger"><?php the_excerpt(); ?></div>
<?php
			if ( '' != $image ) {
?>
		</div>
<?php
			}
?>
	</div><!--END LEAD-->
<?php
			break;
		}
	}
	wp_reset_postdata();
?>
	<div id="recent">
		<h3><?php esc_html_e( 'Recent Stories', 'mimbopro' ); ?></h3>
<?php
	/**
	 * List of recent posts.
	 */
	$query = new WP_Query(
		array(
			'posts_per_page' => 5,
			'ignore_sticky_posts' => true,
		)
	);

	if ( $query->have_posts() ) {
		echo '<ul>';
		while ( $query->have_posts() ) {
			$query->the_post();
			bm_ignorePost( $query->post->ID );
?>
			<li><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></li>
<?php
		}
		echo '</ul>';
	}
?>
	</div>
</section>
<?php
	wp_reset_postdata();
