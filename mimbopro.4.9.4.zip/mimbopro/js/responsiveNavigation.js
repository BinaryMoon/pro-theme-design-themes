(function ($) {
	$.fn.responsiveNavigation = function (options) {

		var defaults = {
			min_menu_size: 4,
			prefix: '-',
			ignore_children: false
		};

		var options = $.extend(defaults, options);

		return this.each(function () {
			$this = $(this);

			if ($this.find ('a').length > options.min_menu_size) {
				var select = $ ('<select></select>');
				navDepth = $this.parents ().length;

				// Add a default home menu item so that the first item can be selected.
				var navOptions = $('<option></option>');
				navOptions.text( js_i18n.menu );
				navOptions.attr( 'value', 'none' );
				select.append( navOptions );

				$this.find ('a').each (function () {
					depth = (($ (this).parents ().length - navDepth) / 2) - 1;

					if (depth == 0 || (depth > 0 && options.ignore_children == false)) {

						optionText = $ (this).text ();
						if (depth > 0) {
							optionText = ' ' + optionText;
						}
						for (i = 0; i < depth; i ++) {
							optionText = options.prefix + optionText;
						}
						navOptions = $('<option></option>');
						navOptions.attr ('value', $(this).attr ('href'));
						if (document.location == $(this).attr ('href')) {
							navOptions.attr ('selected', 'selected');
						}
						navOptions.text (optionText);
						select.append (navOptions);

					}

				});

				var nav_container = $('<nav id="nav-mobile-cats"></nav>').append (select);

				select.change (function () {
					if ( 'none' === this.value ) {
						return;
					}
					document.location = this.value;
				});

			}

			$this.parent().before (nav_container);
		});

	}

})(jQuery);