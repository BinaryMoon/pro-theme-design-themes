(function ($) {
	$.fn.elementalCarousel = function (options) {

		var defaults = {
			interval: 5000,
			min_quantity: 4
		};

		options = $.extend(defaults, options);

		return this.each( function () {

			var $this = $(this);
			var $list = $this.find('ul');
			var item_width = $this.find( 'li' ).outerWidth( true );
			var timer;
			var wrapper = $('<div class="carousel_wrap"></div>');
			
			var start_timer = function() {
				options.interval = parseInt(options.interval);
				if ( options.interval > 0 ) {
					clearInterval( timer );
					timer = setInterval( function() { slide( "right" ); }, options.interval );					
				}
			};
			
			var slide = function( where ) {

				// using a if statement and the where variable check
				// we will check where the user wants to slide (left or right)
				if ( where == 'left' ) {
					var left_indent = parseInt( $list.css( 'left' ) ) + item_width;
				} else {
					var left_indent = parseInt( $list.css( 'left' ) ) - item_width;
				}

				$list.stop( true, true ).animate( { 'left' : left_indent }, 200, function() {

					if ( where == 'left' ) {
						$list.find( 'li:last' ).prependTo( $list );
					} else {
						$list.find( 'li:first' ).appendTo( $list );
					}

					$list.css( { 'left' : -1 * item_width } );
					
				});
				
				start_timer();
				
			}
			
			$this.css('display', 'block');

			wrapper.css('height', $list.outerHeight() );
			$list.wrap( wrapper );
			
			// if there's enough to scroll
			if ( $this.find( 'ul li' ).length > options.min_quantity ) {
				// move the last list item before the first item.
				// this catches the times that the user clicks to slide left
				$list.prepend( $this.find( 'li:last' ) );
				$list.css( { 'left' : -1 * item_width } );
				
				var nav_prev = $('<a class="nav prev"></a>');
				var nav_next = $('<a class="nav next"></a>');

				nav_prev.click(function(){ slide( 'left' ); });
				nav_next.click(function(){ slide( 'right' ); });

				$this.append( nav_prev );
				$this.prepend( nav_next );
				
				$list.hover( function() {
					clearInterval( timer )
				},function() {
					start_timer();
				});

				start_timer();
			}
			
		});
		
	};

})( jQuery );