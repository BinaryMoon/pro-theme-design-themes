<?php
/**
 * Reusable Pagination
 *
 * @package MimboPro
 */
?>
			<section class="clearfloat pagination">
				<div class="left"><?php next_posts_link( __( '&laquo; Older Posts', 'mimbopro' ) ); ?></div>
				<div class="right"><?php previous_posts_link( __( 'Newer Posts &raquo;', 'mimbopro' ) ); ?></div>
			</section>