<?php
/**
 * Author Template
 *
 * @package MimboPro
 */

	get_header();

	global $wp_query;
	$curauth = $wp_query->get_queried_object();
?>
<div class="clearfloat stripes">
<?php
	get_sidebar();
?>
	<section id="content" class="<?php bm_content_class(); ?>">
<?php
	if (have_posts()) {
?>
		<h1 id="pagetitle"><?php _e('Author Archives','mimbopro'); ?> <a href="<?php echo get_author_posts_url( $author, '' ); ?>feed/"><img src="<?php echo get_template_directory_uri(); ?>/images/rss.gif" alt="rss" /></a></h1>
		<section class="subfeature clearfloat" id="site-author">
<?php
		echo get_avatar( $curauth->user_email, '86' );

		if ( ! empty( $curauth->user_description ) ) {
			echo wpautop( $curauth->user_description );
		}
?>
	</section>
		<h4><?php printf( __('Posts by %s','mimbopro'), ucwords( $curauth->user_nicename ) ); ?>:</h4>
			<ul class="more-in">
<?php
		while (have_posts()) {
			the_post();
?>
				<li>
					<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a>
<?php
			if ( ! post_password_required() && ( comments_open() || '0' != get_comments_number() ) ) {
?>
					<span class="commentcount">(<?php comments_popup_link( '0', '1', '%', 'comments_link', '' ); ?>)</span>
<?php
			}
?>
				</li>
<?php
		}
?>
			</ul>
<?php
		get_template_part('pagination');
	} else {
?>
		<article class="entry">
			<p><?php _e('No posts by this author.','mimbopro'); ?></p>
		</article>
<?php
	}
?>
</div>
<?php
	get_footer();
