<?php
/**
 * Run a theme update_themes
 * Local (development) updates are performed through: http://localhost/wordpress-themes/wp-content/theme-updates/check-update/
 *
 * @package mimbopro
 */

/**
 * Run a theme update check for the current theme.
 *
 * @param  object $checked_data Theme update object.
 * @return object
 */
function mimbopro_check_for_theme_update( $checked_data ) {

	global $wp_version;

	// Check that the theme update check is actually happening.
	if ( empty( $checked_data->checked ) ) {

		return $checked_data;

	}

	// Get the update list.
	// Uses PTD_DEBUG so that we always get a fresh version when developing.
	if ( ! PTD_DEBUG ) {

		$response = get_transient( 'mimbopro_theme_update' );

	}

	// If there's no updates then check for an update from the update server.
	if ( empty( $response ) ) {

		// Get update check url.
		$api_url = esc_url( apply_filters( 'mimbopro_theme_update_url', 'https://updates.prothemedesign.com/' ) );
		$api_url .= 'check-update/';

		// Let's start gathering data about the theme.
		// First get the theme directory name (the theme slug - unique).
		$theme = wp_get_theme();
		$slug = $theme->get( 'TextDomain' );

		// Default data response.
		$response = '';

		// Define request properties.
		$send_for_check = array(
			'active-theme' => esc_attr( $slug ),
			'php' => esc_attr( phpversion() ),
			'url' => esc_url( home_url() ),
			'license-key' => esc_attr( get_option( 'mimbopro_license_code' ) ),
		);

		// Create request url.
		$api_url .= '?' . http_build_query( $send_for_check );

		// If Debug enabled then output the api_url as a html comment.
		if ( PTD_DEBUG ) {

			echo '<!-- ' . esc_html( $api_url ) . ' -->';

		}

		// Request the data.
		$raw_response = wp_safe_remote_get( $api_url );

		// If there's no errors then set the response.
		if ( ! is_wp_error( $raw_response ) && 200 === $raw_response['response']['code'] ) {

			$response = unserialize( $raw_response['body'] );

			// Ensure there's something to save.
			if ( ! empty( $response ) ) {

				// Store the response for 2 days.
				set_transient( 'mimbopro_theme_update', $response, 60 * 60 * 24 * 2 );

			}
		}

		// If Debug enabled and there's a problem then output the problem.
		if ( PTD_DEBUG && is_wp_error( $raw_response ) ) {

			echo esc_html( $raw_response->get_error_message() );

		}
	}

	// Feed the update data into WP updater.
	if ( ! empty( $response ) ) {

		foreach ( $response as $theme ) {

			// Ensure the theme we're testing exists (hasn't been uninstalled recently).
			if ( empty( $checked_data->checked[ $theme['theme'] ] ) ) {

				continue;

			}

			// Invalid license, so remove from list of updates.
			// This prevents name clashes with themes on wordpress.org.
			if ( '-1' === $theme['new_version'] && isset( $checked_data->response[ $theme['theme'] ] ) ) {

				unset( $checked_data->response[ $theme['theme'] ] );
				continue;

			}

			// Compare versions to see if it should be added.
			// Compares the checked version with the value returned from the update server.
			if ( version_compare( $checked_data->checked[ $theme['theme'] ], $theme['new_version'], '<' ) ) {

				// Add to update list.
				$checked_data->response[ $theme['theme'] ] = $theme;

			}
		}
	}

	return $checked_data;

}

add_filter( 'pre_set_site_transient_update_themes', 'mimbopro_check_for_theme_update', 99 );
