<?php
/**
 * Allow users to edit footer credits.
 *
 * @package mimbopro
 */

/**
 * Theme Credits Customizer properties
 *
 * @param WP_Customize_Manager $wp_customize WP Customize object. Passed by WordPress.
 */
function mimbopro_customizer_credits( WP_Customize_Manager $wp_customize ) {

	if ( ! current_theme_supports( 'mimbopro-custom-credits' ) ) {
		return;
	}

	/**
	 * Mimbopro theme options section.
	 */
	$wp_customize->add_section(
		'mimbopro_credits',
		array(
			'title' => esc_html__( 'Footer Credits', 'mimbopro' ),
		)
	);

	/**
	 * Setting to allow the credits to be hidden.
	 */
	$wp_customize->add_setting(
		'mimbopro_display_credits',
		array(
			'default' => true,
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'mimbopro_credits_sanitize_checkbox',
			'transport' => 'postMessage',
		)
	);

	$wp_customize->add_control(
		'mimbopro_display_credits',
		array(
			'label' => esc_html__( 'Display Footer Credits', 'mimbopro' ),
			'section' => 'mimbopro_credits',
			'type' => 'checkbox',
		)
	);

	/**
	 * Setting to allow the credits to be hidden.
	 */
	$wp_customize->add_setting(
		'mimbopro_credits_content',
		array(
			'default' => '',
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'wp_kses_post',
			'transport' => 'postMessage',
		)
	);

	$wp_customize->add_control(
		'mimbopro_credits_content',
		array(
			'label' => esc_html__( 'Credits Content', 'mimbopro' ),
			'section' => 'mimbopro_credits',
			'type' => 'textarea',
		)
	);

}

add_action( 'customize_register', 'mimbopro_customizer_credits' );



/**
 * Update Credits without doing a full page refresh.
 *
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function mimbopro_register_customize_refresh_credits( WP_Customize_Manager $wp_customize ) {

	if ( ! current_theme_supports( 'mimbopro-custom-credits' ) ) {
		return;
	}

	// Ensure selective refresh is enabled.
	if ( ! isset( $wp_customize->selective_refresh ) ) {

		return false;

	}

	// Update credits content.
	$wp_customize->selective_refresh->add_partial(
		'mimbopro_credits_content',
		array(
			'selector' => 'section.footer-wrap',
			'render_callback' => function() {
				mimbopro_credits_content( false );
			},
		)
	);

}

add_action( 'customize_register', 'mimbopro_register_customize_refresh_credits' );


/**
 * Display credits content.
 *
 * @param  boolean $wrapper True to display wrapper, false for just contents.
 * @return boolean
 */
function mimbopro_credits_content( $wrapper = true ) {

	$contents = mimbopro_credits_get_content();

	if ( $contents && $wrapper ) {

		$args = get_theme_support( 'mimbopro-custom-credits' );
		$args = $args[0];

		echo $args['before'] . $contents . $args['after']; // WPCS: XSS ok.

	}

	if ( $contents && ! $wrapper ) {

		echo $contents; // WPCS: XSS ok.

	}

	// False to display defaults credits.
	// True to display credits as above.
	return ! empty( $contents );

}


/**
 * Display credits content.
 */
function mimbopro_credits_get_content() {

	$contents = get_theme_mod( 'mimbopro_credits_content', '' );

	$contents = str_replace( '[[YEAR]]', date( 'Y' ), $contents );

	return wp_kses_post( $contents );

}


/**
 * Setup theme properties related to footer credits.
 */
function mimbopro_credits_after_setup_theme() {

	// If the theme doesn't support custom credits return false.
	// False means the default credits will display.
	if ( ! current_theme_supports( 'mimbopro-custom-credits' ) ) {
		return;
	}

	$args = get_theme_support( 'mimbopro-custom-credits' );
	$args = $args[0];

	add_filter( $args['credits_filter'], 'mimbopro_credits_footer' );

}

add_action( 'after_setup_theme', 'mimbopro_credits_after_setup_theme', 11 );


/**
 * Display footer credits.
 * @return [type] [description]
 */
function mimbopro_credits_footer() {

	// If the theme doesn't support custom credits return false.
	// False means the default credits will display.
	if ( ! current_theme_supports( 'mimbopro-custom-credits' ) ) {
		return false;
	}

	// If we're not in the customizer preview and credits have been disabled
	// then lets quit.
	// Return true so that the credits get hidden.
	if ( ! is_customize_preview() && ! get_theme_mod( 'mimbopro_display_credits', true ) ) {
		return true;
	}

	return mimbopro_credits_content();

}


/**
 * Sanitize checkbox input.
 *
 * @param  null|boolean $input Checkbox value to check.
 * @return boolean
 */
function mimbopro_credits_sanitize_checkbox( $input = null ) {

	return (bool) $input;

}


/**
 * Binds JS handlers to make the Customizer preview reload changes asynchronously.
 */
function mimbopro_credits_customize_preview_js() {

	if ( ! current_theme_supports( 'mimbopro-custom-credits' ) ) {
		return;
	}

	wp_enqueue_script( 'mimbopro-credits-customize-preview', get_theme_file_uri( '/helpers/custom-credits/customize-preview.js' ), array( 'customize-preview' ), '1.0', true );

	mimbopro_credits_customizer_vars( 'mimbopro-credits-customize-preview' );

}

add_action( 'customize_preview_init', 'mimbopro_credits_customize_preview_js' );


/**
 * Load dynamic logic for the customizer controls area.
 */
function mimbopro_credits_panels_js() {

	if ( ! current_theme_supports( 'mimbopro-custom-credits' ) ) {
		return;
	}

	wp_enqueue_script( 'mimbopro-credits-panels', get_theme_file_uri( '/helpers/custom-credits/customize-controls.js' ), array(), '1.0', true );

	mimbopro_credits_customizer_vars( 'mimbopro-credits-panels' );

}

add_action( 'customize_controls_enqueue_scripts', 'mimbopro_credits_panels_js' );


/**
 * Setup javascript variables for customizer usage.
 * Allows us to keep the functions generic for usage across multiple themes.
 *
 * @param  string $slug The slug used to identify the javascript file.
 */
function mimbopro_credits_customizer_vars( $slug ) {

	$args = get_theme_support( 'mimbopro-custom-credits' );
	$args = $args[0];

	// Localized Javascript strings and provide access to common properties.
	wp_localize_script(
		$slug,
		'mimbopro_credits_global',
		$args
	);

}
