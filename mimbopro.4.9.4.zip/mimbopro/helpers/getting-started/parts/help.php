<div class="feature-section three-col">

    <h2><?php esc_html_e( 'Getting Started', 'mimbopro' ); ?></h2>

    <div class="col">

        <img src="<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/screenshot.png" class="screenshot" />

    </div>

    <div class="col">

        <h3><a href="https://prothemedesign.com/documentation/theme/<?php echo esc_html( $theme_slug ); ?>/"><?php esc_html_e( 'Theme Documentation', 'mimbopro' ); ?></a></h3>
        <p>
            <?php esc_html_e( 'Read about all of the theme settings, and learn how to use all its different features.', 'mimbopro' ); ?>
        </p>

		<h3><a href="https://prothemedesign.com/documentation/general/demo-content/"><?php esc_html_e( 'Download Demo Content', 'mimbopro' ); ?></a></h3>
        <p>
            <?php esc_html_e( 'Get the theme demo content, and widget data and find out how to install it. This will help you replicate the demo site.', 'mimbopro' ); ?>
        </p>

    </div>

    <div class="col license">
		<form action='options.php' method='post'>
<?php
		settings_fields( 'mimbopro-getting-started' );
		do_settings_sections( 'mimbopro-getting-started' );
		submit_button( esc_html__( 'Save License Key', 'mimbopro' ) );
?>

			<p class="description">
				<a href="https://prothemedesign.com/documentation/general/theme-license-key/" target="_blank"><?php esc_html_e( 'Find out how to get your license key.', 'mimbopro' ); ?></a>
			</p>
		</form>

    </div>

</div>

<hr />
