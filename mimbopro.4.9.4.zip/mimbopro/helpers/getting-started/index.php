<?php
/**
 * Theme updater admin page and functions.
 *
 * @package mimbopro
 */

/**
 * Redirect to Getting Started page on theme activation
 */
function mimbopro_redirect_on_activation() {

	global $pagenow;

	if ( is_admin() && 'themes.php' === $pagenow && isset( $_GET['activated'] ) ) {

		wp_redirect( admin_url( 'themes.php?page=mimbopro-getting-started' ) );

	}

}

add_action( 'admin_init', 'mimbopro_redirect_on_activation' );


/**
 * Load Getting Started styles in the admin
 * @return [type] [description]
 */
function mimbopro_load_admin_scripts() {

	// Load styles only on our page.
	global $pagenow;

	if ( 'themes.php' !== $pagenow || mimbopro_is_child_theme() ) {
		return false;
	}

	// Getting Started styles.
	wp_enqueue_style( 'mimbopro-getting-started', get_template_directory_uri() . '/helpers/getting-started/getting-started.css', false, '1.0.0' );

}

add_action( 'admin_enqueue_scripts', 'mimbopro_load_admin_scripts' );


/**
 * Adds a menu item for the Getting Started page
 */
function mimbopro_getting_started_menu() {

	if ( mimbopro_is_child_theme() ) {
		return false;
	}

	add_theme_page(
		esc_html__( 'Getting Started', 'mimbopro' ),
		esc_html__( 'Getting Started', 'mimbopro' ),
		'manage_options',
		'mimbopro-getting-started',
		'mimbopro_getting_started'
	);

}

add_action( 'admin_menu', 'mimbopro_getting_started_menu' );


/**
 * Outputs the getting started page.
 */
function mimbopro_getting_started() {

	// Theme info.
	$theme = wp_get_theme();
	$theme_name = $theme->get( 'Name' );
	$theme_description = $theme->get( 'Description' );
	$theme_slug = basename( get_stylesheet_directory() );
	$theme_user = wp_get_current_user();

?>

		<div class="wrap getting-started about-wrap">

			<h1><?php printf( esc_html__( 'Getting started with %s', 'mimbopro' ), esc_html( $theme_name ) ); ?></h1>

			<div class="about-text"><?php printf( esc_html__( 'Hi %s, thank you for installing %s! %s', 'mimbopro' ), esc_html( $theme_user->display_name ), esc_html( $theme_name ), esc_html( $theme_description ) ); ?></div>

			<div class="panels">

<?php
	include( 'parts/help.php' );
	include( 'parts/plugins.php' );
	//include( 'parts/theme-club.php' );
	include( 'parts/changelog.php' );
?>

			</div>

		</div>

<?php

}


/**
 * Initialize settings for storing theme license.
 */
function mimbopro_settings_init() {

	register_setting( 'mimbopro-getting-started', 'mimbopro_license_code' );

	add_settings_section(
		'mimbopro-section',
		'',
		'',
		'mimbopro-getting-started'
	);

	add_settings_field(
		'mimbopro_license_code',
		esc_html__( 'Enter your License Key to get automatic theme updates:', 'mimbopro' ),
		'mimbopro_license_code_field',
		'mimbopro-getting-started',
		'mimbopro-section'
	);

}

add_action( 'admin_init', 'mimbopro_settings_init' );


/**
 * Display the license code form input box.
 */
function mimbopro_license_code_field() {

	$license = get_option( 'mimbopro_license_code' );

?>
	<input type="text" name="mimbopro_license_code" placeholder="XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX" value="<?php echo esc_attr( $license ); ?>">
<?php

}
