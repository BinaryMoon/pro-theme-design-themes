<?php
/**
 * Useful functions :).
 *
 * @package mimbopro
 */

/**
 * Is the current theme a child theme or not?
 *
 * @return boolean
 */
function mimbopro_is_child_theme() {

	$theme = wp_get_theme();

	// Get the name.
	$theme_name = $theme->get( 'Name' );

	// Make it all lower case.
	$theme_name = strtolower( $theme_name );

	// Remove spaces. Takes care of name slike mimbo pro which are actually mimbopro.
	$theme_name = str_replace( ' ', '', $theme_name );

	if ( 'mimbopro' !== $theme_name ) {
		return true;
	}

	return false;

}
