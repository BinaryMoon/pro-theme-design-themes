<?php
/**
 * Search Results Template
 *
 * @package MimboPro
 */

	get_header();
?>
<section class="clearfloat stripes">
<?php
	get_sidebar();
?>
	<section id="content" class="<?php bm_content_class(); ?>">
<?php
	if ( have_posts() ) {
?>
		<h1 class="pagetitle"><?php esc_html_e( 'Search Results:', 'mimbopro' ); ?></h1>
		<p><?php esc_html_e( 'You searched for', 'mimbopro' ); ?>: "<strong><?php the_search_query(); ?></strong>"</p>
<?php
		global $post;
		while ( have_posts() ) {
			the_post();
			$image = get_the_post_thumbnail( $post->ID, 'archive-small' );
?>
		<div class="cat-excerpt clearfloat" id="post-<?php the_ID(); ?>">
<?php
			if ( $image ) {
?>
			<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php echo $image; ?></a>
<?php
			}
?>
			<h4><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php bm_searchTitle(); ?></a></h4>
			<?php the_excerpt(); ?>
		</div>
<?php
		}

		get_template_part( 'pagination' );

	} else {
?>
		<h1 class="pagetitle"><?php esc_html_e( 'No posts found', 'mimbopro' ); ?></h1>
<?php
	}
?>
	</section>
</section>
<?php
	get_sidebar();
	get_footer();
