<?php
/**
 * Comments template.
 *
 * @package Passenger
 */

	if ( post_password_required() ) {
		return;
	}
?>
<section class="content-comments container">
<?php
	if ( have_comments() ) {
?>
	<h3 id="comments" class="comment-reply-title">
<?php
		printf( esc_html( _nx( '1 Comment', '%1$s Comments', get_comments_number(), 'comments title', 'passenger' ) ), number_format_i18n( get_comments_number() ), '<span>' . get_the_title() . '</span>' );
?>
		<a href="#respond" class="scroll-to">
			<span class="screen-reader-text"><?php esc_html_e( 'Leave a comment', 'passenger' ); ?></span>
			<?php esc_html_e( '&rsaquo;', 'passenger' ); ?>
		</a>
	</h3>

	<div class="comments-wrapper">

		<ol class="comment-list" id="singlecomments">
<?php
		wp_list_comments(
			array(
				'avatar_size' => 60,
				'short_ping' => true,
				'callback' => 'passenger_comments_layout',
			)
		);
?>
		</ol>

		<?php the_comments_navigation(); ?>
	</div>
<?php

	}

	if ( 'open' === $post->comment_status ) {
		comment_form();
	}
?>
</section>
