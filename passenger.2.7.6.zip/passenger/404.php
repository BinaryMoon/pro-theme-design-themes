<?php
/**
 * Error - file not found
 *
 * @package Passenger
 */

	get_header();
?>
	<div class="wrapper-404">
		<div class="container" role="main">

			<?php get_template_part( 'parts/content-empty' ); ?>

		</div>
	</div>
<?php
	get_footer();
