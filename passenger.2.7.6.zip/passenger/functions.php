<?php
/**
 * Reusable theme functions
 *
 * @package Passenger
 */

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 * keep in mind the theme is responsive so the width is likely to be narrower
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function passenger_content_width() {

	$width = 906;

	$GLOBALS['content_width'] = apply_filters( 'passenger_content_width', $width );

}

add_action( 'after_setup_theme', 'passenger_content_width', 0 );


/**
 * Enqueue all the styles
 *
 * @global type $wp_scripts
 */
function passenger_enqueue() {

	// Styles.
	wp_enqueue_style( 'passenger-style', get_stylesheet_uri(), null, '1.38' );
	wp_enqueue_style( 'genericons', get_template_directory_uri() . '/styles/genericons/genericons/genericons.css', array(), '3.0.3' );

	// Fonts.
	$fonts_url = passenger_fonts();

	if ( $fonts_url ) {
		wp_enqueue_style( 'passenger-fonts', $fonts_url, array(), '1.0' );
	}

	// Javascript.
	if ( is_active_sidebar( 'sidebar-2' ) || ! is_singular() ) {
		wp_enqueue_script( 'masonry' );
	}

	wp_enqueue_script( 'passenger-script-main', get_template_directory_uri() . '/js/main.js', array( 'jquery' ), '1.1', false );

	wp_localize_script(
		'passenger-script-main',
		'js_i18n',
		array(
			'next' => esc_html__( 'next', 'passenger' ),
			'prev' => esc_html__( 'previous', 'passenger' ),
			'menu' => esc_html__( 'Menu', 'passenger' ),
		)
	);

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

}

add_action( 'wp_enqueue_scripts', 'passenger_enqueue' );


/**
 * Get url for google fonts
 */
function passenger_fonts() {

	$fonts = array();

	/* translators: If there are characters in your language that are not supported by Inconsolata, translate this to 'off'. Do not translate into your own language. */
	if ( 'off' !== esc_html_x( 'on', 'Inconsolata: on or off', 'passenger' ) ) {
		$fonts['inconsolata'] = 'Inconsolata:400,700';
	}

	$fonts = apply_filters( 'passenger_fonts', $fonts );

	if ( $fonts ) {
		$query_args = array(
			'family' => rawurlencode( implode( '|', $fonts ) ),
			'subset' => rawurlencode( 'latin,latin-ext' ),
		);

		return add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
	}

	return false;

}


/**
 * Set up all the theme properties and extras
 */
function passenger_after_setup_theme() {

	load_theme_textdomain( 'passenger', get_template_directory() . '/languages' );

	add_theme_support( 'automatic-feed-links' );

	// Post thumbnails.
	add_theme_support( 'post-thumbnails' );

	// Used for attachment (image.php) page links.
	add_image_size( 'passenger-attachment', 120, 120, true );
	add_image_size( 'passenger-logo', 500, 999 );
	add_image_size( 'passenger-header', 1600, 600, true );
	add_image_size( 'passenger-archive', 260, 200, true );
	add_image_size( 'passenger-archive-image', 600, 500, true );
	add_image_size( 'passenger-attachment-fullsize', 1600, 9999 );

	// Custom background.
	add_theme_support(
		'custom-background',
		apply_filters(
			'passenger-custom-background',
			array(
				'default-color' => 'ece9e8',
				'default-image' => '',
			)
		)
	);

	// HTML5 FTW.
	add_theme_support(
		'html5',
		array(
			'navigation-widgets',
			'comment-form',
			'gallery',
			'caption',
			'widgets',
		)
	);

	// Post Formats.
	add_theme_support(
		'post-formats',
		array(
			'video',
			'image',
			'gallery',
			'quote',
			'audio',
		)
	);

	// Title Tag.
	add_theme_support( 'title-tag' );

	// Menus.
	register_nav_menus(
		array(
			'primary' => esc_html__( 'Primary Menu', 'passenger' ),
			'social' => esc_html__( 'Social Links Menu', 'passenger' ),
		)
	);

	// Add support for full width images and other content such as videos.
	add_theme_support( 'align-wide' );

	// Disable custom font sizes, ensuring consistent vertical rhythm.
	add_theme_support( 'disable-custom-font-sizes' );

	// Make Gutenberg embeds responsive.
	add_theme_support( 'responsive-embeds' );

	// Editor font sizes.
	// Uses the default slugs to ensure consistency across themes.
	add_theme_support(
		'editor-font-sizes',
		array(
			array(
				'name' => esc_html__( 'small', 'passenger' ),
				'size' => 14.4,
				'slug' => 'small',
			),
			array(
				'name' => esc_html__( 'normal', 'passenger' ),
				'size' => 18,
				'slug' => 'normal',
			),
			array(
				'name' => esc_html__( 'medium', 'passenger' ),
				'size' => 22.5,
				'slug' => 'medium',
			),
			array(
				'name' => esc_html__( 'large', 'passenger' ),
				'size' => 28,
				'slug' => 'large',
			),
			array(
				'name' => esc_html__( 'huge', 'passenger' ),
				'size' => 35.154,
				'slug' => 'huge',
			),
		)
	);

	// Add support for editor styles.
	add_theme_support( 'editor-styles' );

	// Editor Style.
	$fonts_url = passenger_fonts();

	if ( $fonts_url ) {
		add_editor_style( $fonts_url );
	}

	add_editor_style( get_template_directory_uri() . '/styles/genericons/genericons/genericons.css' );

	add_editor_style( 'styles/css/editor-styles.css' );

}

add_action( 'after_setup_theme', 'passenger_after_setup_theme' );



/**
 * Enqueue WordPress theme styles within Gutenberg.
 */
function passenger_editor_blocks_styles() {

	// Load the additional editor styles.
	// This covers things like the editor title that can't be styled with the normal editor styles.
	wp_enqueue_style( 'passenger-editor-blocks', get_theme_file_uri( '/styles/css/editor-blocks.css' ), null, '1' );

	/**
	 * Overwrite Core theme styles with empty styles.
	 *
	 * @see https://github.com/WordPress/gutenberg/issues/7776#issuecomment-406700703
	 */
	wp_deregister_style( 'wp-block-library-theme' );
	wp_register_style( 'wp-block-library-theme', '' );

}

add_action( 'enqueue_block_editor_assets', 'passenger_editor_blocks_styles' );
add_action( 'enqueue_block_assets', 'passenger_editor_blocks_styles' );


/**
 * Display social links
 *
 * Inspired by http://kovshenin.com/2014/social-menus-in-wordpress-themes/
 *
 * @param boolean $echo Should the link be displayed.
 * @return type
 */
function passenger_social_links( $echo = true ) {

	if ( has_nav_menu( 'social' ) ) {

		$args = array(
			'theme_location' => 'social',
			'echo' => $echo,
			'container_class' => 'menu-social-links',
			'container' => 'div',
			'depth' => 1,
			'link_before' => '<span class="screen-reader-text">',
			'link_after' => '</span>',
			'fallback_cb' => '__return_false',
			'menu_class' => null,
		);

		return wp_nav_menu( $args );

	}

}


/**
 * A get_post_gallery() polyfill for Gutenberg
 *
 * @param string $gallery The current gallery html that may have already been found (through shortcodes).
 * @param int    $post The post id.
 * @return string The gallery html.
 */
function passenger_get_post_gallery( $gallery, $post ) {

	// Already found a gallery so lets quit.
	if ( $gallery ) {
		return $gallery;
	}

	// Check the post exists.
	$post = get_post( $post );
	if ( ! $post ) {
		return $gallery;
	}

	// Not using Gutenberg so let's quit.
	if ( ! function_exists( 'has_blocks' ) ) {
		return $gallery;
	}

	// Not using blocks so let's quit.
	if ( ! has_blocks( $post->post_content ) ) {
		return $gallery;
	}

	/**
	 * Search for gallery blocks and then, if found, return the html from the
	 * first gallery block.
	 *
	 * Thanks to Gabor for help with the regex:
	 * https://twitter.com/javorszky/status/1043785500564381696.
	 */
	$pattern = '/<!--\ wp:gallery.*-->([\s\S]*?)<!--\ \/wp:gallery -->/i';
	preg_match_all( $pattern, $post->post_content, $the_galleries );
	// Check a gallery was found and if so change the gallery html.
	if ( ! empty( $the_galleries[1] ) ) {
		$gallery = reset( $the_galleries[1] );
	}

	return $gallery;

}

add_filter( 'get_post_gallery', 'passenger_get_post_gallery', 10, 2 );


/**
 * Intitiate sidebars
 */
function passenger_widgets_init() {

	// Sidebar.
	register_sidebar(
		array(
			'name' => esc_html__( 'Overlay Widgets', 'passenger' ),
			'id' => 'sidebar-1',
			'description' => esc_html__( 'Widgets that overlay your website. They display when you click on the three dots in the top of your site.', 'passenger' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h3 class="widgettitle">',
			'after_title' => '</h3>',
		)
	);

	// Footer widgets.
	register_sidebar(
		array(
			'name' => esc_html__( 'Footer Widgets', 'passenger' ),
			'id' => 'sidebar-2',
			'description' => esc_html__( 'Widgets that display at the bottom of your website. They are arranged in 3 columns and lined up automatically to make the best use of the space available.', 'passenger' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h3 class="widgettitle">',
			'after_title' => '</h3>',
		)
	);

}

add_action( 'widgets_init', 'passenger_widgets_init' );


/**
 * Fallback for navigation menu
 *
 * @param array $params Menu parameters.
 * @return string
 */
function passenger_nav_menu( $params ) {

	$html = '';
	$echo = $params['echo'];

	$params['echo'] = false;
	$html = wp_page_menu( $params );

	if ( $params['container'] ) {
		$container_start = '<' . $params['container'] . ' id="' . $params['container_id'] . '" class="' . $params['container_class'] . '">';
		$container_end = '</' . $params['container'] . '>';

		$html = str_replace( '<div class="' . $params['menu_class'] . '">', $container_start, $html );
		$html = str_replace( '</div>', $container_end, $html );
	}

	if ( $echo ) {
		echo $html;
	} else {
		return $html;
	}

}


/**
 * Add additional body classes that may be helpful
 *
 * @param array $classes List of body classes.
 * @return string
 */
function passenger_body_class( $classes ) {

	if ( is_singular() ) {
		$classes[] = 'singular';
	}

	if ( is_multi_author() ) {
		$classes[] = 'multi-author-true';
	} else {
		$classes[] = 'multi-author-false';
	}

	if ( is_active_sidebar( 'sidebar-1' ) ) {
		$classes[] = 'themes-sidebar1-active';
	} else {
		$classes[] = 'themes-sidebar1-inactive';
	}

	if ( is_active_sidebar( 'sidebar-2' ) ) {
		$classes[] = 'themes-sidebar2-active';
	} else {
		$classes[] = 'themes-sidebar2-inactive';
	}

	if ( get_header_image() ) {
		$classes[] = 'has-custom-header';
	}

	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	return $classes;

}

add_filter( 'body_class', 'passenger_body_class' );


/**
 * Additional styles for post class
 *
 * @param array $styles List of post classes.
 * @return string
 */
function passenger_post_class( $styles ) {

	if ( is_singular() && is_main_query() ) {
		$styles[] = 'post-singular';
	} else {
		$styles[] = 'post-archive';
	}

	if ( get_the_post_thumbnail( get_the_ID() ) ) {
		$styles[] = 'post-has-thumbnail';
	} else {
		$styles[] = 'post-no-thumbnail';
	}

	return $styles;

}

add_filter( 'post_class', 'passenger_post_class' );


/**
 * Display header image and link to homepage
 * On pages display featured image if it is large enough to fill the space
 */
function passenger_header() {

	$header_image = get_header_image();
	$header_image_width = get_theme_support( 'custom-header', 'width' );
	$header_image_actual_width = get_custom_header()->width;
	$header_image_actual_height = get_custom_header()->height;

	// Use custom headers on pages, but only if the image is large enough.
	if ( is_page() ) {

		$image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'passenger-header' );

		if ( ! empty( $image ) && $image[1] >= $header_image_width ) {
			$header_image = $image[0];
			$header_image_actual_width = $image[1];
			$header_image_actual_height = $image[2];
		}
	}

	if ( ! empty( $header_image ) ) {
?>
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home" class="header-image">
			<img src="<?php echo esc_url( $header_image ); ?>" width="<?php echo (int) $header_image_actual_width; ?>" height="<?php echo (int) $header_image_actual_height; ?>" alt="" />
		</a>
<?php
	}

}


/**
 * Display the post time in a human readable format
 *
 * @return string
 */
function passenger_human_time_diff() {

	$post_time = get_the_time( 'U' );
	$human_time = '';
	$type = 'human';

	$time_now = gmdate( 'U' );

	// Use human time if less that 60 days ago
	// 60 seconds * 60 minutes * 24 hours * 90 days.
	if ( $post_time > $time_now - ( 60 * 60 * 24 * 90 ) ) {
		$human_time = sprintf( esc_html__( '%s ago', 'passenger' ), human_time_diff( $post_time, current_time( 'timestamp' ) ) );
	} else {
		$human_time = get_the_date();
		$type = 'date';
	}

	$human_time = sprintf( '<span class="post-human-time">%s</span>', $human_time );

	return $human_time;

}


/**
 * Get post thumbnail url
 * If a thumbnail doesn't exist then use the first attachment
 * reduces user confusion since they don't always understand the featured image functionality
 *
 * @param int    $post_id ID of post to retrieve thumbnail for.
 * @param string $thumbnail_size Thumbnail size key.
 * @return boolean|string
 */
function passenger_archive_image_url( $post_id = null, $thumbnail_size = 'passenger-archive' ) {

	if ( ! $post_id ) {
		$post_id = get_the_ID();
	}

	$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post_id ), $thumbnail_size );

	// If there's no featured image then grab an attachment image and use that instead.
	if ( ! $image[0] ) {

		$values = get_attached_media( 'image', $post_id );

		if ( $values ) {
			foreach ( $values as $child_id => $attachment ) {
				$image = wp_get_attachment_image_src( $child_id, $thumbnail_size );
				break;
			}
		}
	}

	if ( $image ) {
		return $image;
	} else {
		return false;
	}

}


/**
 * Fill empty post thumbnails with images from the first attachment added to a post
 *
 * @param string  $html Current html for thumbnail image.
 * @param integer $post_id ID for specified post.
 * @param integer $thumbnail_id ID for thumbnail image.
 * @param string  $size expected thumbnail size.
 * @return string
 */
function passenger_post_thumbnail_html( $html, $post_id, $thumbnail_id, $size = '' ) {

	if ( empty( $html ) ) {

		$values = get_attached_media( 'image', $post_id );

		if ( $values ) {
			foreach ( $values as $child_id => $attachment ) {
				$html = wp_get_attachment_image( $child_id, $size );
				break;
			}
		}
	}

	return $html;

}

add_filter( 'post_thumbnail_html', 'passenger_post_thumbnail_html', 10, 4 );


/**
 * Prints HTML with meta information for the current post-date/time
 */
function passenger_post_time() {

	$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';

	$time_string = sprintf(
		$time_string,
		esc_attr( get_the_date( 'c' ) ),
		passenger_human_time_diff()
	);

	$posted_on = sprintf(
		// translators: %s = date posted on.
		esc_html_x( 'Posted %s', 'post date', 'passenger' ),
		'<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a>'
	);

	echo '<span class="posted-on">' . $posted_on . '</span>';

}


/**
 * Prints HTML with the author meta data
 */
function passenger_post_author() {

	if ( is_attachment() ) {
		return;
	}

	$byline = sprintf(
		// translators: %s = author name.
		esc_html_x( 'by %s', 'post author', 'passenger' ),
		'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>'
	);

	echo '<span class="byline"> ' . $byline . '</span>';

}


/**
 * Display a link to the Passenger Comments
 */
function passenger_comments_link() {

	if ( ! post_password_required() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) {
?>
		<span class="comment-count"><?php comments_popup_link( esc_html__( 'Leave a Comment', 'passenger' ), esc_html__( '1 Comment', 'passenger' ), esc_html__( '% Comments', 'passenger' ) ); ?></span>
<?php
	}

}


/**
 * Get the posts custom read more text and, if available, display it instead of 'read more'
 */
function passenger_read_more_text() {

	// Default text value.
	$read_more = sprintf(
		esc_html__( 'Read more %s', 'passenger' ),
		the_title( '<span class="screen-reader-text">', '</span>', false )
	);

	// Get post data.
	$post = get_post();
	$custom_readmore = get_extended( $post->post_content );

	if ( ! empty( $custom_readmore['more_text'] ) ) {
		$read_more = esc_html( $custom_readmore['more_text'] );
	}

	echo $read_more;

}



/**
 * Display a specific user and their contributor info
 *
 * @param type $user_id    int ID of user to display.
 * @param type $post_count boolean Wether or not to display post count.
 */
function passenger_contributor( $user_id = null, $post_count = null ) {

	if ( ! $user_id ) {
		$user_id = get_the_author_meta( 'ID' );
	}

?>
	<div class="contributor">
		<?php echo get_avatar( $user_id, 140 ); ?>
		<h2>
			<a href="<?php echo esc_url( get_author_posts_url( $user_id ) ); ?>">
				<?php the_author_meta( 'display_name', $user_id ); ?>
				<small><?php esc_html_e( 'View All &rarr;', 'passenger' ); ?></small>
			</a>
		</h2>
<?php
	the_author_meta( 'description', $user_id );

	if ( $post_count ) {
?>
	<a class="contributor-posts-link" href="<?php echo esc_url( get_author_posts_url( $user_id ) ); ?>">
		<?php printf( esc_html( _nx( '%d Article', '%d Articles', $post_count, 'contributor article count', 'passenger' ) ), $post_count ); ?>
	</a>
<?php
	}
?>
	</div>
<?php

}


/**
 * Add auto formatting to the author bio.
 *
 * @link https://make.wordpress.org/core/2018/01/17/auto-formatting-of-author-bios-reverted-in-4-9-2/
 */
add_filter( 'get_the_author_description', 'wptexturize' );
add_filter( 'get_the_author_description', 'convert_chars' );
add_filter( 'get_the_author_description', 'wpautop' );
add_filter( 'get_the_author_description', 'shortcode_unautop' );


/**
 * Display the first category for the current post/ project
 */
function passenger_the_main_category() {

	$term_type = 'category';
	if ( 'jetpack-portfolio' === get_post_type() ) {
		$term_type = 'jetpack-portfolio-type';
	}

	$category = get_the_terms( get_the_ID(), $term_type );

	if ( is_array( $category ) ) {
		$category = array_values( $category );
		$category = current( $category );

		if ( is_object( $category ) ) {
?>
	<span class="post-lead-category"><a href="<?php echo esc_url( get_category_link( $category, $term_type ) ); ?>"><?php echo esc_html( $category->name ); ?></a></span>
<?php
		}
	}

}


/**
 * Custom comments layout
 *
 * @param object $comment The comment object.
 * @param array  $args Comment display arguments.
 * @param int    $depth The depth for the current comment.
 * @return void
 */
function passenger_comments_layout( $comment, $args, $depth ) {

	if ( ( 'pingback' === $comment->comment_type || 'trackback' === $comment->comment_type ) && $args['short_ping'] ) {
		passenger_comments_ping( $comment, $depth, $args );
	} else {
		passenger_comments_comment( $comment, $depth, $args );
	}

}


/**
 * Custom pings layout
 * it's actually the same as the default pings html but but I can't see a way to reuse the one from the comments walker class
 *
 * @param object $comment The comment object.
 * @param int    $depth The depth for the current comment.
 * @param array  $args Comment display arguments.
 * @return void
 */
function passenger_comments_ping( $comment, $depth, $args ) {

		$tag = ( 'div' === $args['style'] ) ? 'div' : 'li';
?>
		<<?php echo $tag; ?> id="comment-<?php comment_ID(); ?>" <?php comment_class(); ?>>
			<div class="comment-body">
				<?php printf( esc_html__( 'Pingback: %s', 'passenger' ), get_comment_author_link( $comment ) ); ?> <?php edit_comment_link( esc_html__( 'Edit', 'passenger' ), '<span class="edit-link">', '</span>' ); ?>
			</div>
<?php

}


/**
 * Custom comments layout
 *
 * @param object $comment The comment object.
 * @param int    $depth The depth for the current comment.
 * @param array  $args Comment display arguments.
 * @return void
 */
function passenger_comments_comment( $comment, $depth, $args ) {

	$tag = ( 'div' === $args['style'] ) ? 'div' : 'li';
?>
	<<?php echo $tag; ?> id="comment-<?php comment_ID(); ?>" <?php comment_class(); ?>>
		<article id="div-comment-<?php comment_ID(); ?>">
			<footer class="comment-meta">
				<div class="comment-author vcard">
					<a href="<?php echo esc_url( get_comment_author_url( $comment->comment_ID ) ); ?>" rel="external nofollow" class="url avatar-link">
						<?php if ( 0 != $args['avatar_size'] ) echo get_avatar( $comment, $args['avatar_size'] ); ?>
					</a>
					<span class="author-link">
						<?php comment_author_link(); ?>
					</span>
					<div class="comment-meta-data">
						<span class="comment-link">
							<a href="<?php echo esc_url( get_comment_link( $comment->comment_ID, $args ) ); ?>" class="comment-link">
								<time datetime="<?php comment_time( 'c' ); ?>">
									<?php printf( esc_html_x( '%1$s at %2$s', '1: date, 2: time', 'passenger' ), get_comment_date(), get_comment_time() ); ?>
								</time>
							</a>
						</span>
<?php
	edit_comment_link( esc_html__( 'Edit', 'passenger' ), '<span class="edit-link">', '</span>' );

	comment_reply_link(
		array_merge(
			$args,
			array(
				'add_below' => 'div-comment',
				'depth'     => $depth,
				'max_depth' => $args['max_depth'],
				'before'    => '<span class="reply">',
				'after'     => '</span>',
			)
		)
	);
?>
					</div>
				</div>
			</footer>

			<div class="comment-body">
<?php
	comment_text();

	if ( '0' === $comment->comment_approved ) {
?>
				<p class="comment-awaiting-moderation"><?php esc_html_e( 'Your comment is awaiting moderation.', 'passenger' ); ?></p>
<?php
	}
?>
			</div>

		</article>
<?php

}


/**
 *  Display a list of all of the project categories
 */
function passenger_project_terms() {

	$terms = get_terms(
		'jetpack-portfolio-type',
		array(
			'number' => 20,
			'orderby' => 'count',
			'order' => 'DESC',
		)
	);

	// Make sure the term exists and has some results.
	if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
?>
	<p class="projects-terms">
<?php
		foreach ( $terms as $t ) {
?>
		<a href="<?php echo esc_url( get_term_link( $t ) ); ?>"><span><?php echo esc_html( $t->name ); ?></span></a>
<?php
		}
?>
	</p>
<?php
	}

}


/**
 * Add post terms (categories and tags) to the_content
 * Using this through the_content filter places it before the related posts, social sharing, and other jetpack content
 *
 * @param string $content The original post content.
 * @return string The modified post content.
 */
function passenger_post_taxonomy( $content = '' ) {

	if ( ! is_single() ) {
		return $content;
	}

	if ( 'post' !== get_post_type( get_the_ID() ) ) {
		return $content;
	}

	$terms = '';
	$terms .= get_the_category_list( ' ' ) . ' ';

	if ( get_the_tags( get_the_ID() ) ) {
		$terms .= get_the_tag_list( '', ' ', '' );
	}

	$content .= '<p class="taxonomies">' . $terms . '</p>';

	return $content;

}

add_filter( 'the_content', 'passenger_post_taxonomy' );



/**
 * Add project categories to the_content
 * Using this through the_content filter places it before the related posts, social sharing, and other jetpack content
 *
 * @param string $content The original post content.
 * @return string The modified post content.
 */
function passenger_project_taxonomy( $content = '' ) {

	if ( ! is_single() ) {
		return $content;
	}

	if ( 'jetpack-portfolio' !== get_post_type( get_the_ID() ) ) {
		return $content;
	}

	$categories_list = get_the_term_list( get_the_ID(), 'jetpack-portfolio-type', '', ' ' );

	if ( $categories_list ) {
		$content .= '<p class="taxonomies">' . $categories_list . '</p>';
	}

	return $content;

}

add_filter( 'the_content', 'passenger_project_taxonomy' );



/**
 * Remove paragraphs from images so that they float off to the side in a nice way
 *
 * @param string $content The post content to remove p tags from.
 * @return string
 */
function passenger_remove_paragraphs_from_images( $content ) {

	return preg_replace( '/<p>\s*(<a .*>)?\s*(<img .* \/>)\s*(<\/a>)?\s*<\/p>/iU', '\1\2\3', $content );

}

add_filter( 'the_content', 'passenger_remove_paragraphs_from_images', 9999 );


/**
 * Filter the excerpt "read more" string.
 *
 * @param string $more "Read more" excerpt string.
 * @return string (Maybe) modified "read more" excerpt string.
 */
function passenger_excerpt_more( $more ) {

	return '&hellip;';

}

add_filter( 'excerpt_more', 'passenger_excerpt_more' );


/**
 * Add a span to the category and tag listings
 *
 * @param string $cat_list Html containing list of categories/ tags.
 * @return string
 */
function passenger_add_span_category_list( $cat_list ) {

	$cat_list = str_replace( 'tag">', 'tag"><span>', $cat_list );
	$cat_list = str_replace( '</a>', '</span></a>', $cat_list );

	return $cat_list;

}

add_filter( 'the_category', 'passenger_add_span_category_list' );
add_filter( 'the_tags', 'passenger_add_span_category_list' );


// Remove default gallery styles - the theme looks after these.
add_filter( 'use_default_gallery_style', '__return_false' );


// Custom Header.
require 'inc/custom-header.php';


// Jetpack specific functionality.
require 'inc/jetpack.php';


/**
 * Load WooCommerce compatibility file.
 */
if ( class_exists( 'WooCommerce' ) ) {
	require 'inc/woocommerce.php';
}
