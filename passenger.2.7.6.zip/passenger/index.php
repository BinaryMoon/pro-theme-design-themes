<?php
/**
 * Homepage Template
 *
 * @package Passenger
 */

	get_header();

	if ( have_posts() ) {
?>
	<div id="main-content" class="main-content" role="main">
<?php
		while ( have_posts() ) {

			the_post();
			get_template_part( 'parts/content', get_post_format() );

		}
?>
	</div>
<?php
		the_posts_pagination();

	} else {
?>
	<div id="main-content" class="main-content">
<?php
		get_template_part( 'parts/content-empty' );
?>
	</div>
<?php
	}

	get_footer();
