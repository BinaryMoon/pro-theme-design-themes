<?php
/**
 * WordPress.com specific functionality
 *
 * @package Passenger
 */

/**
 * Theme colours for wp.com custom functionality.
 *
 * @global string $themecolors
 */
function passenger_theme_colors() {

	global $themecolors;

	/**
	 * Set a default theme color array for WP.com.
	 *
	 * @global array $themecolors
	 */
	if ( ! isset( $themecolors ) ) {
		$themecolors = array(
			'bg'     => 'ffffff',
			'border' => 'eeeeee',
			'text'   => '333333',
			'link'   => '000000',
			'url'    => 'aaaaaa',
		);
	}

}

add_action( 'after_setup_theme', 'passenger_theme_colors' );


/**
 * Dequeue Google Fonts if Custom Fonts are being used instead.
 *
 * @param  array $fonts List of fonts loaded by the theme.
 * @return array        Modified list of fonts.
 */
function passenger_dequeue_fonts( $fonts ) {

	if ( class_exists( 'TypekitData' ) && class_exists( 'CustomDesign' ) && CustomDesign::is_upgrade_active() ) {
	    $custom_fonts = TypekitData::get( 'families' );

		if ( $custom_fonts && $custom_fonts['headings']['id'] && $custom_fonts['body-text']['id'] ) {
			unset( $fonts['inconsolata'] );
		}
	}

	return $fonts;

}

add_action( 'passenger_fonts', 'passenger_dequeue_fonts', 11 );


/**
 * Add a class to the body letting wordpress.com know about the usage of widgets in an overlay
 *
 * @param  array $classes Default list of body classes.
 * @return array          Modified list of body classes.
 */
function passenger_widgets_overlay_body_class( $classes ) {

	$classes[] = 'widgets-hidden';

	return $classes;

}

add_filter( 'body_class', 'passenger_widgets_overlay_body_class' );
