<?php
/* Custom Colors: Passenger */

add_color_rule( 'bg', '#ece9e8', array(
	array( 'body,
		.masthead .menu-on,
		table tr:nth-child(odd)', 'background-color' ),

	array( '.search .entry-archive-header,
		.archive .entry-archive-header,
		.page .main-content .entry-header,
		.single .main-content .entry-header,
		table th,
		table caption,
		.infinite-scroll .infinite-loader,
		.infinite-scroll #infinite-handle', 'background-color', '-0.2' ),

	array( 'pre,
		input[type=submit],
		.main .pagination span', 'background-color', '-0.8' ),
	array( 'pre', 'color', 'bg' ),

	array( '.main .post-navigation .nav-previous a:before,
		.main .post-navigation .nav-next a:before,
		.masthead .menu,
		table tr:nth-child(even),
		.content-comments ol.comment-list li.comment', 'background-color', '+0.5' ),

	array( '#main-content article:nth-of-type( 4n + 1 ),
		.wp-caption', 'background-color', '+0.3' ),

	array( '#main-content article:nth-of-type( 4n + 2 ),
		.post-password-required form,
		.post a.post-edit-link:hover,
		.page a.post-edit-link:hover,
		input[type=submit]:hover', 'background-color', '+0.5' ),

	array( '#main-content article:nth-of-type( 4n + 3 )', 'background-color', '+0.7' ),

	array( '#main-content article:nth-of-type( 4n + 4 ),
		q', 'background-color', '+0.9' ),

	array( '#main-content article.sticky:before,
		blockquote', 'background-color', '+1.0' ),

	array( '#main-content article:hover', 'background-color' ),

	array( '.sidebar-overlay', 'background-color', 0.95 ),


	array( '#wp-calendar th,
		#wp-calendar caption,
		.infinite-scroll #infinite-handle span,
		.infinite-scroll #infinite-handle span:focus,
		.infinite-scroll #infinite-handle span:hover,
		.main .contributor a.contributor-posts-link,
		.main .contributor a.contributor-posts-link:focus,
		.main .contributor a.contributor-posts-link:hover,
		ol.comment-list li.comment #respond #cancel-comment-reply-link,
		ol.comment-list li.trackback #respond #cancel-comment-reply-link,
		ol.comment-list li.pingback #respond #cancel-comment-reply-link,
		ol.comment-list li.comment #respond #cancel-comment-reply-link:focus,
		ol.comment-list li.trackback #respond #cancel-comment-reply-link:focus,
		ol.comment-list li.pingback #respond #cancel-comment-reply-link:focus,
		ol.comment-list li.comment #respond #cancel-comment-reply-link:hover,
		ol.comment-list li.trackback #respond #cancel-comment-reply-link:hover,
		ol.comment-list li.pingback #respond #cancel-comment-reply-link:hover,
		ol.comment-list li.comment.bypostauthor,
		ol.comment-list li.trackback.bypostauthor,
		ol.comment-list li.pingback.bypostauthor,
		#respond p.form-submit #submit,
		#respond p.form-submit #submit:focus,
		#respond p.form-submit #submit:hover', 'background-color' ),

	// Border color
	array( '.content-comments ol.comment-list li.comment article', 'border-color' ),

	array( 'table,
		table#wp-calendar,
		#wp-calendar th,
		.widget.widget_flickr #flickr_badge_wrapper,
		.jetpack-testimonial-shortcode .testimonial-entry,
		input[type=text],
		input[type=password],
		input[type=email],
		input[type=url],
		input[type=search],
		input.text,
		textarea,
		input.settings-input', 'border-color', '-0.5' ),

	array( 'div[class^="gr_custom_container"],
		div[class^="gr_custom_each_container"]', 'border-color', '+0.8' ),

	// Color
	array( '.main .contributor a.contributor-posts-link:hover', 'color' ),

	// Color contrasts against link
	array( '.masthead .menu li.current-menu-item > a,
		.masthead .menu li ul li a,
		.masthead .menu li ul li a:hover,
		.masthead .menu li ul li.current-menu-item > a,
		.infinite-scroll #infinite-handle span:hover', 'color', 'link' ),

	array( 'a.toggle:before,
		button.toggle:before', 'background-color', '+0.6' ),

	array( '.site-container,
		.site-container:after,
		.site-container:before,
		.sidebar-overlay,
		div.sharedaddy h3.sd-title:before,
		div#jp-relatedposts h3.jp-relatedposts-headline em:before', 'border-color', '+0.6' ),
) );

// Text
add_color_rule( 'txt', '#4d4d4d', array(
	// Contrast against bg
	array( 'body,
		h1,
		h2,
		h3,
		h4,
		h5,
		h6,
		a:focus,
		a:hover,
		blockquote,
		input[type=submit],
		input[type=submit]:focus,
		input[type=submit]:hover,
		.main .pagination span,
		.infinite-scroll #infinite-handle span:focus,
		.infinite-scroll #infinite-handle span:hover,
		.widget.widget_flickr #flickr_badge_uber_wrapper td a,
		.widget.widget_flickr #flickr_badge_wrapper td a,
		.main .contributor a.contributor-posts-link,
		.main .contributor a.contributor-posts-link:focus,
		.main .contributor a.contributor-posts-link:hover,
		#respond p.form-submit #submit:focus,
		#respond p.form-submit #submit:hover,
		.sidebar-overlay,
		.sidebar-overlay a,
		.masthead .menu .menu-toggle,
		.main .post-navigation .nav-previous a:focus:before,
		.main .post-navigation .nav-next a:focus:before,
		.main .post-navigation .nav-previous a:hover:before,
		.main .post-navigation .nav-next a:hover:before,
		div[class^="gr_custom_container"],
		div[class^="gr_custom_container"] a', 'color', 'bg' ),

	array( '.blog .format-standard,
		.blog .format-link,
		.blog .format-aside,
		.blog .format-audio,
		.blog .format-status,
		.blog .format-quote,
		.blog .format-chat,
		.archives .format-standard,
		.archives .format-link,
		.archives .format-aside,
		.archives .format-audio,
		.archives .format-status,
		.archives .format-quote,
		.archives .format-chat,
		.search .format-standard,
		.search .format-link,
		.search .format-aside,
		.search .format-audio,
		.search .format-status,
		.search .format-quote,
		.search .format-chat,
		.search .type-page', 'color', '#ffffff', 6 ),

	array( '.post-meta-data,
		.content-comments label,
		.main .contributor h2 small,
		.page a.post-edit-link,
		.page a.post-edit-link:hover,
		.single a.post-edit-link,
		.single a.post-edit-link:hover,
		.content-comments h3.comment-reply-title a,
		.content-comments .comment-navigation .nav-links a,
		.main .projects-terms a,
		.main .taxonomies a,
		.the-content .contact-form label span', 'color', 'bg', 3 ),

	array( '.main .projects-terms a:hover,
		.main .taxonomies a:hover', 'color', 'bg', 10 ),

	// Contrast against bg - less contrast
	array( '.wp-caption .wp-caption-text', 'color', 'bg', 8 ),

	array( 'input[type=text]:focus,
		input[type=password]:focus,
		input[type=email]:focus,
		input[type=url]:focus,
		input[type=search]:focus,
		input.text:focus,
		textarea:focus,
		input.settings-input:focus', 'border-color', 'bg' ),

	// Contrast against bg
	array( '#footer,
		#footer a,
		.menu-social-links ul li a:before', 'color', 'bg' ),

	array( '.masthead .menu li.page_item_has_children > a:after,
		.masthead .menu li.menu-item-has-children > a:after', 'border-top-color', 'bg' ),

	array( '.masthead .menu li ul li.page_item_has_children > a:after,
		.masthead .menu li ul li.menu-item-has-children > a:after', 'border-left-color', 'link' ),

	// Contrast against link
	array( '.rtl .masthead .menu li ul li.page_item_has_children > a:after,
		.rtl .masthead .menu li ul li.menu-item-has-children > a:after', 'border-right-color', 'link' ),
), __( 'Color One' ) );

// Link
add_color_rule( 'link', '#333333', array(
	// Contrast against bg
	array( '#main-content article.sticky:before,
		#respond p.form-submit #submit,
		a.toggle:before,
		button.toggle:before,
		.infinite-scroll .infinite-loader span button,
		.infinite-scroll #infinite-handle span button,
		a,
		#main-content article a.read-more,
		.masthead h1.site-title a,
		.masthead h1.site-title a:hover,
		.masthead p.site-description,
		.masthead .menu li,
		.masthead .menu li a,
		.entry-title a,
		.infinite-scroll #infinite-handle span', 'color', 'bg' ),

	array( 'a.toggle:focus:before,
		button.toggle:focus:before,
		a.toggle:hover:before,
		button.toggle:hover:before,
		.menu-social-links ul li a:focus:before,
		.menu-social-links ul li a:hover:before', 'color', 'bg', 3 ),

	array( '.widget.widget_flickr #flickr_badge_uber_wrapper td a,
		.widget.widget_flickr #flickr_badge_wrapper td a,
		.blog .format-standard a,
		.blog .format-link a,
		.blog .format-aside a,
		.blog .format-audio a,
		.blog .format-status a,
		.blog .format-quote a,
		.blog .format-chat a,
		.archives .format-standard a,
		.archives .format-link a,
		.archives .format-aside a,
		.archives .format-audio a,
		.archives .format-status a,
		.archives .format-quote a,
		.archives .format-chat a,
		.search .format-standard a,
		.search .format-link a,
		.search .format-aside a,
		.search .format-audio a,
		.search .format-status a,
		.search .format-quote a,
		.search .format-chat a,
		.search .type-page a,
		#main-content article a.read-more', 'color', '#ffffff', 3 ),

	array( '.masthead .menu li ul,
		.masthead .menu li.current-menu-item > a,
		.masthead .menu li ul li.current-menu-item > a', 'background-color' ),

	array( '.masthead .menu li ul:before', 'border-bottom-color' ),

	array( '.masthead .menu li ul li', 'border-bottom' ),
), __( 'Color Two' ) );

// Foreground1
add_color_rule( 'fg1', '#e6e6e6', array(
	// Color contrast against bg

), __( 'Color Three' ) );

//Foreground2
add_color_rule( 'fg2', '#ffffff', array(
) );

// Extra
add_color_rule( 'extra', '#ffffff', array(
) );

//Extra CSS
function passenger_extra_css() { ?>
	div[class^="gr_custom_container"] {
		background-color: transparent;
		border: 0;
	}

	#main-content article.format-video a.read-more {
		background-color: transparent;
	}

	@media only screen and (min-width: 783px) {
		.site-container .masthead .menu {
			background-color: transparent;
		}
	}

	@media only screen and (max-width: 782px) {
		.site-container .masthead .menu li ul,
		.site-container .masthead .menu li.current-menu-item > a,
		.site-container .masthead .menu li ul li.current-menu-item > a {
			background-color: transparent;
		}

		.masthead .menu li a:hover,
		.masthead .menu li.current-menu-item > a,
		.masthead .menu li ul li a,
		.masthead .menu li ul li a:hover,
		.masthead .menu li ul li.current-menu-item > a {
			color: inherit !important;
		}
	}


<?php }
add_theme_support( 'custom_colors_extra_css', 'passenger_extra_css' );

//Additional palettes
add_color_palette( array(
	'#dee5f6',
	'#000000',
	'#007fff',
), __( 'Palette One' ) );

add_color_palette( array(
	'#bbd2d1',
	'#647878',
	'#30373a',
), __( 'Palette Two' ) );

add_color_palette( array(
	'#343c4b',
	'#20232c',
	'#d9b968'
), __( 'Palette Three' ) );

add_color_palette( array(
	'#534a53',
	'#3e4654',
	'#a8caba'
), __( 'Palette Four' ) );

