<?php
/**
 * Jetpack Compatibility File
 *
 * @link https://jetpack.me/
 *
 * @package Passenger
 */

/**
 * Add theme support for Infinite Scroll
 * See: https://jetpack.me/support/infinite-scroll/
 */
function passenger_jetpack_init() {

	add_theme_support(
		'infinite-scroll',
		array(
			'container' => 'main-content',
			'footer_widgets' => 'sidebar-2',
			'footer' => 'footer-widgets',
			'render' => 'passenger_infinite_scroll_render',
			'wrapper' => false,
		)
	);

	add_theme_support( 'jetpack-testimonial' );

	add_theme_support( 'jetpack-portfolio' );

	add_theme_support( 'jetpack-responsive-videos' );

	add_theme_support(
		'site-logo',
		array(
			'size' => 'passenger-logo',
		)
	);

	// Add supprt for content options.
	add_theme_support(
		'jetpack-content-options',
		array(
			'blog-display' => 'excerpt', // The default setting of the theme: 'content', 'excerpt' or array( 'content, 'excerpt', ).
			'masonry'      => '#main-content', // A CSS selector matching the elements that triggers a masonry refresh if the theme is using a masonry layout.
			'post-details' => array(
				'stylesheet' => 'passenger-style', // Name of the theme's stylesheet.
				'date'       => '.posted-on', // A CSS selector matching the elements that display the post date.
				'categories' => '.main .taxonomies a[rel*="category"]', // A CSS selector matching the elements that display the post categories.
				'tags'       => '.main .taxonomies a[rel="tag"]', // A CSS selector matching the elements that display the post tags.
				'author'     => '.byline', // A CSS selector matching the elements that display the post author.
			),
		)
	);


}

add_action( 'after_setup_theme', 'passenger_jetpack_init' );


/**
 * Render infinite scroll content using template parts
 */
function passenger_infinite_scroll_render() {

	while ( have_posts() ) {

		the_post();

		if ( is_post_type_archive( 'jetpack-testimonial' ) ) {

			get_template_part( 'parts/content', 'testimonial' );

		} else {

			get_template_part( 'parts/content', get_post_format() );

		}
	}

}


/**
 * Change default jetpack infinite scroll setttings
 *
 * @param array $settings
 * @return type
 */
function passenger_infinite_scroll_js_settings( $settings ) {

	$settings['text'] = esc_html__( 'More Posts', 'passenger' );

	return $settings;

}

add_filter( 'infinite_scroll_js_settings', 'passenger_infinite_scroll_js_settings' );


/**
 * Get Jetpack Testimonials Title
 */
function passenger_testimonials_title() {

	$jetpack_options = get_theme_mod( 'jetpack_testimonials' );

	if ( ! empty( $jetpack_options['page-title'] ) ) {
		echo esc_html( $jetpack_options['page-title'] );
	} else {
		esc_html_e( 'Testimonials', 'passenger' );
	}

}


/**
 * Retrieve and format jetpack testimonials description as set in theme customiser
 *
 * @param string $before
 * @param string $after
 * @return boolean
 */
function passenger_testimonials_description( $before = '', $after = '' ) {

	$jetpack_options = get_theme_mod( 'jetpack_testimonials' );
	$content = '';

	if ( ! empty( $jetpack_options['page-content'] ) ) {
		$content = $jetpack_options['page-content'];
		$content = addslashes( $content );
		$content = wp_kses_post( $content );
		$content = stripslashes( $content );
		$content = wptexturize( $content );
		$content = convert_smilies( $content );
		$content = convert_chars( $content );
	}

	if ( $content ) {
		echo $before . $content . $after;
	}

	return false;

}


/**
 * Get Jetpack Testimonials Image
 *
 * @return type
 */
function passenger_testimonials_image() {

	$jetpack_options = get_theme_mod( 'jetpack_testimonials' );
	$image = '';

	if ( '' != $jetpack_options['featured-image'] ) {
		$image = wp_get_attachment_image( (int) $jetpack_options['featured-image'], 'passenger-header' );
	}

	return $image;

}


/**
 * Display site logo if available
 */
function passenger_site_logo() {

	if ( function_exists( 'jetpack_the_site_logo' ) ) {
		jetpack_the_site_logo();
	}

}


/**
 * Flush rewrite rules for CPT on setup and switch
 */
function passenger_flush_rewrite_rules() {

	flush_rewrite_rules();

}

add_action( 'after_switch_theme', 'passenger_flush_rewrite_rules' );


/**
 * Remove styles for contact form
 */
function passenger_remove_jetpack_stylesheets() {

	wp_deregister_style( 'grunion.css' );

}

add_action( 'wp_enqueue_scripts', 'passenger_remove_jetpack_stylesheets' );
