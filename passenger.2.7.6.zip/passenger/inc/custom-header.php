<?php
/**
 * Custom header codes
 *
 * @package Passenger
 */

/**
 * Custom header image
 */
function passenger_custom_header_support() {

	// Custom header image.
	$args = array(
		'default-text-color' => '000000',
		'random-default' => false,
		'width' => 1600,
		'height' => 150,
		'flex-height' => true,
		'header-text' => true,
		'uploads' => true,
		'wp-head-callback' => 'passenger_colour_styles',
	);

	add_theme_support( 'custom-header', apply_filters( 'passenger_custom_header', $args ) );

}

add_action( 'after_setup_theme', 'passenger_custom_header_support' );


/**
 * Print custom header styles
 *
 * @return array
 */
function passenger_colour_styles() {

?>
<style>
<?php
	if ( ! display_header_text() ) {
?>
	.masthead .branding {
		display:none;
	}
<?php
	} else {
?>
	.masthead h1.site-title a,
	.masthead h1.site-title a:hover,
	.masthead p.site-description {
		color:#<?php echo esc_attr( get_header_textcolor() ); ?>;
	}
<?php
	}
?>
</style>
<?php

	return true;

}
