<?php
/**
 * Sidebar template
 *
 * @package Passenger
 */

	if ( is_active_sidebar( 'sidebar-1' ) ) {
?>
<div class="sidebar sidebar-overlay" role="complementary" aria-hidden="true">
	<button href="#header" class="toggle-sidebar-overlay toggle" aria-expanded="false">
		<span class="screen-reader-text"><?php esc_html_e( 'Close widget overlay', 'passenger' ); ?></span>
	</button>
<?php
	dynamic_sidebar( 'sidebar-1' );
?>
</div>
<?php
	}
