<?php
/**
 * Header Template
 *
 * @package Passenger
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div class="site-container">

	<a href="#site-content" class="skip-link screen-reader-text"><?php esc_html_e( 'Skip to content', 'passenger' ); ?></a>

	<?php passenger_header(); ?>

	<header class="masthead" id="header" role="banner">

		<div class="branding">

			<?php passenger_site_logo(); ?>

			<h1 class="site-title">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php esc_attr_e( 'Home', 'passenger' ); ?>" class="site-title-link">
					<?php bloginfo( 'name' ); ?>
				</a>
			</h1>
			<p class="site-description">
				<?php bloginfo( 'description' ); ?>
			</p>
		</div>


		<nav class="menu" role="navigation">
			<button class="menu-toggle" aria-expanded="false"><?php esc_html_e( 'Menu', 'passenger' ); ?></button>
<?php
	wp_nav_menu(
		array(
			'theme_location' => 'primary',
			'menu_id' => 'nav',
			'menu_class' => 'menu-wrap',
			'container' => false,
		)
	);
?>
		</nav>


	</header>
<?php
	if ( is_active_sidebar( 'sidebar-1' ) ) {
?>
		<button rel="nofollow" class="toggle-widgets toggle" href="#header-sidebar" aria-expanded="false">
			<span class="screen-reader-text"><?php esc_html_e( 'Open widget overlay', 'passenger' ); ?></span>
		</button>
<?php
	}

	do_action( 'before' );
?>
	<div class="main" id="site-content">
