<?php
/**
 * Single post content
 *
 * @package Passenger
 */

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<header class="entry-header">
<?php
	the_title( '<h1 class="entry-title">', '</h1>' );

	the_post_navigation(
		array(
			'prev_text' => '<span class="screen-reader-text">Previous post: %title</span>',
			'next_text' => '<span class="screen-reader-text">Next post: %title</span>',
		)
	);

	get_template_part( 'parts/edit-post' );
?>
	</header>

	<section class="entry entry-single container">
<?php
	get_template_part( 'parts/post-meta' );
?>
		<div class="the-content">
<?php
	the_content(
		sprintf(
			esc_html__( 'Read more %s', 'passenger' ),
			the_title( '<span class="screen-reader-text">', '</span>', false )
		)
	);
?>
		</div>
<?php
	wp_link_pages(
		array(
			'before' => '<div class="pagination">',
			'after'  => '</div>',
			'link_before' => '<span>',
			'link_after'  => '</span>',
		)
	);

	if ( is_single() ) {
		passenger_contributor();
	}
?>
	</section>

</article>
