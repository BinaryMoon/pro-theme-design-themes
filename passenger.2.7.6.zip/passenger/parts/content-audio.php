<?php
/**
 * Audio content
 *
 * @package passenger
 */

	$content = apply_filters( 'the_content', get_the_content() );
	$audio = get_media_embedded_in_content( $content, array( 'audio' ) );

	if ( ! $audio ) {

		get_template_part( 'content' );
		return;

	}

	$image = get_the_post_thumbnail( get_the_ID(), 'passenger-archive' );

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<div class="entry-audio">
		<?php echo $audio[0]; /* WPCS: xss ok. */ ?>
	</div>

	<section class="entry entry-archive">

<?php
	if ( get_the_title() ) {
?>

		<h2 class="entry-title">
			<a href="<?php the_permalink() ?>" rel="bookmark">
				<?php the_title(); ?>
			</a>
		</h2>

<?php
	}

	echo wpautop( get_the_excerpt() );

	if ( $image ) {
?>
	<a href="<?php echo esc_url( get_permalink() ); ?>" class="thumbnail">
		<?php echo $image; ?>
	</a>
<?php
	}
?>
		<p><a href="<?php the_permalink(); ?>" class="read-more"><?php passenger_read_more_text(); ?></a></p>

	</section>

</article>
