<?php
/**
 * Page content
 *
 * @package Passenger
 */

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<header class="entry-header">
<?php
	the_title( '<h1 class="entry-title">', '</h1>' );
	get_template_part( 'parts/edit-post' );
?>
	</header>

	<section class="entry entry-single container">
		<div class="the-content">
<?php
	the_content(
		sprintf(
			esc_html__( 'Read more %s', 'passenger' ),
			the_title( '<span class="screen-reader-text">', '</span>', false )
		)
	);
?>
		</div>
<?php
	wp_link_pages(
		array(
			'before' => '<div class="pagination">',
			'after'  => '</div>',
			'link_before' => '<span>',
			'link_after'  => '</span>',
		)
	);
?>
	</section>

</article>
