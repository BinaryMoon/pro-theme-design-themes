<?php
/**
 * Gallery content
 *
 * @package Passenger
 */

	$featured_image = '';
	$images = array();
	$gallery = get_post_gallery( get_the_ID(), false );

	if ( ! empty( $gallery['ids'] ) ) {
		$images = explode( ',', $gallery['ids'] );
	}

	if ( empty( $images ) && ! is_string( $gallery ) ) {
		$featured_image = get_the_post_thumbnail( get_the_ID(), 'passenger-archive-image' );
	}
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<?php
	// If the gallery is a string rather than an array then it's probably a
	// Gutenberg gallery so we should output the html directly.
	if ( is_string( $gallery ) ) {
		echo '<div class="showcase">' . $gallery . '</div>';
	}

	// Display gallery images.
	if ( $images ) {
		echo '<div class="showcase">';
		foreach ( $images as $image ) {
?>
				<a href="<?php echo esc_url( get_attachment_link( $image ) ); ?>" class="item">
					<img src="<?php echo esc_url( wp_get_attachment_image_src( $image, 'passenger-archive' )[0] ); ?>" />
				</a>
<?php
		}
		echo '</div>';
	}

	// Backup in case there's no gallery images to display.
	if ( $featured_image ) {
?>
	<a href="<?php echo esc_url( get_permalink() ); ?>" class="thumbnail">
		<?php echo $featured_image; ?>
	</a>
<?php
	}
?>
	<section class="entry entry-archive">
<?php
	if ( get_the_title() ) {
?>
	<h2 class="entry-title">
		<a href="<?php the_permalink(); ?>" rel="bookmark">
			<?php the_title(); ?>
		</a>
	</h2>
<?php
	}
?>
	</section>

</article>
