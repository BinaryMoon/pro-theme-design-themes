<?php
/**
 * Quote content
 *
 * @package Passenger
 */

	$content = get_the_content();

	preg_match( '/<blockquote>(.*?)<\/blockquote>/s', $content, $matches );

	if ( ! empty( $matches[1] ) ) {
		$content = $matches[1];
	}

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<blockquote>
		<?php echo wpautop( $content ); ?>
		<span class="permalink">
			<a href="<?php the_permalink(); ?>">
				<?php echo esc_html_x( '#', 'A symbol used to link to a blog post', 'passenger' ); ?>
				<span class="screen-reader-text"><?php printf( esc_html__( 'Permanent link to %s', 'passenger' ), get_the_title() ); ?></span>
			</a>
		</span>
	</blockquote>

</article>
