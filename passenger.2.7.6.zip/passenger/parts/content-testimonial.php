<?php
/**
 * Individual Testimonial layout
 *
 * @package Passenger
 */

	$image = get_the_post_thumbnail( get_the_ID(), 'passenger-attachment' );
?>
<article id="post-<?php the_ID(); ?>" class="testimonial">

	<div class="entry">
<?php
	the_content(
		sprintf(
			esc_html__( 'Read more %s', 'passenger' ),
			the_title( '<span class="screen-reader-text">', '</span>', false )
		)
	);
?>
	</div>

	<div class="entry-meta">
<?php
	if ( $image ) {
?>
		<span class="thumbnail">
			<?php echo $image; ?>
		</span>
<?php
	}
?>
		<h3><?php the_title(); ?></h3>
	</div>

</article>
