<?php
/**
 * Image content
 *
 * @package Passenger
 */

	$image = get_the_post_thumbnail( get_the_ID(), 'passenger-archive-image' );
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<?php
	if ( $image ) {
?>
	<a href="<?php echo esc_url( get_permalink() ); ?>" class="thumbnail">
		<?php echo $image; ?>
	</a>
<?php
	}
?>
	<section class="entry entry-archive">
<?php
	if ( get_the_title() ) {
?>
	<h2 class="entry-title">
		<a href="<?php the_permalink() ?>" rel="bookmark">
			<?php the_title(); ?>
		</a>
	</h2>
<?php
	}

	if ( ! $image ) {
		echo wpautop( get_the_excerpt() );
?>
		<p><a href="<?php the_permalink(); ?>" class="read-more"><?php passenger_read_more_text(); ?></a></p>
<?php
	}
?>
	</section>

</article>
