<?php
/**
 * Post meta data
 *
 * @package Passenger
 */

?>
	<div class="post-meta-data">
<?php
	passenger_post_time();

	passenger_comments_link();

	passenger_post_author();
?>
	</div>
