<?php
/**
 * Testimonials Archive Template
 * displays at: http://website.com/portfolio/
 *
 * @package Passenger
 */

	get_header();

	if ( have_posts() ) {

		$image = passenger_testimonials_image();

		if ( $image ) {

			$image_allowed_properties = array(
				'src' => array(),
				'width' => array(),
				'height' => array(),
				'class' => array(),
			);
?>
	<div class="header-image">
		<?php echo wp_kses( $image, array( 'img' => $image_allowed_properties ) ); ?>
	</div>
<?php
		}
?>
	<header class="entry-archive-header">
		<div class="container">
			<h1 class="entry-title entry-archive-title"><?php passenger_testimonials_title(); ?></h1>
			<?php passenger_testimonials_description( '<div class="category-description">', '</div>' ); ?>
		</div>
	</header>

	<div id="main-content" class="main-content testimonials-wrapper" role="main">
<?php
		while ( have_posts() ) {

			the_post();
			get_template_part( 'parts/content', 'testimonial' );

		}
?>
	</div>
<?php
		the_posts_pagination();

	} else {

		get_template_part( 'parts/content-empty' );

	}

	get_footer();
