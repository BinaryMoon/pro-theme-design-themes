<?php
/**
 * Search results template
 *
 * @package Passenger
 */

	get_header();

	if ( have_posts() ) {
?>
	<header class="entry-archive-header">
		<div class="container">
			<h1 class="entry-title entry-archive-title">
				<?php printf( esc_html__( 'Search results for: %s', 'passenger' ), '<span>' . get_search_query() . '</span>' ); ?>
			</h1>

			<?php get_search_form(); ?>
		</div>
	</header>

	<div id="main-content" class="main-content" role="main">
<?php

		while ( have_posts() ) {
			the_post();
			get_template_part( 'parts/content', get_post_format() );
		}
?>
	</div>
<?php
		the_posts_pagination();

	} else {
?>
	<div class="main-content wrapper-404">
		<div class="container">
<?php
		get_template_part( 'parts/content-empty' );
?>
		</div>
	</div>
<?php
	}

	get_footer();
