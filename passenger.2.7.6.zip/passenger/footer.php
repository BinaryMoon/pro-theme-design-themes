<?php
/**
 * Footer Template
 *
 * @package Passenger
 */

?>
	</div>

	<footer role="contentinfo" id="footer">
<?php
	if ( is_active_sidebar( 'sidebar-2' ) ) {
?>
		<aside class="footer-widgets sidebar-footer">
			<?php dynamic_sidebar( 'sidebar-2' ); ?>
		</aside>
<?php
	}

	passenger_social_links();

	/**
	 * Check to see if a custom credits option is set.
	 * If custom credits are set then the filter should output the credits and
	 * return a non false value. This will hide the default footer credits.
	 */
	if ( false === apply_filters( 'passenger_credits', false ) ) {

?>

		<section class="footer-wrap">
<?php
		if ( function_exists( 'the_privacy_policy_link' ) ) {
			the_privacy_policy_link( '', '<span class="sep"> | </span>' );
		}
?>
			<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'passenger' ) ); ?>" title="<?php esc_attr_e( 'A Semantic Personal Publishing Platform', 'passenger' ); ?>" rel="generator"><?php printf( esc_html__( 'Proudly powered by %s', 'passenger' ), 'WordPress' ); ?></a>
			<span class="sep"> | </span>
			<?php printf( esc_html__( 'Theme: %1$s by %2$s.', 'passenger' ), 'Passenger', '<a href="https://prothemedesign.com/" rel="designer">Pro Theme Design</a>' ); ?>
		</section>

<?php
	}
?>

		<a href="#header" class="scroll-to back-to-top toggle">
			<span class="screen-reader-text"><?php esc_html_e( 'Back to top', 'passenger' ); ?></span>
		</a>
	</footer>
</div>

<?php
	get_sidebar();

	wp_footer();
?>

</body>
</html>
