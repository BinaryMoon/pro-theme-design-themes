<?php
/**
 * Template Name: Contributor Page
 *
 * @package Passenger
 */

	get_header();

	get_template_part( 'parts/featured-content' );

	if ( have_posts() ) {
?>
	<div class="main-content" role="main">
<?php
		while ( have_posts() ) {
			the_post();
?>
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<header class="entry-header">
<?php
			the_title( '<h1 class="entry-title">', '</h1>' );
			get_template_part( 'parts/edit-post' );
?>
			</header>

			<section class="entry entry-single container">
<?php
			the_content();
?>
			</section>

			<section class="entry-contributors container">
<?php
			get_template_part( 'parts/content-contributors' );
?>
			</section>
		</article>
<?php
			get_template_part( 'parts/comments' );
		}
?>
	</div>
<?php
	} else {
		get_template_part( 'parts/content-empty' );
	}

	get_footer();
