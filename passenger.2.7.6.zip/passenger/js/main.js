/**
 * main.js v1
 * Created by Ben Gillbanks <http://www.binarymoon.co.uk/>
 * Available under GPL2 license
 */

; ( function( $ ) {

	var $grid = null;
	var $footer_grid = null;

	// js mobile detection

	var is_touch_device = function() {

		return ( ( 'ontouchstart' in window ) || ( navigator.MaxTouchPoints > 0 ) || ( navigator.msMaxTouchPoints > 0 ) );

	};

	// smooth scroll to # anchor

	var scroll_to_hash = function( e ) {

		var $target = $( e.hash );

		if ( $target.length ) {
			var targetOffset = $target.offset().top - parseInt( $( 'html' ).css( 'margin-top' ) );
			$( 'html,body' ).animate( { scrollTop: targetOffset }, 750 );
		}

		return false;

	};

	/**
	 * Set default heights for social media widgets.
	 */
	var social_widget_heights = function() {

		// Twitter.
		$( 'iframe.twitter-timeline' ).each(
			function() {

				var thisHeight = $( this ).height();
				if ( thisHeight > 0 ) {
					$( this ).parent().css(
						{
							'min-height': thisHeight + 'px',
							'display': 'block'
						}
					);
				}

			}
		);

		// Facebook.
		$( '.fb-page' ).each(
			function() {

				var $set_height = $( this ).data( 'height' );
				var $show_facepile = $( this ).data( 'show-facepile' );
				var $show_posts = $( this ).data( 'show-posts' ); // AKA stream.
				var $min_height = $set_height; // Set the default 'min-height'.

				// These values are defaults from the FB widget.
				var $no_posts_no_faces = 130;
				var $no_posts = 220;

				if ( $show_posts ) {

					// Showing posts; may also be showing faces and/or cover -
					// the latter doesn't affect the height at all.
					$min_height = $set_height;

				} else if ( $show_facepile ) {

					// Showing facepile with or without cover image - both would
					// be same height.
					// If the user selected height is lower than the no_posts
					// height, we'll use that instead.
					$min_height = ( $set_height < $no_posts ) ? $set_height : $no_posts;

				} else {

					// Either just showing cover, or nothing is selected (both
					// are same height).
					// If the user selected height is lower than the
					// no_posts_no_faces height, we'll use that instead.
					$min_height = ( $set_height < $no_posts_no_faces ) ? $set_height : $no_posts_no_faces;

				}

				// Apply min-height to .fb-page container.
				$( this ).css(
					{
						'min-height': $min_height + 'px',
						'display': 'block'
					}
				);

			}

		);

		if ( typeof $.fn.masonry === 'function' && $footer_grid !== null ) {
			$footer_grid.masonry( 'layout' );
		}

	};

	$( document ).ready( function() {

		// attachment page navigation

		if ( $( 'body' ).hasClass( 'attachment' ) ) {

			$( document ).keydown(
				function( e ) {

					if ( $( 'textarea, input' ).is( ':focus' ) ) {
						return;
					}

					var url = false;

					switch ( e.which ) {

						// left arrow key (previous attachment)
						case 37:
							url = $( '.image-previous a' ).attr( 'href' );
							break;

						// right arrow key (next attachment)
						case 39:
							url = $( '.image-next a' ).attr( 'href' );
							break;

					}

					if ( url ) {
						window.location = url;
					}

				}
			);


		}

		// masonry layout

		$( window ).on(
			'load',
			function() {

				if ( typeof $.fn.masonry === 'function' ) {

					// add grid-sizer element

					$( '#main-content' ).prepend( '<div class="grid-sizer"></div>' );

					// main post archive

					$grid = $( '#main-content' ).masonry(
						{
							gutter: 0,
							isOriginLeft: !$( 'body' ).is( '.rtl' ),
							columnWidth: '.grid-sizer',
							itemSelector: 'article',
							percentPosition: true
						}
					);

					$grid.imagesLoaded(
						function() {

							$grid.masonry( 'layout' );
							$grid.children().addClass( 'post-loaded' );

						}
					);

					$( 'body' ).on(
						'post-load',
						function() {

							var $new_articles = $( '#main-content' ).children().not( '.post-loaded, .infinite-loader' ).addClass( 'post-loaded' );
							$grid.masonry( 'appended', $new_articles );
							$grid.masonry( 'layout' );

							$grid.imagesLoaded(
								function() {
									$grid.masonry( 'layout' );
								}
							);

						}
					);

					// Footer widgets.

					$footer_grid = $( 'footer#footer .footer-widgets' ).masonry(
						{
							itemSelector: '.widget',
							gutter: 0,
							isOriginLeft: !$( 'body' ).is( '.rtl' )
						}
					);

					$footer_grid.imagesLoaded(
						function() {
							$footer_grid.masonry( 'layout' );
						}
					);

					// Run social_widget_heights a few times to ensure it's fully loaded.
					for ( i = 0; i < 4; i++ ) {
						setTimeout( social_widget_heights, i * 1500 );
					}

				}

			}
		);

		// set menu closed

		$( '#nav' ).attr( 'aria-expanded', false );

		// menu toggle

		$( '.menu-toggle' ).on( 'click', function() {

			var $parent = $( this ).parent();
			var $menu = $parent.find( '#nav' );
			var $this = $( this );

			$parent.toggleClass( 'menu-on' );

			// menu is shown
			if ( $parent.hasClass( 'menu-on' ) ) {

				$menu.attr( 'aria-expanded', 'true' );
				$this.attr( 'aria-expanded', 'true' );

				// menu is hidden
			} else {

				$menu.attr( 'aria-expanded', 'false' );
				$this.attr( 'aria-expanded', 'false' );

			}

		} );

		// set menu items with submenus to aria-haspopup="true".

		$( '.menu-item-has-children' ).each( function() {

			$( this ).attr( 'aria-haspopup', 'true' );

		} );

		// dropdown menu touch screen improvements

		$( '.menu' ).find( 'a' ).on( 'focus blur', function() {

			$( this ).parents().toggleClass( 'focus' );

		} );

		// mobile device detection

		$( 'body' ).addClass( is_touch_device() ? 'device-touch' : 'device-click' );


		// widget overlay

		$( '.toggle-widgets' ).on( 'click', function( e ) {

			e.preventDefault();

			$( this ).attr( 'aria-expanded', 'true' );
			$( '.toggle-sidebar-overlay' ).attr( 'aria-expanded', 'true' );

			$( 'body' ).addClass( 'display-widgets' );
			$( '.sidebar-overlay' ).attr( 'aria-hidden', 'false' );

			setTimeout(
				function() {

					// Remove any media elements currently initialised.
					$( '.sidebar-overlay .mejs-container' ).each(
						function( i, el ) {
							if ( mejs.players[ el.id ] ) {
								mejs.players[ el.id ].remove();
							}
						}
					);

					// Initialize overlay.
					if ( window.wp && window.wp.mediaelement ) {
						window.wp.mediaelement.initialize();
					}

					// Trigger window resize event to fix video size issues.
					// Don't use jqueries trigger event since that only triggers
					// methods hooked to events, and not the events themselves.
					if ( typeof ( Event ) === 'function' ) {
						window.dispatchEvent( new Event( 'resize' ) );
					} else {
						var event = window.document.createEvent( 'UIEvents' );
						event.initUIEvent( 'resize', true, false, window, 0 );
						window.dispatchEvent( event );
					}

				},
				250
			);

			$( '.toggle-sidebar-overlay' ).focus();

		} );


		// widget overlay close button

		$( '.toggle-sidebar-overlay' ).on( 'click', function( e ) {

			e.preventDefault();

			$( 'body' ).removeClass( 'display-widgets' );
			$( '.sidebar-overlay' ).attr( 'aria-hidden', 'true' );

			$( '.toggle-widgets' ).attr( 'aria-expanded', 'false' );
			$( this ).attr( 'aria-expanded', 'false' );

		} );

		// smooth scroll to element

		$( '.scroll-to' ).on(
			'click',
			function() {
				return scroll_to_hash( this );
			}
		);

		// skip link fix
		// https://github.com/Automattic/_s/blob/master/js/skip-link-focus-fix.js

		var isWebkit = navigator.userAgent.toLowerCase().indexOf( 'webkit' ) > -1,
			isOpera = navigator.userAgent.toLowerCase().indexOf( 'opera' ) > -1,
			isIe = navigator.userAgent.toLowerCase().indexOf( 'msie' ) > -1;

		if ( ( isWebkit || isOpera || isIe ) && document.getElementById && window.addEventListener ) {
			window.addEventListener( 'hashchange', function() {
				var id = location.hash.substring( 1 ),
					element;

				if ( !( /^[A-z0-9_-]+$/.test( id ) ) ) {
					return;
				}

				element = document.getElementById( id );

				if ( element ) {
					if ( !( /^(?:a|select|input|button|textarea)$/i.test( element.tagName ) ) ) {
						element.tabIndex = -1;
					}

					element.focus();
				}
			}, false );
		}

	} );

} )( jQuery );
