<?php
/**
 * Archive Template
 *
 * @package Passenger
 */

	get_header();

	if ( have_posts() ) {
?>
	<header class="entry-archive-header">
		<div class="container" role="main">
<?php
		the_archive_title( '<h1 class="entry-title entry-archive-title">', '</h1>' );
		the_archive_description( '<div class="category-description">', '</div>' );

		if ( 'jetpack-portfolio' === get_post_type() ) {
			passenger_project_terms();
		}
?>
		</div>
	</header>

	<div id="main-content" class="main-content">
<?php
		while ( have_posts() ) {
			the_post();
			get_template_part( 'parts/content', get_post_format() );
		}
?>
	</div>
<?php
		the_posts_pagination();

	} else {
?>
	<div id="main-content" class="main-content" role="main">
<?php
		get_template_part( 'parts/content-empty' );
?>
	</div>
<?php
	}

	get_footer();
