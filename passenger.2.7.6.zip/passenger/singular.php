<?php
/**
 * Single post & page template
 *
 * @package Passenger
 */

	get_header();

?>
	<div class="main-content" role="main">
<?php

	if ( have_posts() ) {

		while ( have_posts() ) {

			the_post();

			get_template_part( 'parts/content-single', get_post_type() );
			get_template_part( 'parts/comments' );

		}
	} else {

		get_template_part( 'parts/content-empty' );

	}

?>
	</div>
<?php

	get_footer();
