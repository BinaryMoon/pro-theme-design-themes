=== Passenger ===

Contributors: binarymoon
Requires at least: 4.3
Tested up to: 4.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: black, gray, white, light, one-column, two-columns, responsive-layout, custom-background, custom-colors, custom-header, custom-menu, editor-style, featured-images, featured-image-header, flexible-header, infinite-scroll, post-formats, post-slider, rtl-language-support, site-logo, sticky-post, threaded-comments, translation-ready, art, artwork, blog, design, food, holiday, journal, lifestream, nature, outdoors, travel, tumblelog, bright, clean, conservative, contemporary, elegant, geometric, handcrafted, light, minimal, modern, professional, simple, sophisticated

== Description ==

Passenger is a theme designed for travel journals, and scrapbooking sites. With its unique post formats and clean typography, Passenger is great for telling stories.

[Theme documentation](https://prothemedesign.com/documentation/theme/passenger/)

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Passenger includes support for [Styleguide](https://wordpress.org/plugins/styleguide/) - a plugin that allows you to change fonts, and colours in WordPress themes.

Passenger includes support for most features in [Jetpack](https://wordpress.org/plugins/jetpack/), including Infinite Scroll, Featured Content, and Site Logo.

== Changelog ==

= 2.7.6 - 2nd April 2021 =
* Fix text input width.

= 2.7.5 - 31st January 2021 =
* Clear html widget to prevent floated content from breaking the layout.

= 2.7.4 - 1st January 2021 =
* Add 'navigation-widgets' to supported html5 types.
* Fix jQuery error since jquery migrate has been removed.
* Fix sub menu link colours on mobile devices.
* Update rtl styles.

= 2.7.3 - 5th October 2020 =
* Add support for wp_body_open

= 2.7.2 - 13th July 2020 =
* Add support for accessible widget lists: https://make.wordpress.org/core/2020/07/09/accessibility-improvements-to-widgets-outputting-lists-of-links-in-5-5/

= 2.7.1 - 6th May 2020 =
* Make gallery post formats in archives display correctly for Gutenberg galleries.

= 2.7 - 11th March 2020 =
* Add support for Gutenberg.
* Improve coding standards.

= 2.6.2 - 18th June 2019 =
* Fix button styles in forms. input elements looked good but button elements were not styled. They are now!

= 2.6.1 - 24th August 2018 =
* Fix display of late loading social media widgets when added to the footer sidebar.

= 2.6 - 25th May 2018 =
* Add support for privacy policy link in the site footer.
* Fix display of the cookie consent checkbox in the comments form.

= 2.5.1 - 21st February 2018 =
* Allow footer content to be filtered.
* Add support for editing the footer content to the wp.org version of the theme.
* Tidy javascript code.

= 2.5 - 31st October 2017 =
* WooCommerce for all (.com and .org).
* Disable infinite-scroll on WooCommerce archive pages.

= 2.4.3 - 4th October 2017 =
* Fix display of contributor description.

= 2.4.2 - 13th July 2017 =
* Remove include for inc/wpcom.php, since it's automatically included by WordPress.com sites

= 2.4.1 - 3rd July 2017 =
* Fix PHP errors due to WooCommerce integration.

= 2.4 - 18th June 2017 =
* Add support for WooCommerce

= 2.3.3 - 10th June 2017 =
* Fix compatibility with new media widgets in WP 4.8

= 2.3.2 - 24th May 2017 =
* Improve Infinite Scroll loading on masonry layout
* Improve social widgets responsiveness when in widgets
* Make WordPress custom logo work, replacing Jetpack site logo (self hosted only)

= 2.3.1 - 21st November 2016 =
* Improve infinite scroll behaviour so that it looks more seamless

= 2.3 - 1st October 2016 =
* Add support for Content Options

= 2.2 - 29 July 2016 =
* Improve rtl.css
* Make site title a touch smaller on small screens

= 2.1.2 - 27 May 2016 =
* Tweak the css for the jetpack subscription form so that it looks better
* Improve video detection in post formats

= 2.1.1 =
* Fix for 'read more' IS button not appearing after the first lot of posts have loaded

= 2.1 =
* Add support for audio post format

= 2.0.1 =
* fix issue with Jetpack tiled galleries

= 2.0 =
* Prepared for WordPress.com

= 1.0 =
* Initial release

== Credits ==

* [Inconsolata](https://www.google.com/fonts/specimen/Inconsolata) Font from Google Fonts, licensed under [SIL Open Font License, 1.1](http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL)
* Genericons: font by Automattic (http://automattic.com/), licensed under [GPL2](https://www.gnu.org/licenses/gpl-2.0.html)
