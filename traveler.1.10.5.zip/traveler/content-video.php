<?php
/**
 * Image content
 *
 * @package Traveler
 */

	$content = apply_filters( 'the_content', get_the_content() );
	$video = get_media_embedded_in_content( $content );

	if ( ! $video ) {

		get_template_part( 'content' );
		return;

	}

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<?php echo traveler_video_wrapper( $video[0] ); ?>

	<a href="<?php the_permalink() ?>" rel="bookmark">
		<section  class="post-details">
			<?php the_title( '<h2 class="posttitle">', '</h2>' ); ?>
		</section>
	</a>

	<?php get_template_part( 'post-meta' ); ?>
</article>
