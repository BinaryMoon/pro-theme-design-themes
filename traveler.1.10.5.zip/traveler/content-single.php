<?php
/**
 * Display single post content
 *
 * @package Traveler
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

<?php
	the_title( '<h1 class="posttitle">', '</h1>' );
	get_template_part( 'inc/postmetadata' );
?>
	<hr class="hr-short" />

	<section class="entry">
		<div class="article-style"><?php the_content(); ?></div>
<?php
	wp_link_pages(
		array(
			'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'traveler' ),
			'after'  => '</div>',
		)
	);

	echo '<span class="post-cats">' . esc_html__( 'Categories: ', 'traveler' );
	the_category( ', ' );
	echo '</span>';

	// Tags.
	the_tags( '<span class="post-taxonomies list-tags">' . esc_html__( 'Tags: ', 'traveler' ), ', ', '</span>' );

	edit_post_link( __( 'Edit Entry', 'traveler' ), '<div id="wp-edit">', '</div>' );
?>
	</section>
<?php
	// Author bio.
	if ( is_single() && function_exists( 'jetpack_author_bio' ) ) {
		jetpack_author_bio();
	}

	// Related posts.
	$query = new WP_Query( traveler_related_posts() );
	if ( $query->have_posts() ) {
?>
	<section id="related-posts">
		<h5 class="widgettitle"><?php esc_html_e( 'Related Articles', 'traveler' ); ?></h5>
		<ul>
<?php
		while ( $query->have_posts() ) {
			$query->the_post();
?>
			<li class="clearfix">
<?php
			if ( has_post_thumbnail() ) {
?>
				<div class="related-thumb">
					<a href="<?php the_permalink(); ?>">
						<?php the_post_thumbnail( 'thumbnail' ); ?>
					</a>
				</div>
<?php
			}
?>
				<div class="related-blurb">
					<h5><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
					<?php get_template_part( 'inc/postmetadata' ); ?>
				</div>
			</li>
<?php
		}

		wp_reset_postdata();
?>
		</ul>
<?php
	}
?>
		</section>
<?php

	if ( comments_open() || '0' !== get_comments_number() ) {
		comments_template();
	}
?>
</article>
