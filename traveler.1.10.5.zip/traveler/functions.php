<?php
/**
 * Theme functions
 *
 * @package Traveler
 */

load_theme_textdomain( 'traveler' );

require 'inc/jetpack.php';

/**
 * Enqueue all the styles
 */
function traveler_styles_init() {

	if ( ! is_admin() ) {
		wp_enqueue_style( 'traveler-style', get_template_directory_uri() . '/css/screen.css', array(), '1.1.1' );
		wp_enqueue_style( 'traveler-style-responsive', get_template_directory_uri() . '/css/responsive.css', array(), '1.1' );
		wp_enqueue_style( 'traveler-style-print', get_template_directory_uri() . '/css/print.css', array(), '1.1', 'print' );
	}

	// Fonts.
	$fonts_url = traveler_fonts();

	if ( $fonts_url ) {
		wp_enqueue_style( 'traveler-fonts', $fonts_url, array(), '1.0' );
	}

}

add_action( 'wp_enqueue_scripts', 'traveler_styles_init' );


/**
 * Shorter Excerpts
 *
 * @param int $length Default length.
 * @return int
 */
function traveler_excerpt_length( $length ) {

	return 20;

}


/**
 * Display a list of the top categories as a menu.
 *
 * @param int $count Number of categories to show.
 */
function traveler_top_categories( $count = 12 ) {

	$params = array(
		'title_li' => '',
		'show_option_all' => 'all',
		'show_option_none' => '',
		'orderby' => 'count',
		'order' => 'DESC',
		'number' => (int) $count,
		'echo' => false,
		'depth' => 2,
	);

	$categories = wp_list_categories( $params );
	$categories = str_ireplace( "<li class='cat-item-all'>", '<li>' . esc_html__( 'Categories :', 'traveler' ) . '</li><li class="cat-item-all">', $categories );

	return $categories;

}


/**
 * Enqueue all the things
 */
function traveler_scripts_init() {

	wp_enqueue_script( 'traveler-script-main', get_template_directory_uri() . '/js/main.js', array( 'jquery', 'traveler-script-responsive-navigation', 'masonry' ), '1.2', true );
	wp_enqueue_script( 'traveler-script-responsive-navigation', get_template_directory_uri() . '/js/responsiveNavigation.js', array( 'jquery' ), '1.0', true );
	wp_enqueue_script( 'traveler-script-superfish', get_template_directory_uri() . '/js/superfish.js', array( 'jquery' ), '1.0', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	wp_localize_script(
		'traveler-script-main',
		'js_i18n',
		array(
			'next' => esc_html__( 'next', 'traveler' ),
			'prev' => esc_html__( 'previous', 'traveler' ),
			'menu' => esc_html__( 'Menu', 'traveler' ),
		)
	);

}

add_action( 'wp_enqueue_scripts', 'traveler_scripts_init' );


/**
 * Set up all the theme properties and extras
 */
function traveler_after_setup_theme() {

	load_theme_textdomain( 'traveler', get_template_directory() . '/languages' );

	add_theme_support( 'automatic-feed-links' );

	// Post thumbnails.
	add_theme_support( 'post-thumbnails' );
	add_image_size( 'traveler-post-thumbnail', 400, 165, true );
	add_image_size( 'traveler-header', 1440, 360, true );
	add_image_size( 'traveler-archive-1', 500, 999 );
	add_image_size( 'traveler-site-logo', 100, 60 );

	// Custom background.
	add_theme_support( 'custom-background' );

	// Title tag.
	add_theme_support( 'title-tag' );

	// Post Formats.
	add_theme_support(
		'post-formats',
		array(
			'quote',
			'video',
			'image',
		)
	);

	// Site logo.
	add_theme_support(
		'site-logo',
		array(
			'size' => 'traveler-site-logo',
		)
	);

	// Add support for full width images and other content such as videos.
	add_theme_support( 'align-wide' );

	// Disable custom font sizes, ensuring consistent vertical rhythm.
	add_theme_support( 'disable-custom-font-sizes' );

	// Make Gutenberg embeds responsive.
	add_theme_support( 'responsive-embeds' );

	// Add support for editor styles.
	add_theme_support( 'editor-styles' );

	// Editor Style.
	$fonts_url = traveler_fonts();

	if ( $fonts_url ) {
		add_editor_style( $fonts_url );
	}

	add_editor_style( 'css/editor-styles.css' );

	// Other things.
	add_filter( 'the_content_more_link', 'traveler_more_link', 10, 2 );
	add_filter( 'wp_page_menu', 'traveler_add_menu_class' );
	add_filter( 'excerpt_length', 'traveler_excerpt_length', 999 );
	add_filter( 'wp_nav_menu', 'traveler_nav_menu_html', 10, 2 );

	// Register navigation.
	register_nav_menus(
		array(
			'top_menu' => esc_html__( 'Top Menu', 'traveler' ),
			'category_menu' => esc_html__( 'Under Header.', 'traveler' ),
		)
	);

	// Editor font sizes.
	// Uses the default slugs to ensure consistency across themes.
	add_theme_support(
		'editor-font-sizes',
		array(
			array(
				'name' => esc_html__( 'small', 'traveler' ),
				'size' => 15.5,
				'slug' => 'small',
			),
			array(
				'name' => esc_html__( 'normal', 'traveler' ),
				'size' => 19.3,
				'slug' => 'normal',
			),
			array(
				'name' => esc_html__( 'medium', 'traveler' ),
				'size' => 23.2,
				'slug' => 'medium',
			),
			array(
				'name' => esc_html__( 'large', 'traveler' ),
				'size' => 33,
				'slug' => 'large',
			),
			array(
				'name' => esc_html__( 'huge', 'traveler' ),
				'size' => 38,
				'slug' => 'huge',
			),
		)
	);

}

add_action( 'after_setup_theme', 'traveler_after_setup_theme' );



/**
 * Enqueue WordPress theme styles within Gutenberg.
 */
function traveler_editor_blocks_styles() {

	// Load the additional editor styles.
	// This covers things like the editor title that can't be styled with the normal editor styles.
	wp_enqueue_style( 'traveler-editor-blocks', get_theme_file_uri( '/css/editor-blocks.css' ), null, '1' );

	/**
	 * Overwrite Core theme styles with empty styles.
	 *
	 * @see https://github.com/WordPress/gutenberg/issues/7776#issuecomment-406700703
	 */
	wp_deregister_style( 'wp-block-library-theme' );
	wp_register_style( 'wp-block-library-theme', '' );

	// Add dark mode editor.
	add_theme_support( 'dark-editor-style' );

}

add_action( 'enqueue_block_editor_assets', 'traveler_editor_blocks_styles' );
add_action( 'enqueue_block_assets', 'traveler_editor_blocks_styles' );


/**
 * Get url for Google fonts.
 */
function traveler_fonts() {

	/**
	 * Translators: If there are characters in your language that are not
	 * supported, translate this to 'off'. Do not translate into your
	 * own language.
	 */
	$font = _x( 'on', 'Montserrat: on or off', 'traveler' );
	if ( 'off' !== $font ) {
		$fonts['montserrat'] = 'Montserrat:400,400i,700';
	}

	/**
	 * Translators: If there are characters in your language that are not
	 * supported, translate this to 'off'. Do not translate into your
	 * own language.
	 */
	$font = _x( 'on', 'PT Serif: on or off', 'traveler' );
	if ( 'off' !== $font ) {
		$fonts['pt-serif'] = 'PT+Serif:300,300i,400,400i,700';
	}

	$fonts = apply_filters( 'traveler_fonts', $fonts );

	if ( $fonts ) {

		$query_args = array(
			'family' => rawurlencode( implode( '|', $fonts ) ),
			'subset' => rawurlencode( 'latin,latin-ext' ),
			'display' => 'swap',
		);

		return add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );

	}

}


/**
 * Register sidebar
 */
function traveler_widgets_init() {

	// Sidebar.
	register_sidebar(
		array(
			'name' => esc_html__( 'Footer Widgets', 'traveler' ),
			'id' => 'sidebar-1',
			'description' => esc_html__( 'Widgets that display in the footer of your website', 'traveler' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s"><div class="widget-wrap">',
			'after_widget' => '</div></aside>',
			'before_title' => '<h3 class="widgettitle">',
			'after_title' => '</h3>',
		)
	);

}

add_action( 'widgets_init', 'traveler_widgets_init' );


/**
 * Custom read more text.
 *
 * @param string $more Current read more text.
 * @return string
 */
function traveler_excerptmore( $more ) {

	return '... <a href="' . esc_url( get_permalink() ) . '">' . esc_html__( 'Read More', 'traveler' ) . '</a>';

}


/**
 * Change more link text.
 *
 * @param string $more_link The current link text.
 * @param string $more_link_text The default 'more link' text.
 * @return string
 */
function traveler_more_link( $more_link, $more_link_text ) {

	return str_replace( $more_link_text, esc_html__( 'Continue reading &rarr;', 'traveler' ), $more_link );

}


/**
 * Add a consistent class to menu links.
 *
 * @param string $html Current list html.
 * @return string
 */
function traveler_add_menu_class( $html ) {

	return preg_replace( '/<ul>/', '<ul id="nav">', $html, 1 );

}


/**
 * Display numbered pagination.
 *
 * @global object $wp_query
 * @param int    $page_count Number of pages to display in the pagination.
 * @param object $query WP_Query object for the current page.
 * @return void
 */
function traveler_numeric_pagination( $page_count = 9, $query = null ) {

	global $wp_query, $wp_rewrite;

	if ( null === $query ) {
		$query = $wp_query;
	}

	if ( 1 >= $query->max_num_pages ) {
		return;
	}

	$paged = get_query_var( 'paged' ) ? intval( get_query_var( 'paged' ) ) : 1;
	$pagenum_link = html_entity_decode( get_pagenum_link() );
	$query_args = array();
	$url_parts = explode( '?', $pagenum_link );

	if ( isset( $url_parts[1] ) ) {
		wp_parse_str( $url_parts[1], $query_args );
	}

	$pagenum_link = remove_query_arg( array_keys( $query_args ), $pagenum_link );
	$pagenum_link = trailingslashit( $pagenum_link ) . '%_%';

	$format = $wp_rewrite->using_index_permalinks() && ! strpos( $pagenum_link, 'index.php' ) ? 'index.php/' : '';
	$format .= $wp_rewrite->using_permalinks() ? user_trailingslashit( $wp_rewrite->pagination_base . '/%#%', 'paged' ) : '?paged=%#%';

	// Set up paginated links.
	$links = paginate_links(
		array(
			'base'     => $pagenum_link,
			'format'   => $format,
			'total'    => $query->max_num_pages,
			'current'  => $paged,
			'mid_size' => $page_count,
			'add_args' => array_map( 'urlencode', $query_args ),
			'next_text' => esc_html__( 'Older &rsaquo;', 'traveler' ),
			'prev_text' => esc_html__( '&lsaquo; Newer', 'traveler' ),
		)
	);

	if ( $links ) {
?>
	<nav class="archive-pagination pagination" id="archive-pagination" role="navigation">
		<h1 class="screen-reader"><?php esc_html_e( 'Posts navigation', 'traveler' ); ?></h1>
		<?php echo $links; ?>
	</nav>
<?php
	}

}


/**
 * Convert a complex time into a nicely human readable one.
 *
 * @return string
 */
function traveler_human_time() {

	$post_time = get_the_time( 'U' );
	$human_time = '';

	$time_now = gmdate( 'U' );

	// Use human time if less that 60 days ago
	// 60 seconds * 60 minutes * 24 hours * 90 days.
	if ( $post_time > $time_now - ( 60 * 60 * 24 * 90 ) ) {
		// Translators: %s = time.
		$human_time = sprintf( esc_html__( '%s ago', 'traveler' ), human_time_diff( $post_time, current_time( 'timestamp' ) ) );
	} else {
		$human_time = get_the_date();
	}

	return $human_time;

}


/**
 * Grab the number of likes a post has had
 *
 * @return number of likes/ false
 */
function traveler_post_like_stats() {

	$likes_visible_jetpack = false;

	if ( class_exists( 'Jetpack_Likes_Settings' ) ) {
		$likes_settings = new Jetpack_Likes_Settings();
		$likes_visible_jetpack = $likes_settings->is_likes_visible();
	}

	// Check old Jetpack class.
	if ( ! $likes_visible_jetpack && method_exists( 'Jetpack_Likes', 'is_likes_visible' ) ) {
		$likes_visible_jetpack = Jetpack_Likes::init()->is_likes_visible();
	}

	// If likes are disabled then quit.
	if ( ! $likes_visible_jetpack ) {
		return false;
	}

	// Get blog id.
	if ( defined( 'IS_WPCOM' ) && IS_WPCOM ) {
		$blog_id = get_current_blog_id();
	} else {
		$blog_id = Jetpack_Options::get_option( 'id' );
	}

	$post_id = get_the_ID();

	/**
	 * Example likes url (from travelerdemo.wordpress.com):
	 * https://public-api.wordpress.com/rest/v1/sites/57079153/posts/65/likes/.
	 */
	$likes_url = sprintf(
		'https://public-api.wordpress.com/rest/v1/sites/%1$d/posts/%2$d/likes/',
		(int) $blog_id,
		(int) $post_id
	);

	$response = wp_remote_get( $likes_url );

	if ( is_wp_error( $response ) ) {
		return false;
	}

	$response = json_decode( $response['body'] );

	return $response->found;

}


/**
 * Generate list of related posts.
 *
 * @global type $post
 */
function traveler_related_posts() {

	global $post;
	$categories = get_the_category();
	$cat_list = array();

	foreach ( $categories as $c ) {
		$cat_list[] = $c->term_id;
	}

	return array(
		'cat' => implode( ',', $cat_list ),
		'posts_per_page' => 3,
		'post__not_in' => array( $post->ID ),
		'meta_key' => '_thumbnail_id',
	);

}


/**
 * Comments Callback
 *
 * This code abstracts out comment code and makes the markup editable
 *
 * @param type $comment
 * @param type $args
 * @param type $depth
 */
function traveler_comment( $comment, $args, $depth ) {

	$GLOBALS['comment'] = $comment;
	$GLOBALS['comment_depth'] = $depth;

?>
	<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
		<div id="comment-<?php comment_ID(); ?>">
			<div class="comment-author vcard clearfloat">
				<?php echo get_avatar( $comment, $size = '40' ); ?>
				<div class="commentmetadata">
					<?php printf( '<cite class="fn">%s</cite>', get_comment_author_link() ); ?>
					<div class="comment-date">
						<a href="<?php echo esc_url( get_comment_link( $comment->comment_ID ) ); ?>">
							<?php printf( esc_html__( '%1$s &bull; %2$s', 'traveler' ), esc_html( get_comment_date() ), esc_html( get_comment_time() ) ); ?>
						</a>
						<?php edit_comment_link( esc_html__( 'Edit', 'traveler' ) ); ?>
					</div>
				</div>
			</div>
<?php
	if ( 0 === $comment->comment_approved ) {
?>
			<p class="comment-mod"><em><?php esc_html_e( 'Your comment is awaiting moderation.', 'traveler' ); ?></em></p>
<?php
	}

	if ( 'comment' === $comment->comment_type || empty( $comment->comment_type ) ) {
		comment_text();

?>
			<div class="reply">
<?php
		comment_reply_link(
			array_merge(
				$args,
				array(
					'depth' => $depth,
					'reply_text' => esc_html__( 'Reply &darr;', 'traveler' ),
					'login_text' => esc_html__( 'Log in to reply', 'traveler' ),
					'max_depth' => $args['max_depth'],
				)
			)
		);
?>
			</div>
<?php
	}
?>
		</div>
<?php

}


/**
 * Get details for the current attachment
 *
 * @global <type> $post
 * @return <type>
 */
function traveler_attachment_details() {

	global $post;

	$ret['image'] = wp_get_attachment_link( $post->ID, array( 1280, 1280 ) );
	$ret['info'] = wp_get_attachment_image_src( $post->ID, array( 1280, 1280 ) );

	if ( isset( $post->iconsize ) && $post->iconsize[0] <= 256 ) {
		$ret['classname'] = 'small_attachment attachment';
	} else {
		$ret['classname'] = 'attachment-content';
	}

	$ret = apply_filters( 'bm_attachment_details', $ret );

	return $ret;

}


/**
 * Add custom body class styles to defaults
 *
 * @param array $classes List of body classes.
 * @return string
 */
function traveler_body_class( $classes ) {

	if ( get_theme_mod( 'traveler_display_category_navigation', true ) ) {
		$classes[] = 'traveler_category_navigation_on';
	} else {
		$classes[] = 'traveler_category_navigation_off';
	}

	if ( get_theme_mod( 'traveler_display_header_overlay', false ) ) {
		$classes[] = 'traveler_header_overlay';
	}

	$classes[] = 'traveler_header_height_' . (int) get_theme_mod( 'traveler_header_height', 1 );

	return $classes;

}

add_filter( 'body_class', 'traveler_body_class' );


if ( ! isset( $content_width ) ) {
	$content_width = 1280;
}



/**
 * Filter category menu html so that it displays in the same way as the fallback menu.
 *
 * @param  string $html The menu html.
 * @param  object $args Menu properties.
 * @return string
 */
function traveler_nav_menu_html( $html, $args ) {

	// Return if it's not the category menu.
	if ( 'category_menu' != $args->theme_location ) {
		return $html;
	}

	$html = '<section class="toolbar category-toolbar">
		<section class="row clearfix">
			<div class="cat-details">' . $html . '</div>
		</section>
	</section>';

	return $html;

}


/**
 * A fallback menu display.
 *
 * This uses the previous category menu setup so that sites setup before version
 * 1.6 will continue to display in the same way.
 *
 * @since 1.6
 */
function traveler_nav_menu() {

	if ( ! get_theme_mod( 'traveler_display_category_navigation', true ) ) {
		return;
	}

?>

	<section class="toolbar category-toolbar">
		<section class="row clearfix">
			<div class="cat-details">
				<ul class="menu list-cats menu-below">
					<?php echo traveler_top_categories(); ?>
				</ul>
			</div>
			<?php if ( ! is_singular() ) { ?>
				<div class="toggles">
					<a class="masonry-toggle display-masonry"><?php esc_html_e( 'Linear view vs. Masonry View', 'traveler' ); ?></a>
				</div>
			<?php } ?>
		</section>
	</section>

<?php

}

require 'inc/custom-header.php';

require 'inc/customizer.php';
