<?php
/**
 * Audio content
 *
 * @package Traveler
 */

	$content = apply_filters( 'the_content', get_the_content() );
	$audio = get_media_embedded_in_content( $content, array( 'audio' ) );

	if ( ! $audio ) {

		get_template_part( 'content' );
		return;

	}

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<div class="entry-audio">
		<?php echo $audio[0]; /* WPCS: xss ok. */ ?>
	</div>

	<a href="<?php the_permalink() ?>" rel="bookmark">
		<section  class="post-details">
			<?php the_title( '<h2 class="posttitle">', '</h2>' ); ?>
			<section class="entry">
				<?php the_excerpt(); ?>
			</section>
		</section>
	</a>

	<?php get_template_part( 'post-meta' ); ?>
</article>
