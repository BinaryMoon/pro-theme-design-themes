<?php
/**
 * Site header
 *
 * @package Traveler
 */

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
	<!--[if lt IE 9]><script src="<?php echo get_template_directory_uri(); ?>/js/html5.js"></script><![endif]-->

	<?php wp_head(); ?>

</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="masthead cf" role="banner">
	<section class="row clearfix">
		<nav class="menu clearfix">
<?php
	wp_nav_menu(
		array(
			'theme_location' => 'top_menu',
			'menu_id' => 'nav',
			'menu_class' => 'menu-wrap nav clearfix',
		)
	);
?>
		</nav>

		<div class="branding">
			<?php if ( function_exists( 'jetpack_the_site_logo' ) ) { jetpack_the_site_logo(); } ?>
			<h1 class="logo site-title">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php esc_attr_e( 'Home', 'traveler' ); ?>">
					<?php bloginfo( 'name' ); ?>
				</a>
			</h1>
			<h2 class="description site-description">
				<?php bloginfo( 'description' ); ?>
			</h2>
		</div>

	</section>

</header>

<section class="container hfeed">
<?php

	wp_nav_menu(
		array(
			'theme_location' => 'category_menu',
			'menu_id' => 'nav',
			'menu_class' => 'menu menu-wrap menu-below',
			'container' => false,
			'item_spacing' => 'discard',
			'fallback_cb' => 'traveler_nav_menu',
		)
	);

	do_action( 'before' );

?>
	<section class="row" id="content-wrapper">

		<section class="main">
			<section class="row">
