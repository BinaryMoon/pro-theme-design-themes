<?php
/**
 * Regular post page
 *
 * @package Traveler
 */

	get_header();

	if ( have_posts() ) {

		echo '<div class="masonry-container" id="wrapper">';

		while ( have_posts() ) {
			the_post();
			get_template_part( 'content', get_post_format() );
		}

		echo '</div>';

		traveler_numeric_pagination();

	}

	get_footer();
