<?php
/**
 * Archives
 *
 * @package Traveler
 */

	get_header();

	if ( have_posts() ) {

		if ( is_category() ) {
?>
		<h1 class="pagetitle"><?php printf( esc_html__( 'Archive for &#8216;%s&#8217;', 'traveler' ), single_cat_title( '', false ) ); ?></h1>
<?php
		} elseif ( is_tag() ) {
?>
		<h1 class="pagetitle"><?php printf( esc_html__( 'Tag Archive for &#8216;%s&#8217;', 'traveler' ), single_tag_title( '', false ) ); ?></h1>
<?php
		} elseif ( is_day() ) {
?>
		<h1 class="pagetitle"><?php printf( esc_html__( 'Archive for %s', 'traveler' ), get_the_date( 'F jS, Y' ) ); ?></h1>
<?php
		} elseif ( is_month() ) {
?>
		<h1 class="pagetitle"><?php printf( esc_html__( 'Archive for %s', 'traveler' ), get_the_date( 'F Y' ) ); ?></h1>
<?php
		} elseif ( is_year() ) {
?>
		<h1 class="pagetitle"><?php printf( esc_html__( 'Archive for %s', 'traveler' ), get_the_date( 'Y' ) ); ?></h1>
<?php
		} elseif ( isset( $_GET['paged'] ) && ! empty( $_GET['paged'] ) ) {
?>
		<h1 class="pagetitle"><?php esc_html_e( 'Blog Archives', 'traveler' ); ?></h1>
<?php
		} else {

			the_archive_title( '<h1 class="pagetitle">', '</h1>' );

		}

		the_archive_description( '<div class="category_description">', '</div>' );

		if ( have_posts() ) {

			echo '<div class="masonry-container" id="wrapper">';
			while ( have_posts() ) {
				the_post();
				get_template_part( 'content', get_post_format() );
			}
			echo '</div>';
			traveler_numeric_pagination();

		}
	} else {

?>
		<h2><?php esc_html_e( 'Not Found', 'traveler' ); ?></h2>
<?php
	} // End if().

	get_footer();
