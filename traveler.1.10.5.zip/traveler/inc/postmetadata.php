<?php
/**
 * Post Meta data
 *
 * @package Traveler
 */
?>
	<div class="postmetadata">
<?php
	printf( __( '<em>By</em> <span class="author vcard meta"><a class="url fn n" href="%5$s" title="%6$s" rel="author">%7$s</a></span><time class="entry-date meta" datetime="%3$s">%4$s</time>', 'traveler' ),
		esc_url( get_permalink() ),
		esc_attr( get_the_time() ),
		esc_attr( get_the_date( 'c' ) ),
		esc_html( traveler_human_time() ),
		esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
		esc_attr( sprintf( __( 'View all posts by %s', 'traveler' ), get_the_author() ) ),
		esc_html( get_the_author() )
	);

	// Only display comment count if appropriate.
	if ( ! post_password_required() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) {
?>
	<span class="commentcount meta">( <?php comments_popup_link( __( '0', 'traveler' ), __( '1', 'traveler' ), __( '%', 'traveler' ), 'comments_link'); ?> )</span>
<?php
	}
?>
	</div>
