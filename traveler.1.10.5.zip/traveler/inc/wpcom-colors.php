<?php
/**
 * Theme: Traveler
 *
 * @package: traveler
 */

/**
 * Background
 */
add_color_rule(
	'bg',
	'#1e2123',
	array(

		array(
			'body, .masthead',
			'background-color'
		),

		array(
			'.masonry-container article.post, .masonry-container .postmetadata, .masonry-container .commentcount, .masonry-container .likes',
			'border-color'
		),

	),
	__( 'Background' )
);

/**
 * Primary Color
 */
add_color_rule( 'txt', '#1e2123', array(
	array( '.toolbar', 'background-color' ),
	array( '.chrono, .single article, .page article', 'background-color' ),
	array( '.toolbar, .masonry-toggle:hover', 'border-color', '-2' ),
	array( '.home .menu.menu-below li.cat-item-all, .menu.list-cats li:hover, .menu.list-cats li.current-cat, .masonry-toggle', 'border-color', '-3' ),
	array( 'hr, .hr-short', 'background-color', '-1' ),
	array( 'hr, .hr-short', 'color', '-1' ),
	array( '#respond, #comments, #related-posts, #related-posts li', 'border-top-color', '-1' ),
	array( '#infinite-handle span', 'background-color' ),
	array( '#infinite-handle span:hover', 'background-color', '-1' ),
	array( 'footer', 'background-color' ),
	array( 'article .entry blockquote', 'border-color', '-1' ),
	array( '.masonry-container article.post', 'background-color' ),
	array( 'input, textarea', 'background-color', '+1' ),
	array( '.masonry-container article:hover .postmetadata', 'background-color', '-1' ),
), __( 'Content Background' ) );

add_color_rule( 'extra', '#747c87', array(
	array( '.toolbar', 'color', 'txt' ),
));
add_color_rule( 'extra', '#f6f8fa', array(
	array( '.menu.list-cats a', 'color', 'txt' ),
	array( 'a, h1.posttitle, h2.pagetitle, .menu a:hover, .pagetitle, .masonry-container a:hover, h3#reply-title, .post-edit-link:hover, h3#comments, #related-posts h5', 'color', 'txt' ),
));
add_color_rule( 'extra', '#7f919d', array(
	array( 'body.single .entry p, body.page .entry p', 'color', 'txt' ),
));
add_color_rule( 'extra', '#8ebae1', array(
	array( 'a:hover, a:active', 'color', 'txt' ),
));
add_color_rule( 'extra', '#798a95', array(
	array( 'body, .masonry-container p, .chrono p, .postmetadata .commentcount a', 'color', 'txt' ),
));
add_color_rule( 'extra', '#ffffff', array(
	array( '#infinite-handle span, .postmetadata .commentcount a:hover', 'color', 'txt' ),
));
add_color_rule( 'extra', '#3471A6', array(
	array( 'a:hover, a:active', 'color', 'txt' ),
));
add_color_rule( 'extra', '#111111', array(
	array( 'input, textarea', 'color', 'txt' ),
));

/**
 * Links.
 */
add_color_rule( 'link', '#f6f8fa', array(
	array( 'header.masthead h2.description', 'color' ),
	array( '.masthead .menu a, .masthead .menu a:hover', 'color' ),
	array( '.menu li.current_page_item, .menu li:hover', 'border-color', .25 ),
	array( '.menu li ul li:hover', 'background-color', '-1' ),
	array( '.menu ul.children', 'background-color' ),
	array( '.masthead .menu .children a', 'color', 'link' ),
	array( '.menu ul ul:after, ul.menu.list-cats ul:after', 'border-bottom-color' ),
), __( 'Primary Menu' ) );

add_color_rule( 'extra', '#1e2123', array(
	array( '.masthead .menu .sub-menu a, .masthead .menu .sub-menu a:hover', 'color', 'link' ),
));

/**
 * Accent #1, unused by theme
 */
add_color_rule( 'fg1', '#f2f2f2', array(

) );

/**
 * Accent #2, unused by theme
 */
add_color_rule( 'fg2', '#f2f2f2', array(

) );

/**
 * Custom CSS
 */
function traveler_extra_css() { ?>
	.menu li ul {
		box-shadow: 1px 1px 1px 1px rgba( 0, 0, 0, .2 );
	}
	article .entry code {
		background-color: rgba( 255, 255, 255, .2 );
		color: rgba( 0, 0, 0, .8 );
	}
<?php }

add_theme_support( 'custom_colors_extra_css', 'traveler_extra_css' );

// Additional color palettes.f
add_color_palette( array(
	'#ffffff',
	'#efeff4',
	'#efeff4',
	'',
	'',
), 'All White' );

add_color_palette( array(
	'#e8ddcb',
	'#cdb380',
	'#ff9313',
	'',
	'',
), 'Sand' );

add_color_palette( array(
	'#4879a1',
	'#86a9c5',
	'#ffffff',
	'',
	'',
), 'Atmosphere' );

add_color_palette( array(
	'#382a40',
	'#75457c',
	'#ccb4de',
	'',
	'',
), 'Plum' );
