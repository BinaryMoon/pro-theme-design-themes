<?php
/**
 * Jetpack Compatibility File
 * See: http://jetpack.me/
 *
 * @package traveler
 */

/**
 * Add theme support for Infinite Scroll.
 * See: http://jetpack.me/support/infinite-scroll/
 */
function traveler_infinite_scroll_init() {

	add_theme_support(
		'infinite-scroll',
		array(
			'container' => 'wrapper',
			'footer_widgets' => 'sidebar-1',
			'render' => 'traveler_infinite_scroll_render',
			'footer' => 'footer-wrap',
			'wrapper' => false,
		)
	);

	add_theme_support( 'jetpack-responsive-videos' );

	// Add support for Jetpack content options.
	add_theme_support(
		'jetpack-content-options',
		array(
			// The default setting of the theme: 'content', 'excerpt' or array( 'content, 'excerpt', ).
			'blog-display' => 'excerpt',
			'author-bio' => true,
			'author-bio-default' => false,
			'masonry' => '.masonry-container',
			'post-details' => array(
				'stylesheet' => 'traveler-style',
				'date' => '.entry-date',
				'categories' => '.post-cats',
				'tags' => '.post-taxonomies.list-tags',
				'author' => '.postmetadata em, .postmetadata .author',
			),
		)
	);

}

add_action( 'after_setup_theme', 'traveler_infinite_scroll_init' );


/**
 * Filter author bio avatar size.
 */
function traveler_author_bio_avatar_size() {

	return 80;

}

add_filter( 'jetpack_author_bio_avatar_size', 'traveler_author_bio_avatar_size' );


/**
 * Set the code to be rendered on for calling posts, hooked to template parts when possible.
 *
 * Note: must define a loop.
 */
function traveler_infinite_scroll_render() {

	while ( have_posts() ) {

		the_post();
		get_template_part( 'content', get_post_format() );

	}

}


/**
 * Use the Jetpack Video Embed HTML to make sure the video post types are responsive
 * Has a simple fallback in case Jetpack is not available.
 *
 * @param string $html Video html.
 * @return string html wrapper with the video wrapper.
 */
function traveler_video_wrapper( $html ) {

	if ( function_exists( 'jetpack_responsive_videos_embed_html' ) ) {

		return jetpack_responsive_videos_embed_html( $html );

	} else {

		return '<div class="jetpack-video-wrapper">' . $html . '</div>';

	}

}
