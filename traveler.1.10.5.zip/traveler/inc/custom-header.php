<?php
/**
 * Custom Header
 *
 * @link https://developer.wordpress.org/themes/functionality/custom-headers/
 *
 * @package Traveler
 * @subpackage CustomHeader
 * @author Ben Gillbanks <ben@prothemedesign.com>
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU Public License
 */

/**
 * Add theme support for Custom Header image.
 *
 * Sets the default properties and the custom header callback {@see traveler_colour_styles}.
 */
function traveler_custom_header_support() {

	// Custom header image.
	add_theme_support(
		'custom-header',
		array(
			'default-image' => apply_filters( 'traveler_header_image', '%s/images/headers/clouds.jpg' ),
			'default-text-color' => apply_filters( 'traveler_header_colour', 'f6f8fa' ),
			'random-default' => false,
			'width' => 1440,
			'height' => 360,
			'flex-height' => false,
			'header-text' => true,
			'uploads' => true,
			'wp-head-callback' => 'traveler_colour_styles',
		)
	);


	// Add some default header images.
	register_default_headers(
		array(
			'clouds' => array(
				'url' => '%s/images/headers/clouds.jpg',
				'thumbnail_url' => '%s/images/headers/clouds.thumbnail.jpg',
				'description' => esc_html__( 'Clouds', 'traveler' ),
			),
			'trees' => array(
				'url' => '%s/images/headers/trees.jpg',
				'thumbnail_url' => '%s/images/headers/trees.thumbnail.jpg',
				'description' => esc_html__( 'Trees', 'traveler' ),
			),
			'rocks' => array(
				'url' => '%s/images/headers/rocks.jpg',
				'thumbnail_url' => '%s/images/headers/rocks.thumbnail.jpg',
				'description' => esc_html__( 'Rocks', 'traveler' ),
			),
		)
	);

}

add_action( 'after_setup_theme', 'traveler_custom_header_support' );


/**
 * Print custom header styles.
 *
 * May also change other CSS properties related to the header colours.
 */
function traveler_colour_styles() {

	/**
	 * Header image.
	 */
	traveler_header_styles();

	/**
	 * Take care of header text color and visibility.
	 */
	$header_text_color = get_header_textcolor();

	/**
	 * If no custom options for text are set, let's bail.
	 * get_header_textcolor() options: Any hex value, 'blank' to hide text.
	 * Default: add_theme_support( 'custom-header' ).
	 */
	if ( get_theme_support( 'custom-header', 'default-text-color' ) === $header_text_color ) {
		return;
	}

	if ( ! display_header_text() ) {
?>
<style>
	header.masthead h1.logo,
	header.masthead h1.logo a,
	header.masthead h1.logo a:hover,
	header.masthead h2.description {
		clip: rect( 1px, 1px, 1px, 1px );
		position: absolute;
	}
</style>
<?php
	} else {
?>
<style>
	header.masthead h1.logo,
	header.masthead h1.logo a,
	header.masthead h1.logo a:hover,
	header.masthead h2.description {
		color: #<?php echo esc_attr( $header_text_color ); ?>;
	}
</style>
<?php
	}

}


/**
 * Display the header image.
 */
function traveler_header_styles() {

	if ( is_singular() && get_theme_mod( 'traveler_display_featured_image', false ) ) {

		$image = get_the_post_thumbnail_url( get_the_ID(), 'traveler-header' );

		if ( $image ) {

?>
		<style>
			header.masthead { background-image:url(<?php echo esc_url( $image ); ?>); }
		</style>
<?php

			/**
			 * We are on a single post/ page/ project/ whatever and there's a
			 * header image, so quit early.
			 */
			return;

		}

	}

	/**
	 * Default behaviour.
	 */
	if ( get_header_image() ) {

?>
		<style>
			header.masthead { background-image:url(<?php header_image(); ?>); }
		</style>
<?php

	}

}