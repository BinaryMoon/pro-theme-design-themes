<?php
/**
 * Custom Editor Colors: Traveler
 *
 * @package traveler
 */

/**
 * Background Color (Dark)
 * $config-global--color-background-default
 */
add_editor_color_rule(
	'bg',
	'#1e2123',
	array()
);

add_color_rule(
	'txt',
	'#1e2123',
	array(

		// Background-color.
		array(
			'#editor .editor-styles-wrapper',
			'background-color',
		),

	)
);

add_editor_color_rule(
	'link',
	'#f6f8fa',
	array(

		// Post title.
		array( '#editor .editor-post-title__block .editor-post-title__input', 'color', 'txt' ),

		// Links.
		array( '#editor .editor-styles-wrapper a, #editor .editor-styles-wrapper a:hover', 'color', 'txt' ),

		// Text color.
		array(
			'#editor .editor-styles-wrapper',
			'color',
			'txt',
			4,
		),

		// Headings.
		array(
			'#editor .editor-styles-wrapper h1, #editor .editor-styles-wrapper h2, #editor .editor-styles-wrapper h3, #editor .editor-styles-wrapper h4, #editor .editor-styles-wrapper h5, #editor .editor-styles-wrapper h6,
			#editor .editor-styles-wrapper h1 a, #editor .editor-styles-wrapper h2 a, #editor .editor-styles-wrapper h3 a, #editor .editor-styles-wrapper h4 a, #editor .editor-styles-wrapper h5 a, #editor .editor-styles-wrapper h6 a',
			'color',
			'txt',
		),

	)
);
