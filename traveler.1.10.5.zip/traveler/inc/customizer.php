<?php
/**
 * Theme Customizer
 *
 * @link https://developer.wordpress.org/themes/advanced-topics/customizer-api/
 *
 * @package Traveler
 */

/**
 * Exit if we're not in the Customizer.
 */
if ( ! class_exists( 'WP_Customize_Control' ) ) {

	return null;

}


/**
 * Theme customizer properties
 *
 * @param object $wp_customize Customize object.
 */
function traveler_customizer_settings( $wp_customize ) {

	// Traveler theme options section.
	$wp_customize->add_section(
		'traveler_options',
		array(
			'title' => esc_html__( 'Theme', 'traveler' ),
			'description' => esc_html__( 'Options for the Traveler theme.', 'traveler' ),
		)
	);

	// Setting to allow the categories under the header to be hidden.
	$wp_customize->add_setting(
		'traveler_display_category_navigation',
		array(
			'default' => true,
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'traveler_sanitize_checkboxes',
		)
	);

	// Control for hiding the category list under the header.
	$wp_customize->add_control(
		'traveler_display_category_navigation',
		array(
			'label' => esc_html__( 'Display Category Navigation', 'traveler' ),
			'section' => 'traveler_options',
			'type' => 'checkbox',
		)
	);

	// Setting to allow the header height to be adjusted.
	$wp_customize->add_setting(
		'traveler_header_height',
		array(
			'default' => 1,
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'traveler_sanitize_int',
		)
	);

	// Control for changing the header height.
	$wp_customize->add_control(
		'traveler_header_height',
		array(
			'label' => esc_html__( 'Header height', 'traveler' ),
			'section' => 'traveler_options',
			'type' => 'radio',
			'choices'  => array(
				1 => esc_html__( 'default - tall on homepage, short on other pages', 'traveler' ),
				2 => esc_html__( 'short', 'traveler' ),
				3 => esc_html__( 'tall', 'traveler' ),
			),
		)
	);

	// Setting to allow the categories under the header to be hidden.
	$wp_customize->add_setting(
		'traveler_display_featured_image',
		array(
			'default' => false,
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'traveler_sanitize_checkboxes',
		)
	);

	// Control for hiding the category list under the header.
	$wp_customize->add_control(
		'traveler_display_featured_image',
		array(
			'label' => esc_html__( 'Display Featured Images in Header on Single posts, and pages', 'traveler' ),
			'section' => 'traveler_options',
			'type' => 'checkbox',
		)
	);

	// Setting to allow the categories under the header to be hidden.
	$wp_customize->add_setting(
		'traveler_display_header_overlay',
		array(
			'default' => false,
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'traveler_sanitize_checkboxes',
		)
	);

	// Control for hiding the category list under the header.
	$wp_customize->add_control(
		'traveler_display_header_overlay',
		array(
			'label' => esc_html__( 'Add overlay on top of header images to ensure the text can be read', 'traveler' ),
			'section' => 'traveler_options',
			'type' => 'checkbox',
		)
	);



}

add_action( 'customize_register', 'traveler_customizer_settings' );


/**
 * Update Theme Elements without refreshing content.
 *
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function traveler_register_customize_refresh( WP_Customize_Manager $wp_customize ) {

	// Ensure selective refresh is enabled.
	if ( ! isset( $wp_customize->selective_refresh ) ) {

		return false;

	}

	// Update site title.
	$wp_customize->get_setting( 'blogname' )->transport = 'postMessage';

	$wp_customize->selective_refresh->add_partial(
		'blogname',
		array(
			'selector' => '.site-title',
			'render_callback' => function() {
				bloginfo( 'name' );
			},
		)
	);

	// Update site description.
	$wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';

	$wp_customize->selective_refresh->add_partial(
		'blogdescription',
		array(
			'selector' => '.site-description',
			'render_callback' => function() {
				bloginfo( 'description' );
			},
		)
	);

	// Show and hide header text.
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

	// Change header height.
	$wp_customize->get_setting( 'traveler_header_height' )->transport = 'postMessage';

}

add_action( 'customize_register', 'traveler_register_customize_refresh' );


/**
 * Sanitize the category navigation setting
 *
 * @param int $setting Setting value.
 * @return int|string
 */
function traveler_sanitize_checkboxes( $setting ) {

	return (bool) $setting;

}


/**
 * Sanitize the category navigation setting
 *
 * @param int $setting Setting value.
 * @return int|string
 */
function traveler_sanitize_int( $setting ) {

	return (int) $setting;

}


/**
 * Binds JS handlers to make the Customizer preview reload changes asynchronously.
 */
function traveler_customize_preview_js() {

	wp_enqueue_script( 'traveler-customize-preview', get_theme_file_uri( '/js/customizer-preview.js' ), array( 'customize-preview' ), '1.0', true );

}

add_action( 'customize_preview_init', 'traveler_customize_preview_js' );
