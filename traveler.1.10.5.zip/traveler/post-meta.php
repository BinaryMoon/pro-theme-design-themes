<?php
/**
 * Content meta data for homepage and archive pages
 *
 * @package Traveler
 */

?>

	<section class="postmetadata">
		<time class="entry-date" datetime="<?php echo get_the_time( 'U' ); ?>"><?php echo traveler_human_time(); ?></time>
<?php
	if ( comments_open() ) {
?>
		<span class="commentcount"><?php comments_popup_link( '0', '1', '%', esc_html__( 'comments_link', 'traveler' ) ); ?></span>
<?php
	}

	if ( $like_stats = traveler_post_like_stats() ) {
?>
		<span class="likes"><?php echo $like_stats; ?></span>
<?php
	}
?>
	</section>
