<?php
/**
 * Display paged content
 *
 * @package Traveler
 */

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<h1 class="pagetitle">
		<?php the_title(); ?>
	</h1>
	<hr class="hr-short" />
	<section class="entry article-style">
<?php
	the_content();
	edit_post_link( esc_html__( 'Edit Entry', 'traveler' ), '<p class="wp-edit">', '</p>' );
	wp_link_pages(
		array(
			'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'traveler' ),
			'after'  => '</div>',
		)
	);
?>
	</section>
<?php
	if ( comments_open() || '0' != get_comments_number() ) {
		comments_template();
	}
?>
</article>
