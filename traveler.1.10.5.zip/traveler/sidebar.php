<?php
/**
 * Sidebar template
 *
 * @package Traveler
 */

	if ( is_active_sidebar( 'sidebar-1' ) ) {
?>
<aside id="footer-widgets">
<?php
		do_action( 'before_sidebar' );
		dynamic_sidebar( 'sidebar-1' );
?>
</aside>
<?php
	}
?>