<?php
/**
 * Attachments
 *
 * @package Traveler
 */

	get_header();

	if ( have_posts() ) {
		while ( have_posts() ) {
			the_post();
?>

	<div class="postnav">
		<div class="left"><?php previous_image_link( false, esc_html__( '&lsaquo;', 'traveler' ) ); ?></div>
		<div class="right"><?php next_image_link( false, esc_html__( '&rsaquo;', 'traveler' ) ); ?></div>
	</div>

	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

		<h1 class="posttitle">
			&#8216;<?php the_title(); ?>&#8217;
		</h1>

<?php
		if ( $post->post_parent ) {

			$metadata = wp_get_attachment_metadata();
			printf(
				__( '<p class="postmetadata">Published <span class="entry-date"><time class="entry-date" datetime="%1$s" pubdate>%2$s</time></span> at <a href="%3$s" title="Link to full-size image">%4$s &times; %5$s</a> in <a href="%6$s" title="Return to %7$s" rel="gallery">%7$s</a></p>', 'traveler' ),
				esc_attr( get_the_date( 'c' ) ),
				esc_html( get_the_date() ),
				esc_url( wp_get_attachment_url() ),
				(int) $metadata['width'],
				(int) $metadata['height'],
				esc_url( get_permalink( $post->post_parent ) ),
				esc_attr( strip_tags( get_the_title( $post->post_parent ) ) )
			);
		}
?>

		<hr class="hr-short" />

		<section class="entry">
<?php
		$attachment = traveler_attachment_details();

		echo '<div class="attachment-image">';
		echo $attachment['image'];
		echo '</div>';

		wp_link_pages(
			array(
				'before' => '<p id="archive-pagination">',
				'after' => '</p>',
				'link_before' => '<span>',
				'link_after'  => '</span>',
			)
		);

		edit_post_link( esc_html__( 'Edit Entry', 'traveler' ), '<div id="wp-edit">', '</div>' );

		if ( has_excerpt() ) {
?>
			<div class="entry-caption">
				<?php the_excerpt(); ?>
			</div>
<?php
		}

		the_content();
?>
		</section>
<?php
		if ( comments_open() || '0' != get_comments_number() ) {
			comments_template();
		}
?>
	</article>
<?php
		} // End while().
	} // End if().

	get_footer();
