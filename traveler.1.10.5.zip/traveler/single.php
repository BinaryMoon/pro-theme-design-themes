<?php
/**
 * Single post template
 *
 * @package Traveler
 */

	get_header();
?>

	<div class="postnav">
		<div class="left"><?php previous_post_link( '%link', esc_html__( '&lsaquo;', 'traveler' ) ); ?></div>
		<div class="right"><?php next_post_link( '%link', esc_html__( '&rsaquo;', 'traveler' ) ); ?></div>
	</div>

<?php
	if ( have_posts() ) {
		while ( have_posts() ) {
			the_post();
			get_template_part( 'content-single' );
		}
	}

	get_footer();
