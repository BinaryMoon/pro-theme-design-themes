<?php
/**
 * Footer
 *
 * @package Traveler
 */

?>

			</section>
		</section><!--/main-->
	</section><!--row-->
</section><!--/container-->

<footer role="contentinfo" class="site-footer">
	<section  class="row clearfix">
	<?php get_sidebar(); ?>
	</section>

<div class="push"></div>


	<section class="footer-wrap">
		<section class="row clearfix">
			<hr class="hr-short" />
<?php
		if ( function_exists( 'the_privacy_policy_link' ) ) {
			the_privacy_policy_link( '', '<span class="sep"> | </span>' );
		}
?>
			<a href="http://wordpress.org/" title="<?php esc_attr_e( 'A Semantic Personal Publishing Platform', 'traveler' ); ?>" rel="generator"><?php printf( __( 'Proudly powered <em>by</em> %s', 'traveler' ), 'WordPress' ); ?></a>
			<span class="sep"> | </span>
			<?php printf( esc_html__( 'Theme: %1$s by %2$s.', 'traveler' ), 'Traveler', '<a href="https://prothemedesign.com/" rel="designer">Pro Theme Design</a>' ); ?>
		</section>
	</section>
</footer>

<?php wp_footer(); ?>

</body>
</html>
