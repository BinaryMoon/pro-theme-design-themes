<?php
/**
 * Generic search form layout
 *
 * @package Traveler
 */

?>
<form method="get" class="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<input type="text" value="<?php echo esc_attr( get_search_query() ); ?>" name="s" class="searchfield" placeholder="<?php esc_attr_e( 'Search...', 'traveler' ); ?>" /><input type="image"
	src="<?php echo esc_attr( get_template_directory_uri() ); ?>/images/magnify.png" class="searchsubmit" />
</form>
