/*!
* main.js v1.2
* Created by Ben Gillbanks <http://www.binarymoon.co.uk/>
* Available under GPL2 license
*/

( function( $ ) {

	var traveler_masonry_update = false;
	var traveler_breakpoint = 767;
	var traveler_masonry_setup = {};
	var traveler_masonry_footer_widgets = {};
	var masonry_test_interval = 100;
	var masonry_old_height = 0;
	var widget_footer_parent = '#footer-widgets';
	var $grid = null;

	// Trigger window resize event to fix video size issues.
	// Don't use jqueries trigger event since that only triggers methods hooked
	// to events, and not the events themselves.
	var resize_window = function() {

		if ( typeof ( Event ) === 'function' ) {
			window.dispatchEvent( new Event( 'resize' ) );
		} else {
			var event = window.document.createEvent( 'UIEvents' );
			event.initUIEvent( 'resize', true, false, window, 0 );
			window.dispatchEvent( event );
		}

	};


	var masonry_init = function() {

		// Initialize masonry.
		$grid = $( '.masonry-container' ).masonry( traveler_masonry_setup );
		$( widget_footer_parent ).masonry( traveler_masonry_footer_widgets );

		// masonry widgets
		masonry_widget_load_test();

		// Set timeouts so that we can ensure things are sized accordingly.
		setInterval( traveler_masonry_refresh, 250 );
		setTimeout( resize_window, 2000 );

	};

	/**
	 * Refresh the sizing of masonry items.
	 *
	 * This function is called on a timer so that it can ensure the layout is
	 * always correct.
	 */
	var traveler_masonry_refresh = function() {

		if ( traveler_masonry_update && $grid !== null ) {

			$grid.masonry( 'layout' );

			// Make sure elements that resize based on container
			// size have the correct dimensions.
			resize_window();

		}

		traveler_masonry_update = false;

	};

	/**
	 * Reload the masonry footer layout to ensure all widgets are in the correct
	 * position.
	 */
	var masonry_footer_reload = function() {

		$( widget_footer_parent ).masonry( traveler_masonry_footer_widgets );

	};

	/**
	 * Run a test to see if the widgets have finished loading.
	 *
	 * If a widget changes size then the function will be called again after a
	 * time period. This repeats until the widgets have stayed the same size for
	 * more than 5 seconds.
	 */
	var masonry_widget_load_test = function() {

		var height = 0;

		// get combined height of all widgets
		$( widget_footer_parent ).find( '.widget' ).each(
			function() {
				height += $( this ).height();
			}
		);

		// if height has changed then reposition widgets
		// also reset interval in case something is still loading
		// note that because default 'old' height is 0 this will always get called first time around
		if ( masonry_old_height < height ) {
			masonry_footer_reload();
			masonry_test_interval = 100;
		}

		masonry_old_height = height;
		masonry_test_interval = Math.floor( masonry_test_interval * 2 );

		// no resizing in 5 seconds
		if ( masonry_test_interval < 5000 ) {
			setTimeout( masonry_widget_load_test, masonry_test_interval );
		}

	};

	/**
	 * Initialize superfish for the dropdown menus.
	 */
	var traveler_menu_init = function() {

		$( '.cat-details ul.menu, .masthead #nav' ).superfish();

		$( '.sub-menu' ).addClass( 'children' );

	};

	$( document ).ready( function() {

		traveler_masonry_setup = {
			itemSelector: 'article',
			isAnimated: true,
			isOriginLeft: !$( 'body' ).is( '.rtl' ),
			gutter: 0
		};

		traveler_masonry_footer_widgets = {
			itemSelector: '.widget',
			isAnimated: false,
			isOriginLeft: !$( 'body' ).is( '.rtl' )
		};

		// toggle between masonry and list view on home and archive pages
		$( 'a.masonry-toggle' ).on(
			'click',
			function() {

				$( this ).toggleClass( 'display_list' ).toggleClass( 'display-masonry' );

				if ( $( '#wrapper' ).hasClass( 'masonry-container' ) ) {

					// Destroy masonry object.
					$grid.masonry( 'destroy' );
					$grid = null;

					// Switch classes.
					$( '#wrapper' ).removeClass( 'masonry-container' ).addClass( 'chrono' );

					// Swap image sizes.
					$( '.masonry-container article' ).each(
						function() {
							var image = $( this ).data( 'masonry-image' );
							if ( '' !== image ) {
								$( this ).find( 'img.wp-post-image' ).src = image;
							}
						}
					);

				} else {

					// Switch css classes.
					$( '#wrapper' ).addClass( 'masonry-container' ).removeClass( 'chrono' );

					// Switch image sizes.
					$( '.masonry-container article' ).each(
						function() {
							var image = $( this ).data( 'list-image' );
							if ( '' !== image ) {
								$( this ).find( 'img.wp-post-image' ).src = image;
							}
						}
					);

					// Reinitialize Masonry.
					masonry_init();

				}

				traveler_masonry_update = true;

				resize_window();

				return false;

			}
		);

		// Responsive navigation.
		$( 'ul.menu.list-cats, #nav' ).responsiveNavigation(
			{
				min_menu_size: 0,
				breakpoint: traveler_breakpoint
			}
		);

		// Update masonry when infinite scroll loads new content.
		$( 'body' ).on(
			'post-load',
			function() {

				// Make sure we are viewing a page that uses Masonry.
				if ( 'undefined' === typeof ( $grid ) || 0 === $grid.length ) {
					return;
				}

				// Grab infinite scroll items and move them to the content area.
				var $new_articles = $( '.masonry-container' ).children().not( '.post-loaded, .infinite-loader' ).addClass( 'post-loaded' );

				$grid.children().addClass( 'post-loaded' );

				// Append new articles to masonry object. This gives us the attractive transition.
				$grid.masonry( 'appended', $new_articles );

				// When images are loaded update masonry once more to ensure things are in the correct position.
				$grid.imagesLoaded(
					function() {

						traveler_masonry_update = true;

					}
				);

				setTimeout( resize_window, 2000 );

			}
		);

		// Update masonry when the window is resized.
		$( window ).on(
			'resize',
			function() {
				traveler_masonry_update = true;
			}
		);

		// Update masonry when the images have finished loading.
		// This also sets a post loaded class that is used to ensure content is re-appended.
		$( '.masonry-container' ).imagesLoaded(
			function() {
				traveler_masonry_update = true;
				$grid.children().addClass( 'post-loaded' );
			}
		);

		masonry_init();

		// Initialize menu.
		traveler_menu_init();

	} );

} )( jQuery );
