<?php
/**
 * Comments template.
 *
 * @package traveler
 */

if ( post_password_required() ) {
	return;
}

// Show the comments.
if ( have_comments() ) {
?>
<section class="comment-stuff">

	<h3 id="comments">
<?php
		printf( _n( '1 comment', '%1$s comments', get_comments_number(), 'traveler' ), number_format_i18n( get_comments_number() ), '<span>' . get_the_title() . '</span>' );
?>
		<a href="#respond" title="<?php esc_attr_e( 'Leave a comment', 'traveler' ); ?>"><?php _e( '&rsaquo;', 'traveler' ); ?></a>
	</h3>

	<ol class="commentlist" id="singlecomments">
		<?php wp_list_comments( 'callback=traveler_comment' ); ?>
	</ol>

	<div id="pagination">
		<div class="older">
			<?php previous_comments_link( __( '&lsaquo; Older Comments', 'traveler' ) ); ?>
		</div>
		<div class="newer">
			<?php next_comments_link( __( 'Newer Comments &rsaquo;', 'traveler' ) ); ?>
		</div>
	</div>

</section>
<?php
}
?>
<?php

comment_form();
