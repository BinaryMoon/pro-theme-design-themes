<?php
/**
 * Image content
 *
 * @package Traveler
 */

	$image_masonry = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'traveler-archive' );
	$image_list = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'traveler-post-thumbnail' );
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( array( 'width-1' ) ); ?> data-masonry-image="<?php if ( $image_masonry ) { echo esc_url( $image_masonry[0] ); } ?>" data-list-image="<?php if ( $image_list) { echo esc_url( $image_list[0] ); } ?>">
	<a href="<?php the_permalink(); ?>" title="<?php printf( esc_html__( 'Permalink for: %s', 'traveler' ), esc_attr( get_the_title() ) ); ?>" rel="bookmark">
<?php
	if ( $image_masonry ) {
		echo '<div class="masonry-thumb"><img src="' . esc_url( $image_masonry[0] ) . '" width="' . ( (int) $image_masonry[1] ) . '" height="' . ( (int) $image_masonry[2] ) . '" alt="' . the_title_attribute( 'echo=0' ) . '" class="wp-post-image" /></div>';
	}
?>
		<section  class="post-details">
			<?php the_title( '<h2 class="posttitle">', '</h2>' ); ?>
		</section>
	</a>
	<?php get_template_part( 'post-meta' ); ?>
</article>
