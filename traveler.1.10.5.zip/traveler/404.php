<?php
/**
 * 404 Page
 *
 * @package Traveler
 */

	get_header();
?>
		<h1 class="pagetitle"><?php esc_html_e( 'Error 404 - Not Found', 'traveler' ); ?></h1>
		<p class="error-msg"><?php _e( 'Sorry, but the page you are looking for has not been found. <br />Try checking the URL for errors, then hit the refresh button in your browser.', 'traveler' ); ?></p>
<?php
	get_footer();
