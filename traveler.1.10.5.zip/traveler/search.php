<?php
/**
 * Search Template
 *
 * @package Traveler
 */

	get_header();
?>
	<h1 class="pagetitle">
		<?php esc_html_e( 'Search results for', 'traveler' ); ?> &#8216;<em><?php the_search_query(); ?></em>&#8217;
	</h1>
<?php
	if ( have_posts() ) {
?>
	<div class="masonry-container" id="wrapper">
<?php
		while ( have_posts() ) {
			the_post();
			get_template_part( 'content', get_post_format() );
		}
?>
	</div>
<?php
		traveler_numeric_pagination();
	} else {
?>
	<p><?php esc_html_e( 'Sorry, but nothing matched your search criteria. Please try again with some different keywords.', 'traveler' ); ?></p>
<?php
		get_search_form();
	}

	get_footer();
