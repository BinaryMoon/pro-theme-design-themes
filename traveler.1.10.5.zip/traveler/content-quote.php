<?php
/**
 * Quote content
 *
 * @package Traveler
 */

	$content = get_the_content();

	preg_match( '/<blockquote>(.*?)<\/blockquote>/s', $content, $matches );

	if ( ! empty( $matches[1] ) ) {

		$content = $matches[1];

	}
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( array( 'width-1' ) ); ?>>

	<a href="<?php the_permalink(); ?>" title="<?php printf( esc_html__( 'Permalink for: %s', 'traveler' ), esc_attr( get_the_title() ) ); ?>" rel="bookmark">
		<section  class="post-details">
			<?php the_title( '<h2 class="posttitle">', '</h2>' ); ?>
		</section>
	</a>

	<blockquote>
		<?php echo wpautop( $content ); ?>
	</blockquote>

	<?php get_template_part( 'post-meta' ); ?>
</article>
