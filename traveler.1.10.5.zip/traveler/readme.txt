=== Traveler ===

Contributors: binarymoon
Tags: art, blog-excerpts, blue, classic-menu, clean, contemporary, craft, custom-background, custom-colors, custom-header, custom-menu, dark, elegant, featured-images, fluid-layout, full-width-template, gray, infinite-scroll, journal, lifestream, one-column, photoblogging, photography, professional, responsive-layout, scrapbooking, simple, site-logo, travel, two-columns
Text Domain: traveler
Requires at least: 4.1
Tested up to: 4.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

A WordPress photography theme, perfect for bloggers who want to document their travels with large photos, dramatic colors and Pinterest-style layouts.

[Theme documentation](https://prothemedesign.com/documentation/theme/traveler/)

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Traveler includes support for Styleguide - a plugin that allows you to change fonts, and colours in WordPress themes.

Traveler includes support for most features in Jetpack, including Infinite Scroll, Featured Content, and Site Logo.

== Changelog ==

= 1.10.5 - 18th April 2022 =
* Fix issue with PHP 8 compatibility.

= 1.10.4 - 20th January 2021 =
* Fix issue with editor css on blocks like Verse, Code and any other blocks that use the `pre` element.

= 1.10.3 - 2nd January 2021 =
* Fix jQuery error since jquery migrate has been removed.

= 1.10.2 - 5th October 2020 =
* Add support for wp_body_open

= 1.10.1 - 9th July 2020 =
* Remove use of deprecated Jetpack function `is_ipad`.

= 1.10 - 14th March 2020 =
* Improve coding standards.
* Add support for Gutenberg.
* Tweak spacings for readability.
* Add footer class and tweak styles to avoid conflicts with plugins that add footer elements.
* Improve display of responsive menu.

= 1.9.1 - 9th August 2019 =
* Add alt text to images.

= 1.9 - 12th March 2019 =
* Split header image code out into inc/custom-header to improve standardization, and simplify code.
* Allow featured images to be used as header images. Defaults to off, and can be enabled in the customizer.
* Add an option to display an overlay over header images so that the text can be read more easily.
* Remove traveler_header() function. It was never used.
* Remove old admin head preview stuff. It's no longer in WordPress.

= 1.8.1 - 25th September 2018 =
* Make the header more flexible so it will work better on different screen sizes, in particular for sites with long titles.

= 1.8 - 25th May 2018 =
* Add support for privacy policy link in the site footer.
* Fix display of the cookie consent checkbox in the comments form.

= 1.7.3 - 3rd March 2018 =
* Make masonry-container article meta more robust, so that it sticks to the bottom of the container better.

= 1.7.2 - 1st March 2018 =
* Remove p elements that wrap the_excerpt. These aren't needed and create invalid html. Often converted by browsers into <p></p>.
* Tidy html in header.
* Update profile url to https.

= 1.7.1 - 20th January 2018 =
* Ensure italic font variants are loaded.

= 1.7 - 19th January 2018 =
* Tweak spacing and sizes to improve usability and consistency.
* Fix small display issue with search results layout.
* Make featured images larger to ensure they always fill the space available.
* Remove duplicate image size that isn't used.
* Fix video display in list layout.

= 1.6.4 - 20th December 2017 =
* Improve masonry resizing when using video post format.
* Make video sizing in archive pages behave better.

= 1.6.3 - 1st November 2017 =
* Fix bug with Testimonial (and possibly other post formats) responsive display being too small

= 1.6.2 - 24th October 2017 =
* Improve responsive styles for header area
* Tweak white space on single posts
* Add some default custom colour palettes (for .com only)

= 1.6.1 - 13th October 2017 =
* A rewrite of the masonry javascript that improves infinite scroll behaviour so that the articles do not jump around as they load, and instead display with an attractive transition.
* Also tidied up the js code a bit, adding more comments to make it easier to understand what is going on.

= 1.6 - 2nd October 2017 =
* Allow secondary navigation to be controlled by menu.
* Add setting that lets you select the theme header height.
* Add support for Jetpack content options allowing various theme elements to be hidden.
* Add archive titles for situations where the titles are missing (such as testimonials).
* Fix testimonials archive template layout (and probably other archives that I haven’t noticed).
* Improve spacing and general readability.
* Make image attachment template consistent with other templates.
* Improve coding standards.

= 1.5.4 - 7th September 2017 =
* Make sure jetpack likes only work when the site id can be looked up.

= 1.5.3 - 20th July 2017 =
* Make numeric pagination more robust.
* Fix minor display issue with custom logos.

= 1.5.2 - 14th January 2017 =
* Fix bug with customizer setting being validated incorrectly and so not allowing the menu to show and hide properly.
* A small amount of code tidying.

= 1.5.1 - 10th November 2016 =
* Fix issue with image max-widths that was breaking Instagram widget
* Fix display of sharedaddy sharing links

= 1.5 - 4th November 2016 =
* Tidy up the codes
* Correct textdomain
* Improve image attachment page to display content and excerpts properly
* Tweak comments styles

= 1.4.1 - 24th September 2016 =
* Fix incorrect text domains
* Escape some translations

= 1.4 =
* Fix comments so that trackbacks and pingbacks display properly

= 1.3 =
* Tidy code and escape some of the translated strings
* switch to using the_archive_description for category descriptions
* add support for post formats (quote, image, audio, and video) on archive pages

= 1.2.1 =
* Improve bold font usage
* switch to theme_support( title-tag )
* improve coding standards

= 1.2 =
* tweak homepage header to scale proportionally
* change header image size to something that should fit the header proportions better

= 1.1 =
* update to latest version of masonry
* improve responsive styles
* remove hard coded style on posts

= 1.0 =
* Initial release

== Credits ==

* [Montseratt](https://www.google.com/fonts/specimen/Montserrat) Font from Google Fonts, licensed under [SIL Open Font License, 1.1](http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL).
