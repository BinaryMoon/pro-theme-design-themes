=== Readme ===

Contributors: binarymoon
Tags: black, blog, blue, business, classic-menu, clean, conservative, contemporary, custom-background, custom-colors, custom-header, custom-menu, dark, elegant, featured-images, flexible-header, full-width-template, infinite-scroll, magazine, modern, news, professional, responsive-layout, right-sidebar, site-logo, sophisticated, theme-options, translation-ready, two-columns
Requires at least: 4.1
Tested up to: 4.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

An elegant magazine theme for WordPress, with a responsive design, and support for widgets, post thumbnails, custom headers and custom backgrounds.

[Theme documentation](https://prothemedesign.com/documentation/theme/opti/)

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Opti includes support for [Styleguide](https://wordpress.org/plugins/styleguide/) - a plugin that allows you to change fonts, and colours in WordPress themes.

Opti includes support for most features in [Jetpack](https://wordpress.org/plugins/jetpack/), including Infinite Scroll, Featured Content, and Site Logo.

== Changelog ==

= 1.8.9 - 4th June 2021 =
* Fix issue with spacing at the bottom of the page.

= 1.8.8 - 20th January 2021 =
* Fix editor issues with Verse, Code and other blocks using the `pre` element.

= 1.8.7 - 18th November 2020 =
* Tweak css styles for blog pages when Jetpack ratings are used.

= 1.8.6 - 5th October 2020 =
* Add support for wp_body_open

= 1.8.5 - 17th September 2020 =
* Fix Jetpack Infinite Scroll.
* Improve display of select boxes.

= 1.8.4 - 29th July 2020 =
* Make logo class generic (for 5.5 update).

= 1.8.3 - 11th July 2020 =
* Ensure the responsive navigation is readable.
* Decache styles.
* Fix infinite scroll button styles.

= 1.8.2 - 9th July 2020 =
* Remove use of deprecated Jetpack function `is_ipad`.

= 1.8.1 - 4th July 2020 =
* Fix image alignment.

= 1.8 - 17th March 2020 =
* Add support for Gutenberg.

= 1.7.5 - 24th December 2019 =
* Overhaul form styles. Improve consistency and allow them to work better with form plugins.

= 1.7.4 - 8th June 2019 =
* Improve required alignment styles.

= 1.7.3 - 7th October 2018 =
* Fix bug with homepage category selector that meant the first category in the list could not be selected

= 1.7.2 - 11th September 2018 =
* Fix bug with Jetpack lazy loading images not triggering resize and masonry and so borking the layout.

= 1.7.1 - 7th September 2018 =
* Escape translations strings.
* Tidy some codes.
* Add additional css classes to make it easier to hide html elements.

= 1.7 - 3rd September 2018 =
* Rebuild admin control panel in the Customizer. Yay!
* Add Customizer live preview for site title, description, and title colour.
* Tidy codes.

= 1.6.2 - 1st Septmber 2018 =
* Ensure the featured content area is the correct size in all resize situations.

= 1.6.1 - 18th August 2018 =
* Tweaks to responsive styles affecting blog post images on homepage.

= 1.6 - 25th May 2018 =
* Add support for privacy policy link in the site footer.
* Fix display of the cookie consent checkbox in the comments form.

= 1.5.2 - 3rd March 2018 =
* Add opti_featured_content filter to allow featured content settings to be modified.
* Switch profile url to https

= 1.5.1 - 16th January 2018 =
* Further improvements to colours and css to improve readability and design consistency

= 1.5 - 8th January 2018 =
* Add support for infinite scroll on archive pages.
* Improve nested comment styles to reduce excessive whitespace.
* Correct typo in readme.

= 1.4.1 - 31st December 2017 (New Years Eve!) =
* Reduce the number of colours used to make the design more consistent. This involves merging the colours that are visually very similar.
* Tweak letter spacing to make the headings nicer to read.
* Tweak contrast to improve readability.

= 1.4 - 30th December 2017 =
* Tweak featured content layout for improved display when small images are used.
* Refresh design - mostly small pixel tweaks to margins and padding to offer a nicer, more consistent, reading experience.
* Improve code formatting.
* Improve rtl styles.
* Escape translations.
* Add support for selective refresh widgets.

= 1.3.3 - 15th November 2017 =
* Improve responsive layout on small devices
* Improve footer styles
* Fix category layout in rtl languages.

= 1.3.2 - 17th September 2017 =
* Stop random elements from bumping against the post title in some situations.

= 1.3.1 - 16th June 2017 =
* Small tweak to make infinite scroll posts more consistent in appearance.
* Add search text placeholder in search input.
* Improve coding standards and security.
* Improve responsive layout.

= 1.3 - 28th May 2017 =
* Add support for hiding site logo
* Improve security and coding standards

= 1.2.8 - 24th May 2017 =
* Make WordPress custom logo work, replacing Jetpack site logo (self hosted only)

= 1.2.7 - 15th November 2016 =
* Fix issue with authors widget on wordpress.com

= 1.2.6 - 24th September 2016 =
* Improve coding standards
* fix incorrect text domains

= 1.2.5 =
* Add support for pages and jetpack portfolio projects in homepage slider.

= 1.2.4 =
* Tweak text box styles so they display in a nicer way

= 1.2.3 =
* Fix issue with image attachment template

= 1.2.2 =
* Update responsiveNavigation.js so that the first menu option is selectable

= 1.2.1 =
* tweak header font sizes to reflect header importance

= 1.2 =
* Improve print styles
* add new translations (including a complete Finnish translation)

= 1.1 =
* fix issue with avatars clashing with WordPress admin bar
* stop comments text from displaying in post meta data if comments are disabled and there are no comments to display

= 1.0.1 =
* Change the category description to use the new archive description function - which means tag and other taxonomy descriptions will now display
* Change the home icon so it uses an icon font rather than an image - which means you can change the color with css
* Fix issue with the lead story height on the homepage when there’s only one item to display
* Optimise the css so that there's fewer server requests
* Add support for new title-tag functionality
* Add support for Jetpack plugin site logo functionality
* Fix issue with some search page results
* Tidy up 404 error page design
* Include Jetpack plugin responsive video functionality

= 1.0 =
* Initial release

== Credits ==

* [Merriweather](https://www.google.com/fonts/specimen/Merriweather) Font from Google Fonts, licensed under [SIL Open Font License, 1.1](http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL).
* Genericons: font by Automattic (http://automattic.com/), licensed under [GPL2](https://www.gnu.org/licenses/gpl-2.0.html)
