/**
 * main.js v1
 * Created by Ben Gillbanks <http://www.binarymoon.co.uk/>
 * Available under GPL2 license
 */

var homeSlider;

( function( $ ) {

	$( document ).ready(
		function() {

			// Do navigation.
			if ( typeof $.fn.elementalNav === 'function' ) {
				$( '.menu ul' ).elementalNav();
			}

			// Apply responsive navigation.
			if ( typeof $.fn.responsiveNavigation === 'function' ) {
				$( '.nav' ).responsiveNavigation(
					{
						breakpoint: 567
					}
				);
			}

			$().elementalInit();

			// Do masonry for articles on archives.
			if ( typeof $.fn.masonry === 'function' ) {

				// Blog post content.
				var $grid = $( '.masonry-wrapper' ).masonry(
					{
						itemSelector: 'article',
						gutter: 0,
						isOriginLeft: !$( 'body' ).is( '.rtl' ),
						percentPosition: true
					}
				);

				// Update again once images have loaded.
				$grid.imagesLoaded(
					function() {
						$grid.masonry( 'layout' );
					}
				);

				// Update on infinite scroll load.
				$( 'body' ).on(
					'post-load jetpack-lazy-loaded-image',
					function() {

						var $new_articles = null;

						// Make sure we are viewing a page that uses Masonry.
						if ( 'undefined' === typeof ( $grid ) || 0 === $grid.length ) {

							// Quit the function since we don't need to do anything with masonry.
							return;

						}

						// Grab infinite scroll items and move them to the content area.
						$new_articles = $( '.infinite-wrap' ).find( 'article' ).hide();
						$grid.append( $new_articles );
						$( '.infinite-wrap, .infinite-loader' ).remove();

						// When images are loaded appended infinite scroll items to Masonry.
						$grid.imagesLoaded(
							function() {

								$grid
									.masonry( 'appended', $new_articles )
									.masonry( 'reloadItems' )
									.masonry( 'layout' );

								// Make sure elements that resize based on container
								// size have the correct dimensions.
								resize_window();

							}
						);

					}
				);

			}

			if ( typeof $.fn.elementalSlides === 'function' ) {
				homeSlider = $( '#lead-story' ).elementalSlides();
			}

			// resize lead story slider height based on content height
			update_lead_story_height();

			var resized = false;

			$( window ).on(
				'resize orientationchange jetpack-lazy-loaded-image',
				function() {
					resized = true;
				}
			);

			// Periodically check to see if the page has changed size.
			setInterval(
				function() {
					if ( resized ) {
						update_lead_story_height();
					}
					resized = false;
				},
				250
			);

		}
	);


	// Trigger window resize event to fix video size issues.
	// Don't use jqueries trigger event since that only triggers methods hooked
	// to events, and not the events themselves.
	var resize_window = function() {

		if ( typeof ( Event ) === 'function' ) {
			window.dispatchEvent( new Event( 'resize' ) );
		} else {
			var event = window.document.createEvent( 'UIEvents' );
			event.initUIEvent( 'resize', true, false, window, 0 );
			window.dispatchEvent( event );
		}

	};


	/**
	 * Ensure the height of the lead story matches the height of the tallest story.
	 * This reduces the up and down motion that could happen to the page content
	 * if stories are of different heights.
	 */
	function update_lead_story_height() {

		var items = $( '#lead-story .item' );
		var max_height = 'none';

		if ( items.length > 1 ) {

			max_height = 0;

			items.each(
				function() {
					max_height = Math.max( $( this ).outerHeight( true ), max_height );
				}
			);

		}

		$( '#lead-story' ).css(
			{ 'height': max_height }
		);

	}

} )( jQuery );
