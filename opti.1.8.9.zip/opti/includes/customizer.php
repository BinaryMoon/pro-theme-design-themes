<?php
/**
 * Theme Customizer
 *
 * @link https://developer.wordpress.org/themes/advanced-topics/customizer-api/
 *
 * @package Opti
 * @subpackage ThemeCustomizerSettings
 * @author Ben Gillbanks <ben@prothemedesign.com>
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU Public License
 */

/**
 * Exit if we're not in the Customizer.
 */
if ( ! class_exists( 'WP_Customize_Control' ) ) {

	return null;

}


/**
 * Theme Customizer properties
 *
 * @param WP_Customize_Manager $wp_customize WP Customize object. Passed by WordPress.
 */
function opti_customizer_settings( WP_Customize_Manager $wp_customize ) {

	/**
	 * Opti theme options section.
	 */
	$wp_customize->add_section(
		'opti_options',
		array(
			'title' => esc_html__( 'Theme Options', 'opti' ),
		)
	);


	/**
	 * Adjust the number of posts to display in each featured category.
	 */
	$wp_customize->add_setting(
		'opti_homepage[hide-homepage-categories]',
		array(
			'type' => 'option',
			'default' => false,
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'opti_sanitize_checkbox',
		)
	);

	$wp_customize->add_control(
		'opti_homepage[hide-homepage-categories]',
		array(
			'label' => esc_html__( 'Hide the homepage categories listing', 'opti' ),
			'section' => 'opti_options',
			'type' => 'checkbox',
		)
	);


	$wp_customize->add_setting(
		'opti_homepage[homepage-categories]',
		array(
			'type' => 'option',
			'default' => '',
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'opti_sanitize_categories',
			'transport' => 'postMessage',
		)
	);

	$wp_customize->add_control(
		new Opti_DragDrop_List_Control(
			$wp_customize,
			'opti_homepage[homepage-categories]',
			array(
				'label' => esc_html__( 'Featured Categories', 'opti' ),
				'section' => 'opti_options',
			)
		)
	);


	/**
	 * Adjust the number of posts to display in each featured category.
	 */
	$wp_customize->add_setting(
		'opti_homepage[featured-posts]',
		array(
			'type' => 'option',
			'default' => 2,
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'opti_sanitize_int',
			'input_attrs' => array(
				'min' => 1,
				'max' => 30,
				'step' => 1,
			),
		)
	);

	$wp_customize->add_control(
		'opti_homepage[featured-posts]',
		array(
			'label' => esc_html__( 'Featured Posts', 'opti' ),
			'description' => esc_html__( 'Number of featured posts to display on the homepage in the featured categories section.', 'opti' ),
			'section' => 'opti_options',
			'type' => 'number',
		)
	);


	/**
	 * Adjust the number of posts to display in each featured category.
	 */
	$wp_customize->add_setting(
		'opti_homepage[display-header-image]',
		array(
			'type' => 'option',
			'default' => false,
			'capability' => 'edit_theme_options',
			// 'sanitize_callback' => 'opti_sanitize_checkbox',
		)
	);

	$wp_customize->add_control(
		'opti_homepage[display-header-image]',
		array(
			'label' => esc_html__( 'Display Header Image on', 'opti' ),
			'section' => 'opti_options',
			'type' => 'radio',
			'choices' => array(
				'homepage' => esc_html__( 'Homepage', 'opti' ),
				'all-pages' => esc_html__( 'All Pages', 'opti' ),
			),
		)
	);


	/**
	 * Adjust the number of posts to display in each featured category.
	 */
	$wp_customize->add_setting(
		'opti_homepage[related-posts]',
		array(
			'type' => 'option',
			'default' => false,
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'opti_sanitize_checkbox',
		)
	);

	$wp_customize->add_control(
		'opti_homepage[related-posts]',
		array(
			'label' => esc_html__( 'Display Related Posts', 'opti' ),
			'description' => esc_html__( 'Would you like to display the related posts on single post pages?', 'opti' ),
			'section' => 'opti_options',
			'type' => 'checkbox',
		)
	);

}

add_action( 'customize_register', 'opti_customizer_settings' );


/**
 * Update Theme Elements without refreshing content.
 *
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function opti_register_customize_refresh( WP_Customize_Manager $wp_customize ) {

	// Ensure selective refresh is enabled.
	if ( ! isset( $wp_customize->selective_refresh ) ) {

		return false;

	}

	// Update site title.
	$wp_customize->get_setting( 'blogname' )->transport = 'postMessage';

	$wp_customize->selective_refresh->add_partial(
		'blogname',
		array(
			'selector' => '.site-title',
			'render_callback' => function() {
				bloginfo( 'name' );
			},
		)
	);

	// Update site description.
	$wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';

	$wp_customize->selective_refresh->add_partial(
		'blogdescription',
		array(
			'selector' => '.site-description',
			'render_callback' => function() {
				bloginfo( 'description' );
			},
		)
	);

	// Show and hide header text.
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

}

add_action( 'customize_register', 'opti_register_customize_refresh' );


/**
 * Binds JS handlers to make the Customizer preview reload changes asynchronously.
 */
function opti_customize_preview_js() {

	wp_enqueue_script(
		'opti-customize-preview',
		get_theme_file_uri( '/js/customizer-preview.js' ),
		array( 'customize-preview' ),
		'1.0',
		true
	);

}

add_action( 'customize_preview_init', 'opti_customize_preview_js' );


/**
 * Sanitize checkbox input
 *
 * @param boolean $setting Value to check and sanitize.
 * @return boolean
 */
function opti_sanitize_checkbox( $setting ) {

	return (bool) $setting;

}


/**
 * Sanitize category list
 *
 * The list is comma separated. First split the string into items, then loop
 * through all categories and make sure they are ints then join them back
 * together again.
 *
 * @param string $setting Value to check and sanitize.
 * @return string comma separated list of category ids
 */
function opti_sanitize_categories( $setting ) {

	$clean_cats = array();
	$cats = explode( ',', $setting );

	foreach ( $cats as $c ) {
		$c = (int) $c;

		if ( $c > 0 ) {
			$clean_cats[] = $c;
		}
	}

	return implode( ',', $clean_cats );

}


/**
 * Sanitize the value of an integer.
 *
 * Can be used for dropdown controls, or any other controls where an integer is
 * expected.
 *
 * @param number $setting Value to sanitize.
 * @return integer
 */
function opti_sanitize_int( $setting ) {

	return (int) $setting;

}


/**
 * Sanitize colours
 *
 * Would be so much nicer if sanitize_hex_color was available to themes! :)
 *
 * @param string $color Value to sanitize.
 * @return hex|string Returns clean colour, or empty string if not a valid colour.
 */
function opti_sanitize_hex_color( $color ) {

	if ( '' === $color ) {

		return '';

	}

	// 3 or 6 hex digits, or the empty string.
	if ( preg_match( '|^#([A-Fa-f0-9]{3}){1,2}$|', $color ) ) {

		return $color;

	}

	return '';

}