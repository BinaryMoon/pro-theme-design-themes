<?php
/**
 * Archive pagination
 *
 * @package Opti
 */

?>
<ul id="pagination">
	<li id="older">
		<?php next_posts_link( esc_html__( '&lsaquo; Older Entries', 'opti' ) ); ?>
	</li>
	<li id="newer">
		<?php previous_posts_link( esc_html__( 'Newer Entries &rsaquo;', 'opti' ) ); ?>
	</li>
</ul>
