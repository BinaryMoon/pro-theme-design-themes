<?php
/**
 * Add the edit link for posts and pages
 *
 * @package Opti
 */

edit_post_link( esc_html__( 'Edit', 'opti' ), '', '' );
