<?php
add_color_rule( 'bg', '#FFFFFF', array(
 	array( 'body', 'background-color' ),
 	array( 'table caption', 'background-color' ),
 	array( '.wrapper', 'background-color' ),
	array( '#lead-story', 'background-color', '-1' ),
	array( '#recent-posts .sticky', 'background-color', '-.75' ),
	array( 'a, a:visited', 'border-color', '-1' ),
	array( 'a:hover, a:active', 'border-color', '-1.75' ),
	array( '#featured-cats h5, .custom-colors #featured-cats h5', 'background-color', '-1' ),
	array( '#featured-cats h5, .custom-colors #featured-cats h5, .headlines li, aside .widget li, #recent-excerpts li, #related-posts', 'border-color', '-1.75' ),
	array( 'aside .widget, aside h3.widgettitle, tr', 'background-color', '-1' ),
 	array( 'aside .widget-wrap', 'background-color' ),
 	array( '.row .eightcol, aside .widget-wrap, td', 'border-color', '-1.75' ),
 	array( 'h1.pagetitle, .archive article, .search article, .page-template-custom-page-blog-php article, #archive-pagination a, #archive-pagination a:visited', 'border-color', '-1.75' ),
 	array( '#archive-pagination a:hover, #archive-pagination a:active', 'border-color', '-2.5' ),
 	array( 'a.post-edit-link, a.post-edit-link:visited, #sharethis a, #sharethis a:visited, #related-posts ul a, #related-posts ul a:visited', 'border-color' ),
 	array( 'a.post-edit-link, a.post-edit-link:visited, #sharethis a, #sharethis a:visited, #related-posts ul a, #related-posts ul a:visited', 'background-color', '-.5' ),
 	array( 'a.post-edit-link:hover, a.post-edit-link:active, #sharethis a:hover, #sharethis a:active, #related-posts ul a:hover, #related-posts ul a:active', 'border-color', '-1.75' ),
 	array( 'a.post-edit-link:hover, a.post-edit-link:active, #sharethis a:hover, #sharethis a:active, #related-posts ul a:hover, #related-posts ul a:active', 'background-color', '-1' ),
 	array( '.entry .post-taxonomies a', 'background-color', '-.5' ),
 	array( '.entry .post-taxonomies a', 'border-color', '-1' ),
 	array( '.entry .post-taxonomies a', 'color', '-1.75' ),
 	array( '.entry .post-taxonomies a:hover', 'color', '-2.5' ),
 	array( 'footer h4.widgettitle', 'color', 'fg1' ),
 	array( 'footer h4.widgettitle', 'border-color', 'fg1' ),
 	array( '.milestone-header', 'color', 'fg1' ),
), __( 'Background' ) );

add_color_rule( 'fg1', '#293033', array(
 	array( '#masthead, .custom-colors #masthead', 'background-color' ),
 	array( '.milestone-header', 'background-color' ),
 	array( '#nav-primary,
 			.custom-colors #nav-primary', 'background', '1' ),

 	array( '#nav-primary,
 			.custom-colors #nav-primary', 'border-color', '-1' ),

 	array( '#nav-primary .nav > li,
 			.custom-colors #nav-primary .nav > li', 'border-right-color', '-1' ),

 	array( '#nav-primary .nav > li,
 			.custom-colors #nav-primary .nav > li', 'border-left-color' ),

 	array( '.custom-colors #nav-primary .nav > li.current-menu-item,
 			.custom-colors #nav-primary .nav > li:hover,
 			.custom-colors #nav-primary .nav > li.current-cat', 'background-color', '-1' ),

 	array( 'header input.searchfield, .custom-colors header input.searchfield', 'background-color', '-.5' ),
 	array( 'header .searchfield:focus, header .searchfield:hover, .custom-colors header .searchfield:focus, .custom-colors header .searchfield:hover', 'background-color', '-1' ),
 	array( 'footer, .custom-colors footer', 'background-color', '-.5' ),
 	array( '#footer-wrap', 'border-color', '-1' ),
), __( 'Header, Footer' ) );

add_color_rule( 'fg2', '#FEFEFE', array(
	array( '#masthead, .custom-colors #masthead', 'color', 'fg1' ),

 	array( '#nav-primary .nav > li > a,
 			.custom-colors #nav-primary .nav > li > a,
 			#nav-primary .nav > li.current-menu-item > a,
 			#nav-primary .nav > li.current-cat > a,
 			.custom-colors #nav-primary .nav > li.current-menu-item > a,
 			.custom-colors #nav-primary .nav > li.current-cat > a', 'color', 'fg1' ),

 	array( '#nav-primary .nav > li.current-menu-item > a,
 			#nav-primary .nav > li.current-cat > a,
 			.custom-colors #nav-primary .nav > li.current-menu-item > a,
 			.custom-colors #nav-primary .nav > li.current-cat > a', 'border-color', 'fg1' ),

 	array( '#nav-primary .nav > li:hover,
 			#nav-primary .nav > li.current-cat', 'color', 'fg1' ),

 	array( '#nav-primary .nav > li.current-menu-item', 'color', 'fg1' ),

 	array( '#masthead #logo a, #masthead #logo a:visited, .custom-colors #masthead #logo a, .custom-colors #masthead #logo a:visited', 'color', 'fg1' ),
 	array( '#masthead h2, .custom-colors #masthead h2', 'color', 'fg1' ),
 	array( 'header input.searchfield, .custom-colors header input.searchfield', 'color', 'fg1' ),
 	array( 'footer a, footer a:visited, .custom-colors footer a, .custom-colors footer a:visited', 'color', 'fg1' ),
 	array( 'footer a:hover, footer a:active, .custom-colors footer a:hover, .custom-colors footer a:active', 'color', 'fg1' ),
), __( 'Site Title, Site Description, Header/Footer Links' ) );

add_color_rule( 'link', '#1899CB', array(
 	array( 'a, a:visited, .custom-colors a, .custom-colors a:visited', 'color', 'bg' ),
 	array( 'a:hover, a:active, .custom-colors a:hover, .custom-colors a:active', 'color', '-1.75', 'bg' ),
) );

add_color_rule( 'txt', '#111111', array(
 	array( 'body', 'color', 'bg' ),
 	array( 'a.dark, a.dark:visited, aside .widget li a, aside .widget li a:visited', 'color', 'bg' ),
 	array( '#featured-cats h5 a, #featured-cats h5 a:visited, .custom-colors #featured-cats h5 a, .custom-colors #featured-cats h5 a:visited', 'color', 'bg' ),
 	array( '#featured-cats .date', 'color', 'bg' ),
 	array( '#featured-cats h3, #recent-posts h3', 'border-color', 'bg' ),
 	array( '.entry .post-taxonomies', 'color', 'bg' ),
 	array( 'footer, .custom-colors footer', 'color' ),
), __( 'Text Color, Headings' ) );



add_theme_support( 'custom_colors_extra_css', 'opti_extra_css' );
function opti_extra_css() { ?>
	h2#description, #logo, #nav-primary a {
		text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.1);
	}
	.wp-playlist-light {
		color: #111;
	}
<?php
}