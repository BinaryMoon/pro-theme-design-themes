<?php
/**
 * Full width page template
 * Template Name: Full Width
 *
 * The sidebar is actually called in footer.php and the full width element is controlled
 * through css. As such this template is super simple. The main element used is
 * the name.
 *
 * @package Bexley
 */

	get_template_part( 'page' );