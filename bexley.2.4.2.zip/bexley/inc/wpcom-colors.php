<?php
/**
 * Color annotation for Bexley, by Pro Theme Design.
 */

add_color_rule( 'bg', '#f2f2f2', array(
 	array( 'body, .social_links a:before, table caption, table th, blockquote, .wp-caption, .post-password-required form, a.post-edit-link', 'background-color' ),
 	array( 'table', 'border-color' ),
), __( 'Background' ) );

add_color_rule( 'txt', '#2ecc71', array(
 	array( 'a, pre,#respond p.logged-in-as a:hover,#main article.sticky:after, .widget h3.widgettitle:before, .milestone-countdown', 'color', '#ffffff', 3 ),
 	array( 'a:hover', 'color', '#ffffff' ),
 	array( 'form.searchform button.searchsubmit:hover, form input[type=submit]:hover, .infinite-scroll #infinite-handle span:hover', 'background-color', '#ffffff' ),
 	array( 'blockquote,ol.commentlist li.comment.bypostauthor', 'border-left-color', '#ffffff', 3 ),
 	array( '.menu li a.sf-with-ul:after', 'border-top-color', '#1a1a1a', 3 ),
 	array( '.menu li ul:before', 'border-bottom-color', '#ffffff', 3 ),
 	array( '.menu li ul li', 'border-bottom-color', 'txt', 1.5 ),
 	array( '.menu li ul li a.sf-with-ul:after', 'border-left-color', 'txt', 2 ),
 	array( 'form input[type=text]:focus,form input[type=password]:focus,form input[type=email]:focus,form input[type=url]:focus,form input.text:focus,form textarea:focus,form input.settings-input:focus', 'outline-color', '#ffffff', 3 ),
 	array( 'form input[type=text]:focus,form input[type=password]:focus,form input[type=email]:focus,form input[type=url]:focus,form input.text:focus,form textarea:focus,form input.settings-input:focus,form input[type=submit],form input[type=submit]:hover,ol.commentlist li.comment .reply a, .milestone-countdown', 'border-color', '#ffffff', 3 ),
 	array( 'form input[type=submit],.infinite-scroll #infinite-handle span,ol.commentlist li.comment .reply a:hover, #main article .showcase, form.searchform button.searchsubmit, #main .archive-pagination span.current, #main article .postnav .next a:before, #main article .postnav .prev a:before, #main article .postnav .next a:after, #main article .postnav .prev a:after, ol.commentlist li.comment .reply a, .milestone-header, .menu li ul', 'background-color', '#ffffff', 3 ),
 	array( '#footer a', 'color', 'bg' ),
), __( 'Accent and Link Color' ) );

add_color_rule( 'link', '#000000', array(
	// not used
) );

add_color_rule( 'fg1', '#000000', array(
	// not used
) );

add_color_rule( 'fg2', '#000000', array(
	// not used
) );

add_color_rule( 'extra', '#666666', array(
 	array( '#footer', 'color', 'bg', 2 ),
) );

add_color_rule( 'extra', '#808080', array(
 	array( '.wp-caption .wp-caption-text', 'color', 'bg' ),
) );

add_color_rule( 'extra', '#ffffff', array(
 	array( '#main article a.read-more', 'background-color', .25 ),
 	array( '#main article a.read-more:hover', 'background-color', .15 ),
) );

/**
 * Custom CSS
 */
function bromley_extra_css() { ?>
	::selection {
		background: none;
	}
	input[type=submit],
	input[type=submit]:hover,
	form input[type=submit],
	form input[type=submit]:hover,
	ol.commentlist li.comment .reply a,
	ol.commentlist li.comment .reply a:hover {
		background-image: none;
	}
	.milestone-header {
		color: #fff;
	}
	.milestone-countdown {
		background-color: #fff;
	}
	#wp-calendar {
		border: none;
	}
<?php }

add_theme_support( 'custom_colors_extra_css', 'bromley_extra_css' );
