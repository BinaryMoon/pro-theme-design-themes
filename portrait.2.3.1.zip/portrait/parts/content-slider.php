<?php
/**
 * Jetpack Featured Content Slide
 *
 * @link https://jetpack.me/support/featured-content/
 *
 * @package Portrait
 * @subpackage TemplatePart
 * @author Ben Gillbanks <ben@prothemedesign.com>
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU Public License
 */

	$image = portrait_post_image();
?>

	<article <?php post_class(); ?>>

<?php
	if ( $image ) {
?>

		<a href="<?php echo esc_url( get_permalink() ); ?>" class="thumbnail">
			<?php echo $image; // WPCS: XSS OK. ?>
		</a>

<?php
	}

	get_template_part( 'parts/edit-post' );
?>

		<section class="entry">

<?php
	get_template_part( 'parts/post-meta' );

	the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );

	echo wpautop( get_the_excerpt() );
?>

		</section>

	</article>
