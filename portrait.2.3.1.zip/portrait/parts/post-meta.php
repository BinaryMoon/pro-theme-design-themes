<?php
/**
 * Post Meta Data
 *
 * @package Portrait
 * @subpackage TemplatePart
 * @author Ben Gillbanks <ben@prothemedesign.com>
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU Public License
 */

?>

	<div class="post-meta-data">

<?php
	portrait_post_time();

	if ( is_singular() ) {

		get_template_part( 'parts/edit-post' );

	}
?>

	</div>
