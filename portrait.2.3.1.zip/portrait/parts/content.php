<?php
/**
 * Generic Content Template Partial
 *
 * @package Portrait
 * @subpackage TemplatePart
 * @author Ben Gillbanks <ben@prothemedesign.com>
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU Public License
 */

	$image = portrait_post_image();
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

<?php
	if ( $image ) {
?>

	<a href="<?php echo esc_url( get_permalink() ); ?>" class="thumbnail" aria-hidden="true">
		<?php echo $image; // WPCS: XSS OK. ?>
	</a>

<?php
	}

	get_template_part( 'parts/edit-post' );
?>

	<section class="entry entry-archive">

<?php
	get_template_part( 'parts/post-meta' );

	the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );

	if ( ! $image ) {

		the_excerpt();

	}
?>

	</section>

</article>
