=== Portrait ===

Contributors: binarymoon
Requires at least: 4.7
Tested up to: 4.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: Black, Gray, Yellow, Dark, Light, Responsive Layout, Two Columns, Left Sidebar, Accessibility Ready, Custom Background, Custom Colors, Custom Header, Custom Menu, Editor Style, Featured Image Header, Featured Images, Flexible Header, Full Width Template, Post Formats, RTL Language Support, Sticky Post, Theme Options, Threaded Comments, Translation Ready

== Description ==

Portrait is an elegantly simple photo based theme with an emphasis on vertical images.

[Theme documentation](https://prothemedesign.com/documentation/theme/portrait/)

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Portrait includes support for [Styleguide](https://wordpress.org/plugins/styleguide/) - a plugin that allows you to change fonts, and colours in WordPress themes.

Portrait includes support for most features in [Jetpack](https://wordpress.org/plugins/jetpack/), including Infinite Scroll, Featured Content, and Site Logo.

== Changelog ==

= 2.3.1 - 27th October 2020 =
* Add 'navigation-widgets' to supported html5 types.

= 2.3 - 7th March 2020 =
* Add support for Gutenberg including editor styles, and wide content.
* Hide post taxonomies and post author content on password protected posts.
* Improve the layout of the image attachments.

= 2.2.3 - 30th September 2019 =
* Improve default search input styles.

= 2.2.2 - 13th May 2019 =
* Add font display swap to Google Font loading, to increase font display speed.

= 2.2.1 - 12th February 2019 =
* Fix issue with the contributor template displaying the same user description for all users.

= 2.2 - 25th May 2018 =
* Add support for privacy policy link in the site footer.
* Fix display of the cookie consent checkbox in the comments form.

= 2.1 - 4th March 2018 =
* Remove duplicate comment form from custom page templates when used on blog posts.
* Change profile url to https.
* Rename css animations.
* Ensure masonry is enqueued on projects, and grid custom page templates.
* Ensure videos are positioned correctly in masonry views.

= 2.0.5 - 28th January 2018 =
* Optimize CSS.
* Remove file that was generated in the wrong place.

= 2.0.4 - 27th January 2018 =
* Correct post navigation labels.

= 2.0.3 - 10th January 2018 =
* Fix display of full width template in blog posts.

= 2.0.2 - 5th October 2017 =
* Fix undefined index issue when using Testimonials.

= 2.0.1 - 24th August 2017 =
* Small CSS tweaks and fixes to improve header layout on responsive screens.
* Fix jetpack subscription widget input field size.
* Update rtl.css
* Ensure main menu container is not displayed if there is no menu set.

= 2.0 =
* wordpress.com release

= 1.0 =
* Initial release

== Credits ==

* [Muli](https://fonts.google.com/specimen/Open+Sans) Font from Google Fonts, licensed under [SIL Open Font License, 1.1](http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL)
