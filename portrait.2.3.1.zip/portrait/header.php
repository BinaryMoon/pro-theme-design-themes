<?php
/**
 * Header Template
 *
 * Display the site header content (logo, site title, description). Also houses
 * the site head.
 *
 * The head is kept as small as is reasonably possible. Any head content
 * should be hooked into the wp_head filter.
 *
 * Styles and scripts and enqueued through the {@se portrait_enqueue} function found
 * in inc/wordpress.php
 *
 * @link https://developer.wordpress.org/themes/template-files-section/partial-and-miscellaneous-template-files/#header-php
 *
 * @package Portrait
 * @subpackage TemplatePart
 * @author Ben Gillbanks <ben@prothemedesign.com>
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU Public License
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<div class="webpage">

	<a href="#site-content" class="screen-reader-shortcut"><?php esc_html_e( 'Skip to content', 'portrait' ); ?></a>

	<header class="masthead" id="header">

		<div class="branding">

<?php
	the_custom_logo();

	if ( is_front_page() && ! is_paged() ) {
?>
			<h1 class="site-title">
				<?php bloginfo( 'name' ); ?>
			</h1>
<?php
	} else {
?>
			<p class="site-title">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
			</p>
<?php
	}

	// Get site description.
	$description = get_bloginfo( 'description', 'display' );

	if ( $description || is_customize_preview() ) {
?>
			<p class="site-description">
				<?php echo portrait_widont( $description ); /* WPCS: xss ok. */ ?>
			</p>
<?php
	}

	// Display single level sub-menu.
	if ( has_nav_menu( 'menu-2' ) ) {

?>

<nav class="menu menu-secondary" aria-label="<?php esc_attr_e( 'Secondary Menu', 'portrait' ); ?>">

<?php
	wp_nav_menu(
		array(
			'theme_location' => 'menu-2',
			'menu_id' => 'nav',
			'menu_class' => 'menu-wrap',
			'depth' => 1,
			'fallback_cb' => false,
			'container' => false,
			'item_spacing' => 'discard',
		)
	);
?>

</nav>

<?php

	}

	// Only display the skip to content link if the header is shown full width.
	if ( is_home() || is_page_template( 'templates/full-width-page.php' ) ) {
?>

			<a href="#page-content" class="page-content-shortcut scroll-to">
				<span class="screen-reader-text"><?php esc_html_e( 'Skip to navigation', 'portrait' ); ?></span>
			</a>

<?php
	}
?>

		</div>

<?php

	get_template_part( 'parts/jetpack-featured-content' );

?>

	</header>

	<div class="page-content" id="page-content">

<?php
	// Display main menu.
	if ( has_nav_menu( 'menu-1' ) ) {
?>
		<div class="menu-container">
			<nav class="menu menu-primary" aria-label="<?php esc_attr_e( 'Primary Menu', 'portrait' ); ?>">

				<button class="menu-toggle" type="button" aria-controls="primary-menu" aria-expanded="false">
<?php
		portrait_svg( 'menu-rows' );
		esc_html_e( 'Menu', 'portrait' );
?>
				</button>

<?php
		wp_nav_menu(
			array(
				'theme_location' => 'menu-1',
				'menu_id' => 'nav',
				'menu_class' => 'menu-wrap',
				'fallback_cb' => false,
				'container' => false,
				'item_spacing' => 'discard',
			)
		);
?>

			</nav>

		</div>

<?php
	}

	do_action( 'before' );
?>

		<div class="container" id="site-content">

<?php
	portrait_header();
