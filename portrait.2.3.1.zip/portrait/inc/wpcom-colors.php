<?php
/* Custom Colors: Portrait */

//Background
add_color_rule( 'bg', '#ffffff', array(
	array( 'body,
		input[type=text]:focus,
		input[type=password]:focus,
		input[type=email]:focus,
		input[type=url]:focus,
		input[type=search]:focus,
		input[type="date"]:focus,
		input[type="time"]:focus,
		input[type="datetime-local"]:focus,
		input[type="week"]:focus,
		input[type="month"]:focus,
		input[type="tel"]:focus,
		input[type="number"]:focus,
		input.text:focus,
		select:focus,
		textarea:focus,
		input.settings-input:focus,
		input[type=submit]:focus, input[type=submit]:hover,
		a.button:focus,
		a.button:hover,
		button:focus,
		button:hover,
		.infinite-scroll #infinite-footer .container,
		.woocommerce #respond input#submit:focus, .woocommerce #respond input#submit:hover,
		.woocommerce a.button:focus,
		.woocommerce a.button:hover,
		.woocommerce button.button:focus,
		.woocommerce button.button:hover,
		.woocommerce input.button:focus,
		.woocommerce input.button:hover,
		.woocommerce #respond input#submit.alt:focus, .woocommerce #respond input#submit.alt:hover,
		.woocommerce a.button.alt:focus,
		.woocommerce a.button.alt:hover,
		.woocommerce button.button.alt:focus,
		.woocommerce button.button.alt:hover,
		.woocommerce input.button.alt:focus,
		.woocommerce input.button.alt:hover,
		.menu-container .menu li ul li a:focus,
		.menu-container .menu li ul li a:hover,
		.image-navigation .nav-parent a:hover,
		.image-navigation .nav-next a:hover,
		.image-navigation .nav-previous a:hover,
		.comment-navigation .nav-parent a:hover,
		.comment-navigation .nav-next a:hover,
		.comment-navigation .nav-previous a:hover,
		.post-navigation .nav-parent a:hover,
		.post-navigation .nav-next a:hover,
		.post-navigation .nav-previous a:hover,
		.content-posts article a.post-edit-link:focus,
		.content-posts article a.post-edit-link:hover,
		.content-comments .form-submit input[type=submit]:hover,
		.contributor .contributor-posts-link:focus,
		.contributor .contributor-posts-link:hover,
		.the-content .button:focus,
		.the-content .button:hover', 'background-color' ),

	// Slight contrast against bg
	array( 'input[type=text],
		input[type=password],
		input[type=email],
		input[type=url],
		input[type=search],
		input[type="date"],
		input[type="time"],
		input[type="datetime-local"],
		input[type="week"],
		input[type="month"],
		input[type="tel"],
		input[type="number"],
		input.text,
		select,
		textarea,
		input.settings-input,
		.post-password-required form', 'background-color', 'bg', 1 ),

	// Border color
	array( '.content-comments table', 'border-color', 'txt' ),

	array( 'table th,
		.widget.widget_flickr #flickr_badge_wrapper', 'border-color', 'bg', 3 ),

	// Color - no contrast
	array( 'input[type=submit],
		a.button,
		button,
		.woocommerce #respond input#submit,
		.woocommerce a.button,
		.woocommerce button.button,
		.woocommerce input.button', 'color' ),

	// Color - contrast
	array( '.content-posts article,
		.content-posts article h2.entry-title a,
		.content-posts article h1,
		.content-posts article h2,
		.content-posts article h3,
		.content-posts article h4,
		.content-posts article h5,
		.content-posts article h6,
		.content-posts article a.post-edit-link,
		.contributor .contributor-posts-link,
		.infinite-scroll #infinite-handle,
		.infinite-scroll .infinite-loader', 'color', 'txt' ),

) );

// Text
add_color_rule( 'txt', '#333333', array(
	// Color - no constrast
	array( 'a.thumbnail:after', 'color' ),

	// Color - Contrast against bg - 4
	array( 'input[type=text]::-webkit-input-placeholder,
		input[type=password]::-webkit-input-placeholder,
		input[type=email]::-webkit-input-placeholder,
		input[type=url]::-webkit-input-placeholder,
		input[type=search]::-webkit-input-placeholder,
		input[type="date"]::-webkit-input-placeholder,
		input[type="time"]::-webkit-input-placeholder,
		input[type="datetime-local"]::-webkit-input-placeholder,
		input[type="week"]::-webkit-input-placeholder,
		input[type="month"]::-webkit-input-placeholder,
		input[type="tel"]::-webkit-input-placeholder,
		input[type="number"]::-webkit-input-placeholder,
		input.text::-webkit-input-placeholder,
		select::-webkit-input-placeholder,
		textarea::-webkit-input-placeholder,
		input.settings-input::-webkit-input-placeholder', 'color', 'bg', 4 ),

	array( 'input[type=text]::-moz-placeholder,
		input[type=password]::-moz-placeholder,
		input[type=email]::-moz-placeholder,
		input[type=url]::-moz-placeholder,
		input[type=search]::-moz-placeholder,
		input[type="date"]::-moz-placeholder,
		input[type="time"]::-moz-placeholder,
		input[type="datetime-local"]::-moz-placeholder,
		input[type="week"]::-moz-placeholder,
		input[type="month"]::-moz-placeholder,
		input[type="tel"]::-moz-placeholder,
		input[type="number"]::-moz-placeholder,
		input.text::-moz-placeholder,
		select::-moz-placeholder,
		textarea::-moz-placeholder,
		input.settings-input::-moz-placeholder', 'color', 'bg', 4 ),

	array( 'input[type=text]:-ms-input-placeholder,
		input[type=password]:-ms-input-placeholder,
		input[type=email]:-ms-input-placeholder,
		input[type=url]:-ms-input-placeholder,
		input[type=search]:-ms-input-placeholder,
		input[type="date"]:-ms-input-placeholder,
		input[type="time"]:-ms-input-placeholder,
		input[type="datetime-local"]:-ms-input-placeholder,
		input[type="week"]:-ms-input-placeholder,
		input[type="month"]:-ms-input-placeholder,
		input[type="tel"]:-ms-input-placeholder,
		input[type="number"]:-ms-input-placeholder,
		input.text:-ms-input-placeholder,
		select:-ms-input-placeholder,
		textarea:-ms-input-placeholder,
		input.settings-input:-ms-input-placeholder', 'color', 'bg', 4 ),

	array( 'input[type=text]:placeholder,
		input[type=password]:placeholder,
		input[type=email]:placeholder,
		input[type=url]:placeholder,
		input[type=search]:placeholder,
		input[type="date"]:placeholder,
		input[type="time"]:placeholder,
		input[type="datetime-local"]:placeholder,
		input[type="week"]:placeholder,
		input[type="month"]:placeholder,
		input[type="tel"]:placeholder,
		input[type="number"]:placeholder,
		input.text:placeholder,
		select:placeholder,
		textarea:placeholder,
		input.settings-input:placeholder', 'color', 'bg', 4 ),

	// Contrast against bg - 8
	array( 'body,
		html,
		.infinite-scroll #infinite-footer .blog-info a:focus, .infinite-scroll #infinite-footer .blog-info a:hover,
		.infinite-scroll #infinite-footer .blog-credits a:focus,
		.infinite-scroll #infinite-footer .blog-credits a:hover,
		form.search-form button.search-submit .icon', 'color', 'bg', 8 ),

	array( '.entry-breadcrumbs a:after', 'border-left-color', 'bg', 8 ),
	array( '.showcase .arrow.arrow-next:before,
		.rtl .showcase .arrow.arrow-prev:before', 'border-left-color', 'txt', 8 ),
	array( '.rtl .entry-breadcrumbs a:after', 'border-right-color', 'bg', 8 ),
	array( '.rtl .showcase .arrow.arrow-next:before,
		.showcase .arrow.arrow-prev:before', 'border-right-color', 'txt', 8 ),

	// Contrast against bg - 14
	array( 'h1,
		h2,
		h3,
		h4,
		h5,
		h6,
		h1 a,
		h2 a,
		h3 a,
		h4 a,
		h5 a,
		h6 a,
		input[type=text]:focus,
		input[type=password]:focus,
		input[type=email]:focus,
		input[type=url]:focus,
		input[type=search]:focus,
		input[type="date"]:focus,
		input[type="time"]:focus,
		input[type="datetime-local"]:focus,
		input[type="week"]:focus,
		input[type="month"]:focus,
		input[type="tel"]:focus,
		input[type="number"]:focus,
		input.text:focus,
		select:focus,
		textarea:focus,
		input.settings-input:focus,
		a.button:focus,
		a.button:hover,
		button:focus,
		button:hover,
		.infinite-scroll .infinite-loader,
		.infinite-scroll #infinite-footer .blog-info a,
		.woocommerce #respond input#submit:focus, .woocommerce #respond input#submit:hover,
		.woocommerce a.button:focus,
		.woocommerce a.button:hover,
		.woocommerce button.button:focus,
		.woocommerce button.button:hover,
		.woocommerce input.button:focus,
		.woocommerce input.button:hover,
		.woocommerce #respond input#submit.alt:focus, .woocommerce #respond input#submit.alt:hover,
		.woocommerce a.button.alt:focus,
		.woocommerce a.button.alt:hover,
		.woocommerce button.button.alt:focus,
		.woocommerce button.button.alt:hover,
		.woocommerce input.button.alt:focus,
		.woocommerce input.button.alt:hover,
		.masthead .branding .site-title a,
		.masthead .page-content-shortcut:after,
		.content-posts article a.post-edit-link:focus,
		.content-posts article a.post-edit-link:hover,
		.contributor .contributor-posts-link:focus,
		.contributor .contributor-posts-link:hover,
		.the-content .button:focus,
		.the-content .button:hover', 'color', 'bg', 14 ),

	array( 'input[type=submit],
		a.button,
		button,
		.woocommerce #respond input#submit,
		.woocommerce a.button,
		.woocommerce button.button,
		.woocommerce input.button', 'background-color', 'bg', 14 ),

	array( 'input[type=text],
		input[type=password],
		input[type=email],
		input[type=url],
		input[type=search],
		input[type="date"],
		input[type="time"],
		input[type="datetime-local"],
		input[type="week"],
		input[type="month"],
		input[type="tel"],
		input[type="number"],
		input.text,
		select,
		textarea,
		input.settings-input,
		input[type=text]:hover,
		input[type=password]:hover,
		input[type=email]:hover,
		input[type=url]:hover,
		input[type=search]:hover,
		input[type="date"]:hover,
		input[type="time"]:hover,
		input[type="datetime-local"]:hover,
		input[type="week"]:hover,
		input[type="month"]:hover,
		input[type="tel"]:hover,
		input[type="number"]:hover,
		input.text:hover,
		select:hover,
		textarea:hover,
		input.settings-input:hover,
		input[type=text]:focus,
		input[type=password]:focus,
		input[type=email]:focus,
		input[type=url]:focus,
		input[type=search]:focus,
		input[type="date"]:focus,
		input[type="time"]:focus,
		input[type="datetime-local"]:focus,
		input[type="week"]:focus,
		input[type="month"]:focus,
		input[type="tel"]:focus,
		input[type="number"]:focus,
		input.text:focus,
		select:focus,
		textarea:focus,
		input.settings-input:focus,
		fieldset,
		table th', 'border-color', 'bg', 14 ),

	// Color - contrast against txt
	array( '.infinite-scroll #infinite-footer .blog-credits', 'color', 'txt', 6 ),

	// #666666
	array( '.infinite-scroll #infinite-footer .blog-credits a', 'color', 'txt', 4 ),

	// Background - no contrast
	array( 'pre,
		blockquote,
		.pagination .nav-links,
		#infinite-scroll,
		.content-posts article a.post-edit-link,
		.content-posts article .entry,
		.content-posts article.format-quote .permalink a,
		.content-posts article.format-gallery .slideshow-window,
		.content-single article .entry-header,
		.content-single article.post-has-thumbnail .entry-header:before,
		.content-comments,
		.contributor .contributor-posts-link,
		.showcase,
		.projects-terms,
		.infinite-scroll #infinite-handle button:hover,
		.the-content .button', 'background-color' ),

	// Color - contrast against fg1
	array( '.menu-container .menu li ul li a,
		.menu-container .menu li ul li a:focus,
		.menu-container .menu li ul li a:hover,
		.menu-container .menu a,
		.image-navigation a,
		.comment-navigation a,
		.post-navigation a,
		.content-comments .form-submit input[type=submit],
		.pagination span.current,
		.jetpack-social-navigation div ul a:hover,
		#footer .footer-wrap a', 'color', 'fg1' ),

	// Mobile
	array( '.menu-container .menu .menu-toggle,
		.menu-container .menu li,
		.menu-container .menu li ul li a,
		.menu-container .menu li li a,
		.menu-container .menu li a,
		.menu-container .menu li ul li a:focus, .menu-container .menu li ul li a:hover,
		.menu-container .menu li li a:focus,
		.menu-container .menu li li a:hover,
		.menu-container .menu li a:focus,
		.menu-container .menu li a:hover', 'color', 'fg1' ),

	array( '.menu-container .menu li ul li a:focus,
		.menu-container .menu li ul li a:hover,
		.image-navigation .nav-parent a:hover,
		.image-navigation .nav-next a:hover,
		.image-navigation .nav-previous a:hover,
		.comment-navigation .nav-parent a:hover,
		.comment-navigation .nav-next a:hover,
		.comment-navigation .nav-previous a:hover,
		.post-navigation .nav-parent a:hover,
		.post-navigation .nav-next a:hover,
		.post-navigation .nav-previous a:hover', 'color', 'bg' ),
) );


// Links
add_color_rule( 'link', '#1e71a9', array(
	// Color - contrast against bg
	array( 'a,
		.widget.widget_flickr #flickr_badge_uber_wrapper td a,
		.widget.widget_flickr #flickr_badge_wrapper td a', 'color', 'bg' ),


	// Background
	array( '.woocommerce #respond input#submit.alt,
		.woocommerce a.button.alt,
		.woocommerce button.button.alt,
		.woocommerce input.button.alt', 'background-color' ),
) );


// Light Yellow
add_color_rule( 'fg1', '#fffc8c', array(
	array( 'blockquote a,
		.content-posts article .entry a,
		.content-single article .entry-header a,
		.content-comments a,
		.content-comments ol.comment-list li.comment .reply a .icon,
		.content-testimonials .testimonial .entry a,
		.projects-terms a', 'color', 'txt', 6 ),

	array( '.showcase nav .tab:hover:before,
		.showcase nav .tab.selected:before', 'background-color', 'txt' ),

	array( 'blockquote:before,
		.content-posts article.sticky .entry:before,
		.content-comments .no-comments', 'border-color', 'txt', 6 ),

	// Background
	array( '.menu-container .menu li ul,
		.menu-container .menu,
		.image-navigation,
		.comment-navigation,
		.post-navigation,
		.content-comments .form-submit input[type=submit],
		.pagination span.current,
		#footer .footer-wrap,
		.menu-container .menu', 'background-color' ),

	// Background - Semi-transparent
	array( '.masthead .branding .site-title a:hover,
		.masthead .page-content-shortcut:hover', 'background-color', 0.3 ),
) );


// Extras
add_color_rule( 'extra', '#ffffff', array(
	// Contrast against link
	array( '.woocommerce #respond input#submit.alt,
		.woocommerce a.button.alt,
		.woocommerce button.button.alt,
		.woocommerce input.button.alt', 'color', 'link' ),

	// Contrast against bg
	array( '.content-comments .form-submit input[type=submit]:hover', 'color', 'bg' ),

	// Contrast against txt
	array( 'blockquote,
		.pagination .nav-links,
		.pagination .nav-links a,
		.content-single article .entry-header .entry-title,
		.content-testimonials .testimonial .entry p,
		.projects-terms,
		.infinite-scroll #infinite-handle button:hover,
		.the-content .button,
		.content-comments,
		.content-comments h1,
		.content-comments h2,
		.content-comments h3,
		.content-comments h4,
		.content-comments h5,
		.content-comments h6,
		pre', 'color', 'txt' ),


	array( '.content-comments ol.comment-list li.comment .reply a', 'color', 'txt', 4 ),

	// Contrast against fg1
	array( '.pagination .nav-links span.current', 'color', 'fg1' ),

	array( '.showcase nav .tab:before', 'background-color', 'txt' ),
) );


//Extra CSS
function portrait_extra_css() { ?>
	.rtl .entry-breadcrumbs a:after,
	.rtl .showcase .arrow.arrow-next:before {
		border-left-color: transparent;
	}

	.rtl .showcase .arrow.arrow-prev:before {
		border-right-color: transparent;
	}

	/* Reduce text shadow, to work nicer when dealing with lighter backgrounds */
	.content-single article.post-has-thumbnail .entry-header .post-meta-data,
	.content-single article.post-has-thumbnail .entry-header .entry-title {
		text-shadow: 0 0 1em rgba(0,0,0,0.5);
	}

<?php }
add_theme_support( 'custom_colors_extra_css', 'portrait_extra_css' );


//Additional palettes
add_color_palette( array(
	'#efefef',
	'#3a3a3a',
	'#db4c4c',
	'#00b4cc',
) );

add_color_palette( array(
	'#ffffff',
	'#572d4b',
	'#ce3b87',
	'#83d2a1'
) );

add_color_palette( array(
	'#ffffff',
	'#0c264a',
	'#ac1028',
	'#96b6e2',
) );

add_color_palette( array(
	'#0f0f0f',
	'#282828',
	'#8ddccf',
	'#30ab96'
) );

add_color_palette( array(
	'#262626',
	'#111111',
	'#ee5353',
	'#931a1a'
) );

add_color_palette( array(
	'#222222',
	'#111111',
	'#78abd7',
	'#236aa8'
) );
