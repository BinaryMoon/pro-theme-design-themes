<?php
/**
 * Theme Customizer
 *
 * @link https://developer.wordpress.org/themes/advanced-topics/customizer-api/
 *
 * @package Portrait
 * @subpackage ThemeCustomizerSettings
 * @author Ben Gillbanks <ben@prothemedesign.com>
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU Public License
 */

/**
 * Exit if we're not in the Customizer.
 */
if ( ! class_exists( 'WP_Customize_Control' ) ) {

	return null;

}




/**
 * Theme Customizer properties
 *
 * @param WP_Customize_Manager $wp_customize WP Customize object. Passed by WordPress.
 */
function portrait_customizer_settings( WP_Customize_Manager $wp_customize ) {

	/**
	 * Portrait theme options section.
	 */
	$wp_customize->add_section(
		'portrait_options',
		array(
			'title' => esc_html__( 'Theme Options', 'portrait' ),
		)
	);

	/**
	 * Setting to control whether the slider autoplays or not.
	 */
	$wp_customize->add_setting(
		'portrait_autoplay_slider',
		array(
			'default' => false,
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'portrait_sanitize_checkboxes',
		)
	);

	$wp_customize->add_control(
		'portrait_autoplay_slider',
		array(
			'label' => esc_html__( 'Autoplay the Featured Content Slider', 'portrait' ),
			'section' => 'portrait_options',
			'type' => 'checkbox',
		)
	);

}

add_action( 'customize_register', 'portrait_customizer_settings' );


/**
 * Update Theme Elements without refreshing content.
 *
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function portrait_register_customize_refresh( WP_Customize_Manager $wp_customize ) {

	// Ensure selective refresh is enabled.
	if ( ! isset( $wp_customize->selective_refresh ) ) {

		return false;

	}

	// Update site title.
	$wp_customize->get_setting( 'blogname' )->transport = 'postMessage';

	$wp_customize->selective_refresh->add_partial(
		'blogname',
		array(
			'selector' => '.site-title',
			'render_callback' => function() {
				bloginfo( 'name' );
			},
		)
	);

	// Update site description.
	$wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';

	$wp_customize->selective_refresh->add_partial(
		'blogdescription',
		array(
			'selector' => '.site-description',
			'render_callback' => function() {
				bloginfo( 'description' );
			},
		)
	);

	// Show and hide header text.
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

}

add_action( 'customize_register', 'portrait_register_customize_refresh' );


/**
 * Binds JS handlers to make the Customizer preview reload changes asynchronously.
 */
function portrait_customize_preview_js() {

	wp_enqueue_script( 'portrait-customize-preview', get_theme_file_uri( '/assets/scripts/customizer-preview.js' ), array( 'customize-preview' ), '1.0', true );

}

add_action( 'customize_preview_init', 'portrait_customize_preview_js' );


/**
 * Sanitize checkbox input
 *
 * @param boolean $setting Value to check and sanitize.
 * @return boolean
 */
function portrait_sanitize_checkboxes( $setting ) {

	return (bool) $setting;

}
