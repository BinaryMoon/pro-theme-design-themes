<?php
/**
 * Image Attachment Template
 *
 * This file displays Image attachments on their own page with a link back to
 * the parent blog post/ page.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Portrait
 * @subpackage Template
 * @author Ben Gillbanks <ben@prothemedesign.com>
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU Public License
 */

	get_header();

	if ( have_posts() ) {

?>

	<main class="main-content content-single">

<?php
		while ( have_posts() ) {

			the_post();
?>

		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

			<header class="entry-header">

<?php
			the_title( '<h1 class="entry-title">', '</h1>' );
			get_template_part( 'parts/post-meta' );
?>

			</header>

			<div class="attachment-image">
				<?php echo wp_get_attachment_link( get_the_ID(), 'portrait-attachment-fullsize' ); ?>
			</div>
<?php
			if ( has_excerpt() ) {
?>
					<div class="attachment-caption">
						<?php the_excerpt(); ?>
					</div>
<?php
			}
?>
			<section class="entry entry-single">

				<div class="attachment-description">
<?php
			the_content();
?>
				</div>

			</section>
<?php
			if ( $post->post_parent ) {
?>

				<nav id="image-navigation" class="navigation image-navigation">
					<div class="nav-links">
						<span class="nav-parent">
							<a href="<?php echo esc_url( get_permalink( $post->post_parent ) ); ?>" rev="attachment" class="attachment-parent"><?php esc_html_e( '&lsaquo; Return to post', 'portrait' ); ?></a>
						</span>
						<span class="nav-previous">
							<?php previous_image_link( false, esc_html__( 'Previous Image', 'portrait' ) ); ?>
						</span>
						<span class="nav-next">
							<?php next_image_link( false, esc_html__( 'Next Image', 'portrait' ) ); ?>
						</span>
					</div>
				</nav>

<?php
			}
?>

		</article>

<?php
			get_template_part( 'parts/comments' );

		} // End while().
?>

	</main>

<?php
	} // End if().

	get_footer();
