<?php
/**
 * Reusable theme functions
 *
 * @package Exhibit
 */

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 * keep in mind the theme is responsive so the width is likely to be narrower
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function exhibit_content_width() {

	$width = 700;

	if ( is_page_template( 'page-templates/full-width.php' ) || ! is_active_sidebar( 'sidebar-1' ) ) {
		$width = 1080;
	}

	$GLOBALS['content_width'] = apply_filters( 'exhibit_content_width', $width );

}

add_action( 'after_setup_theme', 'exhibit_content_width', 0 );


/**
 * Enqueue all the styles.
 *
 * @global type $wp_scripts
 */
function exhibit_enqueue() {

	// Styles.
	wp_enqueue_style( 'exhibit-style', get_stylesheet_uri(), null, '1.0' );
	wp_enqueue_style( 'genericons', get_template_directory_uri() . '/styles/genericons/genericons.css', array(), '3.0.3' );

	// Fonts.
	$fonts_url = exhibit_fonts();

	if ( $fonts_url ) {
		wp_enqueue_style( 'exhibit-fonts', $fonts_url, array(), '1.1' );
	}

	// Javascript.
	// Enqueue masonry for the footer (sidebar-2) and testimonials archive.
	if ( is_active_sidebar( 'sidebar-2' ) || is_post_type_archive( 'jetpack-testimonial' ) ) {
		wp_enqueue_script( 'masonry' );
	}

	wp_enqueue_script( 'exhibit-script-main', get_template_directory_uri() . '/js/main.js', array( 'jquery' ), '1.0', false );

	wp_localize_script(
		'exhibit-script-main',
		'js_i18n',
		array(
			'next' => esc_html__( 'next', 'exhibit' ),
			'prev' => esc_html__( 'previous', 'exhibit' ),
			'menu' => esc_html__( 'Menu', 'exhibit' ),
		)
	);

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

}

add_action( 'wp_enqueue_scripts', 'exhibit_enqueue' );


/**
 * Set up all the theme properties and extras
 */
function exhibit_after_setup_theme() {

	load_theme_textdomain( 'exhibit', get_template_directory() . '/languages' );

	add_theme_support( 'automatic-feed-links' );

	// Post thumbnails.
	add_theme_support( 'post-thumbnails' );

	// Image sizes.
	add_image_size( 'exhibit-attachment', 100, 100, true ); // Used for attachment (image.php) page links.
	add_image_size( 'exhibit-logo', 200, 999 );
	add_image_size( 'exhibit-header', 1440, 400, true );
	add_image_size( 'exhibit-archive', 600, 390, true );
	add_image_size( 'exhibit-testimonial', 60, 60, true );
	add_image_size( 'exhibit-attachment-fullsize', 1440, 9999 );

	// Custom background.
	add_theme_support(
		'custom-background',
		apply_filters(
			'exhibit-custom-background',
			array(
				'default-color' => 'f2f2f2',
				'default-image' => '',
			)
		)
	);

	// HTML5 ftw.
	add_theme_support(
		'html5',
		array(
			'comment-form',
			'gallery',
			'caption',
			'widgets',
			'navigation-widgets',
		)
	);

	// Title tag.
	add_theme_support( 'title-tag' );

	register_nav_menu( 'top_menu', esc_html__( 'Top Menu', 'exhibit' ) );
	register_nav_menu( 'footer_menu', esc_html__( 'Footer Menu', 'exhibit' ) );
	register_nav_menu( 'social_menu', esc_html__( 'Social Menu', 'exhibit' ) );

	// Add support for full width images and other content such as videos.
	add_theme_support( 'align-wide' );

	// Disable custom font sizes, ensuring consistent vertical rhythm.
	add_theme_support( 'disable-custom-font-sizes' );

	// Make Gutenberg embeds responsive.
	add_theme_support( 'responsive-embeds' );

	// Editor font sizes.
	// Uses the default slugs to ensure consistency across themes.
	add_theme_support(
		'editor-font-sizes',
		array(
			array(
				'name' => esc_html__( 'small', 'exhibit' ),
				'size' => 13,
				'slug' => 'small',
			),
			array(
				'name' => esc_html__( 'normal', 'exhibit' ),
				'size' => 16,
				'slug' => 'normal',
			),
			array(
				'name' => esc_html__( 'medium', 'exhibit' ),
				'size' => 20,
				'slug' => 'medium',
			),
			array(
				'name' => esc_html__( 'large', 'exhibit' ),
				'size' => 36,
				'slug' => 'large',
			),
			array(
				'name' => esc_html__( 'huge', 'exhibit' ),
				'size' => 42,
				'slug' => 'huge',
			),
		)
	);

	// Editor fonts.
	$fonts_url = exhibit_fonts();

	if ( $fonts_url ) {
		add_editor_style( $fonts_url );
	}

	// Add support for editor styles.
	add_theme_support( 'editor-styles' );

	add_editor_style( 'styles/css/editor-style.css' );

}

add_action( 'after_setup_theme', 'exhibit_after_setup_theme' );


/**
 * Enqueue WordPress theme styles within Gutenberg.
 */
function exhibit_editor_blocks_styles() {

	// Load the additional editor styles.
	// This covers things like the editor title that can't be styled with the normal editor styles.
	wp_enqueue_style( 'exhibit-editor-blocks', get_theme_file_uri( '/styles/css/editor-blocks.css' ), null, '1' );

	/**
	 * Overwrite Core theme styles with empty styles.
	 * @see https://github.com/WordPress/gutenberg/issues/7776#issuecomment-406700703
	 */
	wp_deregister_style( 'wp-block-library-theme' );
	wp_register_style( 'wp-block-library-theme', '' );

}

add_action( 'enqueue_block_editor_assets', 'exhibit_editor_blocks_styles' );
add_action( 'enqueue_block_assets', 'exhibit_editor_blocks_styles' );


/**
 * Initialize Widgets.
 */
function exhibit_widgets_init() {

	// Sidebar.
	register_sidebar(
		array(
			'name' => esc_html__( 'Sidebar Widgets', 'exhibit' ),
			'id' => 'sidebar-1',
			'description' => esc_html__( 'Widgets that display on the side of your website', 'exhibit' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h3 class="widgettitle">',
			'after_title' => '</h3>',
		)
	);

	// Footer widgets.
	register_sidebar(
		array(
			'name' => esc_html__( 'Footer Widgets', 'exhibit' ),
			'id' => 'sidebar-2',
			'description' => esc_html__( 'Widgets that display at the bottom of your website. They are arranged in 3 columns and lined up automatically to make the best use of the space available.', 'exhibit' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h3 class="widgettitle">',
			'after_title' => '</h3>',
		)
	);

}

add_action( 'widgets_init', 'exhibit_widgets_init' );


/**
 * Custom excerpt length
 *
 * @param int $length Current length of excpert.
 * @return int
 */
function exhibit_excerpt_length( $length ) {

	$length = 30;

	// If there's no thumbnail then show a longer excerpt to fill the space better.
	if ( ! get_the_post_thumbnail( get_the_ID() ) ) {
		$length = 90;
	}

	return $length;

}

add_filter( 'excerpt_length', 'exhibit_excerpt_length', 18 );


/**
 * F for navigation menu
 *
 * @param array $params List of menu parameters.
 * @return string
 */
function exhibit_nav_menu( $params ) {

	$html = '';
	$echo = $params['echo'];

	$params['echo'] = false;
	$html = wp_page_menu( $params );

	if ( $params['container'] ) {
		$container_start = '<' . $params['container'] . ' id="' . $params['container_id'] . '" class="' . $params['container_class'] . '">';
		$container_end = '</' . $params['container'] . '>';

		$html = str_replace( '<div class="' . $params['menu_class'] . '">', $container_start, $html );
		$html = str_replace( '</div>', $container_end, $html );
	}

	if ( $echo ) {
		echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	} else {
		return $html;
	}

}


/**
 * Numeric pagination for custom queries
 * Much nicer than next and previous links :)
 * Based on code from TwentyFourteen
 *
 * @global type $wp_query
 * @return type
 */
function exhibit_numeric_pagination() {

	global $wp_query, $wp_rewrite;

	if ( 1 >= $wp_query->max_num_pages ) {
		return;
	}

	$paged = get_query_var( 'paged' ) ? intval( get_query_var( 'paged' ) ) : 1;
	$pagenum_link = html_entity_decode( get_pagenum_link() );
	$query_args = array();
	$url_parts = explode( '?', $pagenum_link );

	if ( isset( $url_parts[1] ) ) {
		wp_parse_str( $url_parts[1], $query_args );
	}

	$pagenum_link = remove_query_arg( array_keys( $query_args ), $pagenum_link );
	$pagenum_link = trailingslashit( $pagenum_link ) . '%_%';

	$format = $wp_rewrite->using_index_permalinks() && ! strpos( $pagenum_link, 'index.php' ) ? 'index.php/' : '';
	$format .= $wp_rewrite->using_permalinks() ? user_trailingslashit( $wp_rewrite->pagination_base . '/%#%', 'paged' ) : '?paged=%#%';

	// Set up paginated links.
	$links = paginate_links(
		array(
			'base' => $pagenum_link,
			'format' => $format,
			'total' => $wp_query->max_num_pages,
			'current' => $paged,
			'mid_size' => 2,
			'add_args' => array_map( 'urlencode', $query_args ),
			'next_text' => esc_html__( 'Older &rsaquo;', 'exhibit' ),
			'prev_text' => esc_html__( '&lsaquo; Newer', 'exhibit' ),
		)
	);

	if ( $links ) {
?>
	<nav class="archive-pagination pagination" role="navigation">
		<h1 class="screen-reader"><?php esc_html_e( 'Posts navigation', 'exhibit' ); ?></h1>
		<?php echo $links; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	</nav>
<?php
	}

}


/**
 * Add additional body classes that may be helpful
 *
 * @param array $styles List of body classes.
 * @return array
 */
function exhibit_body_class( $styles ) {

	if ( is_singular() ) {
		$styles[] = 'singular';
	}

	if ( is_active_sidebar( 'sidebar-1' ) ) {
		$styles[] = 'themes-sidebar1-active';
	} else {
		$styles[] = 'themes-sidebar1-inactive';
	}

	if ( is_active_sidebar( 'sidebar-2' ) ) {
		$styles[] = 'themes-sidebar2-active';
	} else {
		$styles[] = 'themes-sidebar2-inactive';
	}

	if ( get_header_image() ) {
		$styles[] = 'has-custom-header';
	}

	return $styles;

}

add_filter( 'body_class', 'exhibit_body_class' );


/**
 * Additional styles for post class
 *
 * @param array $styles List of post classes.
 * @return array
 */
function exhibit_post_class( $styles ) {

	if ( is_singular() && is_main_query() ) {
		$styles[] = 'post-singular';
	} else {
		$styles[] = 'post-archive';
	}

	if ( get_the_post_thumbnail( get_the_ID() ) ) {
		$styles[] = 'post-has-thumbnail';
	}

	return $styles;

}

add_filter( 'post_class', 'exhibit_post_class' );


/**
 * Display header image and link to homepage
 * On pages display featured image if it is large enough to fill the space
 */
function exhibit_header() {

	$header_image = get_header_image();
	$header_image_width = get_theme_support( 'custom-header', 'width' );
	$header_image_actual_width = get_custom_header()->width;
	$header_image_actual_height = get_custom_header()->height;

	// Use custom headers on pages, but only if the image is large enough.
	if ( is_page() ) {

		$image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'exhibit-header' );

		if ( ! empty( $image ) && $image[1] >= $header_image_width ) {
			$header_image = esc_url( $image[0] );
			$header_image_actual_width = (int) $image[1];
			$header_image_actual_height = (int) $image[2];
		}
	}

	if ( ! empty( $header_image ) ) {
?>
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home" class="header-image">
			<img src="<?php echo esc_url( $header_image ); ?>" width="<?php echo (int) $header_image_actual_width; ?>" height="<?php echo (int) $header_image_actual_height; ?>" alt="" />
		</a>
<?php
	}

}


/**
 * Display human readable time format.
 *
 * @return string
 */
function exhibit_human_time_diff() {

	$post_time = get_the_time( 'U' );
	$human_time = '';

	$time_now = gmdate( 'U' );

	// Use human time if less that 60 days ago
	// 60 seconds * 60 minutes * 24 hours * 90 days.
	if ( $post_time > $time_now - ( 60 * 60 * 24 * 90 ) ) {
		// Translators: %s = time.
		$human_time = sprintf( esc_html__( '%s ago', 'exhibit' ), human_time_diff( $post_time, current_time( 'timestamp' ) ) );
	} else {
		$human_time = get_the_date();
	}

	return $human_time;

}


/**
 * Get post thumbnail url
 * If a thumbnail doesn't exist then use the first attachment
 * reduces user confusion since they don't always understand the featured image functionality
 *
 * @param  int    $post_id        Post id.
 * @param  string $thumbnail_size Thumbnail size.
 * @return string image
 */
function exhibit_archive_image_url( $post_id = null, $thumbnail_size = 'exhibit-archive' ) {

	if ( ! $post_id ) {
		$post_id = get_the_ID();
	}

	$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post_id ), $thumbnail_size );

	// If there's no featured image then grab an attachment image and use that instead.
	if ( ! $image[0] ) {

		$values = get_attached_media( 'image', $post_id );

		if ( $values ) {
			foreach ( $values as $child_id => $attachment ) {
				$image = wp_get_attachment_image_src( $child_id, $thumbnail_size );
				break;
			}
		}
	}

	if ( $image ) {
		return $image;
	} else {
		return false;
	}

}


/**
 * Fill empty post thumbnails with images from the first attachment added to a post
 *
 * @param string $html Post thumbnail html.
 * @param int    $post_id Post id.
 * @param int    $thumbnail_id Thumbnail id.
 * @param string $size Thumbnail size.
 * @return string
 */
function exhibit_post_thumbnail_html( $html, $post_id, $thumbnail_id, $size = '' ) {

	if ( empty( $html ) ) {

		$values = get_attached_media( 'image', $post_id );

		if ( $values ) {
			foreach ( $values as $child_id => $attachment ) {
				$html = wp_get_attachment_image( $child_id, $size );
				break;
			}
		}
	}

	return $html;

}

add_filter( 'post_thumbnail_html', 'exhibit_post_thumbnail_html', 10, 4 );


add_filter( 'use_default_gallery_style', '__return_false' );


/**
 * Get a list of children for the current page
 *
 * @return WP_Query
 */
function exhibit_child_pages() {

	return new WP_Query(
		array(
			'post_type'      => 'page',
			'orderby'        => 'menu_order',
			'order'          => 'ASC',
			'post_parent'    => get_the_ID(),
			'posts_per_page' => 999,
			'no_found_rows'  => true,
		)
	);

}


/**
 * Display the first category for the current post/ project
 */
function exhibit_the_main_category() {

	$term_type = 'category';
	if ( 'jetpack-portfolio' === get_post_type() ) {
		$term_type = 'jetpack-portfolio-type';
	}

	$category = get_the_terms( get_the_ID(), $term_type );

	if ( is_array( $category ) ) {
		$category = array_values( $category );
		$category = current( $category );

		if ( is_object( $category ) ) {
?>
	<span class="post-lead-category"><a href="<?php echo esc_url( get_category_link( $category, $term_type ) ); ?>"><?php echo esc_html( $category->name ); ?></a></span>
<?php
		}
	}

}


/**
 * Get the posts custom read more text and, if available, display it instead of 'read more'
 */
function exhibit_read_more_text() {

	// Default text value.
	$read_more = esc_html__( 'Read More &rarr;', 'exhibit' );

	// Get post data.
	$post = get_post();
	$custom_readmore = get_extended( $post->post_content );

	if ( ! empty( $custom_readmore['more_text'] ) ) {
		$read_more = $custom_readmore['more_text'];
	}

	echo esc_html( $read_more );

}


/**
 * Add 'Read more' link to excerpts
 *
 * @param  string $excerpt Current more link.
 * @return string
 */
function exhibit_excerpt_more( $excerpt ) {

	// Translators: %1$s = post title.
	return '&hellip; <a class="read-more" href="' . esc_url( get_permalink() ) . '">' . sprintf( wp_kses_post( __( 'Read more <span class="screen-reader-text">%1$s</span> &rarr;', 'exhibit' ) ), esc_attr( wp_strip_all_tags( get_the_title() ) ) ) . '</a>';

}

add_filter( 'excerpt_more', 'exhibit_excerpt_more' );


/**
 * Display a list of all of the project categories
 */
function exhibit_project_terms() {

	$terms = get_terms(
		'jetpack-portfolio-type',
		array(
			'number' => 20,
			'orderby' => 'count',
			'order' => 'DESC',
		)
	);

	// Highlight currently selected page.
	$class = 'current-page';

	// Get the term for the current page.
	$current_term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );

	// We're on a project category page, and not the main portfolio page, so reset the class.
	if ( $current_term ) {
		$class = '';
	}

	// Make sure the term exists and has some results.
	if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
?>

	<p class="projects-terms">

		<a class="<?php echo esc_attr( $class ); ?>" href="<?php echo esc_url( home_url( '/portfolio/' ) ); ?>"><?php esc_html_e( 'All', 'exhibit' ); ?></a>

<?php
		foreach ( $terms as $t ) {
			$class = '';

			if ( $current_term && $current_term->term_id === (int) $t->term_id ) {
				$class = 'current-page';
			}
?>
		<a class="<?php echo esc_attr( $class ); ?>" href="<?php echo esc_url( get_term_link( $t ) ); ?>"><?php echo esc_html( $t->name ); ?></a>
<?php
		}
?>

	</p>

<?php
	}

}


/**
 * Custom comments layout
 *
 * @param object $comment The comment object.
 * @param array  $args Comment display arguments.
 * @param int    $depth The depth for the current comment.
 * @return void
 */
function exhibit_comments_layout( $comment, $args, $depth ) {

	if ( ( 'pingback' === $comment->comment_type || 'trackback' === $comment->comment_type ) && $args['short_ping'] ) {
		exhibit_comments_ping( $comment, $depth, $args );
	} else {
		exhibit_comments_comment( $comment, $depth, $args );
	}

}


/**
 * Custom pings layout
 * it's actually the same as the default pings html but but I can't see a way to reuse the one from the comments walker class
 *
 * @param object $comment The comment object.
 * @param int    $depth The depth for the current comment.
 * @param array  $args Comment display arguments.
 * @return void
 */
function exhibit_comments_ping( $comment, $depth, $args ) {

		$tag = ( 'div' === $args['style'] ) ? 'div' : 'li';
?>
		<<?php echo $tag; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> id="comment-<?php comment_ID(); ?>" <?php comment_class(); ?>>
			<div class="comment-body">
				<?php printf( esc_html__( 'Pingback: %s', 'exhibit' ), get_comment_author_link() ); ?> <?php edit_comment_link( esc_html__( 'Edit', 'exhibit' ), '<span class="edit-link">', '</span>' ); ?>
			</div>
<?php

}


/**
 * Custom comments layout.
 *
 * @param object $comment The comment object.
 * @param int    $depth The depth for the current comment.
 * @param array  $args Comment display arguments.
 * @return void
 */
function exhibit_comments_comment( $comment, $depth, $args ) {

	$tag = ( 'div' === $args['style'] ) ? 'div' : 'li';
?>
	<<?php echo $tag; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> id="comment-<?php comment_ID(); ?>" <?php comment_class(); ?>>
		<article id="div-comment-<?php comment_ID(); ?>">
			<footer class="comment-meta">
				<div class="comment-author vcard">
					<a href="<?php echo esc_url( get_comment_author_url( $comment->comment_ID ) ); ?>" rel="external nofollow" class="url avatar-link">
						<?php if ( 0 != $args['avatar_size'] ) echo get_avatar( $comment, $args['avatar_size'] ); ?>
					</a>
					<span class="author-link">
						<?php comment_author_link(); ?>
					</span>
					<div class="comment-meta-data">
						<span class="comment-link">
							<a href="<?php echo esc_url( get_comment_link( $comment->comment_ID, $args ) ); ?>" class="comment-link">
								<time datetime="<?php comment_time( 'c' ); ?>">
									<?php printf( esc_html_x( '%1$s at %2$s', '1: date, 2: time', 'exhibit' ), get_comment_date(), get_comment_time() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								</time>
							</a>
						</span>
<?php
	edit_comment_link( esc_html__( 'Edit', 'exhibit' ), '<span class="edit-link">', '</span>' );

	comment_reply_link(
		array_merge(
			$args,
			array(
				'add_below' => 'div-comment',
				'depth'     => $depth,
				'max_depth' => $args['max_depth'],
				'before'    => '<span class="reply">',
				'after'     => '</span>',
			)
		)
	);
?>
					</div>
				</div>
			</footer>

			<div class="comment-body">
<?php
	comment_text();

	if ( '0' == $comment->comment_approved ) {
?>
				<p class="comment-awaiting-moderation"><?php esc_html_e( 'Your comment is awaiting moderation.', 'exhibit' ); ?></p>
<?php
	}
?>
			</div>


		</article>
<?php

}


/**
 * Get url for google fonts.
 *
 * @return string|false
 */
function exhibit_fonts() {

	$fonts = array();

	/**
	 * Translators: If there are characters in your language that are not
	 * supported, translate this to 'off'. Do not translate into your
	 * own language.
	 */
	$font = esc_html_x( 'on', 'Roboto Slab: on or off', 'exhibit' );

	if ( 'off' !== $font ) {
		$fonts['roboto-slab'] = 'Roboto Slab:300,400';
	}

	$fonts = apply_filters( 'exhibit_fonts', $fonts );

	if ( $fonts ) {
		$query_args = array(
			'family' => rawurlencode( implode( '|', $fonts ) ),
			'subset' => rawurlencode( 'latin,latin-ext' ),
		);

		return add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
	}

	return false;

}


// Custom header.
require 'inc/custom-header.php';

// Jetpack specific functionality.
require 'inc/jetpack.php';

// Customizer controls for setting theme properties.
require 'inc/customizer.php';


/**
 * Load WooCommerce compatibility file.
 */
if ( class_exists( 'WooCommerce' ) ) {
	require 'inc/woocommerce.php';
}
