<?php
/**
 * Full width page template
 * Template Name: Full Width
 *
 * @package Exhibit
 */

	get_header();
?>
	<div class="container">
		<div class="main-content full-width">
<?php
	if ( have_posts() ) {
		while ( have_posts() ) {
			the_post();
			get_template_part( 'content-page' );
			get_template_part( 'inc/comments' );
		}
	}
?>
		</div>
	</div>
<?php
	get_footer();
