<?php
/**
 * Template Name: Contributor Page
 *
 * @package Exhibit
 */

	get_header();

	if ( have_posts() ) {
?>
	<div class="container">
		<div class="main-content">
<?php
		while ( have_posts() ) {
			the_post();
?>
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<?php
			the_title( '<h1 class="entry-title">', '</h1>' );
?>
			<section class="entry entry-single">
<?php
			the_content();
			edit_post_link();
?>
			</section>

			<section class="entry-contributors">
<?php
			get_template_part( 'content-contributors' );
?>
			</section>
		</article>
<?php
			get_template_part( 'inc/comments' );
		}
?>
		</div>
<?php
	} else {
		get_template_part( 'content-empty' );
	}

	get_sidebar();
?>
	</div>
<?php
	get_footer();
