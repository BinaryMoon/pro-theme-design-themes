<?php
/**
 * Projects template
 * Template Name: Projects and Testimonials Homepage
 *
 * @package Exhibit
 */

	get_header();

	if ( have_posts() ) {
		while ( have_posts() ) {
			the_post();

			if ( get_the_content() ) {
?>
	<section class="content-wrapper content-projects-title">
		<div class="container site-intro">
			<?php the_content(); ?>
		</div>
	</section>
<?php
			}
		}
	}

	get_template_part( 'inc/jetpack-projects' );

	get_template_part( 'inc/jetpack-testimonials' );

	get_footer();
