<?php
/**
 * Homepage Template
 *
 * @package Exhibit
 */

	get_header();

	if ( have_posts() ) {
?>
	<section class="content-wrapper content-blog-posts">
		<div id="main-content" class="container exhibit post-archive">
<?php
		while ( have_posts() ) {
			the_post();
			get_template_part( 'content', get_post_format() );
		}
		exhibit_numeric_pagination();
?>
		</div>
	</section>
<?php
	} else {
		get_template_part( 'content-empty' );
	}

	get_footer();
