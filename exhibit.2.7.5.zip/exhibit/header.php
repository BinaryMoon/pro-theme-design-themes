<?php
/**
 * Header Template
 *
 * @package Exhibit
 */

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a href="#main-content" class="screen-reader-shortcut"><?php esc_html_e( 'Skip to content', 'exhibit' ); ?></a>

<div class="page-wrapper">

<header class="masthead" role="banner">
	<div class="branding-menu container">
		<div class="branding">
			<?php exhibit_site_logo(); ?>
			<h1 class="site-title">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php esc_attr_e( 'Home', 'exhibit' ); ?>">
					<?php bloginfo( 'name' ); ?>
				</a>
			</h1>
			<p class="site-description">
				<?php bloginfo( 'description' ); ?>
			</p>
		</div>
	</div>

	<nav class="menu menu-after-header" role="navigation">
		<h3 class="menu-toggle"><?php esc_html_e( 'Menu', 'exhibit' ); ?></h3>
<?php
	wp_nav_menu(
		array(
			'theme_location' => 'top_menu',
			'menu_id' => 'nav',
			'menu_class' => 'menu-wrap',
			'container' => false,
		)
	);
?>
	</nav>
</header>


<?php exhibit_header(); ?>

<div class="hfeed">
<?php
	do_action( 'before' );
?>
	<div class="main">
