<?php
/**
 * Single portfolio template
 *
 * @package Exhibit
 */

	get_header();

?>
	<div class="container">
		<div class="main-content main-content-portfolio">
<?php

	if ( have_posts() ) {

		while ( have_posts() ) {
			the_post();
			get_template_part( 'content-portfolio' );
			get_template_part( 'inc/comments' );
		}

	} else {
		get_template_part( 'content-empty' );
	}

?>
		</div>
	</div>
<?php
	get_template_part( 'inc/jetpack-testimonials' );

	get_footer();
