<?php
/**
 * Search results template
 *
 * @package Exhibit
 */

	get_header();
?>
	<header class="entry-archive-header">
		<h1 class="entry-title entry-archive-title">
			<?php printf( esc_html__( 'Search results for &#8216;%s&#8217;', 'exhibit' ), get_search_query() ); ?>
		</h1>
	</header>

	<div id="main-content" class="container post-archive">
<?php
	if ( have_posts() ) {
		while ( have_posts() ) {
			the_post();
			get_template_part( 'content', get_post_format() );
		}
		exhibit_numeric_pagination();
	} else {
		get_template_part( 'content-empty' );
	}
?>
	</div>
<?php
	get_footer();
