<?php
/**
 * Single post content
 *
 * @package Exhibit
 */

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<?php
	the_title( '<h1 class="entry-title">', '</h1>' );
	get_template_part( 'inc/post-meta' );
?>
	<section class="entry entry-single">
<?php
	the_content();

	edit_post_link();

	wp_link_pages(
		array(
			'before' => '<div class="archive-pagination">',
			'after'  => '</div>',
			'link_before' => '<span>',
			'link_after'  => '</span>',
		)
	);

	get_template_part( 'inc/post-terms' );
?>
	</section>
</article>

<nav class="post-nav">
	<h1 class="screen-reader"><?php esc_html_e( 'Post navigation', 'exhibit' ); ?></h1>
<?php
	the_post_navigation(
		array(
			'prev_text' => '<span>%title</span>',
			'next_text' => '<span>%title</span>',
		)
	);
?>
</nav>
