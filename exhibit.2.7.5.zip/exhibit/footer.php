<?php
/**
 * Footer Template
 *
 * @package Exhibit
 */
?>
	</div>
</div>

<?php
	if ( is_active_sidebar( 'sidebar-2' ) && ! is_front_page() ) {
?>
	<aside class="footer-widgets-container">
		<div class="container footer-widgets sidebar-footer">
			<?php dynamic_sidebar( 'sidebar-2' ); ?>
		</div>
	</aside>
<?php
	}
?>
	<footer role="contentinfo" id="footer">
<?php
	if ( has_nav_menu( 'social_menu' ) ) {

		wp_nav_menu(
			array(
				'theme_location' => 'social_menu',
				'depth' => 1,
				'container_class' => 'menu-social-links',
				'container' => 'div',
				'link_before' => '<span class="screen-reader">',
				'link_after' => '</span>',
				'fallback_cb' => '__return_false',
			)
		);

	}

	if ( has_nav_menu( 'footer_menu' ) ) {
?>
		<nav class="menu" role="navigation">
<?php
	wp_nav_menu(
		array(
			'theme_location' => 'footer_menu',
			'menu_id' => 'nav',
			'menu_class' => 'menu-wrap',
			'container' => false,
			'depth' => 1,
		)
	);
?>
		</nav>
<?php
	}
?>
			<section class="footer-wrap">
<?php
	if ( function_exists( 'the_privacy_policy_link' ) ) {
		the_privacy_policy_link( '', '<span class="sep" role="separator" aria-hidden="true"> | </span>' );
	}
?>				<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'exhibit' ) ); ?>" title="<?php esc_attr_e( 'A Semantic Personal Publishing Platform', 'exhibit' ); ?>" rel="generator"><?php printf( esc_html__( 'Proudly powered by %s', 'exhibit' ), 'WordPress' ); ?></a>
				<span class="sep"> | </span>
				<?php printf( esc_html__( 'Theme: %1$s by %2$s.', 'exhibit' ), 'Exhibit', '<a href="https://prothemedesign.com/" rel="designer">Pro Theme Design</a>' ); ?>
			</section>
	</footer>

</div>

<?php wp_footer(); ?>

</body>
</html>
