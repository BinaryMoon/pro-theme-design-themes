<?php
/**
 * Error - file not found
 *
 * @package Exhibit
 */

	get_header();
?>
	<div id="main-content" class="main-content">
		<header class="entry-archive-header">
			<h1 class="entry-title"><?php esc_html_e( 'That page can&rsquo;t be found.', 'exhibit' ); ?></h1>
		</header>

		<article class="page-404 main-content container post-singular">

			<section class="entry entry-single">
				<p><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try a search?', 'exhibit' ); ?></p>
				<?php get_search_form(); ?>
			</section>

		</article>
	</div>

<?php
	get_footer();
