<?php
/**
 * WordPress.com specific functionality
 *
 * @package Exhibit
 */

/**
 * Theme colours for wp.com custom functionality
 *
 * @global string $themecolors
 */
function exhibit_theme_colors() {

	global $themecolors;

	/**
	 * Set a default theme color array for WP.com.
	 *
	 * @global array $themecolors
	 */
	if ( ! isset( $themecolors ) ) {
		$themecolors = array(
			'bg'     => 'ffffff',
			'border' => 'eeeeee',
			'text'   => '000000',
			'link'   => '9C604B',
			'url'    => 'aaaaaa',
		);
	}

}

add_action( 'after_setup_theme', 'exhibit_theme_colors' );


/**
 * Dequeue Google Fonts if Custom Fonts are being used instead.
 *
 * @param  array $fonts Font list to check.
 * @return array
 */
function exhibit_dequeue_fonts( $fonts ) {

	if ( class_exists( 'TypekitData' ) && class_exists( 'CustomDesign' ) && CustomDesign::is_upgrade_active() ) {
	    $custom_fonts = TypekitData::get( 'families' );

		if ( $custom_fonts && $custom_fonts['headings']['id'] && $custom_fonts && $custom_fonts['body-text']['id'] ) {
			unset( $fonts['roboto-slab'] );
	    }
	}

	return $fonts;

}

add_filter( 'exhibit_fonts', 'exhibit_dequeue_fonts', 11 );
