<?php

add_filter( 'typekit_add_font_category_rules', function( $category_rules ) {

	TypekitTheme::add_font_category_rule( $category_rules, 'body-text',
		'body,
		html',
		array(
			array( 'property' => 'font-family', 'value' => '"Roboto Slab", Georgia, serif' ),
			array( 'property' => 'font-size', 'value' => '16px' ),
			array( 'property' => 'font-weight', 'value' => '300' ),
		)
	);

	TypekitTheme::add_font_category_rule( $category_rules, 'none',
		'code,
		kbd,
		pre,
		samp',
		array(
			array( 'property' => 'font-family', 'value' => '"andale mono", "lucida console", monospace' ),
			array( 'property' => 'font-size', 'value' => '15px' ),
		)
	);

	TypekitTheme::add_font_category_rule( $category_rules, 'headings',
		'h1,
		h2,
		h3,
		h4,
		h5,
		h6',
		array(
			array( 'property' => 'font-family', 'value' => '"Roboto Slab", Georgia, serif' ),
			array( 'property' => 'font-weight', 'value' => '400' ),
		)
	);

	TypekitTheme::add_font_category_rule( $category_rules, 'headings',
		'h1',
		array(
			array( 'property' => 'font-size', 'value' => '49px' ),
		)
	);

	TypekitTheme::add_font_category_rule( $category_rules, 'headings',
		'h2',
		array(
			array( 'property' => 'font-size', 'value' => '31px' ),
		)
	);

	TypekitTheme::add_font_category_rule( $category_rules, 'headings',
		'h3',
		array(
			array( 'property' => 'font-size', 'value' => '25px' ),
		)
	);

	TypekitTheme::add_font_category_rule( $category_rules, 'headings',
		'h4',
		array(
			array( 'property' => 'font-size', 'value' => '20px' ),
		)
	);

	TypekitTheme::add_font_category_rule( $category_rules, 'headings',
		'h5,
		h6',
		array(
			array( 'property' => 'font-size', 'value' => '16px' ),
			array( 'property' => 'font-weight', 'value' => '600' ),
		)
	);

	TypekitTheme::add_font_category_rule( $category_rules, 'headings',
		'.masthead .branding h1.site-title',
		array(
			array( 'property' => 'font-size', 'value' => '76px' ),
		)
	);

	TypekitTheme::add_font_category_rule( $category_rules, 'headings',
		'.home .masthead .branding h1.site-title',
		array(
			array( 'property' => 'font-size', 'value' => '95px' ),
		)
	);

	TypekitTheme::add_font_category_rule( $category_rules, 'body-text',
		'.masthead .branding p.site-description',
		array(
			array( 'property' => 'font-size', 'value' => '20px' ),
		)
	);

	TypekitTheme::add_font_category_rule( $category_rules, 'body-text',
		'.home .masthead .branding p.site-description',
		array(
			array( 'property' => 'font-size', 'value' => '25px' ),
		)
	);

	TypekitTheme::add_font_category_rule( $category_rules, 'headings',
		'.home .masthead .branding h1.site-title,
  		.masthead .branding h1.site-title',
		array(
			array( 'property' => 'font-size', 'value' => '28px' ),
		),
		array(
			'screen and ( max-width: 782px )',
		)
	);

	TypekitTheme::add_font_category_rule( $category_rules, 'body-text',
		'.home .masthead .branding p.site-description,
  		.masthead .branding p.site-description',
		array(
			array( 'property' => 'font-size', 'value' => '20px' ),
		),
		array(
			'screen and ( max-width: 782px )',
		)
	);

	TypekitTheme::add_font_category_rule( $category_rules, 'headings',
		'.main .post-archive article h2.entry-title',
		array(
			array( 'property' => 'font-size', 'value' => '25px' ),
		)
	);

	TypekitTheme::add_font_category_rule( $category_rules, 'headings',
		'.main-content h1.entry-title',
		array(
			array( 'property' => 'font-size', 'value' => '31px' ),
		),
		array(
			'screen and ( max-width: 898px )',
		)
	);

	TypekitTheme::add_font_category_rule( $category_rules, 'headings',
		'.widget h3.widgettitle',
		array(
			array( 'property' => 'font-size', 'value' => '16px' ),
		)
	);

	TypekitTheme::add_font_category_rule( $category_rules, 'body-text',
		'blockquote',
		array(
			array( 'property' => 'font-family', 'value' => '"Roboto Slab", Georgia, serif' ),
			array( 'property' => 'font-style', 'value' => 'italic' ),
		)
	);

	TypekitTheme::add_font_category_rule( $category_rules, 'body-text',
		'blockquote cite',
		array(
			array( 'property' => 'font-size', 'value' => '13px' ),
			array( 'property' => 'font-weight', 'value' => '600' ),
		)
	);

	TypekitTheme::add_font_category_rule( $category_rules, 'body-text',
		'.post-meta-data,
		.main .taxonomy,
		.main .post-archive article a.read-more,
		footer#footer .footer-wrap,
		ol.comment-list li.comment .comment-meta-data,
		ol.comment-list li.trackback .comment-meta-data,
		ol.comment-list li.pingback .comment-meta-data',
		array(
			array( 'property' => 'font-size', 'value' => '13px' ),
			array( 'property' => 'font-weight', 'value' => '400' ),
		)
	);

	TypekitTheme::add_font_category_rule( $category_rules, 'body-text',
		'.main .contributor a.contributor-posts-link',
		array(
			array( 'property' => 'font-size', 'value' => '16px' ),
			array( 'property' => 'font-weight', 'value' => '400' ),
		)
	);

	TypekitTheme::add_font_category_rule( $category_rules, 'body-text',
		'.main-content .entry-single,
		.masthead .menu',
		array(
			array( 'property' => 'font-size', 'value' => '16px' ),
		)
	);

	TypekitTheme::add_font_category_rule( $category_rules, 'body-text',
		'.masthead .menu li ul li',
		array(
			array( 'property' => 'font-size', 'value' => '13px' ),
			array( 'property' => 'font-weight', 'value' => '300' ),
		)
	);

	TypekitTheme::add_font_category_rule( $category_rules, 'body-text',
		'.main div.jp-relatedposts h3,
		.main div.sharedaddy h3',
		array(
			array( 'property' => 'font-family', 'value' => '"Roboto Slab", Georgia, serif' ),
			array( 'property' => 'font-size', 'value' => '12px' ),
		)
	);

	TypekitTheme::add_font_category_rule( $category_rules, 'body-text',
		'ol.comment-list li.comment #respond #cancel-comment-reply-link,
		ol.comment-list li.pingback #respond #cancel-comment-reply-link,
		ol.comment-list li.trackback #respond #cancel-comment-reply-link',
		array(
			array( 'property' => 'font-family', 'value' => '"Roboto Slab", Georgia, serif' ),
			array( 'property' => 'font-size', 'value' => '13px' ),
			array( 'property' => 'font-weight', 'value' => '400' ),
		)
	);

	TypekitTheme::add_font_category_rule( $category_rules, 'headings',
		'.content-wrapper header.wrap-title h2',
		array(
			array( 'property' => 'font-family', 'value' => '"Roboto Slab", Georgia, serif' ),
		)
	);

	return $category_rules;
} );
