<?php
/**
 * List Testimonials on a page
 *
 * @package Exhibit
 */

	$testimonials = new WP_Query(
		array(
			'post_type' => 'jetpack-testimonial',
			'orderby' => 'rand',
			'posts_per_page' => 2,
			'no_found_rows' => true,
		)
	);

	// Only display if there are some testimonials to display.
	if ( $testimonials->have_posts() ) {
?>
	<section class="content-wrapper content-testimonials">
		<div class="testimonials-wrapper container">
			<header class="wrap-title">
				<h2 class="entry-title">
					<?php exhibit_testimonials_title(); ?>
				</h2>
			</header>
			<div class="testimonials">
<?php
		while ( $testimonials->have_posts() ) {
			$testimonials->the_post();
			get_template_part( 'content-testimonial' );
		}
?>
			</div>

			<div class="more-wrapper">
				<a href="<?php echo esc_url( home_url( 'testimonial/' ) ); ?>" class="more"><?php esc_html_e( 'View All Testimonials', 'exhibit' ); ?></a>
			</div>
		</div>
	</section>
<?php
	}

	wp_reset_postdata();
