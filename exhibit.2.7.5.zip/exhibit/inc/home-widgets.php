<?php
/**
 * Homepage Widgets
 *
 * @package Exhibit
 */

	if ( is_active_sidebar( 'sidebar-3' ) ) {
		$title = get_theme_mod( 'exhibit_title_home_widgets', '' );
?>
	<section class="content-wrapper content-home-widgets">
<?php
		if ( $title ) {
?>
			<header class="wrap-title">
				<h2 class="entry-title">
					<?php echo esc_html( $title ); ?>
				</h2>
			</header>
<?php
		}
?>
		<div class="home-widgets container">
			<?php dynamic_sidebar( 'sidebar-3' ); ?>
		</div>
	</section>
<?php
	}
