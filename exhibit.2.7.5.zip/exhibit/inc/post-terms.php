<?php
/**
 * Post terms
 *
 * @package Exhibit
 */

	if ( 'post' === get_post_type( get_the_ID() ) ) {
?>
		<div class="taxonomies">
			<span class="tax-categories taxonomy">
<?php
	echo get_the_category_list( esc_html_x( ', ', 'Category/ Tag list separator (includes a space after the comma)', 'exhibit' ) );
?>
			</span>
<?php
	if ( get_the_tags() ) {
?>
			<span class="tax-tags taxonomy">
<?php
		echo get_the_tag_list( '', esc_html_x( ', ', 'Category/ Tag list separator (includes a space after the comma)', 'exhibit' ), '' );
?>
			</span>
<?php
	}
?>
		</div>
<?php
	}
