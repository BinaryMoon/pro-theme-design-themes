<?php
/**
 * Custom header codes
 *
 * @package Exhibit
 */

/**
 * Custom header image
 */
function exhibit_custom_header_support() {

	// Custom header image.
	$args = array(
		'default-text-color' => '000000',
		'random-default' => false,
		'width' => 1440,
		'height' => 400,
		'flex-height' => true,
		'header-text' => true,
		'uploads' => true,
		'wp-head-callback' => 'exhibit_colour_styles',
	);

	add_theme_support( 'custom-header', apply_filters( 'exhibit_custom_header', $args ) );

}

add_action( 'after_setup_theme', 'exhibit_custom_header_support' );


/**
 * Print custom header styles
 *
 * @return array
 */
function exhibit_colour_styles() {

?>
<style>
<?php
	if ( 'blank' === get_header_textcolor() ) {
?>
	.masthead .branding h1.site-title,
	.masthead .branding p.site-description {
		display:none;
	}
<?php
	} else {
?>
	.masthead .branding h1.site-title a,
	.masthead .branding h1.site-title a:hover,
	.masthead .branding p.site-description {
		color:#<?php echo esc_attr( get_header_textcolor() ); ?>;
	}
<?php
	}
?>
</style>
<?php

	return true;

}
