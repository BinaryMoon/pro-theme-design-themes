<?php
/**
 * Jetpack Compatibility File
 * See: http://jetpack.me/
 *
 * @package Exhibit
 */

/**
 * Add theme support for Infinite Scroll.
 * See: http://jetpack.me/support/infinite-scroll/
 */
function exhibit_jetpack_init() {

	add_theme_support(
		'infinite-scroll',
		array(
			'container' => 'main-content',
			'footer_widgets' => 'sidebar-2',
			'footer' => 'footer-widgets',
			'posts_per_page' => 8,
			'render' => 'exhibit_infinite_scroll_render',
			'wrapper' => false,
		)
	);

	add_theme_support( 'jetpack-testimonial' );

	add_theme_support( 'jetpack-portfolio' );

	add_theme_support( 'jetpack-responsive-videos' );

	add_theme_support(
		'site-logo',
		array(
			'size' => 'exhibit-logo',
		)
	);

}

add_action( 'after_setup_theme', 'exhibit_jetpack_init' );


/**
 * Render infinite scroll content using template parts.
 */
function exhibit_infinite_scroll_render() {

	while ( have_posts() ) {

		the_post();

		if ( is_post_type_archive( 'jetpack-testimonial' ) ) {

			get_template_part( 'content', 'testimonial' );

		} elseif ( is_post_type_archive( 'jetpack-portfolio' ) ) {

			get_template_part( 'content', 'grid' );

		} else {

			get_template_part( 'content' );

		}
	}

}


/**
 * Change default jetpack infinite scroll setttings
 *
 * @param array $settings Infinite scroll default settings.
 * @return array
 */
function exhibit_infinite_scroll_js_settings( $settings ) {

	$settings['text'] = esc_html__( 'More Posts', 'exhibit' );

	return $settings;

}

add_filter( 'infinite_scroll_js_settings', 'exhibit_infinite_scroll_js_settings' );


/**
 * Get Jetpack Testimonials Title
 */
function exhibit_testimonials_title() {

	$jetpack_options = get_theme_mod( 'jetpack_testimonials' );

	if ( ! empty( $jetpack_options['page-title'] ) ) {
		echo esc_html( $jetpack_options['page-title'] );
	} else {
		esc_html_e( 'Testimonials', 'exhibit' );
	}

}


/**
 * Retrieve and format jetpack testimonials description as set in theme customiser
 *
 * @param  string $before String to display before description.
 * @param  string $after  String to display after description.
 * @return string|false
 */
function exhibit_testimonials_description( $before = '', $after = '' ) {

	$jetpack_options = get_theme_mod( 'jetpack_testimonials' );
	$content = '';

	if ( ! empty( $jetpack_options['page-content'] ) ) {
		$content = $jetpack_options['page-content'];
		$content = addslashes( $content );
		$content = wp_kses_post( $content );
		$content = stripslashes( $content );
		$content = wptexturize( $content );
		$content = convert_smilies( $content );
		$content = convert_chars( $content );
	}

	if ( $content ) {
		echo $before . $content . $after;
	}

	return false;

}


/**
 * Get Jetpack Testimonials Image
 *
 * @return type
 */
function exhibit_testimonials_image() {

	$jetpack_options = get_theme_mod( 'jetpack_testimonials' );
	$image = '';

	if ( ! empty( $jetpack_options['featured-image'] ) ) {
		$image = wp_get_attachment_image( (int) $jetpack_options['featured-image'], 'exhibit-header' );
	}

	return $image;

}


/**
 * Flush rewrite rules for CPT on setup and switch
 */
function exhibit_flush_rewrite_rules() {

	flush_rewrite_rules();

}

add_action( 'after_switch_theme', 'exhibit_flush_rewrite_rules' );


/**
 * Display site logo if available
 */
function exhibit_site_logo() {

	if ( function_exists( 'jetpack_the_site_logo' ) ) {
		jetpack_the_site_logo();
	}

}
