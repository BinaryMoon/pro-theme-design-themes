<?php
/**
 * Jetpack Projects
 *
 * @package Exhibit
 */

	$projects_count = get_theme_mod( 'exhibit_projects_count', 6 );

	if ( $projects_count <= 0 ) {
		return;
	}

	$query = new WP_Query(
		array(
			'post_type' => 'jetpack-portfolio',
			'posts_per_page' => intval( $projects_count ),
		)
	);

	$title = get_theme_mod( 'exhibit_title_projects', esc_html__( 'Recent Projects', 'exhibit' ) );

	if ( $query->have_posts() ) {
?>
	<section class="content-wrapper content-projects-archive">
		<div class="projects exhibit container post-archive">
<?php
		if ( ! empty( $title ) ) {
?>
			<header class="wrap-title">
				<h2 class="entry-title">
					<?php echo esc_html( $title ); ?>
				</h2>
			</header>
<?php
		}

		exhibit_project_terms();

		while ( $query->have_posts() ) {
			$query->the_post();

			get_template_part( 'content', 'grid' );
		}

		$all_projects_text = get_theme_mod( 'exhibit_title_projects_button', esc_html__( 'View All Projects', 'exhibit' ) );

		if ( ! empty( $all_projects_text ) ) {
?>
			<div class="more-wrapper">
				<a href="<?php echo esc_url( home_url( 'portfolio/' ) ); ?>" class="more"><?php echo esc_html( $all_projects_text ); ?></a>
			</div>
<?php
		}
?>
		</div>
	</section>
<?php
		wp_reset_postdata();

	} // End if().
