<?php
/**
 * Theme Customizer
 *
 * @package Exhibit
 */

if ( ! class_exists( 'WP_Customize_Control' ) ) {
	return null;
}


/**
 * Theme customizer properties
 *
 * @param object $wp_customize WP_Customize object.
 */
function exhibit_customizer_settings( $wp_customize ) {

	// Exhibit theme options section.
	$wp_customize->add_section( 'exhibit_options', array(
		'title' => esc_html__( 'Theme Options', 'exhibit' ),
		'description' => esc_html__( 'Options for the Exhibit theme.', 'exhibit' ),
	) );

	// ---
	// Setting to edit the title for the Projects section.
	$wp_customize->add_setting( 'exhibit_title_projects', array(
		'default' => esc_html__( 'Recent Projects', 'exhibit' ),
		'capability' => 'edit_theme_options',
		'sanitize_callback' => 'esc_html',
	) );

	// Control to edit the title for the projects.
	$wp_customize->add_control( 'exhibit_title_projects', array(
		'label' => esc_html__( 'Projects Template Projects Title', 'exhibit' ),
		'section' => 'exhibit_options',
		'type' => 'text',
	) );

	// ---
	// Setting to edit the button text on the view all projects button.
	$wp_customize->add_setting( 'exhibit_title_projects_button', array(
		'default' => esc_html__( 'View All Projects', 'exhibit' ),
		'capability' => 'edit_theme_options',
		'sanitize_callback' => 'esc_html',
	) );

	// Control to edit the title for the projects.
	$wp_customize->add_control( 'exhibit_title_projects_button', array(
		'label' => esc_html__( 'View all Projects Button Text', 'exhibit' ),
		'section' => 'exhibit_options',
		'type' => 'text',
	) );

	// ---
	// setting to edit the number of projects to display on the homepage
	$wp_customize->add_setting( 'exhibit_projects_count', array(
		'default' => 6,
		'capability' => 'edit_theme_options',
		'sanitize_callback' => 'absint',
	) );

	// Control to edit the title for the recent updates.
	$wp_customize->add_control( 'exhibit_projects_count', array(
		'label' => esc_html__( 'Projects Template Projects Quantity', 'exhibit' ),
		'section' => 'exhibit_options',
		'type' => 'number',
		'input_attrs' => array(
			'min'   => 0,
			'step'  => 3,
		),
	) );

}

add_action( 'customize_register', 'exhibit_customizer_settings' );
