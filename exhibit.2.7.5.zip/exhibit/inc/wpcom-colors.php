<?php
/* Custom Colors: Exhibit */

// Background
add_color_rule( 'bg', '#f2f2f2', array(
	// No contrast
	array( 'body', 'background-color' ),
	array( 'footer#footer .menu-social-links ul li a:before', 'background-color' ),
) );

// Text
add_color_rule( 'txt', '#000000', array(
),
__( 'Text' ) );

// Links
add_color_rule( 'link', '#dd614a', array(
	array( 'a, a:hover', 'color', 'bg' ),

	array( '.widget.widget_flickr #flickr_badge_uber_wrapper td a,
			.widget.widget_flickr #flickr_badge_wrapper td a,
			.main .post-archive article h2.entry-title a:hover,
			.main .post-archive article a.read-more,
			form.search-form button.search-submit,
			footer#footer .menu-social-links ul li a:hover:before,
			.footer-widgets-container a,
			footer#footer .menu ul li a,
			footer#footer .menu-social-links ul li a:before', 'color', 'bg' ),

	array( '.main .post-nav .nav-previous a:before,
			.main .post-nav .prev a:before', 'color', 'bg' ),

	array( '.masthead .menu.menu-after-header', 'background-color' ),

	array( 'a.thumbnail:before', 'background-color', 0.8 ),

	array( 'input[type=submit]:hover,
			.infinite-scroll #infinite-handle span:hover,
			.main .contributor a.contributor-posts-link:hover,
			#respond p.form-submit #submit:hover,
			.more-wrapper a.more:hover,
			.main .archive-pagination span.current,
			.testimonials-wrapper .testimonial .entry', 'background-color', 'bg' ),

	array( 'input[type=text]:focus,
			input[type=password]:focus,
			input[type=email]:focus,
			input[type=url]:focus,
			input[type=search]:focus,
			input.text:focus,
			textarea:focus,
			select:focus,
			input.settings-input:focus', 'outline-color', 'bg' ),

	array( 'input[type=text]:focus,
			input[type=password]:focus,
			input[type=email]:focus,
			input[type=url]:focus,
			input[type=search]:focus,
			input.text:focus,
			textarea:focus,
			select:focus,
			input.settings-input:focus,
			input[type=submit]:hover,
			.infinite-scroll #infinite-handle span:hover,
			.main .contributor a.contributor-posts-link:hover,
			#respond p.form-submit #submit:hover,
			.more-wrapper a.more:hover', 'border-color', 'bg' ),

	array( '.testimonials-wrapper .testimonial .entry:after', 'border-top-color', 'bg' ),
),
__( 'Links' ) );


add_color_rule( 'fg1', '#000000', array(
) );

add_color_rule( 'fg2', '#000000', array(
) );

add_color_rule( 'extra', '#ffffff', array(
	array( '.masthead .menu a,
			.masthead .menu .menu-toggle,
			.masthead .menu li ul li a,
			.masthead .menu li li a,
			.masthead .menu li a,
			.masthead .menu li a:hover,
			.masthead .menu li ul li a:hover,
			.masthead .menu li li a:hover,
			.masthead .menu li a:hover ', 'color', 'link' ),

	array( '.more-wrapper a.more:hover', 'color', 'link', 12 ),

	array( '.menu-on .masthead .menu li ul li a,
			input[type=submit]:hover,
			.infinite-scroll #infinite-handle span:hover', 'color', 'link', 16 ),

	array( '.testimonials-wrapper .testimonial .entry', 'color', 'link' ),
	array( '.testimonials-wrapper .testimonial .entry a', 'color', 'link' ),
	array( '.content-wrapper:nth-child(even)', 'background-color', 0.3 ),

	array( '.masthead,
			blockquote,
			.wp-caption', 'background-color', 0.7 ),

	array( 'ol.comment-list li.comment.bypostauthor,
			.content-comments ol.comment-list,
			ol.comment-list li.trackback.bypostauthor,
			ol.comment-list li.pingback.bypostauthor', 'background-color', 0.2 ),

	array( '.footer-widgets-container', 'background-color', 0.2 ),
	array( 'footer#footer .menu-social-links ul li a:hover:before', 'background-color', 0.3 ),

	array( 'a.post-edit-link, .main .post-nav', 'background-color', 0.2 ),
	array( 'a.post-edit-link:hover', 'background-color', 0.3 ),

	array( '.masthead .menu li.page_item_has_children > a:after,
			.masthead .menu li.menu-item-has-children > a:after', 'border-top-color', 'link' ),

	array( '.main .post-nav .nav-previous,
			.content-comments ol.comment-list li.comment article', 'border-bottom-color', 0.15 ),

	array( 'footer#footer', 'border-top-color', 0.3 ),
) );

add_color_rule( 'extra', '#444444', array(
	array( 'body', 'color', 'bg' ),
	array( '.footer-widgets-container', 'color', 'bg' ),
) );

add_color_rule( 'extra', '#999999', array(
	array( '.main .taxonomy', 'color', 'bg' ),
) );

add_color_rule( 'extra', '#000000', array(
	array( 'h1,
			h2,
			h3,
			h4,
			h5,
			h6,
			input[type=submit],
			.infinite-scroll #infinite-handle span,
			.main .contributor a.contributor-posts-link,
			ol.comment-list li.comment #respond #cancel-comment-reply-link,
			ol.comment-list li.trackback #respond #cancel-comment-reply-link,
			ol.comment-list li.pingback #respond #cancel-comment-reply-link,
			#respond p.form-submit #submit,
			.masthead .branding h1.site-title,
			.content-wrapper .site-intro p,
			.more-wrapper a.more,
			.main .post-archive article h2.entry-title a,
			.main .exhibit.projects .projects-terms a,
			.post-meta-data', 'color', 'bg' ),

	array( '.content-wrapper:nth-child(even)', 'color' ),
	array( '.masthead .menu li.current-menu-item > a,
			.masthead .menu li ul li.current-menu-item > a', 'color', 'link' ),

	array( '.infinite-scroll #infinite-handle span', 'border-color', 'bg' ),
	array( '.main .contributor a.contributor-posts-link, .more-wrapper a.more', 'border-color', 'bg' ),
) );

//Extra CSS
function exhibit_extra_css() { ?>
	@media screen and (min-width: 782px) {
		.masthead .menu li ul li a,
		.masthead .menu li ul li a:hover {
			color: #000000 !important;
		}
	}

	ol.comment-list li.comment.bypostauthor,
	ol.comment-list li.trackback.bypostauthor,
	ol.comment-list li.pingback.bypostauthor {
		background-color: transparent;
	}
<?php }
add_theme_support( 'custom_colors_extra_css', 'exhibit_extra_css' );


// Additional color palettes
add_color_palette( array(
	'#f6f6f6',
	'',
	'#333333',
	'',
	'',
), 'Graphite' );

add_color_palette( array(
	'#f2f2f2',
	'',
	'#45ada8',
	'',
	'',
), 'Marine' );

add_color_palette( array(
	'#e8ddcb',
	'',
	'#036564',
	'',
	'',
), 'Sandy' );
