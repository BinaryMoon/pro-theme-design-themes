<?php
/**
 * Page content
 *
 * @package Exhibit
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<?php
	the_title( '<h1 class="entry-title">', '</h1>' );
?>
	<section class="entry entry-single">
<?php
	the_content();

	edit_post_link();

	wp_link_pages(
		array(
			'before' => '<div class="archive-pagination">',
			'after'  => '</div>',
			'link_before' => '<span>',
			'link_after'  => '</span>',
		)
	);
?>
	</section>
</article>
