<?php
/**
 * Testimonials Archive Template
 *
 * displays at: http://website.com/testimonial/
 *
 * @package Exhibit
 */

	get_header();

	if ( have_posts() ) {

		if ( $image = exhibit_testimonials_image() ) {
?>
	<div class="page-image-header">
		<?php echo $image; ?>
	</div>
<?php
		}
?>
	<header class="entry-archive-header">
		<h1 class="entry-title entry-archive-title"><?php exhibit_testimonials_title(); ?></h1>
<?php
		exhibit_testimonials_description( '<div class="category-description">', '</div>' );
?>
	</header>

	<div id="main-content" class="main-content container testimonials testimonials-wrapper">
<?php
		while ( have_posts() ) {
			the_post();
			get_template_part( 'content', 'testimonial' );
		}
?>
	</div>
<?php

	} else {

		get_template_part( 'content-empty' );

	}

	get_footer();
