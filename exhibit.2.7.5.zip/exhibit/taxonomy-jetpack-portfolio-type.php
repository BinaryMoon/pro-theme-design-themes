<?php
/**
 * Portfolio Archive Template
 * Reuses archive template
 *
 * @package Exhibit
 */

get_template_part( 'archive-jetpack-portfolio' );
