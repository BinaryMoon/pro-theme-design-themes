<?php
/**
 * Contributors listing
 *
 * @package Exhibit
 */

$contributor_ids = get_users(
	array(
		'fields'  => 'ID',
		'order'   => 'DESC',
		'who'     => 'authors',
	)
);

foreach ( $contributor_ids as $contributor_id ) {
	$post_count = count_user_posts( $contributor_id );

	// Move on if user has not published a post (yet).
	if ( ! $post_count ) {
		continue;
	}
?>
<div class="contributor">
	<?php echo get_avatar( $contributor_id, 200 ); ?>
	<h2><?php echo get_the_author_meta( 'display_name', $contributor_id ); ?></h2>
	<?php echo wpautop( get_the_author_meta( 'description', $contributor_id ) ); ?>
	<a class="contributor-posts-link" href="<?php echo esc_url( get_author_posts_url( $contributor_id ) ); ?>">
		<?php printf( esc_html( _nx( '%d Article', '%d Articles', $post_count, 'contributor article count', 'exhibit' ) ), absint( $post_count ) ); ?>
	</a>
</div>
<?php
}
