<?php
/**
 * Individual Testimonial layout
 *
 * @package Exhibit
 */

	$image = get_the_post_thumbnail( get_the_ID(), 'exhibit-testimonial' );
?>
<article id="post-<?php the_ID(); ?>" class="testimonial">
	<div class="entry">
<?php
	the_content();
?>
	</div>

	<p class="post-meta-data">
<?php
	if ( $image ) {
?>
		<span class="thumbnail">
			<?php echo $image; ?>
		</span>
<?php
	}
?>
		<span class="testimonial-author"><?php the_title(); ?></span>
	</p>

</article>
