<?php
/**
 * Attachment template
 *
 * @package Exhibit
 */

	get_header();
?>
	<div class="container">
		<div class="main-content">
			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<?php
	the_title( '<h1 class="entry-title">&#8216;', '&#8217;</h1>' );
?>
				<section class="entry">
<?php
	if ( $post->post_parent ) {

		$metadata = wp_get_attachment_metadata();
		printf( __( '<p class="post-meta-data">Published <time class="entry-date" datetime="%1$s" pubdate>%2$s</time> at <a href="%3$s" title="Link to full-size image">%4$s &times; %5$s</a> in <a href="%6$s" title="Return to %7$s" rel="gallery">%7$s</a></p>', 'exhibit' ),
			esc_attr( get_the_date( 'c' ) ),
			esc_html( get_the_date() ),
			esc_url( wp_get_attachment_url() ),
			(int) $metadata['width'],
			(int) $metadata['height'],
			esc_url( get_permalink( $post->post_parent ) ),
			get_the_title( $post->post_parent )
		);

	}
?>
					<div class="attachment-image"><?php echo wp_get_attachment_link( $post->ID, 'exhibit-attachment-fullsize' ); ?></div>
<?php

	if ( has_excerpt() ) {
?>
					<div class="entry-caption">
						<?php the_excerpt(); ?>
					</div>
<?php
	}

	if ( $post->post_parent ) {
?>
				<nav id="image-navigation" class="site-navigation" role="navigation">
					<span class="image-previous"><?php previous_image_link( 'exhibit-attachment' ); ?></span>
					<span class="image-parent"><a href="<?php echo esc_url( get_permalink( $post->post_parent ) ); ?>" rev="attachment" class="attachment-parent"><?php esc_html_e( '&lsaquo; Return to post', 'exhibit' ); ?></a></span>
					<span class="image-next"><?php next_image_link( 'exhibit-attachment' ); ?></span>
				</nav>
<?php
	}

	get_template_part( 'inc/comments' );
?>
				</section>
			</article>
		</div>
		<?php get_sidebar(); ?>
	</div>
<?php

	get_footer();
