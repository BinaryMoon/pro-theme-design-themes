=== Exhibit ===

Contributors: binarymoon
Requires at least: 4.5
Tested up to: 4.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: light, gray, red, white, one-column, two-columns, right-sidebar, responsive-layout, custom-background, custom-colors, custom-header, custom-menu, editor-style, featured-images, featured-image-header, full-width-template, infinite-scroll, rtl-language-support, site-logo, sticky-post, theme-options, threaded-comments, translation-ready, art, artwork, blog, business, craft, design, photography, portfolio, clean, conservative, contemporary, formal, light, modern

== Description ==

Exhibit is the perfect theme for businesses big and small to exhibit their work. Acting as both a portfolio and a blog Exhibit allows you to show off your projects, and to keep your customers informed.

[Theme documentation](https://prothemedesign.com/documentation/theme/exhibit/)

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Exhibit includes support for [Styleguide](https://wordpress.org/plugins/styleguide/) - a plugin that allows you to change fonts, and colours in WordPress themes.

Exhibit includes support for most features in [Jetpack](https://wordpress.org/plugins/jetpack/), including Infinite Scroll, Featured Content, and Site Logo.

== Changelog ==

= 2.7.5 - 2nd April 2021 =
* Fix text input width.

= 2.7.4 - 31st January 2021 =
* Clear html widget to prevent floated content from breaking the layout.

= 2.7.3 - 1st January 2021 =
* Fix jQuery error since jquery migrate has been removed.
* Fix sub menu link colours on mobile devices.

= 2.7.2 - 27th October 2020 =
* Add 'navigation-widgets' to supported html5 types.

= 2.7.1 - 5th October 2020 =
* Add support for wp_body_open()

= 2.7 - 9th March 2020 =
* Add support for Gutenberg styles.
* Improve editor styles for the new block editor.
* Improve coding standards.
* Improve heading line heights for better readability.

= 2.6.2 - 18th June 2019 =
* Fix button styles in forms. input elements looked good but button elements were not styled. They are now!

= 2.6.1 - 15th June 2018 =
* Fix portfolio archive infinite scroll display so that it's consistent.
* center portfolio photos in archives when they are too small.

= 2.6 - 25th May 2018 =
* Add support for privacy policy link in the site footer.
* Fix display of the cookie consent checkbox in the comments form.

= 2.5.2 - 27th April 2018 =
* Tweak the content_width to be more accurate.

= 2.5.1 - 21st April 2018 =
* Add class to single post featured image so that it can be targeted with css.
* Update auto prefixed styles
* Tidy codes

= 2.5 - 31st October 2017 =
* WooCommerce for all (.com and .org).
* Disable infinite-scroll on WooCommerce archive pages.

= 2.4.1 - 13th July 2017 =
* Remove include for inc/wpcom.php, since it's automatically included by WordPress.com sites

= 2.4 - 3rd July 2017 =
* Add support for WooCommerce.

= 2.3.3 - 13th April 2017 =
* Fix a bug with testimonials not being laid out properly due to Masonry not enqueuing.

= 2.3.2 - 12th April 2017 =
* Add CSS classes to html so that different elements are more easily targeted with CSS.
* Improve masonry behaviour of testimonials.

= 2.3.1 - 11th April 2017 =
* Make featured image on single project page centered.

= 2.3 - 24th February 2017 =
* Make Jetpack infinite scroll load testimonials properly
* Improve social media widget responsive behaviour
* Improve coding standards
* Escape some more properties for added security
* Make testimonials archive display content in traditional archive order (rather than randomly) so that Jetpack infinite scroll works properly

= 2.2 - 29th January 2017 =
* Make the project terms list on projects and portfolio pages highlight the term you are currently viewing.

= 2.1.3 - 14th December 2016 =
* Fix link colour on testimonials so that they are readable once more.

= 2.1.2 - 15th October 2016 =
* remove css box shadow prefixes

= 2.1.1 - 17th July 2016 =
* Improve coding standards

= 2.1 - 28th June 2016 =
* Add option to change 'view all projects' button text in the Customizer. Allows users to make the projects title and button match.
* You can also now hide the 'view all projects' button by removing the default text
* Various minor site style improvements

= 2.0.3 =
* Fix issue with image attachment template
* Tweak header size so that it fits a bit better on shorter screens

= 2.0.2 =
* Add social link icons usable in menus with the addition of the icon class

= 2.0.1 =
* Improve coding standards
* Make 404 template consistent
* More minor css tweaks and improvements

= 2.0.0 =
* Bump version to avoid clashes with wp.org theme
* Improve css

= 1.0.4 =
* Add support for Behance to social links menu
* Ensure bold fonts work with custom fonts

= 1.0.3 =
* make sure margins work when custom page is set as homepage

= 1.0.2 =
* add comments to full width template
* standardize comments include on contributors template

= 1.0.1 =
* improve responsive styles on projects template intro

= 1.0 =
* Initial release

== Credits ==

* [Roboto Slab](https://www.google.com/fonts/specimen/Roboto+Slab) Font from Google Fonts, licensed under [Apache License, version 2.0](http://www.apache.org/licenses/LICENSE-2.0.html)
* Genericons: font by Automattic (http://automattic.com/), licensed under [GPL2](https://www.gnu.org/licenses/gpl-2.0.html)
