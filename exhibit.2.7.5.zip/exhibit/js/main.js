/**
 * main.js v1
 * Created by Ben Gillbanks <http://www.binarymoon.co.uk/>
 * Available under GPL2 license
 */

; ( function( $ ) {

	function is_touch_device() {
		return ( ( 'ontouchstart' in window )
			|| ( navigator.MaxTouchPoints > 0 )
			|| ( navigator.msMaxTouchPoints > 0 ) );
	}

	$( document ).ready( function() {

		if ( typeof $.fn.responsiveNavigation === 'function' ) {
			$( 'ul#nav' ).responsiveNavigation( {
				breakpoint: 549
			} );
		}

		// Attachment page navigation
		if ( $( 'body' ).hasClass( 'attachment' ) ) {

			$( document ).keydown( function( e ) {

				if ( $( 'textarea, input' ).is( ':focus' ) ) {
					return;
				}

				var url = false;

				switch ( e.which ) {
					// left arrow key (previous attachment)
					case 37:
						url = $( '.image-previous a' ).attr( 'href' );
						break;

					// right arrow key (next attachment)
					case 39:
						url = $( '.image-next a' ).attr( 'href' );
						break;

				}

				if ( url ) {
					window.location = url;
				}
			} );

		}

		$( window ).on(
			'load',
			function() {

				if ( typeof $.fn.masonry === 'function' ) {
					$( '.footer-widgets' ).imagesLoaded(
						function() {
							$( '.footer-widgets' ).masonry( {
								itemSelector: '.widget',
								gutter: 0,
								isOriginLeft: !$( 'body' ).is( '.rtl' )
							} );
						}
					);

					var $testimonials;

					$( 'body.archive .testimonials' ).imagesLoaded( function() {
						$testimonials = $( 'body.archive .testimonials' ).masonry(
							{
								itemSelector: '.testimonial',
								gutter: 0,
								isOriginLeft: !$( 'body' ).is( '.rtl' )
							}
						);
						$testimonials.children().addClass( 'post-loaded' );
					} );
				}

				// Update on infinite scroll load.
				$( 'body' ).on(
					'post-load',
					function() {

						// Make sure there are some testimonials to Masonry load.
						if ( 'undefined' == typeof ( $testimonials ) || 0 === $testimonials.length ) {
							return;
						}

						var $new_articles = $( 'body.archive .testimonials' ).children().not( '.post-loaded, .infinite-loader' ).addClass( 'post-loaded' );

						// Make sure there are some new articles to reload.
						if ( 0 === $new_articles.length ) {
							return;
						}

						$testimonials.masonry( 'appended', $new_articles );
						$testimonials.masonry( 'reloadItems' );
						$testimonials.masonry( 'layout' );

						$testimonials.imagesLoaded(
							function() {
								$testimonials.masonry( 'layout' );
							}
						);

					}
				);
			} );

		$( '.menu-toggle' ).on( 'click', function() {
			$( this ).parent().toggleClass( 'menu-on' );
		} );

		$( '.menu' ).find( 'a' ).on( 'focus blur', function() {
			$( this ).parents().toggleClass( 'focus' );
		} );

		$( 'body' ).addClass( is_touch_device() ? 'device-touch' : 'device-click' );

	} );

} )( jQuery );
