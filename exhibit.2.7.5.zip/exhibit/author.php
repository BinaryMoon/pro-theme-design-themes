<?php
/**
 * Author post listing
 *
 * @package Exhibit
 */

	get_header();
	$user_id = get_query_var( 'author' );
?>
	<header class="entry-archive-header">
		<h1 class="entry-title entry-archive-title">
			<?php esc_html_e( 'Author Archives', 'exhibit' ); ?>
		</h1>
	</header>

	<div id="main-content" class="container post-archive">
		<div class="contributor">
			<?php echo get_avatar( get_the_author_meta( 'user_email', $user_id ), 200 ); ?>
			<h2><?php the_author_meta( 'display_name', $user_id ); ?></h2>
			<?php echo wpautop( get_the_author_meta( 'description', $user_id ) ); ?>
		</div>
<?php
	if ( have_posts() ) {

		while ( have_posts() ) {
			the_post();
			get_template_part( 'content', get_post_format() );
		}
		exhibit_numeric_pagination();

	} else {
		get_template_part( 'content-empty' );
	}
?>
	</div>
<?php

	get_footer();
