<?php
/**
 * Comments template.
 *
 * @package Exhibit
 */

	if ( post_password_required() ) {
		return;
	}
?>
<section class="content-comments">
<?php
	if ( have_comments() ) {
?>
	<h3 id="comments">
<?php
		printf( esc_html( _nx( '1 Comment', '%1$s Comments', get_comments_number(), 'comments title', 'exhibit' ) ), number_format_i18n( get_comments_number() ), '<span>' . get_the_title() . '</span>' );
?>
		<a href="#respond" title="<?php esc_attr_e( 'Leave a comment', 'exhibit' ); ?>">&raquo;</a>
	</h3>
	<ol class="comment-list" id="singlecomments">
<?php
		wp_list_comments( array(
			'avatar_size' => 60,
			'short_ping' => true,
			'callback' => 'exhibit_comments_layout',
		));
?>
	</ol>
<?php
		if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) {
?>
	<nav class="post-nav">
		<h1 class="screen-reader"><?php esc_html_e( 'Comment navigation', 'exhibit' ); ?></h1>
		<div class="nav-previous">
			<?php previous_comments_link( esc_html__( 'Older Comments', 'exhibit' ) ); ?>
		</div>
		<div class="nav-next">
			<?php next_comments_link( esc_html__( 'Newer Comments', 'exhibit' ) ); ?>
		</div>
	</nav>
<?php
		}
	}

	if ( 'open' === $post->comment_status ) {
		comment_form();
	}
?>
</section>
