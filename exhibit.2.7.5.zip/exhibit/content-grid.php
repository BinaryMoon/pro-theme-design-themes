<?php
/**
 * Content display for use on featured content and projects
 *
 * @package Exhibit
 */

	$image = get_the_post_thumbnail( get_the_ID(), 'exhibit-archive' );
?>
	<article <?php post_class(); ?>>
<?php
	if ( $image ) {
?>
		<a href="<?php echo esc_url( get_permalink() ); ?>" class="thumbnail">
			<?php echo $image; ?>
		</a>
<?php
	}
?>
		<h2 class="entry-title">
			<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		</h2>
<?php
	get_template_part( 'inc/post-meta' );
?>
	</article>
