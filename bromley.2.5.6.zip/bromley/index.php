<?php
/**
 * Homepage Template
 *
 * @package Bromley
 */

	get_header();

	get_template_part( 'inc/featured-content' );
?>
<section class="articles">
<?php
	if ( have_posts() ) {
?>
	<div id="main-content">
<?php
		while ( have_posts() ) {
			the_post();
			get_template_part( 'content' );
		}
		bromley_numeric_pagination();
?>
	</div>
<?php
	} else {
		get_template_part( 'content-empty' );
	}
?>
</section>
<?php
	get_sidebar();

	get_footer();
