<?php
/**
 * Sidebar template for the homepage
 *
 * @package Bromley
 */

	if ( is_active_sidebar( 'sidebar-1' ) ) {
?>
<aside class="sidebar">
<?php
		do_action( 'before_sidebar' );
		dynamic_sidebar( 'sidebar-1' );
?>
</aside>
<?php
	}
