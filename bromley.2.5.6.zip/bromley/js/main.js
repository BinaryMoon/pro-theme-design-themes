/**
 * responsive-navigation.js v1
 * Created by Ben Gillbanks <http://www.binarymoon.co.uk/>
 * Available under GPL2 license
 */

( function( $ ) {
	$.fn.responsiveNavigation = function( options ) {

		var defaults, display, resized;

		defaults = {
			min_menu_size: 4,
			prefix: '-',
			ignore_children: false,
			breakpoint: 449
		};

		options = $.extend( defaults, options );

		display = function() {
			var window_width = $( window ).width();
			if ( window_width < options.breakpoint ) {
				$( '.rn_nav' ).hide();
				$( '.rn_select' ).show();
			}

			if ( window_width > options.breakpoint ) {
				$( '.rn_nav' ).show();
				$( '.rn_select' ).hide();
			}
		};

		$( window ).on(
			'resize',
			function() {
				resized = true;
			}
		);

		// super simple debounce
		// fires once every half second to do the work if needed
		setInterval( function() {
			if ( resized ) {
				display();
			}
			resized = false;
		}, 500 );

		return this.each( function() {
			var $this, select, navDepth;

			$this = $( this );

			if ( $this.find( 'a' ).length > options.min_menu_size ) {
				$this.addClass( 'rn_nav' );

				select = $( '<select class="rn_select"></select>' );
				navDepth = $this.parents().length;

				// add default text
				var navOptions = $( '<option></option>' );
				navOptions.text( js_i18n.menu );
				navOptions.attr( 'value', '' );

				select.append( navOptions );

				$this.find( 'a' ).each( function() {
					var depth, i, optionText, navOptions;

					depth = ( ( $( this ).parents().length - navDepth ) / 2 ) - 1;

					if ( depth === 0 || ( depth > 0 && options.ignore_children === false ) ) {

						optionText = $( this ).text();
						if ( depth > 0 ) {
							optionText = ' ' + optionText;
						}
						for ( i = 0; i < depth; i++ ) {
							optionText = options.prefix + optionText;
						}
						navOptions = $( '<option></option>' );
						navOptions.attr( 'value', $( this ).attr( 'href' ) );
						if ( document.location === $( this ).attr( 'href' ) ) {
							navOptions.attr( 'selected', 'selected' );
						}
						navOptions.text( optionText );
						select.append( navOptions );

					}

				} );

				select.change( function() {
					if ( this.value !== '' ) {
						document.location = this.value;
					}
				} );
			}

			$this.after( select );
			display();
		} );

	};

} )( jQuery );


( function( $ ) {

	// widgets that use masonry for positioning
	var widget_footer_parent = '#footer-widgets .widgets';
	var masonry_footer_properties = {};
	var masonry_test_interval = 100;
	var masonry_old_height = 0;

	function masonry_reload() {

		$( widget_footer_parent ).masonry( masonry_footer_properties );

	}

	function masonry_widget_load_test() {

		var height = 0;

		// get combined height of all widgets
		$( widget_footer_parent ).find( '.widget' ).each( function() {
			height += $( this ).height();
		} );

		// if height has changed then reposition widgets
		// also reset interval in case something is still loading
		// note that because default 'old' height is 0 this will always get called first time around
		if ( masonry_old_height < height ) {
			masonry_reload();
			masonry_test_interval = 100;
		}

		masonry_old_height = height;
		masonry_test_interval = Math.floor( masonry_test_interval * 2 );

		// no resizing in 5 seconds
		if ( masonry_test_interval < 3000 ) {
			setTimeout( masonry_widget_load_test, masonry_test_interval );
		}

	}

	$( document ).ready( function() {

		$( 'ul#nav' ).superfish( {
			animation: { opacity: 'show', height: 'show' },
			speed: 250
		} );

		$( 'ul#nav' ).responsiveNavigation( {
			breakpoint: 699
		} );

		// dynamic header height
		var header = $( 'header.masthead' );
		var content = $( '.container' );
		var update = true;

		// set the content position so that it doesn't get hidden by the fixed menu
		function set_header_height() {
			var height = header.outerHeight( true );
			content.css( 'margin-top', height );
		}

		$( window ).on(
			'resize',
			function() {
				update = true;
			}
		);

		// update things once every 250 milliseconds at most
		setInterval( function() {
			if ( update ) {
				set_header_height();
			}
			update = false;
		}, 250 );

		set_header_height();

		if ( typeof $.fn.masonry === 'function' ) {

			masonry_footer_properties = {
				itemSelector: '.widget',
				gutter: 0,
				isOriginLeft: !$( 'body' ).is( '.rtl' ),
				percentPosition: true
			};

			// masonry widgets
			masonry_widget_load_test();

		}

		$( '.showcase .item' ).on(
			'click',
			function() {
				var url = $( this ).data( 'url' ) || null;
				if ( Boolean( url ) ) {
					var a = document.createElement( 'A' );
					a.href = url;                                    // Setting the anchor's href attribute will escape the URL for us.
					if ( a.hostname === window.location.hostname ) { // For `javascript:` urls, a.hostname is an empty string.
						document.location.href = a.href;               // Redirect to escaped url.
					}
				}
			}
		);

		if ( typeof $.fn.elementalSlides === 'function' ) {
			$( '.showcase' ).elementalSlides(
				{
					interval: 7500,
					group_selector: '.row'
				}
			);
		}

	} );


} )( jQuery );
