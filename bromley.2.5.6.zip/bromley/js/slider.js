/**
 * slider.js v1.1
 * Created by Ben Gillbanks <http://www.binarymoon.co.uk/>
 * Available under GPL2 license
 */

( function( $ ) {
	$.fn.elementalSlides = function( options ) {

		var total_slides = 0;

		var defaults = {
			interval: 4000,
			group_selector: 'article',
		};
		options = $.extend( defaults, options );

		return this.each( function() {

			var start_timer = function() {
				clearInterval( timer );
				timer = setInterval( function() { next(); }, interval );
			};

			var display = function( slide ) {
				articles.fadeOut( 500 ).removeClass( 'current' ).filter( slide ).fadeIn( 500 ).addClass( 'current' );
			};

			var next = function() {
				var next_slide = nav.find( '.selected' ).removeClass( 'selected' ).next();
				if ( next_slide.length === 0 ) {
					next_slide = nav.find( ':first' );
				}
				next_slide.addClass( 'selected' );
				display( next_slide.attr( 'href' ) );
			};

			var $this = $( this );
			var timer;
			var slide_count = 0;

			// remove empty elements
			$this.children( options.group_selector ).filter( function() {
				return $.trim( this.innerHTML ).length < 1;
			} ).remove();

			var articles = $this.children( options.group_selector );
			var nav = $this.find( 'nav' );
			var interval = $this.data( 'interval' ) || options.interval;

			// quit if there is nothing to display
			if ( articles.length <= 1 ) {
				return;
			}

			// create nav if it doesn't exist
			if ( nav.length === 0 ) {
				nav = $( '<nav></nav>' );
				$this.prepend( nav );
			}

			// loop through articles and create buttons for the nav
			articles.each( function() {
				slide_count++;
				total_slides++;
				$( this ).attr( 'id', 'slide_' + total_slides );
				var tab = $( '<a href="#slide_' + total_slides + '">' + slide_count + '</a>' );
				nav.append( tab );
			} );

			// click button
			nav.find( 'a' ).on(
				'click',
				function() {
					display( this.hash );
					nav.find( 'a' ).removeClass( 'selected' );
					$( this ).addClass( 'selected' );
					start_timer();
					return false;
				}
			);

			// stop the animation when the mouse hovers the content (so user is reading content)
			$this[ ( $.fn.hoverIntent ) ? 'hoverIntent' : 'hover' ]( function() {
				clearInterval( timer );
			}, function() {
				start_timer();
			} );

			nav.find( ':first' ).click();
			start_timer();

		} );

	};
} )( jQuery );