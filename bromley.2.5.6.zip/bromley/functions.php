<?php
/**
 * Reusable theme functions
 *
 * @package Bromley
 */

// This is the max width - it's the same on all pages.
// Keep in mind the theme is responsive so the width is likely to be narrower.
if ( ! isset( $content_width ) ) {
	$content_width = 863;
}


/**
 * Adjust content width
 *
 * @global int $content_width
 */
function bromley_adjust_content_width() {

	global $content_width;

	if ( is_single() && is_active_sidebar( 'sidebar-3' ) ) {
		$content_width = 667;
	}

}

add_action( 'template_redirect', 'bromley_adjust_content_width' );


/**
 * Enqueue all the styles
 */
function bromley_enqueue() {

	// Styles.
	wp_enqueue_style( 'bromley-style', get_template_directory_uri() . '/styles/css/styles.css', null, '1.1.2' );
	wp_enqueue_style( 'bromley-style-animation', get_template_directory_uri() . '/styles/css/animate.css', null, '1.0' );
	wp_enqueue_style( 'genericons', get_template_directory_uri() . '/styles/genericons/genericons.css', array(), '3.0.3' );

	// Fonts.
	$fonts_url = bromley_fonts();
	if ( $fonts_url ) {
		wp_enqueue_style( 'bromley-fonts', $fonts_url, array(), '1.0' );
	}

	// Scripts.
	if ( bromley_has_featured_posts() ) {
		wp_enqueue_script( 'bromley-script-slider', get_template_directory_uri() . '/js/slider.js', array( 'jquery' ), '1.1', false );
	}

	wp_enqueue_script( 'bromley-script-superfish', get_template_directory_uri() . '/js/superfish.js', array( 'jquery' ), '1.0', false );
	wp_enqueue_script( 'bromley-script-main', get_template_directory_uri() . '/js/main.js', array( 'jquery', 'masonry' ), '1.1', false );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	wp_localize_script(
		'bromley-script-main',
		'js_i18n',
		array(
			'menu' => esc_html__( 'Menu', 'bromley' ),
		)
	);

}

add_action( 'wp_enqueue_scripts', 'bromley_enqueue' );


/**
 * Set up all the theme properties and extras
 */
function bromley_after_setup_theme() {

	load_theme_textdomain( 'bromley', get_template_directory() . '/languages' );

	add_theme_support( 'automatic-feed-links' );

	// Post thumbnails.
	add_theme_support( 'post-thumbnails' );
	add_image_size( 'bromley-content', 400, 9999, false );
	add_image_size( 'bromley-sticky', 1000, 360, false );

	// Custom background.
	add_theme_support( 'custom-background' );

	/**
	 * Custom Logo.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/custom-logo/
	 */
	add_theme_support(
		'custom-logo',
		apply_filters(
			'bromley_custom_logo_args',
			array(
				'height' => 100,
				'width' => 500,
				'flex-height' => true,
				'flex-width' => true,
			)
		)
	);

	// HTML5 ftw.
	add_theme_support( 'html5', array( 'comment-list', 'search-form', 'comment-form' ) );

	// Title tag.
	add_theme_support( 'title-tag' );
	register_nav_menu( 'top_menu', esc_html__( 'Top Menu', 'bromley' ) );

	// Add support for full width images and other content such as videos.
	add_theme_support( 'align-wide' );

	// Disable custom font sizes, ensuring consistent vertical rhythm.
	add_theme_support( 'disable-custom-font-sizes' );

	// Make Gutenberg embeds responsive.
	add_theme_support( 'responsive-embeds' );

	// Editor font sizes.
	// Uses the default slugs to ensure consistency across themes.
	add_theme_support(
		'editor-font-sizes',
		array(
			array(
				'name' => esc_html__( 'small', 'bromley' ),
				'size' => 12,
				'slug' => 'small',
			),
			array(
				'name' => esc_html__( 'normal', 'bromley' ),
				'size' => 16,
				'slug' => 'normal',
			),
			array(
				'name' => esc_html__( 'medium', 'bromley' ),
				'size' => 18.6,
				'slug' => 'medium',
			),
			array(
				'name' => esc_html__( 'large', 'bromley' ),
				'size' => 21.3,
				'slug' => 'large',
			),
			array(
				'name' => esc_html__( 'huge', 'bromley' ),
				'size' => 32,
				'slug' => 'huge',
			),
		)
	);

	// Add support for editor styles.
	add_theme_support( 'editor-styles' );

	// Editor Style.
	$fonts_url = bromley_fonts();
	if ( $fonts_url ) {
		add_editor_style( $fonts_url );
	}

	add_editor_style( 'styles/css/editor-styles.css' );

}


/**
 * Initialize Widgets
 */
function bromley_widgets_init() {

	// Homepage sidebar.
	register_sidebar(
		array(
			'name' => esc_html__( 'Archive Sidebar Widgets', 'bromley' ),
			'id' => 'sidebar-1',
			'description' => __( 'Widgets that display on the side of your website on the homepage only (leave empty to hide)', 'bromley' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h3 class="widgettitle">',
			'after_title' => '</h3>',
		)
	);

	// Single sidebar.
	register_sidebar(
		array(
			'name' => esc_html__( 'Single Post Sidebar Widgets', 'bromley' ),
			'id' => 'sidebar-3',
			'description' => esc_html__( 'Widgets that display on the side of your website on blog posts only (leave empty to hide)', 'bromley' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h3 class="widgettitle">',
			'after_title' => '</h3>',
		)
	);

	// Footer widgets.
	register_sidebar(
		array(
			'name' => esc_html__( 'Footer Widgets', 'bromley' ),
			'id' => 'sidebar-2',
			'description' => esc_html__( 'Widgets that display at the bottom of your website', 'bromley' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h3 class="widgettitle">',
			'after_title' => '</h3>',
		)
	);

}

add_action( 'widgets_init', 'bromley_widgets_init' );


/**
 * Enqueue WordPress theme styles within Gutenberg.
 */
function bromley_editor_blocks_styles() {

	// Load the additional editor styles.
	// This covers things like the editor title that can't be styled with the normal editor styles.
	wp_enqueue_style( 'bromley-editor-blocks', get_theme_file_uri( '/styles/css/editor-blocks.css' ), null, '1' );

	/**
	 * Overwrite Core theme styles with empty styles.
	 *
	 * @see https://github.com/WordPress/gutenberg/issues/7776#issuecomment-406700703
	 */
	wp_deregister_style( 'wp-block-library-theme' );
	wp_register_style( 'wp-block-library-theme', '' );

}

add_action( 'enqueue_block_editor_assets', 'bromley_editor_blocks_styles' );
add_action( 'enqueue_block_assets', 'bromley_editor_blocks_styles' );


/**
 * Get url for Google fonts.
 */
function bromley_fonts() {

	/**
	 * Translators: If there are characters in your language that are not
	 * supported, translate this to 'off'. Do not translate into your
	 * own language.
	 */
	$font = _x( 'on', 'Source Sans Pro: on or off', 'bromley' );
	if ( 'off' !== $font ) {
		$fonts['source-sans-pro'] = 'Source+Sans+Pro:300,700';
	}

	$fonts = apply_filters( 'bromley_fonts', $fonts );

	if ( $fonts ) {

		$query_args = array(
			'family' => rawurlencode( implode( '|', $fonts ) ),
			'subset' => rawurlencode( 'latin,latin-ext' ),
			'display' => 'swap',
		);

		return add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );

	}

}


/**
 * Custom excerpt length
 *
 * @param int $length Excerpt length.
 * @return int
 */
function bromley_excerpt_length( $length ) {

	if ( has_post_thumbnail() ) {
		$length = 30;
	} else {
		$length = 50;
	}

	return $length;

}


/**
 * Add an id to menus
 *
 * @param string $ulclass Menu html.
 * @return type
 */
function bromley_add_menu_class( $ulclass ) {

	return preg_replace( '/<ul>/', '<ul id="nav">', $ulclass, 1 );

}


/**
 * Numeric pagination for custom queries
 * Much nicer than next and previous links :)
 *
 * @global object $wp_query
 * @param int    $page_count The number of pages to show.
 * @param object $query A custom query.
 */
function bromley_numeric_pagination( $page_count = 9, $query = null ) {

	if ( null == $query ) {
		global $wp_query;
		$query = $wp_query;
	}

	if ( 1 >= $query->max_num_pages ) {
		return;
	}

	$big = 9999999999; // Need an unlikely integer.

	echo '<div class="archive-pagination pagination">';
	echo paginate_links(
		array(
			'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
			'format' => '?paged=%#%',
			'current' => max( 1, get_query_var( 'paged' ) ),
			'total' => $query->max_num_pages,
			'end_size' => 0,
			'mid_size' => $page_count,
			'next_text' => esc_html__( 'Older &rsaquo;', 'bromley' ),
			'prev_text' => esc_html__( '&lsaquo; Newer', 'bromley' ),
		)
	);

	echo '</div>';

}


/**
 * Display header image
 */
function bromley_header() {

	$header_image = get_header_image();

	if ( ! empty( $header_image ) ) {
?>
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home" id="header-image">
			<img src="<?php header_image(); ?>" width="<?php echo (int) get_custom_header()->width; ?>" height="<?php echo (int) get_custom_header()->height; ?>" alt="" />
		</a>
<?php
	}

}


/**
 * Add additional classes to make it easier to target styles to specific pages.
 *
 * @param array $classes List of classes to apply to the body.
 * @return string
 */
function bromley_body_class( $classes ) {

	if ( is_singular() ) {
		$classes[] = 'singular';
	}

	if ( is_active_sidebar( 'sidebar-1' ) ) {
		$classes[] = 'themes-sidebar1-active';
	} else {
		$classes[] = 'themes-sidebar1-inactive';
	}

	if ( is_active_sidebar( 'sidebar-2' ) ) {
		$classes[] = 'themes-sidebar2-active';
	} else {
		$classes[] = 'themes-sidebar2-inactive';
	}

	if ( is_active_sidebar( 'sidebar-3' ) ) {
		$classes[] = 'themes-sidebar3-active';
	} else {
		$classes[] = 'themes-sidebar3-inactive';
	}

	return $classes;

}

add_action( 'after_setup_theme', 'bromley_after_setup_theme' );

add_filter( 'body_class', 'bromley_body_class' );
add_filter( 'use_default_gallery_style', '__return_false' );
add_filter( 'excerpt_length', 'bromley_excerpt_length', 18 );
add_filter( 'wp_page_menu', 'bromley_add_menu_class' );


$themecolors = array(
	'bg'     => 'ffffff',
	'border' => 'eeeeee',
	'text'   => '333333',
	'link'   => 'E74C3C',
	'url'    => 'C0392B',
);

require 'inc/custom-header.php';
require 'inc/jetpack.php';
