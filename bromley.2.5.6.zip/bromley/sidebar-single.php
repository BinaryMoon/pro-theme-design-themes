<?php
/**
 * Sidebar template for single post templates
 *
 * @package Bromley
 */

	if ( is_active_sidebar( 'sidebar-3' ) ) {
?>
<aside class="sidebar">
<?php
		do_action( 'before_sidebar' );
		dynamic_sidebar( 'sidebar-3' );
?>
</aside>
<?php
	}
