<?php
/**
 * Archive Template
 *
 * @package Bromley
 */

	get_header();

	if ( have_posts() ) {

		if ( is_category() ) {

			$title = single_cat_title( '', false );

		} elseif ( is_tag() ) {

			$title = single_tag_title( '', false );

		} elseif ( is_author() ) {

			$title = sprintf( __( 'Author: %s', 'bromley' ), '<span class="vcard">' . get_the_author() . '</span>' );

		} elseif ( is_day() ) {

			$title = sprintf( __( 'Day: %s', 'bromley' ), '<span>' . get_the_date() . '</span>' );

		} elseif ( is_month() ) {

			$title = sprintf( __( 'Month: %s', 'bromley' ), '<span>' . get_the_date( _x( 'F Y', 'monthly archives date format', 'bromley' ) ) . '</span>' );

		} elseif ( is_year() ) {

			$title = sprintf( __( 'Year: %s', 'bromley' ), '<span>' . get_the_date( _x( 'Y', 'yearly archives date format', 'bromley' ) ) . '</span>' );

		} elseif ( is_tax( 'post_format', 'post-format-aside' ) ) {

			$title = __( 'Asides', 'bromley' );

		} elseif ( is_tax( 'post_format', 'post-format-gallery' ) ) {

			$title = __( 'Galleries', 'bromley' );

		} elseif ( is_tax( 'post_format', 'post-format-image' ) ) {

			$title = __( 'Images', 'bromley' );

		} elseif ( is_tax( 'post_format', 'post-format-video' ) ) {
			$title = __( 'Videos', 'bromley' );

		} elseif ( is_tax( 'post_format', 'post-format-quote' ) ) {

			$title = __( 'Quotes', 'bromley' );

		} elseif ( is_tax( 'post_format', 'post-format-link' ) ) {

			$title = __( 'Links', 'bromley' );

		} elseif ( is_tax( 'post_format', 'post-format-status' ) ) {

			$title = __( 'Statuses', 'bromley' );

		} elseif ( is_tax( 'post_format', 'post-format-audio' ) ) {

			$title = __( 'Audios', 'bromley' );

		} elseif ( is_tax( 'post_format', 'post-format-chat' ) ) {

			$title = __( 'Chats', 'bromley' );

		} else {

			$title = __( 'Archives', 'bromley' );

		} // End if().
?>
	<h1 class="title"><?php echo $title; ?></h1>
<?php
	the_archive_description( '<div class="category-description">', '</div>' );
?>
	<div id="main-content">
<?php
		while ( have_posts() ) {
			the_post();
			get_template_part( 'content' );
		}

		bromley_numeric_pagination();
?>
	</div>
<?php
	} else {
		 get_template_part( 'content-empty' );
	} // End if().

	get_footer();
