<?php
/**
 * Jetpack Featured Content
 * See: http://jetpack.me/support/featured-content/
 *
 * @package Bromley
 */

	if ( bromley_has_featured_posts() ) {
		$featured_posts = bromley_get_featured_posts( 4 );
?>
	<section class="showcase">
		<div class="row">
<?php
		$count = 0;
		foreach ( $featured_posts as $post ) {
			setup_postdata( $post );

			$category = get_the_category();

			$image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'bromley-content' );
			$styles = '';

			if ( $image[0] ) {
				$styles = 'style="background-image:url(' . esc_url( $image[0] ) . ');"';
			}
?>
			<div class="item" <?php echo $styles; ?> data-url="<?php the_permalink(); ?>">
				<div class="entry">
					<div class="postmetadata">
						<a href="<?php echo get_category_link( $category[0]->term_id ); ?>"><?php echo $category[0]->cat_name; ?></a>
					</div>
					<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
				</div>
			</div>
<?php
			$count++;
			if ( 4 == $count ) {
				$count = 0;
?>
		</div>
		<div class="row">
<?php
			}
		}
?>
		</div>
	</section>
<?php
		wp_reset_postdata();
	}
