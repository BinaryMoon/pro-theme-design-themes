<?php
/**
 * Custom header codes
 *
 * @package Bromley
 */

/**
 * Custom header image
 */
function bromley_custom_header_support() {

	// Custom header image.
	$args = array(
		'default-image' => '',
		'default-text-color' => apply_filters( 'bromley_header_textcolor', 'ffffff' ),
		'random-default' => false,
		'width' => 1140,
		'height' => 150,
		'flex-height' => true,
		'header-text' => true,
		'uploads' => true,
		'wp-head-callback' => 'bromley_colour_styles',
		'admin-head-callback' => '',
		'admin-preview-callback' => '',
	);
	add_theme_support( 'custom-header', $args );

}

add_action( 'after_setup_theme', 'bromley_custom_header_support' );


/**
 * Print custom header styles
 *
 * @return array
 */
function bromley_colour_styles() {

?>
<style>
<?php
	if ( 'blank' === get_header_textcolor() ) {
?>
	.masthead .branding {
		display:none;
	}
	.masthead .menu {
		width:100%;
	}
<?php
	} else {
?>
	.masthead .branding h1.logo a,
	.masthead .branding h1.logo a:hover,
	.masthead .branding h2.description {
		color:#<?php echo esc_attr( get_header_textcolor() ); ?>;
	}
<?php
	}
?>
</style>
<?php

	return true;

}
