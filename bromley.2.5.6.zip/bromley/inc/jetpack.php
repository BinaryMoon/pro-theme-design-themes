<?php
/**
 * Jetpack Compatibility File
 * See: http://jetpack.me/
 *
 * @package Bromley
 */

/**
 * Add theme support for Infinite Scroll.
 * See: http://jetpack.me/support/infinite-scroll/
 */
function bromley_jetpack_init() {

	$settings = array(
		'container' => 'main-content',
		'footer_widgets' => 'sidebar-2',
		'footer' => 'footer-widgets',
	);

	add_theme_support( 'infinite-scroll', $settings );

	add_theme_support(
		'social-links',
		array(
			'facebook',
			'twitter',
			'google_plus',
			'linkedin',
			'tumblr',
		)
	);

	add_theme_support(
		'featured-content',
		array(
			'featured_content_filter' => 'bromley_get_featured_posts',
			'max_posts'   => 12,
			'post_types' => array( 'post', 'page', 'jetpack-portfolio' ),
		)
	);

	add_theme_support( 'jetpack-responsive-videos' );

}

add_action( 'after_setup_theme', 'bromley_jetpack_init' );


/**
 * Get social links from jetpack publicise functionality
 * http://jetpack.me/support/social-links/
 */
function bromley_social_links() {

	$social_links = array(
		'twitter',
		'facebook',
		'tumblr',
		'linkedin',
		'google_plus',
	);
	$links = '';

	foreach ( $social_links as $social ) {

		$url = get_theme_mod( 'jetpack-' . $social );
		if ( $url ) {
			$links .= '<a href="' . esc_url( $url ) . '" class="' . esc_attr( 'social_link_' . $social ) . '"><span>' . $social . '</span></a>';
		}
	}

	if ( $links ) {
		echo '<div class="social_links">' . $links . '</div>';
	}

}


/**
 * Get Jetpack featured posts.
 */
function bromley_get_featured_posts() {

	return apply_filters( 'bromley_get_featured_posts', array() );

}


/**
 * Are there any featured posts to display.
 *
 * @param int $minimum Minimum number of posts to display.
 * @return boolean
 */
function bromley_has_featured_posts( $minimum = 1 ) {

	if ( is_paged() ) {
		return false;
	}

	$minimum = absint( $minimum );
	$featured_posts = apply_filters( 'bromley_get_featured_posts', array() );

	if ( ! is_array( $featured_posts ) ) {
		return false;
	}

	if ( $minimum > count( $featured_posts ) ) {
		return false;
	}

	return true;

}
