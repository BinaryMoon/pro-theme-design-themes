<?php
/**
 * Color annotation for Bromley, by Pro Theme Design.
 */

add_color_rule( 'bg', '#f2f2f2', array(
 	array( 'body', 'background-color' ),
 	array( '.showcase .item', 'border-right-color' ),
), __( 'Background' ) );

add_color_rule( 'txt', '#e74c3c', array(
 	array( '.masthead,.infinite-scroll #infinite-handle span,.main .archive-pagination span.current,form.searchform button.searchsubmit,form input[type=submit],.main .postnav .next a:before, .main .postnav .prev a:before, .main .postnav .next a:after, .main .postnav .prev a:after', 'background-color' ),
 	array( 'a,#respond h3#reply-title:before', 'color', '#ffffff', 3 ),
 	array( 'blockquote,ol.commentlist li.comment.bypostauthor', 'border-left-color' ),
 	array( '.main article.post-archive.sticky a.thumbnail', 'border-bottom-color' ),
 	array( '.masthead .menu li a', 'border-color' ),
 	array( '.masthead .menu li a:hover,.masthead .menu li.current-menu-item a, .masthead .menu li.current_page_item a', 'border-color', '+1' ),
 	array( '.masthead .menu li a.sf-with-ul:after', 'border-top-color', 'txt' ),
 	array( '.masthead .menu li a', 'color', 'txt' ),
 	array( '.masthead .branding h1.logo a, .masthead .branding h1.logo a:hover, .masthead .branding h2.description', 'color', 'txt' ),
 	array( '.masthead .menu li ul li a.sf-with-ul:after', 'border-left-color' ),
 	array( 'form input[type=text]:focus,form input[type=password]:focus,form input[type=email]:focus,form input[type=url]:focus,form input.text:focus,form textarea:focus,form input.settings-input:focus', 'outline-color', '#ffffff', 3 ),
 	array( 'form input[type=text]:focus,form input[type=password]:focus,form input[type=email]:focus,form input[type=url]:focus,form input.text:focus,form textarea:focus,form input.settings-input:focus,form input[type=submit]', 'border-color' ),
 	array( '.infinite-scroll #infinite-handle span,ol.commentlist li.pingback .reply a,ol.commentlist li.comment .reply a', 'background-color' ),
 	array( '.infinite-scroll #infinite-handle span,ol.commentlist li.pingback .reply a,ol.commentlist li.comment .reply a', 'border-color', '-1' ),
 	array( '.infinite-scroll #infinite-handle span:hover,ol.commentlist li.pingback .reply a:hover,ol.commentlist li.comment .reply a:hover', 'background-color', '-1' ),
 	array( '.infinite-scroll #infinite-handle span:hover,ol.commentlist li.pingback .reply a:hover,ol.commentlist li.comment .reply a:hover', 'border-color', '-2' ),
 	array( '.social_links a:before', 'background-color' ),
 	array( '.social_links a:hover:before', 'background-color', '-1' ),
), __( 'Accent and Link Color' ) );

add_color_rule( 'link', '#b3b3b3', array(
 	array( '.widget h3.widgettitle, #footer-widgets .widgets .widget h3.widgettitle, .showcase .item,form input[type=submit]:hover,form.searchform button.searchsubmit:hover', 'background-color' ),
 	array( 'form input[type=submit]:hover', 'border-color' ),
 	array( 'a:hover', 'color', '#ffffff', 2 ),
 	array( '#footer-widgets .widgets .widget h3.widgettitle', 'color', 'link', 15 ),
), __( 'Widget Heading Background' ) );

add_color_rule( 'fg1', '#000000', array(
 	// not used
) );

add_color_rule( 'fg2', '#000000', array(
	// not used
) );

add_color_rule( 'extra', '#666666', array(
 	array( '#footer', 'color', 'bg', 4 ),
 	array( '#footer a', 'color', 'bg' ),
 	array( '#footer a:hover', 'color', 'bg', 15 ),
) );

add_color_rule( 'extra', '#1a1a1a', array(
 	array( '.archive .main h1.title, .search .main h1.title', 'color', 'bg', 3 ),
) );

add_color_rule( 'extra', '#ffffff', array(
 	array( '.infinite-scroll #infinite-handle span,.infinite-scroll #infinite-handle span:hover,ol.commentlist li.pingback .reply a:hover,ol.commentlist li.pingback .reply a', 'color', 'txt' ),
	array( '.social_links a:before,.social_links a:hover:before', 'color', 'txt' ),
) );


/**
 * Custom CSS
 */
function bromley_extra_css() { ?>
	input[type=submit],
	input[type=submit]:hover,
	form input[type=submit],
	form input[type=submit]:hover,
	ol.commentlist li.comment .reply a,
	ol.commentlist li.comment .reply a:hover,
	ol.commentlist li.pingback .reply a,
	ol.commentlist li.pingback .reply a:hover,
	.infinite-scroll #infinite-handle span,
	.infinite-scroll #infinite-handle span:hover {
		background-image: none;
	}
<?php }

add_theme_support( 'custom_colors_extra_css', 'bromley_extra_css' );
