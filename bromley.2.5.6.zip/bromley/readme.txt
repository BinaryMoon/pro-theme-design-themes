=== Bromley ===

Contributors: binarymoon
Requires at least: 4.3
Tested up to: 4.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: blog, blog-excerpts, bright, business, clean, conservative, contemporary, custom-background, custom-colors, custom-header, custom-menu, elegant, featured-images, formal, full-width-template, gaming, geometric, gray, infinite-scroll, journal, lifestream, light, magazine, minimal, modern, news, one-column, post-slider, professional, red, responsive-layout, rtl-language-support, simple, sophisticated, sticky-post, translation-ready, two-columns, white

== Description ==

The best elements of blogging themes manipulated into something beautifully simple. Ideal for local community, fan magazines, and talking about updates in your industry.

[Theme documentation](https://prothemedesign.com/documentation/theme/bromley/)

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Bromley includes support for [Styleguide](https://wordpress.org/plugins/styleguide/) - a plugin that allows you to change fonts, and colours in WordPress themes.

Bromley includes support for most features in [Jetpack](https://wordpress.org/plugins/jetpack/), including Infinite Scroll, Featured Content, and Site Logo.

== Changelog ==

= 2.5.6 - 2nd April 2021 =
* Fix text input width.

= 2.5.5 - 19th January 2021 =
* Fix PHP warning.
* Clear html widget to prevent floated content from breaking the layout.

= 2.5.4 - 2nd January 2021 =
* Fix jQuery error since jquery migrate has been removed.

= 2.5.3 - 5th October 2020 =
* Add support for wp_body_open.

= 2.5.2 - 11th July 2020 =
* Fix infinite scroll button styles.

= 2.5.1 - 9th July 2020 =
* Remove use of deprecated Jetpack function `is_ipad`.
* Tweak search button styles so they don't overlap the search field

= 2.5 - 4th May 2020 =
* Happy Star Wars day!
* Added support for site logos, and tweaked the responsive header styles.

= 2.4 - 13th March 2020 =
* Improve coding standards.
* Improve responsive layout.
* Add Gutenberg support.
* Add a wrapper around the 'on' text in post meta so that it can be hidden.

= 2.3 - 25th May 2018 =
* Add support for privacy policy link in the site footer.
* Fix display of the cookie consent checkbox in the comments form.

= 2.2.2 - 28th January 2018 =
* Improve css browser prefixes.

= 2.2.1 - 28th March 2017 =
* Improve responsive display of social widgets.

= 2.2 - 11th January 2017 =
* Tweak sticky post styles so that the image ratio remains consistent
* Improve coding standards
* Switch to the_archive_description on archive pages

= 2.1 - 7th October 2016 =
* add support for projects and pages in featured content
* tweak word wrap settings in widgets
* remove css box-shadow prefixes

= 2.0 =
* update theme for WordPress coding standards
* slow down slider speed
* add title tag support
* update to latest masonry
* add support for jetpack responsive videos

= 1.1 =
* fix image post parent issue on attachment pages
* add jetpack testimonials shortcode styles
* update sidebar description
* update & improve css styles
* improve responsive navigation code
* various other tweaks and improvements

= 1.0 =
* Initial release

== Credits ==

* [Open Sans](https://www.google.com/fonts/specimen/Open+Sans) Font from Google Fonts, licensed under [Apache License, version 2.0](http://www.apache.org/licenses/LICENSE-2.0.html)
* [Oswald](https://www.google.com/fonts/specimen/Oswald) Font from Google Fonts, licensed under [SIL Open Font License, 1.1](http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL)
* Genericons: font by Automattic (http://automattic.com/), licensed under [GPL2](https://www.gnu.org/licenses/gpl-2.0.html)
