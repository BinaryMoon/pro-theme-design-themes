<?php
/**
 * Single page template
 *
 * @package Bromley
 */

	get_header();

	get_template_part( 'inc/featured-content' );

	if ( have_posts() ) {
?>
	<div class="main-content">
<?php
		while ( have_posts() ) {
			the_post();
			get_template_part( 'content-page' );
			if ( comments_open() || '0' != get_comments_number() ) {
				comments_template( '', true );
			}
		}
?>
	</div>
<?php
	}

	get_footer();
