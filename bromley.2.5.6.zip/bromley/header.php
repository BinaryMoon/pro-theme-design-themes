<?php
/**
 * Header Template
 *
 * @package Bromley
 */

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta http-equiv="Content-Type" content="<?php bloginfo( 'html_type' ); ?>; charset=<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />

	<!--[if lt IE 9]>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/html5.js" type="text/javascript"></script>
	<![endif]-->

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<?php wp_body_open(); ?>

	<header class="masthead fadeInDown animated" role="banner">

		<?php the_custom_logo(); ?>

		<div class="branding">
			<h1 class="logo">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php esc_attr_e( 'Home', 'bromley' ); ?>">
					<?php bloginfo( 'name' ); ?>
				</a>
			</h1>
			<h2 class="description">
				<?php bloginfo( 'description' ); ?>
			</h2>
		</div>
		<nav class="menu">
			<?php wp_nav_menu( array( 'theme_location' => 'top_menu', 'menu_id' => 'nav', 'menu_class' => 'menu-wrap clearfix' ) ); ?>
		</nav>
	</header>

	<div class="container hfeed">
		<div class="main">
<?php
	bromley_header();
	do_action( 'before' );
?>
