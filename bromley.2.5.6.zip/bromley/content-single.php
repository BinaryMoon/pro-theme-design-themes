<?php
/**
 * Single post content
 *
 * @package Bromley
 */

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<?php
	get_template_part( 'inc/postmetadata' );
	the_title( '<h1 class="title">', '</h1>' );
?>
	<section class="entry">
<?php
	the_content();

	edit_post_link();

	wp_link_pages(
		array(
			'before' => '<div class="archive-pagination">' . __( 'Pages: ', 'bromley' ),
			'after'  => '</div>',
			'link_before' => '<span>',
			'link_after'  => '</span>',
		)
	);
?>
		<div class="taxonomies">
			<p class="tax-categories taxonomy">
<?php
	esc_html_e( 'Categories: ', 'bromley' );
	the_category( ', ' );
?>
			</p>
<?php

	// Display tags (if there are any).
	if ( get_the_tags() ) {
		the_tags( '<p class="tax-tags taxonomy">' . __( 'Tagged as: ', 'bromley' ), _x( ', ', 'Tag list seperator', 'bromley' ), '</p>' );
	}
?>
		</div>
	</section>
</article>
<nav class="postnav">
	<div class="prev">
		<?php previous_post_link( __( '<span class="more-link">%link</span>', 'bromley' ) ); ?>
	</div>
	<div class="next">
		<?php next_post_link( __( '<span class="more-link">%link</span>', 'bromley' ) ); ?>
	</div>
</nav>
