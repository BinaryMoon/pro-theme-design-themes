<?php
/**
 * No content
 *
 * @package Bromley
 */

?>
<article class="no-results not-found">
	<h1 class="title"><?php esc_html_e( 'Nothing Found', 'bromley' ); ?></h1>

	<section class="entry">
<?php
	if ( is_home() && current_user_can( 'publish_posts' ) ) {
?>
		<p><?php printf( __( 'Ready to publish your first post? <a href="%1$s">Get started here</a>.', 'bromley' ), esc_url( admin_url( 'post-new.php' ) ) ); ?></p>
<?php
	} if ( is_search() ) {
?>
		<p><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'bromley' ); ?></p>
<?php
		get_search_form();
	} else {
?>
		<p><?php esc_html_e( 'It seems we can\'t find what you\'re looking for. Perhaps searching can help.', 'bromley' ); ?></p>
<?php
		get_search_form();
	}
?>
	</section>
</article>
