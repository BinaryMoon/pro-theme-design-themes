<?php
/**
 * Generic content
 *
 * @package Bromley
 */

	$post_classes = array( 'post-archive' );

	if ( is_sticky() ) {
		$image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'bromley-content-sticky' );
	} else {
		$image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'bromley-content' );
	}

	$styles = '';

	if ( $image && $image[0] ) {
		$post_classes[] = 'has-image';
		$styles = 'style="background-image:url(' . esc_url( $image[0] ) . ');"';
	}

?>
<article id="post-<?php the_ID(); ?>" <?php post_class( $post_classes ); ?>>
<?php
	if ( $styles ) {
?>
	<a href="<?php echo esc_url( get_permalink() ); ?>" class="thumbnail" <?php echo $styles; ?>></a>
<?php
	}
?>
	<div class="post-archive-wrap">
		<?php get_template_part( 'inc/postmetadata' ); ?>
		<h2 class="posttitle">
			<a href="<?php the_permalink(); ?>" rel="bookmark">
				<?php the_title(); ?>
			</a>
		</h2>
		<?php the_excerpt(); ?>
	</div>

</article>
