<?php
/**
 * Footer Template
 *
 * @package Bromley
 */

?>
	</div>
</div><!--/container-->

<?php
	if ( is_active_sidebar( 'sidebar-2' ) ) {
?>
<footer id="footer-widgets">
	<aside class="widgets">
		<?php dynamic_sidebar( 'sidebar-2' ); ?>
	</aside>
</footer>
<?php
	}
?>
<footer role="contentinfo" id="footer">
<?php
	bromley_social_links();

	if ( function_exists( 'the_privacy_policy_link' ) ) {
		the_privacy_policy_link( '', '<span class="sep" role="separator" aria-hidden="true"> | </span>' );
	}
?>
	<a href="http://wordpress.org/" title="<?php esc_attr_e( 'A Semantic Personal Publishing Platform', 'bromley' ); ?>" rel="generator"><?php printf( __( 'Proudly powered by %s', 'bromley' ), 'WordPress' ); ?></a>
	<span class="sep" role="separator" aria-hidden="true"> | </span>
	<?php printf( __( 'Theme: %1$s by %2$s.', 'bromley' ), 'Bromley', '<a href="https://prothemedesign.com/" rel="designer">Pro Theme Design</a>' ); ?>
</footer>

<?php wp_footer(); ?>

</body>
</html>
