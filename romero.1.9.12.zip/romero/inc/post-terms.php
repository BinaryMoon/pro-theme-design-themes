<?php
/**
 * Post terms
 *
 * @package Romero
 */

	// Not applicable to all post types.
	if ( 'post' !== get_post_type( get_the_ID() ) ) {
		return;
	}

	$message = '<span class="tax-categories">' . sprintf(
		/* Translators: %s: list of post categories */
		esc_html__( 'Posted in %s', 'romero' ),
		get_the_category_list( _x( ', ', 'Category/ Tag list separator (includes a space after the comma)', 'romero' ) )
	) . '</span>';


	if ( get_the_tags() ) {

		$message .= ' <span class="tax-tags">' . sprintf(
			/* Translators: %s: list of post tags */
			esc_html__( 'Tagged %s', 'romero' ),
			get_the_tag_list( '#', _x( ', ', 'Category/ Tag list separator (includes a space after the comma)', 'romero' ), '' ) . '</span>'
		) . '</span>';

	}

	if ( $message ) {
		echo '<span class="terms">' . $message . '</span>';
	}
