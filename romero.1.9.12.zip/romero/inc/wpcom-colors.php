<?php
/* Custom Colors: Romero */
// Background
add_color_rule( 'bg', '#e6e6e6', array(
	array( 'body, .masthead .menu-primary', 'background-color' ),
	array( 'header.header-overlap, .content-comments', 'background', '+.5' ),
) );
add_color_rule( 'txt', '#666666', array(
) );

// Links
add_color_rule( 'link', '#4a90e2', array(
	array( 'input[type=submit], .infinite-scroll #infinite-handle span, .screen-reader-shortcut, .main .contributor a.contributor-posts-link, .masthead .menu-primary #sidebar-menu-toggle:before, .main .pagination span.current, article .post-lead-category a, #sidebar-menu', 'background' ),
	array( 'input[type=text]:focus, input[type=password]:focus, input[type=email]:focus, input[type=url]:focus, input.text:focus, textarea:focus, select:focus, input.settings-input:focus', 'outline-color' ),
	array( 'input[type=text]:focus, input[type=password]:focus, input[type=email]:focus, input[type=url]:focus, input.text:focus, textarea:focus, select:focus, input.settings-input:focus, .sidebar-main .widget:before', 'border-color' ),
	array( '.sidebar-main .widget.widget_flickr #flickr_badge_uber_wrapper td a, .sidebar-main .widget.widget_flickr #flickr_badge_wrapper td a, a, .sidebar-footer a', 'color', '#ffffff', 5 ),
	array( '.main .post-navigation .nav-previous a:hover, .main .post-navigation .nav-next a:hover, article.post-archive h2.entry-title a:hover, .sidebar-main .widget a:hover, .menu-social-links ul li a:hover:before, .widget a:hover', 'color' ),
	array( 'a:hover', 'color', '+.15' ),
	array( 'article .post-lead-category a:hover, .masthead .menu-primary #sidebar-menu-toggle:hover::before, .infinite-scroll #infinite-handle span:hover', 'background', '+.15' ),
	array( '.sidebar-menu .widget:before', 'border-color', '+.15' ),
),
__( 'Links, Borders and Hover Effects' ) );

add_color_rule( 'fg1', '#666666', array(
) );

add_color_rule( 'fg2', '#666666', array(
) );

// Extra
add_color_rule( 'extra', '#666666', array(
	array( 'body.blog .main', 'color', 'bg', 5 ),
) );
add_color_rule( 'extra', '#ffffff', array(
	array( '.masthead .menu-primary #sidebar-menu-toggle:before, .main .pagination span.current, article .post-lead-category a, .infinite-scroll #infinite-handle span, .infinite-scroll #infinite-handle span:hover, #sidebar-menu .widget h3.widgettitle, #sidebar-menu .widget', 'color', 'link', 5 ),
) );
add_color_rule( 'extra', '#E8E8E8', array(
	array( '.sidebar-main .widget_calendar thead, .sidebar-main .widget_calendar tbody, .sidebar-main .widget_calendar tfoot, .sidebar-main #wp-calendar a', 'color', '#ffffff', 5 ),
) );
add_color_rule( 'extra', '#666666', array(
	array( '.sidebar-main, .sidebar-main .widget a, body .archive, body .blog', 'color', 'bg', 5 ),
) );
add_color_rule( 'extra', '#999999', array(
	array( '.sidebar-main .widget', 'color', 'bg', 5 ),
) );
add_color_rule( 'extra', '#1a1a1a', array(
	array( '.entry-title, .sidebar-main h1, .sidebar-main h2, .sidebar-main h3, .sidebar-main h4, .sidebar-main h5, .sidebar-main h6, h3#comments, h3#comments a, #reply-title', 'color', 'bg', 5 ),
) );
add_color_rule( 'extra', '#1a1a1a', array(
	array( '.main-content h1, .main-content h2, .main-content h3, .main-content h4, .main-content h5, .main-content h6, .sidebar-footer h1, .sidebar-footer h2, .sidebar-footer h3, .sidebar-footer h4, .sidebar-footer h5, .sidebar-footer h6', 'color', '#ffffff', 5 ),
) );
add_color_rule( 'extra', '#000000', array(
	array( '.masthead .menu-primary a, .masthead .actions .menu-primary a, article.post-archive h2.entry-title a', 'color', 'bg', 5 ),
) );
add_color_rule( 'extra', '#000000', array(
	array( '.showcase article.post-archive h2.entry-title a', 'color', '#ffffff', 5 ),
) );
add_color_rule( 'extra', '#000000', array(
	array( '.masthead .menu li.page_item_has_children > a:after, .masthead .menu li.menu-item-has-children > a:after', 'border-top-color', 'bg', 5 ),
) );
add_color_rule( 'extra', '#cee1f7', array(
	array( '#sidebar-menu .widget a', 'color', 'link', 5 ),
) );
add_color_rule( 'extra', '#4a90e2', array(
	array( '.blog .main a', 'color', 'bg', 5 ),
) );
add_color_rule( 'extra', '#4a90e2', array(
	array( '.blog .main a:hover', 'color', 'bg', 5 ),
) );
add_color_rule( 'extra', '#cccccc', array(
	array( '.masthead .menu li.current-menu-item > a', 'background-color' ),
) );
add_color_rule( 'extra', '#000000', array(
	array( '.masthead .menu li.current-menu-item > a', 'color', '#cccccc', 5 ),
) );

//Additional palettes
add_color_palette( array(
	'#000000',
	'',
	'#ffd000',
), 'Q' );
add_color_palette( array(
	'#3e9a36',
	'',
	'#88c425',
), 'Lantern' );
add_color_palette( array(
	'#858f97',
	'',
	'#1b676b',
), 'Uniform' );
add_color_palette( array(
	'#eeeeee',
	'',
	'#df4d4d',
), 'Super' );
add_color_palette( array(
	'#eae1d1',
	'',
	'#af8b59',
), 'Donkey' );
add_color_palette( array(
	'#333f41',
	'',
	'#59af5c',
), 'Froggy' );
add_color_palette( array(
	'#e8e4eb',
	'',
	'#9c59af',
), 'Asteroid' );
