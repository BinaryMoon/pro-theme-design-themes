<?php
/**
 * Jetpack Compatibility File
 * See: http://jetpack.me/
 *
 * @package Romero
 */

/**
 * Add theme support for Infinite Scroll.
 * See: http://jetpack.me/support/infinite-scroll/
 */
function romero_jetpack_init() {

	add_theme_support(
		'infinite-scroll',
		array(
			'container' => 'main-content',
			'footer_widgets' => romero_can_infinite_scroll(),
			'footer' => 'header-wrapper',
			'posts_per_page' => 16,
			'wrapper' => false,
		)
	);

	add_theme_support(
		'featured-content',
		array(
			'featured_content_filter' => 'romero_get_featured_posts',
			'max_posts' => 7,
			'post_types' => array( 'post', 'page', 'jetpack-portfolio' ),
		)
	);

	add_theme_support( 'jetpack-responsive-videos' );

	add_theme_support(
		'site-logo',
		array(
			'size' => 'romero-logo',
		)
	);

	// Add support for Jetpack content options.
	add_theme_support(
		'jetpack-content-options',
		array(
			// The default setting of the theme: 'content', 'excerpt' or array( 'content, 'excerpt', ).
			'blog-display' => 'excerpt',
			'author-bio' => true,
			'post-details' => array(
				'stylesheet' => 'romero-style',
				'date' => '.posted-on',
				'categories' => '.tax-categories, article .post-lead-category a, article.featured-post .post-lead-category a',
				'tags' => '.tax-tags',
				'author' => '.byline',
			),
		)
	);

}

add_action( 'after_setup_theme', 'romero_jetpack_init' );


/**
 * Get featured posts using Jetpack Featured content
 */
function romero_get_featured_posts() {

	return apply_filters( 'romero_get_featured_posts', array() );

}


/**
 * Check if Jetpack Featured Content has any featured posts available
 *
 * @param int $minimum The minimum number of featured posts to display.
 * @return boolean
 */
function romero_has_featured_posts( $minimum = 1 ) {

	if ( is_paged() ) {
		return false;
	}

	$minimum = absint( $minimum );
	$featured_posts = apply_filters( 'romero_get_featured_posts', array() );

	if ( ! is_array( $featured_posts ) ) {
		return false;
	}

	if ( $minimum > count( $featured_posts ) ) {
		return false;
	}

	return true;

}


/**
 * Count how many featured posts there are
 *
 * @return boolean
 */
function romero_count_featured_posts() {

	if ( is_paged() ) {
		return false;
	}

	$featured_posts = apply_filters( 'romero_get_featured_posts', array() );

	if ( ! is_array( $featured_posts ) ) {
		return 0;
	}

	return count( $featured_posts );

}


/**
 * Can jetpack enable the auto loading infinite scroll.
 *
 * @return boolean
 */
function romero_can_infinite_scroll() {

	if ( function_exists( 'jetpack_is_mobile' ) && jetpack_is_mobile() ) {
		return true;
	}

	return false;

}


/**
 * Change default jetpack infinite scroll setttings
 *
 * @param  array $settings Options for the Infinite scroll setup.
 * @return array
 */
function romero_infinite_scroll_js_settings( $settings ) {

	$settings['text'] = esc_html__( 'More Posts', 'romero' );

	return $settings;

}


/**
 * The function to display Author Bio in a theme.
 *
 * @return null
 */
function romero_author_bio() {

	$options = get_theme_support( 'jetpack-content-options' );
	$author_bio = null;

	if ( ! empty( $options[0]['author-bio'] ) ) {
		$author_bio = $options[0]['author-bio'];
	}

	// If the theme doesn't support "jetpack-content-options['author-bio']", don't continue.
	if ( true !== $author_bio ) {
		return;
	}

	// If "jetpack_content_author_bio" is false and we aren't in the customizer, don't continue.
	if ( ! get_option( 'jetpack_content_author_bio', 1 ) ) {
		return;
	}

	// If we aren't on a single post, don't continue.
	if ( ! is_single() ) {
		return;
	}

	// Display the author bio.
	romero_contributor();

}

add_filter( 'infinite_scroll_js_settings', 'romero_infinite_scroll_js_settings' );
