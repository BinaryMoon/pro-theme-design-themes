<?php
/**
 * Error - file not found
 *
 * @package Romero
 */

	get_header();
?>
	<header class="entry-archive-header header-overlap">
		<div class="container container-404">
			<h1 class="entry-title">
				<?php esc_html_e( 'Oops! That page can&rsquo;t be found.', 'romero' ); ?>
			</h1>
		</div>
	</header>

	<div class="container hfeed">
		<div class="main">
			<div id="main-content" class="main-content showcase">
				<?php get_template_part( 'content-empty' ); ?>
			</div>
<?php

	get_footer();
