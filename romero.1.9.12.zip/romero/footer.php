<?php
/**
 * Footer Template
 *
 * @package Romero
 */

?>
	</div>
</div>

<?php

	get_sidebar( 'footer' );

?>

<footer role="contentinfo" id="footer">

<?php

	romero_social_links();

	/**
	 * Check to see if a custom credits option is set.
	 * If custom credits are set then the filter should output the credits and
	 * return a non false value. This will hide the default footer credits.
	 */
	if ( false === apply_filters( 'romero_credits', false ) ) {

?>

	<section class="footer-wrap">

<?php

		if ( function_exists( 'the_privacy_policy_link' ) ) {
			the_privacy_policy_link( '', '<span class="sep"> | </span>' );
		}

?>

		<a href="http://wordpress.org/" title="<?php esc_attr_e( 'A Semantic Personal Publishing Platform', 'romero' ); ?>" rel="generator"><?php printf( __( 'Proudly powered by %s', 'romero' ), 'WordPress' ); ?></a>
		<span class="sep"> | </span>
		<?php printf( __( 'Theme: %1$s by %2$s.', 'romero' ), 'Romero', '<a href="https://prothemedesign.com/" rel="designer">Pro Theme Design</a>' ); ?>

	</section>

<?php
		}
?>

</footer>

<?php wp_footer(); ?>

</body>
</html>
