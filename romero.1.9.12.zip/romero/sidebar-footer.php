<?php
/**
 * Footer Sidebar
 * Only shows on posts and pages
 *
 * @package Romero
 */

	$sidebar_slug = '';

	if ( is_singular() ) {

		if ( is_active_sidebar( 'sidebar-2' ) ) {
			$sidebar_slug = 'sidebar-2';
		}

	} else {

		if ( is_active_sidebar( 'sidebar-6' ) ) {
			$sidebar_slug = 'sidebar-6';
		}

	}

	if ( ! $sidebar_slug ) {

		return;

	}

?>

<section class="sidebar sidebar-footer" id="sidebar-footer" role="complementary">
	<div class="container">
		<?php dynamic_sidebar( $sidebar_slug ); ?>
	</div>
</section>
