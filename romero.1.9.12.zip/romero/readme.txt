=== Romero ===

Contributors: binarymoon
Tags: blue, gray, white, light, one-column, two-columns, responsive-layout, custom-background, custom-colors, custom-header, custom-menu, editor-style, featured-images, featured-image-header, flexible-header, full-width-template, infinite-scroll, rtl-language-support, site-logo, sticky-post, translation-ready, artwork, design, gaming, journal, magazine, music, news, sports, bright, clean, contemporary, minimal, modern, professional, simple
Requires at least: 4.1
Tested up to: 4.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Romero is a WordPress theme designed for visual magazine sites. With full width featured images making your featured blog posts really stand out, it's ideal for video game sites, motoring magazines, and other topics that have large vibrant imagery.

[Theme documentation](https://prothemedesign.com/documentation/theme/romero/)

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==

= 1.9.12 - 2nd April 2021 =
* Fix text input width.

= 1.9.11 - 31st January 2021 =
* Clear html widget to prevent floated content from breaking the layout.

= 1.9.10 - 1st January 2021 =
* Fix jQuery error since jquery migrate has been removed.
* Fix sub menu link colours on mobile devices.

= 1.9.9 - 27th October 2020 =
* Add 'navigation-widgets' to supported html5 types.

= 1.9.8 - 13th October 2020 =
* Fix logo being hidden on mobile devices.
* Tweaks to avatar styles in post contributor box.

= 1.9.7 - 5th October 2020 =
* Add support for wp_body_open.

= 1.9.6 - 3rd October 2020 =
* Fix problem with mobile menu with dropdowns.

= 1.9.5 - 29th July 2020 =
* Make logo class generic (for 5.5 update).

= 1.9.4 - 9th July 2020 =
* Remove use of deprecated Jetpack function `is_ipad`.

= 1.9.3 - 29th May 2020 =
* Add support for custom credits.
* Add support for new editor styles.

= 1.9.2 - 6th April 2020 =
* Fix bug with homepage layout.

= 1.9.1 - 4th April 2020 =
* Improve button styles.
* Improve spacing in comment form.

= 1.9 - 22nd March 2020 =
* Update Gutenberg styles.
* Standardize 404 page layout. Now it matches the 'no search results' layout.

= 1.8.3 - 9th August 2019 =
* Add an additional footer widgets sidebar for the homepage and archives. To prevent existing sites from being changed this is a new sidebar that can be configured independently.
* Add a new filter that allows the featured images from attachments to be disabled with a one line plugin `add_filter( 'romero_use_image_attachments', '__return_false' );`

= 1.8.2 - 10th July 2019 =
* Increase max width of titles on large featured content box.

= 1.8.1 - 18th June 2019 =
* Fix button styles in forms. input elements looked good but button elements were not styled. They are now!

= 1.8 - 12th March 2019 =
* Add the excerpt to the featured post. It's hidden by default, but this allows it to be displayed with custom css.

= 1.7.2 - 6th October 2018 =
* Make featured header image larger to account for larger screens. The proportions are consistent so existing sites won't change design.

= 1.7.1 - 12th August 2018 =
* Some minor style tweaks to improve support for WordAds.

= 1.7 - 25th May 2018 =
* Add support for privacy policy link in the site footer.
* Fix display of the cookie consent checkbox in the comments form.

= 1.6 - 31st October 2017 =
* WooCommerce for all (.com and .org).
* Disable infinite-scroll on WooCommerce archive pages.

= 1.5.2 - 13th July 2017 =
* Remove include for inc/wpcom.php, since it's automatically included by WordPress.com sites

= 1.5.1 - 3rd July 2017 =
* Fix PHP errors due to WooCommerce integration.

= 1.5 - 18th June 2017 =
* Add support for WooCommerce

= 1.4.3 - 10th June 2017 =
* Improve compatibility with new media widgets in WP 4.8

= 1.4.2 - 24th May 2017 =
* Make WordPress custom logo work, replacing Jetpack site logo (self hosted only)
* Improve coding standards and text escaping

= 1.4.1 - 11th April 2017 =
* Fix small issue with display of Jetpack ratings on homepage and archives.

= 1.4 - 26th March 2017 =
* Setup Jetpack content options to allow showing and hiding of different elements in the theme. The settings can be found in the Customizer. Requires Jetpack to be installed.
* Tidy the codes

= 1.3.6 - 3rd March 2017 =
* Fix issue with drop down menu arrow custom colours on wordpress.com
* Improve iframe widget display (such as social widgets) in narrow sidebars
* Improve colour contrast in some instances to increase readability

= 1.3.5 - 18th November 2016 =
* Improve Responsive styles in header

= 1.3.4 - 24th September 2016 =
* Fix incorrect text domain
* Tweak word-wrap so that it's a bit less aggressive
* Tidy the codes
* Add support for pages and portfolios to featured content

= 1.3.3 - 14th May 2016 =
* Add some additional class names, and extra divs, to header content so that the divs can be more easily targeted with custom css.

= 1.3.2 =
* Fix small issue with image attachment page

= 1.3.1 =
* Add social link icons usable in menus with the addition of the icon class

= 1.3 =
* Make featured images on pages work in the same way as featured images on blog posts

= 1.2.5 =
* improve coding standards
* Add an .intro class that allows text to be increased in size in blog posts

= 1.2.4 =
* Correct invalid html in widget toggle
* misc css tweaks and improvements

= 1.2.3 =
* fix site logo so that logo and title & description can be hidden independently
* fix image alignments and tweak a few other small css bits

= 1.2.2 =
* fix issue with the site title not hiding properly when property changed in customizer
* update widget styles

= 1.2.1 =
* fix icon font positions for Internet Explorer

= 1.2 =
* improve comments html and styles

= 1.1.4 =
* various css improvements including responsive comments layout, and default widgets styles

= 1.1.3 =
* make the logo width variable

= 1.1.2 =
* make bold fonts stand out even more! :)

= 1.1.1 =
* fix issue with bold styles not displaying on blog posts
* fix issue with font loading for Open Sans font weights

= 1.1 =
* give the menu a little more space if there's no widgets to display in the dropdown menu
* fix issue with mobile menu

= 1.0 =
* Initial release.

== Credits ==

* [Open Sans](https://www.google.com/fonts/specimen/Open+Sans) Font from Google Fonts, licensed under [Apache License, version 2.0](http://www.apache.org/licenses/LICENSE-2.0.html).
* [Oswald](https://www.google.com/fonts/specimen/Oswald) Font from Google Fonts, licensed under [SIL Open Font License, 1.1](http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL).
* Genericons: font by Automattic (http://automattic.com/), licensed under [GPL2](https://www.gnu.org/licenses/gpl-2.0.html)
