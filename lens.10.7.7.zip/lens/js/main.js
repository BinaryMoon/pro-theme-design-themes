/**
 * main.js v1
 * Created by Ben Gillbanks <http://www.binarymoon.co.uk/>
 * Available under GPL2 license
 */

( function( $ ) {

	// widgets that may contain content that could change size during load
	var widget_containers = '.widget_facebook_likebox, .widget_twitter_timeline, .widget_text';
	// widgets that use masonry for positioning
	var widget_footer_parents = 'footer#footer .footer-widgets';
	var masonry_footer_properties = {};

	function masonry_reload() {

		$( widget_footer_parents ).masonry( masonry_footer_properties );

	}

	function masonry_widget_load_test() {

		// get widgets
		var widgets = $( widget_containers );
		// default to all widgets loaded
		var loaded = true;

		// check if widgets have loaded by testing their height
		// all widgets should be greater than 30 pixels tall
		// needs to include extra height since many widgets have links in the default code
		widgets.each(
			function() {
				if ( $( this ).height() < 30 ) {
					loaded = false;
				}
			}
		);

		if ( loaded ) {
			masonry_reload();
		} else {
			setTimeout( masonry_widget_load_test, 250 );
		}

	}

	function is_touch_device() {

		return ( ( 'ontouchstart' in window )
			|| ( navigator.MaxTouchPoints > 0 )
			|| ( navigator.msMaxTouchPoints > 0 ) );

	}

	$( document ).ready( function() {

		// Set default heights for social media widgets

		// Twitter
		$( 'a.twitter-timeline, iframe.twitter-timeline' ).each(
			function() {
				var thisHeight = $( this ).attr( 'height' );
				$( this ).parent().css( 'min-height', thisHeight + 'px' );
			}
		);

		// Facebook
		$( '.fb-page' ).each(
			function() {

				// Get some settings from the initial markup:
				var $set_height = $( this ).data( 'height' );
				var $show_facepile = $( this ).data( 'show-facepile' );
				var $show_posts = $( this ).data( 'show-posts' ); // AKA stream
				var $min_height = $set_height; // set the default 'min-height'

				// These values are defaults from the FB widget.
				var $no_posts_no_faces = 130;
				var $no_posts = 220;

				if ( $show_posts ) {

					// Showing posts; may also be showing faces and/or cover - the latter doesn't affect the height at all.
					$min_height = $set_height;

				} else if ( $show_facepile ) {

					// Showing facepile with or without cover image - both would be same height.
					// If the user selected height is lower than the no_posts height, we'll use that instead
					$min_height = ( $set_height < $no_posts ) ? $set_height : $no_posts;

				} else {

					// Either just showing cover, or nothing is selected (both are same height).
					// If the user selected height is lower than the no_posts_no_faces height, we'll use that instead
					$min_height = ( $set_height < $no_posts_no_faces ) ? $set_height : $no_posts_no_faces;

				}

				// apply min-height to .fb-page container
				$( this ).css( 'min-height', $min_height + 'px' );

			}
		);

		// Arrange footer widgets vertically.
		if ( typeof $.fn.masonry === 'function' ) {

			masonry_footer_properties = {
				itemSelector: '.widget',
				gutter: 0,
				isOriginLeft: !$( 'body' ).is( '.rtl' )
			};

			// masonry widgets
			$( widget_footer_parents ).masonry( masonry_footer_properties );

			// update when images load
			$( widget_footer_parents ).imagesLoaded(
				function() {
					masonry_reload();
				}
			);

			// update when facebook, and twitter widgets load content
			if ( $( widget_containers ).length > 0 ) {
				masonry_widget_load_test();
			}

		}

		// Attachment page navigation.
		if ( $( 'body' ).hasClass( 'attachment' ) ) {

			$( document ).keydown(
				function( e ) {

					if ( $( 'textarea, input' ).is( ':focus' ) ) {
						return;
					}

					var url = false;

					switch ( e.which ) {
						// left arrow key (previous attachment)
						case 37:
							url = $( '.image-previous a' ).attr( 'href' );
							break;

						// right arrow key (next attachment)
						case 39:
							url = $( '.image-next a' ).attr( 'href' );
							break;

					}

					if ( url ) {
						window.location = url;
					}
				}
			);

		}

		// menu toggle

		$( '.menu-toggle' ).on(
			'click',
			function() {
				$( this ).parent().toggleClass( 'menu-on' );
			}
		);

		// Dropdown menu touch screen improvements.
		// Only performed on touch devices.
		if ( is_touch_device() ) {

			// If a dropdown menu is tapped on a touch device then focus the menu.
			$( '.menu-item-has-children > a, .page_item_has_children > a' ).on(
				'touchstart',
				function( e ) {

					$( '.menu li' ).removeClass( 'focus' );
					var $parent = $( this ).parent( 'li' );

					/**
					 * If the parent is not focused then cancel the click.
					 * This prevents the page from changing before children can
					 * be seen and selected.
					 * If you click a link again then the link will be followed.
					 */
					if ( !$parent.hasClass( 'focus' ) && !$( '.menu' ).hasClass( 'menu-on' ) ) {
						e.preventDefault();
					}

					$parent.toggleClass( 'focus' );

				}
			);

			// If you tap on the page body then the page will remove focus from all menu items.
			$( 'body' ).on(
				'touchstart',
				function( e ) {
					if ( !$( e.target ).closest( '.menu li' ).length ) {
						$( '.menu li' ).removeClass( 'focus' );
					}
				}
			);

		}


		$( '.post-image-wrapper' ).on(
			'focus mouseover',
			function() {
				$( this ).parent().addClass( 'focus' );
			}
		);

		$( '.post-image-wrapper' ).on(
			'blur mouseleave',
			function() {
				$( this ).parent().removeClass( 'focus' );
			}
		);

		$( 'body' ).addClass( is_touch_device() ? 'device-touch' : 'device-click' );

	} );

} )( jQuery );