<?php

add_color_rule( 'bg', '#f2f2f2', array(
	array( 'body, blockquote', 'background' ),
	array( 'footer#footer, footer#footer .footer-widgets .widget, table tr:nth-child(2n+1), .masthead, ol.commentlist li.comment.bypostauthor, ol.commentlist li.trackback.bypostauthor, ol.commentlist li.pingback.bypostauthor,.widget, nav.postnav a:hover:before, nav.postnav a:hover', 'background', '+1' ), /* Should be lighter than the background color, white by default */
	array( '.col-sidebar .postinfo', 'background', '+1.5' ),
	array( 'table tr:nth-child(2n), a.post-edit-link', 'background', '+1.5' ),
	array( 'input[type="text"], input[type="password"], input[type="email"], input[type="url"], input.text, textarea, input.settings-input, a.post-edit-link:hover', 'background', '+1.8' ),
	array( 'table, footer#footer .footer-wrap, input[type="text"], input[type="password"], input[type="email"], input[type="url"], input.text, textarea, input.settings-input, .col-sidebar .postinfo, .widget, .more-posts, .col-sidebar .postinfo .taxonomies', 'border-color', 0.6 ),
	array( 'article.post-archive, nav.postnav', 'border-color', '+1' ),
	array( '.main article h1.title:after, .main article .entry:after', 'background', '-1' ),
	array( 'article.post-archive.sticky:after', 'border-top-color', '+1' ),
	array( 'article.post-archive.sticky:after', 'border-right-color', '+1' ),
	array( 'ol.commentlist li.comment .comment-meta .comment-metadata .edit-link a, ol.commentlist li.trackback .comment-meta .comment-metadata .edit-link a, ol.commentlist li.pingback .comment-meta .comment-metadata .edit-link a', 'background', '+1' ),
	array( 'ol.commentlist li.comment .comment-meta .comment-metadata .edit-link a:hover, ol.commentlist li.trackback .comment-meta .comment-metadata .edit-link a:hover, ol.commentlist li.pingback .comment-meta .comment-metadata .edit-link a:hover', 'background', '+2' ),
	array( '.main .content-comments ol.commentlist li.comment, .main .content-comments ol.commentlist li.trackback, .main .content-comments ol.commentlist li.pingback', 'border-color', 'bg' ),
),
	__( 'Background', 'lens' )
);

add_color_rule( 'txt', '#333333', array(
	array( '.masthead .branding h1.logo a, .masthead .branding h2.description, .main article h1.title, h1, h2, h3, h4, h5, h6, #respond h3#reply-title:before', 'color', 'bg' ),
),
	__( 'Site Title and Headlines', 'lens' )
	
);

add_color_rule( 'link', '#c0392b', array(
	array( '.social-links a:before, .masthead .menu li ul, .main .archive-pagination span.current, .screen-reader-shortcut', 'background' ),
	array( 'a,body a:hover, form.searchform button.searchsubmit, .masthead .menu li a, article.post-archive.sticky:before, #respond p.logged-in-as a:hover, .widget.widget_flickr #flickr_badge_uber_wrapper td a, .widget.widget_flickr #flickr_badge_wrapper td a,.masthead .menu li.current-menu-item > a', 'color', 'bg' ),
	array( 'form.searchform button.searchsubmit:hover', 'color', 'bg', '-2' ),
	array( '.masthead .menu li a:hover', 'color', 'bg' ),
	array( '.masthead .menu li.current-menu-item a', 'border-bottom-color', 'bg' ),
	array( '.masthead .menu li ul li', 'border-bottom-color', '-1' ),
	array( '.main .contributor a.contributor-posts-link:hover, ol.commentlist li.comment .reply a:hover, ol.commentlist li.trackback .reply a:hover, ol.commentlist li.pingback .reply a:hover, input[type=submit]:hover, .infinite-scroll #infinite-handle span', 'background-color' ),
	array( '.infinite-scroll #infinite-handle span:hover, ol.commentlist li.comment .reply a, ol.commentlist li.trackback .reply a, ol.commentlist li.pingback .reply a', 'background-color', '-1' ),
),
	array( '.main .contributor a.contributor-posts-link:hover, .main .contributor a.contributor-posts-link, ol.commentlist li.comment .reply a:hover, ol.commentlist li.trackback .reply a:hover, ol.commentlist li.pingback .reply a:hover, .infinite-scroll #infinite-handle span:hover, input[type=submit]:hover', 'border-color', 'bg', '-1' ),
	array( '.infinite-scroll #infinite-handle span, input[type=text]:focus, input[type=password]:focus, input[type=email]:focus, input[type=url]:focus, input.text:focus, textarea:focus, input.settings-input:focus', 'border-color', 'bg' ),
	array( 'ol.commentlist li.comment.bypostauthor, ol.commentlist li.trackback.bypostauthor, ol.commentlist li.pingback.bypostauthor, blockquote', 'border-left-color', 'bg' ),
	array( 'input[type=text]:focus, input[type=password]:focus, input[type=email]:focus, input[type=url]:focus, input.text:focus, textarea:focus, input.settings-input:focus', 'outline-color', 'bg' ),
	array( '.masthead .menu li.page_item_has_children > a:after, .masthead .menu li.menu-item-has-children > a:after, .masthead .menu li ul:before, .masthead .menu li ul li.page_item_has_children > a:after, .masthead .menu li ul li.menu-item-has-children > a:after', 'border-top-color', 'bg' ),
	array( '.masthead .menu li ul li.page_item_has_children > a:after, .masthead .menu li ul li.menu-item-has-children > a:after', 'border-left-color', 'bg' ),	
	__( 'Link and Accent', 'lens' )
);

add_color_rule( 'fg1', '#666666', array(
	array( 'body', 'color', 'bg' ),
	array( '.widget h3.widgettitle span, .widget h3.widgettitle:before', 'color', 'bg' ),
	array( 'ol.commentlist li.comment .comment-meta .comment-metadata a, ol.commentlist li.trackback .comment-meta .comment-metadata a, ol.commentlist li.pingback .comment-meta .comment-metadata a', 'color', 'bg' ),
),
	__( 'Body and Widget Text', 'lens' )
	
);

/* Extra Colors */

add_color_rule( 'extra', '#e6e6e6', array(
	array( '.main article .entry:after', 'background', 'bg' ),	
) );

add_color_rule( 'extra', '#ffffff', array(
	array( '.social-links a:before, .main .archive-pagination span.current, .main .contributor a.contributor-posts-link, .screen-reader-shortcut, .infinite-scroll #infinite-handle span, .masthead .menu li ul li a, .masthead .menu li ul li a:hover, ol.commentlist li.comment .reply a, ol.commentlist li.trackback .reply a, ol.commentlist li.pingback .reply a, ol.commentlist li.comment .reply a:hover, ol.commentlist li.trackback .reply a:hover, ol.commentlist li.pingback .reply a:hover', 'color', 'link' ),
	array( 'ol.commentlist li.comment .comment-meta .comment-metadata .edit-link a, ol.commentlist li.trackback .comment-meta .comment-metadata .edit-link a, ol.commentlist li.pingback .comment-meta .comment-metadata .edit-link a', 'color', 'bg' ),
) );

add_color_rule( 'extra', '#c0392b', array(
	array( '#respond p.logged-in-as a:hover', 'color', 'bg' ),	
) );

add_color_rule ( 'extra', '#000000', array( 
	array( 'form.searchform input.searchfield', 'color', 'bg' ),
) );

/* Additional color palettes */

add_color_palette( array(
    '#594f4f',
    '#dad1c7',
    '#e79382',
    '#f1d4af',
), 'First' );

add_color_palette( array(
    '#003f4c',
    '#f1f5a7',
    '#9ec9ff',
    '#f3e1ec',
), 'Second' );

add_color_palette( array(
    '#618364',
    '#dad1c7',
    '#af7b6e',
    '#f1d4af',
), 'Third' );

add_color_palette( array(
    '#f3e1ec',
    '#4e3780',
    '#b8a9da',
    '#ece5ce',
), 'Fourth' );


/*
 * Extra CSS
 */
add_theme_support( 'custom_colors_extra_css', 'lens_extra_css' );
function lens_extra_css() { ?>
	.main .contributor a.contributor-posts-link:hover,
	ol.commentlist li.comment .reply a:hover,
	ol.commentlist li.trackback .reply a:hover,
	ol.commentlist li.pingback .reply a:hover,
	.infinite-scroll #infinite-handle span:hover,
	.infinite-scroll #infinite-handle span,
	input[type=submit]:hover, ol.commentlist li.comment .reply a, ol.commentlist li.trackback .reply a, ol.commentlist li.pingback .reply a {
	  background-image: none;
	  box-shadow: none;
	}
	.masthead .menu li.page_item_has_children > a:after, .masthead .menu li.menu-item-has-children > a:after {
		border-top-color: inherit;
	}
	.masthead .menu li ul:before {
		border-bottom-color: inherit;
	}
	.masthead .menu li ul li.page_item_has_children > a:after, .masthead .menu li ul li.menu-item-has-children > a:after {
		border-left-color: inherit;
	}
	ol.commentlist li.comment .reply a, ol.commentlist li.trackback .reply a, ol.commentlist li.pingback .reply a {
		border: none;
	}
	.bypostauthor,
	.bypostauthor a {
		color: #666;
	}
	.bypostauthor a:hover,
	ol.commentlist li.comment.bypostauthor .comment-meta .comment-metadata a {
		color: #b3b3b3;
	}
	blockquote p {
		color: inherit;
	}
<?php
}