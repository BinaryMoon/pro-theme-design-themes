<?php
/**
 * Custom header codes
 *
 * @package Lens
 */

/**
 * Custom header image
 */
function lens_custom_header_support() {

	$args = array(
		'default-text-color' => '333333',
		'random-default' => false,
		'width' => 1600,
		'height' => 150,
		'flex-height' => true,
		'header-text' => true,
		'uploads' => true,
		'wp-head-callback' => 'lens_colour_styles',
		'admin-head-callback' => 'lens_admin_head',
		'admin-preview-callback' => 'lens_admin_preview',
	);

	add_theme_support( 'custom-header', apply_filters( 'lens_custom_header', $args ) );

}

add_action( 'after_setup_theme', 'lens_custom_header_support' );


/**
 * Custom header admin styles
 */
function lens_admin_head() {

?>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,700" type="text/css" media="all" />
<style>
	.lens-header-wrapper {
		background:#fff;
		padding:20px 40px;
		font-size:16px;
		line-height:1;
	}
	.lens-header-wrapper h1 {
		margin:0 0 5px 0;
		padding:0;
		font-size:1.2em;
	}
	.lens-header-wrapper h1 a {
		text-decoration:none;
		font-family:'Roboto Slab', "Trebuchet MS", "Lucida Grande", "Lucida Sans Unicode", "Lucida Sans", Tahoma, sans-serif;
		font-weight:700;
		color:#<?php echo esc_attr( get_header_textcolor() ); ?>;
	}
	.lens-header-wrapper #desc {
		font-family:'Roboto Slab', "Trebuchet MS", "Lucida Grande", "Lucida Sans Unicode", "Lucida Sans", Tahoma, sans-serif;
		font-weight:400;
		text-transform:uppercase;
		font-size:0.7em;
		letter-spacing:1px;
		color:#<?php echo esc_attr( get_header_textcolor() ); ?>;
	}
	#headimg {
		background-size:cover;
		background-position:center center;
	}
</style>
<?php
}


/**
 * Custom header admin preview
 */
function lens_admin_preview() {

?>
	<div class="lens-header-wrapper">
		<h1><a id="name" class="displaying-header-text" onclick="return false;" href="#"><?php bloginfo( 'name' ); ?></a></h1>
		<div id="desc" class="displaying-header-text"><?php bloginfo( 'description' ); ?></div>
	</div>
	<div id="headimg" style="background-image:url(<?php echo esc_url( get_header_image() ); ?>); max-width:1600px; height:150px;">
	</div>
<?php

}


/**
 * Print custom header styles
 *
 * @return array
 */
function lens_colour_styles() {

?>
<style>
<?php
	if ( 'blank' === get_header_textcolor() ) {
?>
	.branding { display:none; }
	.masthead .menu {
		width:100%;
		text-align:center;
	}
<?php
	} else {
?>
	.masthead .branding h1.logo a, .masthead .branding h2.description {
		color:#<?php echo esc_attr( get_header_textcolor() ); ?>;
	}
	.branding h1.logo a:hover { color:#<?php echo esc_attr( get_header_textcolor() ); ?>; }
<?php
	}
?>
</style>
<?php

	return true;

}
