<?php
/**
 * Display recent posts (that are normally listed on the homepage)
 *
 * @package Lens
 */

	if ( is_singular() ) {
		$args = array(
			'posts_per_page' => apply_filters( 'lens_more_posts_quantity', 8 ),
			'post__not_in' => array( get_the_ID() ),
			'ignore_sticky_posts' => true,
		);

		$query = new WP_Query( $args );

		if ( $query->have_posts() ) {
?>
	<section id="recent-updates" class="more-posts">
<?php
			while ( $query->have_posts() ) {
				$query->the_post();
				get_template_part( 'content' );
			}
?>
	</section>
<?php
		}

		wp_reset_postdata();
	}
