<?php
/**
 * Post meta data
 *
 * @package Lens
 */

?>
	<p class="postmetadata">
<?php
	printf(
		__( '<em>By</em> <span class="author vcard"><a class="url fn n" href="%5$s" title="%6$s" rel="author">%7$s</a></span><br /> On <a href="%1$s" title="%2$s" rel="bookmark"><time class="entry-date" datetime="%3$s">%4$s</time></a>', 'lens' ),
		esc_url( get_permalink() ),
		esc_attr( get_the_time() ),
		esc_attr( get_the_date( 'c' ) ),
		esc_html( get_the_date() ),
		esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
		esc_attr( sprintf( __( 'View all posts by %s', 'lens' ), get_the_author() ) ),
		get_the_author()
	);

	if ( ! post_password_required() && ( comments_open() || '0' != get_comments_number() ) ) {
?>
	<br /><span class="commentcount"><?php comments_popup_link( esc_html__( 'Leave a comment', 'lens' ), esc_html__( '1 Comment', 'lens' ), esc_html__( '% Comments', 'lens' ) ); ?></span>
<?php
	}
?>
	</p>
