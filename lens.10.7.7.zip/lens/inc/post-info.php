<?php
/**
 * Post information
 *
 * @package Lens
 */

	$image = lens_archive_image( get_the_ID() );

	$style = array();
	if ( $image[0] ) {
		$style[] = 'background-image:url(' . esc_url( $image[0] ) . ');';
	}
?>
	<div class="postinfo">
<?php
	if ( ! empty( $style ) ) {
?>
		<article style="<?php echo esc_attr( implode( ' ', $style ) ); ?>"></article>
<?php
	}
?>
		<div class="meta">
			<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" class="author-avatar">
				<?php echo get_avatar( get_the_author_meta( 'ID' ), 40 ); ?>
			</a>
			<?php get_template_part( 'inc/post-metadata' ); ?>
		</div>

		<nav class="postnav">
			<div class="prev control">
				<?php previous_post_link( '%link', _x( '<span>Previous</span>', 'Previous post link', 'lens' ) ); ?>
			</div>

			<div class="next control">
				<?php next_post_link( '%link', _x( '<span>Next</span>', 'Next post link', 'lens' ) ); ?>
			</div>
		</nav>
<?php
	// Taxonomies for posts and pages.
	if ( 'post' === get_post_type() || 'page' === get_post_type() ) {
?>
		<div class="meta taxonomies">
			<p class="tax-categories taxonomy"><?php the_category( esc_html_x( ', ', 'Tag list seperator', 'lens' ) ); ?></p>
<?php
		// Display tags (if there are any.
		if ( get_the_tags() ) {
			the_tags( '<p class="tax-tags taxonomy">', esc_html_x( ', ', 'Tag list seperator', 'lens' ), '</p>' );
		}
?>
		</div>
<?php
	}

	// Taxonomies for projects.
	if ( 'jetpack-portfolio' === get_post_type() ) {
?>
		<div class="meta taxonomies">
			<p class="tax-categories taxonomy"><?php lens_project_terms_list(); ?></p>
		</div>
<?php
	}
?>
	</div>
