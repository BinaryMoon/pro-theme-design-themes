<?php
/**
 * WordPress.com specific stuff
 *
 * @package Lens
 */

/**
 * Theme Colours.
 */
function lens_theme_colors() {

	global $themecolors;

	/**
	 * Set a default theme color array for WP.com.
	 *
	 * @global array $themecolors
	 */
	if ( ! isset( $themecolors ) ) {
		$themecolors = array(
			'bg' => 'f2f2f2',
			'border' => 'ffffff',
			'text' => '666666',
			'link' => 'c0392b',
			'url' => '999999',
		);
	}

}

add_action( 'after_setup_theme', 'lens_theme_colors' );


/**
 * Dequeue Google Fonts if Custom Fonts are being used instead.
 */
function lens_dequeue_fonts() {

	if ( class_exists( 'TypekitData' ) && class_exists( 'CustomDesign' ) && CustomDesign::is_upgrade_active() ) {
	    $custom_fonts = TypekitData::get( 'families' );

		if ( $custom_fonts && $custom_fonts['headings']['id'] ) {
			wp_dequeue_style( 'lens-roboto-slab' );
	    }

		if ( $custom_fonts && $custom_fonts['body-text']['id'] ) {
			wp_dequeue_style( 'lens-roboto-slab' );
		}
	}

}

add_action( 'wp_enqueue_scripts', 'lens_dequeue_fonts', 11 );
