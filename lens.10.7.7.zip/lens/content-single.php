<?php
/**
 * Single post content
 *
 * @package Lens
 */

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<?php
	the_title( '<h1 class="title">', '</h1>' );
?>
	<section class="entry">
<?php
	the_content();

	edit_post_link();

	wp_link_pages(
		array(
			'before' => '<div class="archive-pagination">' . esc_html__( 'Pages: ', 'lens' ),
			'after'  => '</div>',
			'link_before' => '<span>',
			'link_after'  => '</span>',
		)
	);
?>
	</section>
</article>
