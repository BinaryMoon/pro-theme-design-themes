<?php
/**
 * Generic content
 *
 * @package Lens
 */

	$post_classes = array( 'post-archive' );
	$style = array();
	$category = get_the_category();
	$image = null;
	$section_class = 'excerpt';

	$image = lens_archive_image( get_the_ID() );

	if ( $image[0] ) {
		$style[] = 'background-image:url(' . esc_url( $image[0] ) . ');';
		$post_classes[] = 'has-thumbnail';
		$section_class = 'meta';
	}
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( $post_classes ); ?>>
	<section class="<?php echo esc_attr( $section_class ); ?>">
<?php
	if ( ! empty( $category[0] ) ) {
?>
		<p class="postmetadata">
			<a href="<?php echo esc_url( get_category_link( $category[0]->term_id ) ); ?>">
				<?php echo esc_html( $category[0]->cat_name ); ?>
			</a>
		</p>
<?php
	}
?>
		<h2 class="posttitle">
			<a href="<?php the_permalink() ?>" rel="bookmark">
				<?php the_title(); ?>
			</a>
		</h2>
		<div class="entry"><?php echo get_the_excerpt(); ?></div>
	</section>
<?php
	if ( $image[0] ) {
?>
	<a class="post-image-wrapper" style="<?php echo esc_attr( implode( ' ', $style ) ); ?>" href="<?php the_permalink(); ?>" rel="bookmark">
		<span class="screen-reader"><?php the_title(); ?></span>
	</a>
<?php
	}
?>
</article>
