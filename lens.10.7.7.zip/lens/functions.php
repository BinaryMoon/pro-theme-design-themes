<?php
/**
 * Reusable theme functions
 *
 * @package Lens
 */

load_theme_textdomain( 'lens' );

require 'inc/custom-header.php';
require 'inc/jetpack.php';

// This is the max width - it's the same on all pages.
// Keep in mind the theme is responsive so the width is likely to be narrower.
if ( ! isset( $content_width ) ) {
	$content_width = 695;
}

/**
 * Adjust content width
 *
 * @global int $content_width
 */
function lens_adjust_content_width() {

	global $content_width;

	// Pages don't have sidebars so the content is wider.
	if ( is_page() ) {
		$content_width = 883;
	}

}

add_action( 'template_redirect', 'lens_adjust_content_width' );


/**
 * Enqueue all the styles.
 *
 * @global type $wp_scripts
 */
function lens_enqueue() {

	global $wp_scripts;

	wp_enqueue_style( 'lens-style', get_template_directory_uri() . '/styles/css/styles.css', null, '1.0' );
	wp_enqueue_style( 'genericons', get_template_directory_uri() . '/styles/genericons/genericons.css', array(), '3.0.3' );

	// Fonts.
	$fonts_url = lens_fonts();
	if ( $fonts_url ) {
		wp_enqueue_style( 'lens-fonts', $fonts_url, array(), '1.0' );
	}

	wp_enqueue_script( 'lens-script-main', get_template_directory_uri() . '/js/main.js', array( 'jquery', 'masonry' ), '1.0', false );
	wp_enqueue_script( 'lens-html5shiv', get_template_directory_uri() . '/js/html5.js', null, '1.0', false );
	$wp_scripts->add_data( 'lens-html5shiv', 'conditional', 'lt IE 9' );

	wp_localize_script(
		'lens-script-main',
		'js_i18n',
		array(
			'menu' => esc_html__( 'Menu', 'lens' ),
		)
	);

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

}

add_action( 'wp_enqueue_scripts', 'lens_enqueue' );


/**
 * Set up all the theme properties and extras
 */
function lens_after_setup_theme() {

	load_theme_textdomain( 'lens', get_template_directory() . '/languages' );

	add_theme_support( 'automatic-feed-links' );

	add_theme_support( 'title-tag' );

	add_theme_support( 'post-thumbnails' );

	// Used for attachment (image.php) page links.
	add_image_size( 'lens-attachment', 120, 120, true );
	add_image_size( 'lens-archive', 440, 440, true );
	add_image_size( 'lens-header', 1600, 500, true );
	add_image_size( 'lens-logo', 120, 80, true );

	// Custom background.
	add_theme_support( 'custom-background' );

	// HTML5 ftw.
	add_theme_support( 'html5', array( 'comment-list', 'search-form', 'comment-form' ) );

	register_nav_menu( 'top_menu', __( 'Top Menu', 'lens' ) );

	// Site logo.
	add_theme_support(
		'site-logo',
		array(
			'size' => 'lens-logo',
		)
	);

	// Add support for full width images and other content such as videos.
	add_theme_support( 'align-wide' );

	// Disable custom font sizes, ensuring consistent vertical rhythm.
	add_theme_support( 'disable-custom-font-sizes' );

	// Make Gutenberg embeds responsive.
	add_theme_support( 'responsive-embeds' );

	// Editor font sizes.
	// Uses the default slugs to ensure consistency across themes.
	add_theme_support(
		'editor-font-sizes',
		array(
			array(
				'name' => esc_html__( 'small', 'lens' ),
				'size' => 13,
				'slug' => 'small',
			),
			array(
				'name' => esc_html__( 'normal', 'lens' ),
				'size' => 16,
				'slug' => 'normal',
			),
			array(
				'name' => esc_html__( 'medium', 'lens' ),
				'size' => 20,
				'slug' => 'medium',
			),
			array(
				'name' => esc_html__( 'large', 'lens' ),
				'size' => 36,
				'slug' => 'large',
			),
			array(
				'name' => esc_html__( 'huge', 'lens' ),
				'size' => 42,
				'slug' => 'huge',
			),
		)
	);

	// Add support for editor styles.
	add_theme_support( 'editor-styles' );

	// Editor Style.
	$fonts_url = lens_fonts();

	if ( $fonts_url ) {
		add_editor_style( $fonts_url );
	}

	add_editor_style( 'styles/css/editor-styles.css' );

}


/**
 * Get url for Google fonts.
 */
function lens_fonts() {

	/**
	 * Translators: If there are characters in your language that are not
	 * supported, translate this to 'off'. Do not translate into your
	 * own language.
	 */
	$font = _x( 'on', 'Roboto Slab: on or off', 'lens' );
	if ( 'off' !== $font ) {
		$fonts['robot-slab'] = 'Roboto Slab:300,700';
	}

	$fonts = apply_filters( 'lens_fonts', $fonts );

	if ( $fonts ) {

		$query_args = array(
			'family' => rawurlencode( implode( '|', $fonts ) ),
			'subset' => rawurlencode( 'latin,latin-ext' ),
			'display' => 'swap',
		);

		return add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );

	}

}


/**
 * Register sidebars
 */
function lens_widgets_init() {

	// Sidebar.
	register_sidebar(
		array(
			'name' => esc_html__( 'Sidebar Widgets', 'lens' ),
			'id' => 'sidebar-1',
			'description' => esc_html__( 'Widgets that display on the right hand side of your website', 'lens' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h3 class="widgettitle"><span>',
			'after_title' => '</span></h3>',
		)
	);

	// Footer widgets.
	register_sidebar(
		array(
			'name' => esc_html__( 'Footer Widgets', 'lens' ),
			'id' => 'sidebar-2',
			'description' => esc_html__( 'Widgets that display at the bottom of your website', 'lens' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h3 class="widgettitle"><span>',
			'after_title' => '</span></h3>',
		)
	);

}

add_action( 'widgets_init', 'lens_widgets_init' );



/**
 * Enqueue WordPress theme styles within Gutenberg.
 */
function lens_editor_blocks_styles() {

	// Load the additional editor styles.
	// This covers things like the editor title that can't be styled with the normal editor styles.
	wp_enqueue_style( 'lens-editor-blocks', get_theme_file_uri( '/styles/css/editor-blocks.css' ), null, '1' );

	/**
	 * Overwrite Core theme styles with empty styles.
	 * @see https://github.com/WordPress/gutenberg/issues/7776#issuecomment-406700703
	 */
	wp_deregister_style( 'wp-block-library-theme' );
	wp_register_style( 'wp-block-library-theme', '' );

}

add_action( 'enqueue_block_editor_assets', 'lens_editor_blocks_styles' );
add_action( 'enqueue_block_assets', 'lens_editor_blocks_styles' );


/**
 * Custom excerpt length.
 *
 * @param int $length Default excerpt length.
 * @return int
 */
function lens_excerpt_length( $length ) {

	// Cos there's not much space for excerpts, reduce the length if the title is long.
	$title_length = strlen( get_the_title() );

	if ( $title_length > 50 ) {
		return 10;
	}

	return 30;

}


/**
 * Add nav id to menus
 *
 * @param string $ulclass Menu html.
 * @return string
 */
function lens_add_menu_class( $ulclass ) {

	return preg_replace( '/<ul>/', '<ul id="nav">', $ulclass, 1 );

}


/**
 * Numeric pagination for custom queries
 * Much nicer than next and previous links :)
 *
 * @global object $wp_query
 * @param int    $page_count Number of pages to display.
 * @param object $query Possible existing WordPress query.
 * @return void
 */
function lens_numeric_pagination( $page_count = 9, $query = null ) {

	if ( null === $query ) {
		global $wp_query;
		$query = $wp_query;
	}

	if ( 1 >= $query->max_num_pages ) {
		return;
	}

	$big = 9999999999; // Need an unlikely integer.

	echo '<div class="archive-pagination pagination">';
	echo paginate_links(
		array(
			'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
			'format' => '?paged=%#%',
			'current' => max( 1, get_query_var( 'paged' ) ),
			'total' => $query->max_num_pages,
			'end_size' => 0,
			'mid_size' => $page_count,
			'next_text' => esc_html__( 'Older &rsaquo;', 'lens' ),
			'prev_text' => esc_html__( '&lsaquo; Newer', 'lens' ),
		)
	);
	echo '</div>';

}


/**
 * Add additional body classes that may be helpful
 *
 * @param array $styles List of current body class styles.
 * @return array
 */
function lens_body_class( $styles ) {

	if ( is_singular() ) {
		$styles[] = 'singular';
	}

	return $styles;

}


/**
 * Display site header
 * Uses featured image on pages that have a large enough featured image set
 */
function lens_header() {

	// Default header image.
	$header_image = get_header_image();
	$header_image_width = get_theme_support( 'custom-header', 'width' );
	$header_image_actual_width = get_custom_header()->width;
	$header_image_actual_height = get_custom_header()->height;

	// Use custom headers on pages, but only if the image is large enough.
	if ( is_page() ) {
		$image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'lens-header' );
		if ( ! empty( $image ) && $image[1] >= $header_image_width ) {
			$header_image = esc_url( $image[0] );
			$header_image_actual_width = (int) $image[1];
			$header_image_actual_height = (int) $image[2];
		}
	}

	if ( ! empty( $header_image ) ) {
?>
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home" id="header-image">
			<img src="<?php echo esc_url( $header_image ); ?>" width="<?php echo (int) $header_image_actual_width; ?>" height="<?php echo (int) $header_image_actual_height; ?>" alt="" />
		</a>
<?php
	}

}


/**
 * Get archive image.
 *
 * @param  int    $post_id        ID of post that we want to get the featured image from.
 * @param  string $thumbnail_size Name of thumbnail size.
 * @return string|false
 */
function lens_archive_image( $post_id, $thumbnail_size = 'lens-archive' ) {

	$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post_id ), $thumbnail_size );

	// If there's no featured image then grab an attachment image and use that instead.
	if ( ! $image[0] ) {

		$values = get_attached_media( 'image', $post_id );

		if ( $values ) {
			foreach ( $values as $child_id => $attachment ) {
				$image = wp_get_attachment_image_src( $child_id, $thumbnail_size );
				break;
			}
		}
	}

	if ( $image ) {
		return $image;
	}

	return false;

}


/**
 * Display a list of all of the project categories for the current project
 */
function lens_project_terms_list() {

	$terms = wp_get_post_terms( get_the_ID(), 'jetpack-portfolio-type' );

	if ( $terms ) {

		$count = 0;

		foreach ( $terms as $t ) {
			if ( $count > 0 ) {
				echo esc_html_x( ', ', 'Tag list seperator', 'lens' );
			}
?>
		<a href="<?php echo esc_url( get_term_link( $t ) ); ?>"><?php echo esc_html( $t->name ); ?></a>
<?php
			$count ++;

		}
	}

}


add_action( 'after_setup_theme', 'lens_after_setup_theme' );

add_filter( 'body_class', 'lens_body_class' );
add_filter( 'use_default_gallery_style', '__return_false' );
add_filter( 'excerpt_length', 'lens_excerpt_length', 999 );
add_filter( 'wp_page_menu', 'lens_add_menu_class' );
