<?php
/**
 * Sidebar template
 *
 * @package Lens
 */

	if ( is_single() ) {
?>
<div class="col-sidebar">
<?php
		if ( ! is_attachment() ) {
			get_template_part( 'inc/post-info' );
		}
		if ( is_active_sidebar( 'sidebar-1' ) ) {
			do_action( 'before_sidebar' );
			dynamic_sidebar( 'sidebar-1' );
		}
?>
</div>
<?php
	}
