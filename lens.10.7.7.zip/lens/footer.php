<?php
/**
 * Theme Footer
 *
 * @package Lens
 */

?>
	</div>
	<?php get_sidebar(); ?>
</div><!--/container-->
<?php
	// Display list of recent posts, mirroring the archive layout.
	get_template_part( 'inc/posts-more' );
?>
<footer role="contentinfo" id="footer">
<?php
	if ( is_active_sidebar( 'sidebar-2' ) ) {
?>
	<aside class="footer-widgets">
		<?php dynamic_sidebar( 'sidebar-2' ); ?>
	</aside>
<?php
	}
?>
	<section class="footer-wrap">
<?php
	lens_social_links();

	if ( function_exists( 'the_privacy_policy_link' ) ) {
		the_privacy_policy_link( '', '<span class="sep"> | </span>' );
	}
?>
	<a href="http://wordpress.org/" title="<?php esc_attr_e( 'A Semantic Personal Publishing Platform', 'lens' ); ?>" rel="generator"><?php printf( esc_html__( 'Proudly powered by %s', 'lens' ), 'WordPress' ); ?></a>
	<span class="sep"> | </span>
	<?php printf( esc_html__( 'Theme: %1$s by %2$s.', 'lens' ), 'Lens', '<a href="https://prothemedesign.com/" rel="designer">Pro Theme Design</a>' ); ?>
	</section>
</footer>

<?php wp_footer(); ?>

</body>
</html>
