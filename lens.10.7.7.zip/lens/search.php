<?php
/**
 * Search results template
 *
 * @package Lens
 */

	get_header();

	if ( have_posts() ) {
?>
	<div id="main-content">

		<h1 class="title">
<?php
	printf(
		wp_kses(
			/* Translators: %s: Search query */
			__( 'Search results for &#8216;<em>%s</em>&#8217;', 'lens' ),
			array(
				'em' => array(),
			)
		),
		esc_html( get_search_query() )
	);
?>
		</h1>

<?php
		while ( have_posts() ) {
			the_post();
			get_template_part( 'content' );
		}

		lens_numeric_pagination();
?>
	</div>
<?php
	} else {
?>
	<article class="page-404">
		<h1 class="title"><?php esc_html_e( 'No search results', 'lens' ); ?></h1>
		<p><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'lens' ); ?></p>
		<?php get_search_form(); ?>
	</article>
<?php
	}

	get_footer();

