<?php
/**
 * Archive Template
 *
 * @package Lens
 */

	get_header();

	if ( have_posts() ) {

		if ( is_category() ) {

			$title = single_cat_title( '', false );

		} elseif ( is_tag() ) {

			$title = single_tag_title( '', false );

		} elseif ( is_author() ) {

			/* Translators: %s: Author name in author archives */
			$title = sprintf( esc_html__( 'Author: %s', 'lens' ), '<span class="vcard">' . get_the_author() . '</span>' );

		} elseif ( is_day() ) {

			/* Translators: %s: Date name in daily archives */
			$title = sprintf( esc_html__( 'Day: %s', 'lens' ), '<span>' . get_the_date() . '</span>' );

		} elseif ( is_month() ) {

			/* Translators: %s: Month name in monthly archives */
			$title = sprintf( esc_html__( 'Month: %s', 'lens' ), '<span>' . get_the_date( _x( 'F Y', 'monthly archives date format', 'lens' ) ) . '</span>' );

		} elseif ( is_year() ) {

			/* Translators: %s: Year in yearly archives */
			$title = sprintf( esc_html__( 'Year: %s', 'lens' ), '<span>' . get_the_date( _x( 'Y', 'yearly archives date format', 'lens' ) ) . '</span>' );

		} elseif ( is_tax( 'post_format', 'post-format-aside' ) ) {

			$title = esc_html__( 'Asides', 'lens' );

		} elseif ( is_tax( 'post_format', 'post-format-gallery' ) ) {

			$title = esc_html__( 'Galleries', 'lens' );

		} elseif ( is_tax( 'post_format', 'post-format-image' ) ) {

			$title = esc_html__( 'Images', 'lens' );

		} elseif ( is_tax( 'post_format', 'post-format-video' ) ) {

			$title = esc_html__( 'Videos', 'lens' );

		} elseif ( is_tax( 'post_format', 'post-format-quote' ) ) {

			$title = esc_html__( 'Quotes', 'lens' );

		} elseif ( is_tax( 'post_format', 'post-format-link' ) ) {

			$title = esc_html__( 'Links', 'lens' );

		} elseif ( is_tax( 'post_format', 'post-format-status' ) ) {

			$title = esc_html__( 'Statuses', 'lens' );

		} elseif ( is_tax( 'post_format', 'post-format-audio' ) ) {

			$title = esc_html__( 'Audios', 'lens' );

		} elseif ( is_tax( 'post_format', 'post-format-chat' ) ) {

			$title = esc_html__( 'Chats', 'lens' );

		} elseif ( is_tax() ) {

			$title = single_term_title( '', false );

		} elseif ( is_post_type_archive() ) {

			$title = post_type_archive_title( '', false );

		} else {

			$title = esc_html__( 'Archives', 'lens' );

		} // End if().
?>
	<h1 class="title"><?php echo $title; ?></h1>
<?php
		the_archive_description( '<div class="category-description">', '</div>' );
?>
	<div id="main-content" class="more-posts">
<?php
		while ( have_posts() ) {
			the_post();
			get_template_part( 'content' );
		}

		lens_numeric_pagination();
?>
	</div>
<?php
	} else {
?>
	<div id="main-content" class="main-content">
<?php
		get_template_part( 'content-empty' );
?>
	</div>
<?php
	} // End if().

	get_footer();
