=== Lens ===

Contributors: binarymoon
Requires at least: 4.1
Tested up to: 4.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: gray, silver, white, light, two-columns, right-sidebar, responsive-layout, custom-background, custom-colors, custom-header, custom-menu, featured-images, featured-image-header, flexible-header, full-width-template, infinite-scroll, rtl-language-support, sticky-post, theme-options, translation-ready, art, artwork, craft, design, fashion, food, gaming, photoblogging, photography, bright, clean, conservative, contemporary, elegant, formal, geometric, industrial, light, minimal, modern, professional, simple, tech, site-logo

== Description ==

Lens is a photo-oriented theme, great for people who like to tell stories with pictures.

[Theme documentation](https://prothemedesign.com/documentation/theme/lens/)

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Lens includes support for [Styleguide](https://wordpress.org/plugins/styleguide/) - a plugin that allows you to change fonts, and colours in WordPress themes.

Lens includes support for most features in [Jetpack](https://wordpress.org/plugins/jetpack/), including Infinite Scroll, Featured Content, and Site Logo.

== Changelog ==

= 10.7.7 - 2nd April 2021 =
* Fix text input width.

= 10.7.6 - 16th March 2021 =
* Ensure menu is readable on mobile devices.

= 10.7.5 - 31st January 2021 =
* Clear html widget to prevent floated content from breaking the layout.

= 10.7.4 - 21st January 2021 =
* Fix issue with full width content on mobile devices.

= 10.7.3 - 2nd January 2021 =
* Fix sub menu link colours on mobile devices.

= 10.7.2 - 5th October 2020 =
* Add support for wp_body_open.

= 10.7.1 - 11th July 2020 =
* Fix infinite scroll button styles.

= 10.7 - 18th March 2020 =
* Add support for Gutenberg.
* Improve coding standards.

= 10.6.1 - 24th May 2019 =
* Improve archive display on touch devices.

= 10.6 - 21st May 2019 =
* Improve behaviour of dropdown menus on touch devices.
* Improve menu design on small screens.
* Tweak whitespace on small screens to make the layout more consistent.

= 10.5 - 18th March 2019 =
* Improve mobile layout.
* Reduce browser prefixes.

= 10.4 - 3rd September 2018 =
* Tweak styles to improve readability.

= 10.3 - 25th May 2018 =
* Add support for privacy policy link in the site footer.
* Fix display of the cookie consent checkbox in the comments form.

= 10.2.4 - Star Wars Day 2018 =
* Fix bug with image overlays in mobile Safari.
* Improve responsive design.
* Switch profile url to https.

= 10.2.3 - 28th January 2018 =
* Improve css browser prefixes.

= 10.2.2 - 13th July 2017 =
* Remove include for inc/wpcom.php, since it's automatically included by WordPress.com sites

= 10.2.1 - 14th March 2017 =
* Tidy all the codes to improve coding standards and sanitize more strings for extra security.

= 10.2 - 7th October 2016 =
* Lots of code tidying, standards improvements, and security enhancements.
* Tweak word wrap settings in widgets
* tweak spacings and padding to improve readability and layout.

= 10.1.5 =
* Reduce the width of the dropdown menus slightly

= 10.1.4 =
* Stop loading responsive-nav.js to remove 404 error
* tidy html
* set min-heights for socialmedia widgets so that they work better in masonry footer

= 10.1.3 =
* Fix issue with image attachment template

= 10.1.2 =
* make the post archive boxes a proportional size rather than an absolute pixel value. Means the boxes remain square

= 10.1.1 =
* remove title filter that is no longer needed now we're using add_theme_support(title-tag)

= 10.1 =
* add post categories to projects
* tidy up some of the sidebar code
* make the next and previous post links easier to click on single post pages

= 10 =
* major version bump. This is purely so that the theme version does not clash with the free theme of the same name available on wordpress.org

= 1.1 =
* change responsive menu to use a more modern style and rely less on javascript - removes responsive-navigation.js
* tweaks to responsive sizes so that things look nicer on a wider variety of screen sizes

= 1.0.2 =
* improve responsive styles for homepage and archive pages
* improve css support for more of the default widgets found in Jetpack & on wordpress.com

= 1.0.1 =
* make comments show the short_ping format again - it was changed in core so that a different layout is used by default
* switch to using add_theme_support(title-tag)
* css improvements

= 1.0 =
* Initial release

== Credits ==

* [Roboto Slab](https://www.google.com/fonts/specimen/Roboto+Slab) Font from Google Fonts, licensed under [Apache License, version 2.0](http://www.apache.org/licenses/LICENSE-2.0.html)
* [HTML5 Shiv](https://github.com/afarkas/html5shiv) Javascript fallback for missing HTML5 elements, licensed under [GPL2](https://www.gnu.org/licenses/gpl-2.0.html)
* Genericons: font by Automattic (http://automattic.com/), licensed under [GPL2](https://www.gnu.org/licenses/gpl-2.0.html)
