<?php
/**
 * Header Template
 *
 * @package Lens
 */

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta http-equiv="Content-Type" content="<?php bloginfo( 'html_type' ); ?>; charset=<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<?php wp_body_open(); ?>

	<a href="#main-content" class="screen-reader-shortcut"><?php esc_html_e( 'Skip to content', 'lens' ); ?></a>
	<header class="masthead" role="banner">
		<?php do_action( 'before' ); ?>
		<div class="branding">
			<?php if ( function_exists( 'jetpack_the_site_logo' ) ) { jetpack_the_site_logo(); } ?>
			<h1 class="logo">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php esc_attr_e( 'Home', 'lens' ); ?>">
					<?php bloginfo( 'name' ); ?>
				</a>
			</h1>
			<h2 class="description">
				<?php bloginfo( 'description' ); ?>
			</h2>
		</div>
		<nav class="menu" role="navigation">
			<h3 class="menu-toggle"><?php esc_html_e( 'Menu', 'lens' ); ?></h3>
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'top_menu',
					'menu_id' => 'nav',
					'menu_class' => 'menu-wrap clearfix'
				)
			); ?>
		</nav>
	</header>
<?php
	lens_header();
?>
	<div class="container hfeed">
		<div class="main">
