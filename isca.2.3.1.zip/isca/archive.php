<?php
/**
 * List content archive
 *
 * @package Isca
 */

get_header();

if ( have_posts() ) {

	if ( is_category() ) {
?>
		<h1 class="pagetitle"><?php single_cat_title(); ?></h1>

<?php
	} elseif ( is_tag() ) {
?>

		<h1 class="pagetitle"><?php printf( __( 'Tag Archive for &#8216;%s&#8217;', 'isca' ), single_tag_title( '', false ) ); ?></h1>

<?php
	} elseif ( is_day() ) {
?>

		<h1 class="pagetitle"><?php printf( __( 'Archive for %s', 'isca' ), get_the_time( 'F jS, Y' ) ); ?></h1>

<?php
	} elseif ( is_month() ) {
?>
		<h1 class="pagetitle"><?php printf( __( 'Archive for %s', 'isca' ), get_the_time( 'F Y' ) ); ?></h1>

<?php
	} elseif ( is_year() ) {
?>

		<h1 class="pagetitle"><?php printf( __( 'Archive for %s', 'isca' ), get_the_time( 'Y' ) ); ?></h1>

<?php
	} elseif ( isset( $_GET['paged'] ) && ! empty( $_GET['paged'] ) ) {
?>

		<h1 class="pagetitle"><?php _e( 'Blog Archives', 'isca' ); ?></h1>

<?php

	}

	the_archive_description( '<div class="category_description">', '</div>' );

	while ( have_posts() ) {
		the_post();
		get_template_part( 'content-loop' );
	}

	the_posts_pagination(
		array(
			'mid_size' => 2,
			'next_text' => esc_html__( 'Older &rsaquo;', 'isca' ),
			'prev_text' => esc_html__( '&lsaquo; Newer', 'isca' ),
		)
	);

} else {

?>
	<h2><?php esc_html_e( 'Not Found', 'isca' ); ?></h2>
<?php
}

get_footer();
