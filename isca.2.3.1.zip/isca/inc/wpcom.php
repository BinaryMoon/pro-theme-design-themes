<?php
/**
 * WP.com theme stuff
 *
 * @package Isca
 */
global $themecolors, $content_width;


function isca_set_themecolors() {
	global $themecolors;
	$themecolors = array(
		'bg'     => 'ffffff',
		'border' => 'eeeeee',
		'text'   => '1B1B1B',
		'link'   => '3399CC',
		'url'    => '59BCED',
	);
}
add_action( 'after_setup_theme', 'isca_set_themecolors' );
