<?php

/**
 * Isca: Color Annotations
 */


/*
 * Background.
 * This includes the colored band at the top of the site and the footer.
 */

add_color_rule( 'bg', '#E9E6E0', array(
	array( 'body', 'background-color' ),
), __( 'Primary Background' ) );


/*
 * Secondary Background.
 * 1. Colored band at the top of the theme.
 * 2. Footer.
 */

add_color_rule( 'fg1', '#293033', array(
	array( '#masthead', 'background-color' ),
	array( '#masthead', 'border-bottom-color', '-1' ),
	array( '.site-footer', 'background-color' ),
	array( '.site-footer .milestone-header', 'background-color', '-1' ),
), __( 'Secondary Background' ) );
add_color_rule( 'extra', '#bcb9b3', array(
	array( '#nav-primary li a',      'color', 'fg1' ),
	array( '#nav-primary a:hover',   'color', 'fg1' ),
	array( '#nav-primary a:active',  'color', 'fg1' ),
	array( '#nav-primary a:visited', 'color', 'fg1' ),
	array( '#nav-primary a:focus',   'color', 'fg1' ),
) );
add_color_rule( 'extra', '#666', array(
	array( '.nav a.has-children:after', 'border-top-color', 'fg1' ),
) );
add_color_rule( 'extra', '#a0a0a0', array(
	array( '.site-footer', 'color', 'fg1' ),
) );
add_color_rule( 'extra', '#000', array(
	array( '.site-footer .milestone-header .date',  'color', 'fg1' ),
	array( '.site-footer .milestone-header .event', 'color', 'fg1' ),
) );
add_color_rule( 'extra', '#f7f7f7', array(
	array( '.site-footer h4.widgettitle', 'color', 'fg1' ),
) );
add_color_rule( 'extra', '#363636', array(
	array( '.site-footer h4.widgettitle', 'border-bottom-color', 'fg1' ),
) );
add_color_rule( 'extra', '#ddd', array(
	array( '.site-footer a',         'color', 'fg1' ),
	array( '.site-footer a:hover',   'color', 'fg1' ),
	array( '.site-footer a:active',  'color', 'fg1' ),
	array( '.site-footer a:visited', 'color', 'fg1' ),
	array( '.site-footer a:focus',   'color', 'fg1' ),
	array( '.site-footer .widget li a',         'color', 'fg1' ),
	array( '.site-footer .widget li a:hover',   'color', 'fg1' ),
	array( '.site-footer .widget li a:active',  'color', 'fg1' ),
	array( '.site-footer .widget li a:visited', 'color', 'fg1' ),
	array( '.site-footer .widget li a:focus',   'color', 'fg1' ),
) );
add_color_rule( 'extra', '#cdcbc5', array(
	array( '.site-footer aside .widget li',    'border-bottom-color', 'fg1' ),
	array( '.site-footer #recent-excerpts li', 'border-bottom-color', 'fg1' ),
	array( '.site-footer #related-posts',      'border-bottom-color', 'fg1' ),
) );


/*
 * Links.
 */
add_color_rule( 'fg2', '#E65A1E', array(

	array( '.content_row table a',         'color', '#f3f3f3', '2' ),
	array( '.content_row table a:hover',   'color', '#f3f3f3', '2' ),
	array( '.content_row table a:active',  'color', '#f3f3f3', '2' ),
	array( '.content_row table a:visited', 'color', '#f3f3f3', '2' ),
	array( '.content_row table a:focus',   'color', '#f3f3f3', '2' ),

	array( '.nav a',         'color', '#fff', '2' ),
	array( '.nav a:hover',   'color', '#fff', '2' ),
	array( '.nav a:active',  'color', '#fff', '2' ),
	array( '.nav a:visited', 'color', '#fff', '2' ),
	array( '.nav a:focus',   'color', '#fff', '2' ),

	array( '#sidebar a',         'color', '#fff', '2' ),
	array( '#sidebar a:hover',   'color', '#fff', '2' ),
	array( '#sidebar a:active',  'color', '#fff', '2' ),
	array( '#sidebar a:visited', 'color', '#fff', '2' ),
	array( '#sidebar a:focus',   'color', '#fff', '2' ),

	array( 'a.post-edit-link',  'color', '#f3f3f3', '2' ),
	array( '.posttitle a:hover',  'color', '#fff', '2' ),
	array( '.posttitle a:active', 'color', '#fff', '2' ),
	array( '.posttitle a:focus',  'color', '#fff', '2' ),

	array( '.hentry a',         'color', '#fff', '2' ),
	array( '.hentry a:hover',   'color', '#fff', '2' ),
	array( '.hentry a:active',  'color', '#fff', '2' ),
	array( '.hentry a:visited', 'color', '#fff', '2' ),
	array( '.hentry a:focus',   'color', '#fff', '2' ),

	array( '.content_row table a',         'color', '#f3f3f3', '2' ),
	array( '.content_row table a:hover',   'color', '#f3f3f3', '2' ),
	array( '.content_row table a:active',  'color', '#f3f3f3', '2' ),
	array( '.content_row table a:visited', 'color', '#f3f3f3', '2' ),
	array( '.content_row table a:focus',   'color', '#f3f3f3', '2' ),

	array( '.commentcount a',         'color', '#fff', '2' ),
	array( '.commentcount a:hover',   'color', '#fff', '2' ),
	array( '.commentcount a:active',  'color', '#fff', '2' ),
	array( '.commentcount a:visited', 'color', '#fff', '2' ),
	array( '.commentcount a:focus',   'color', '#fff', '2' ),

	array( '#comments a',         'color', '#fff', '2' ),
	array( '#comments a:hover',   'color', '#fff', '2' ),
	array( '#comments a:active',  'color', '#fff', '2' ),
	array( '#comments a:visited', 'color', '#fff', '2' ),
	array( '#comments a:focus',   'color', '#fff', '2' ),

	array( '.commentlist a',         'color', '#fff', '2' ),
	array( '.commentlist a:hover',   'color', '#fff', '2' ),
	array( '.commentlist a:active',  'color', '#fff', '2' ),
	array( '.commentlist a:visited', 'color', '#fff', '2' ),
	array( '.commentlist a:focus',   'color', '#fff', '2' ),
), __( 'Links' ) );


/*
 * Sidebar Widget Headings.
 */
add_color_rule( 'link', '#6e6b60', array(
	array( '#sidebar aside h3.widgettitle', 'background' ), // We need to override the entire background group here due to use of gradients.
	array( '#sidebar aside h3.widgettitle:before', 'border-top-color' ),
), __( 'Sidebar Widget Headings' ) );

add_color_rule( 'extra', '#fff', array(
	array( '#sidebar aside h3.widgettitle', 'color', 'link' ),
) );

/*
 * Unused.
 */
add_color_rule( 'txt', '#FFFFFF', array() );


/*
 * Custom Styles.
 */
function themename_extra_css() { ?>
	#sidebar aside h3.widgettitle {
		text-shadow: none;
	}
	.site-footer .wp-caption-text {
		color: #000;
	}
	.hentry .posttitle a:link,
	.hentry .posttitle a:visited,
	.hentry .more-link,
	.hentry .more-link:hover,
	.hentry .more-link:active,
	.hentry .more-link:visited,
	.hentry .more-link:focus,
	.hentry .more-link a,
	.hentry .more-link a:hover,
	.hentry .more-link a:active,
	.hentry .more-link a:visited,
	.hentry .more-link a:focus,
	.hentry .post-taxonomies,
	.hentry .post-taxonomies a:hover,
	.hentry .post-taxonomies a:active,
	.hentry .post-taxonomies a:visited,
	.hentry .post-taxonomies a:focus,
	.commentlist .commentmetadata a,
	.commentlist .commentmetadata a:hover,
	.commentlist .commentmetadata a:active,
	.commentlist .commentmetadata a:visited,
	.commentlist .commentmetadata a:focus {
		color: #282828;
	}
	article.sticky.post {
		background-color: #f5f5f5;
		border-color: #e5e5e5;
	}
	a.more-link,
	a.more-link:visited,
	.more-link a,
	.more-link:visited a {
		background:#e9e9e9;
	}
	a.more-link:hover,
	a.more-link:active,
	.more-link:hover a,
	.more-link:active a {
		background: #dcdcdc;
	}
<?php
}
add_theme_support( 'custom_colors_extra_css', 'themename_extra_css' );
