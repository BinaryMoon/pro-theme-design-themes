<?php
/**
 * Display the Chat post format
 *
 * @package Isca
 */
?>
<div class="entry">
	<?php the_content(); ?>
</div>