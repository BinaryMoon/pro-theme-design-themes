<?php
/**
 * Display the Aside post format
 *
 * @package Isca
 */

?>
<div class="entry">
<?php
	the_content();
?>
</div>
