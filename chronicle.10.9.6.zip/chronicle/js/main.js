/**
 * main.js v1
 * Created by Ben Gillbanks <https://prothemedesign.com/>
 * Available under GPL2 license
 */

;( function( $ ) {

	$( document ).ready( function() {

		// Improve social menu in responsive situations

		// Uses jquery to duplicate social menu to avoid redundant markup
		var social_menu = $( 'nav.menu-primary .social_links a' ).clone();

		social_menu.insertBefore( 'nav.menu-primary .menu-wrap' )
			.wrapAll( '<div class="social_links" aria-hidden="true"></div>' );

	});

})( jQuery );