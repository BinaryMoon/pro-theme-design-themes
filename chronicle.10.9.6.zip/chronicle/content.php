<?php
/**
 * Generic content
 *
 * @package Chronicle
 */

	global $content_width;

	$thumbnail = 'chronicle-archive';

	if ( $content_width > 800 || is_archive() ) {
		$thumbnail = 'chronicle-archive-large';
	}

	if ( get_theme_mod( 'chronicle_post_archive_layout', 0 ) > 0 ) {
		$thumbnail = 'chronicle-feature';
	}

	$image = get_the_post_thumbnail( get_the_ID(), $thumbnail );

	$class = array(
		'post-archive',
		$thumbnail,
	);

	if ( $image ) {
		$class[] = 'has-post-thumbnail';
	}
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( $class ); ?>>
<?php
	if ( $image ) {
?>
	<a href="<?php echo esc_url( get_permalink() ); ?>" class="thumbnail">
		<?php echo $image; ?>
	</a>
<?php
	}
?>
	<section class="entry">
<?php
	if ( get_the_title() ) {
?>
	<h2 class="posttitle">
		<a href="<?php the_permalink() ?>" rel="bookmark">
			<?php the_title(); ?>
		</a>
	</h2>
<?php
	}

	get_template_part( 'inc/post-metadata' );

	the_excerpt();
?>
	</section>
</article>
