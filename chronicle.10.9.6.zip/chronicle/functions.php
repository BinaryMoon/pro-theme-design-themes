<?php
/**
 * Reusable theme functions
 *
 * @package Chronicle
 */

include( 'inc/customizer.php' );

// Keep in mind the theme is responsive so the width is likely to be narrower.
if ( ! isset( $content_width ) ) {
	$content_width = 890;
}

/**
 * Work out content_width
 *
 * @global int $content_width
 */
function chronicle_adjust_content_width() {

	global $content_width;

	if ( is_page_template( 'custom-templates/full-width.php' ) ) {
		$content_width = 1250;
	} else {

		// Slightly unusual technique here
		// but it's a simpler method than calculating the different combinations of sidebars.
		if ( ! is_active_sidebar( 'sidebar-1' ) ) {
			$content_width += 320;
		}

		if ( ! is_active_sidebar( 'sidebar-3' ) ) {
			$content_width += 220;
		}
	}

}

add_action( 'template_redirect', 'chronicle_adjust_content_width' );


/**
 * Enqueue all the styles, and dequeue the styles we no longer need.
 *
 * @global type $wp_scripts
 */
function chronicle_enqueue() {

	wp_dequeue_style( 'broadsheet-style-neuton' );

	// Fonts.
	$fonts_url = chronicle_fonts();
	if ( $fonts_url ) {
		wp_enqueue_style( 'chronicle-fonts', $fonts_url, array(), '1.0' );
	}

	// Javascripts.
	wp_enqueue_script( 'chronicle-script-main', get_stylesheet_directory_uri() . '/js/main.js', array( 'jquery' ), '1.0', false );

}

add_action( 'wp_enqueue_scripts', 'chronicle_enqueue', 20 );


/**
 * Change the default header colour.
 *
 * @param string $color The current colour.
 * @return string
 */
function chronicle_header_textcolor( $color ) {

	return '000';

}

add_filter( 'broadsheet_header_textcolor', 'chronicle_header_textcolor' );


/**
 * Change the default background colour.
 *
 * @param string $color The current colour.
 * @return string
 */
function chronicle_background_color( $color ) {

	return 'f2f2f2';

}

add_filter( 'broadsheet_background_color', 'chronicle_background_color' );


/**
 * Change the header image width.
 *
 * @param int $width The current width of the header image.
 * @return int
 */
function chronicle_header_width( $width ) {

	return 1250;

}

add_filter( 'broadsheet_header_width', 'chronicle_header_width' );


/**
 * Add new image size for featured content
 */
function chronicle_after_setup_theme() {

	load_theme_textdomain( 'chronicle', get_template_directory() . '/languages' );

	add_image_size( 'chronicle-feature', 300, 200, true );
	add_image_size( 'chronicle-archive', 930, 500, true );
	add_image_size( 'chronicle-archive-large', 1250, 600, true );

	// Editor font sizes.
	// Uses the default slugs to ensure consistency across themes.
	add_theme_support(
		'editor-font-sizes',
		array(
			array(
				'name' => esc_html__( 'small', 'broadsheet' ),
				'size' => 17,
				'slug' => 'small',
			),
			array(
				'name' => esc_html__( 'normal', 'broadsheet' ),
				'size' => 20,
				'slug' => 'normal',
			),
			array(
				'name' => esc_html__( 'medium', 'broadsheet' ),
				'size' => 22,
				'slug' => 'medium',
			),
			array(
				'name' => esc_html__( 'large', 'broadsheet' ),
				'size' => 34,
				'slug' => 'large',
			),
			array(
				'name' => esc_html__( 'huge', 'broadsheet' ),
				'size' => 45,
				'slug' => 'huge',
			),
		)
	);

	// Add support for editor styles.
	add_theme_support( 'editor-styles' );

	// Editor Style.
	$fonts_url = chronicle_fonts();

	if ( $fonts_url ) {
		add_editor_style( $fonts_url );
	}

}

add_action( 'after_setup_theme', 'chronicle_after_setup_theme' );


/**
 * Custom excerpt length
 *
 * @param int $length Default excerpt length.
 * @return int
 */
function chronicle_excerpt_length( $length ) {

	return 48;

}

add_filter( 'excerpt_length', 'chronicle_excerpt_length', 19 );


/**
 * Remove customizer control(s) that are not needed
 *
 * @param object $wp_customize Customizer object.
 */
function chronicle_customize_register( $wp_customize ) {

	$wp_customize->remove_setting( 'broadsheet_display_date_social' );
	$wp_customize->remove_control( 'broadsheet_display_date_social' );

	$wp_customize->remove_setting( 'broadsheet_date_format' );
	$wp_customize->remove_control( 'broadsheet_date_format' );

}

add_action( 'customize_register', 'chronicle_customize_register', 20 );


/**
 * Add a class to blog posts so that they can have different layouts
 *
 * @param array $class List of post classes to manipulate.
 * @return array
 */
function chronicle_custom_post_class( $class ) {

	switch ( get_theme_mod( 'chronicle_post_archive_layout', 0 ) ) {
		case 1:
			$class[] = 'layout-horizontal-left';
			break;

		case 2:
			$class[] = 'layout-horizontal-right';
			break;
	}

	return $class;

}

add_action( 'post_class', 'chronicle_custom_post_class' );


/**
 * Get url for Google fonts.
 */
function chronicle_fonts() {

	/**
	 * Translators: If there are characters in your language that are not
	 * supported, translate this to 'off'. Do not translate into your
	 * own language.
	 */
	$font = _x( 'on', 'Lato: on or off', 'chronicle' );
	if ( 'off' !== $font ) {
		$fonts['lato'] = 'Lato:400,900';
	}

	$fonts = apply_filters( 'chronicle_fonts', $fonts );

	if ( $fonts ) {

		$query_args = array(
			'family' => rawurlencode( implode( '|', $fonts ) ),
			'subset' => rawurlencode( 'latin,latin-ext' ),
			'display' => 'swap',
		);

		return add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );

	}

}
