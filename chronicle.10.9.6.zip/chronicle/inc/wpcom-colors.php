<?php

/**
 * Color annotation for Broadsheet, by Pro Theme Design.
 */

add_color_rule( 'bg', '#f2f2f2', array(
	array( 'body', 'background-color' ),

	//Contrast against #fff white content area
	array( '.widget h3.widgettitle:before', 'color', '#fff' ),
), __( 'Background' ) );

add_color_rule( 'fg1', '#c0392b', array(

) );

add_color_rule( 'fg2', '#1a1a1a', array(

) );

add_color_rule( 'link', '#1a1a1a', array(
	//No contrast
	array( 'ol.commentlist li.comment .reply a:hover, ol.commentlist li.trackback .reply a:hover, ol.commentlist li.pingback .reply a:hover', 'background-color' ),
	array( 'input[type=submit]:hover', 'background-color' ),
	array( 'input[type=submit]:hover', 'border-color' ),

	//Contrast against background
	array( '.archive .title, .pagination a, .pagination a:hover', 'color', 'bg' ),

	//Contrast against white content area
	array( '.main h1.title a, .main h2.title a, .main h2.posttitle a, h1, h2, h3, h4, h5, h6, .masthead h1.logo,.masthead .branding h1.logo a, .masthead .branding h1.logo a:hover, .masthead .branding h2.description', 'color', '#fff' ),

	array( '.primary-content .primary-wrapper .item .postmetadata', 'color', '#000' ),

), __( 'Headings' ) );

add_color_rule( 'txt', '#c0392b', array(

	//No contrast
	array( 'input[type=submit]', 'background-color' ),
	array( 'input[type=submit]', 'border-color' ),
	array( '.infinite-scroll #infinite-handle span', 'background-color' ),
	array( '.infinite-scroll #infinite-handle span:hover', 'background-color', '-2' ),
	array( '.testimonials-wrapper header a.button', 'background-color' ),
	array( '.testimonials-wrapper header a.button', 'border-color' ),
	array( '.testimonials-wrapper header a.button:hover', 'background-color', '-2' ),
	array( 'nav.menu-primary', 'background-color' ),
	array( '.main .archive-pagination span.current', 'background-color' ),
	array( '.primary-content nav', 'background-color' ),
	array( 'nav.menu-primary .menu ul li a:before', 'color', '-1' ),
	array( '.main article a.post-lead-category:hover', 'background-color', '-1' ),
	array( 'blockquote', 'border-left-color' ),
	array( 'ol.commentlist li.comment .reply a, ol.commentlist li.trackback .reply a, ol.commentlist li.pingback .reply a', 'background-color' ),
	array( '.primary-content nav a', 'background-color', '-1' ),
	array( 'nav.menu-primary .menu > li.page_item_has_children > a:after, nav.menu-primary .menu > li.menu-item-has-children > a:after', 'background-color' ),
	array( 'nav.menu-primary .menu li.page_item_has_children > a:after, nav.menu-primary .menu li.menu-item-has-children > a:after', 'border-top-color', '+1' ),
	array( 'ol.commentlist li.comment.bypostauthor > article, ol.commentlist li.trackback.bypostauthor > article, ol.commentlist li.pingback.bypostauthor > article', 'border-color' ),

	//Contrast against white content area
	array( 'a', 'color', '#fff' ),
	array( '.main article .postmetadata a', 'color', '#fff' ),
	array( '.social_links a:hover:before', 'color', '#fff' ),
	array( 'a:hover', 'color', '#fff' ),
	array( '.main article .postmetadata a:hover', 'color', '#fff' ),
	array( 'input[type=text]:focus, input[type=password]:focus, input[type=email]:focus, input[type=url]:focus, input.text:focus, textarea:focus, input.settings-input:focus', 'border-color', '#fff' ),
	array( 'input[type=text]:focus, input[type=password]:focus, input[type=email]:focus, input[type=url]:focus, input.text:focus, textarea:focus, input.settings-input:focus', 'outline-color', '#fff' ),
	array( '.masthead .search-wrapper form.searchform button.searchsubmit', 'color', '#fff' ),
	array( '.sidebar-main .widget h3.widgettitle a, .sidebar-small .widget h3.widgettitle a', 'color', '#fff' ),
	array( '.main h1.title a:hover, .main h2.title a:hover, .main h2.posttitle a:hover', 'color', '#fff', '3' ),

	//Lighter color
	array( 'nav.menu-primary .menu .social_links a:before', 'color', 'txt' ),

	// Contrast against bg
	array( '.main .category_description a', 'color', 'bg', 6 ),

), __( 'Main Accent' ) );

add_color_rule( 'extra', '#ffffff', array(

	//Contrast against main accent
	array( 'input[type=submit]', 'color', 'txt' ),
	array( 'nav.menu-primary .menu a', 'color', 'txt' ),
	array( 'nav.menu-primary .menu a:hover', 'color', 'txt' ),
	array( 'nav.menu-primary .menu .menu-toggle', 'color', 'txt' ),
	array( 'nav.menu-primary .social_links a:before, nav.menu-primary .social_links a:hover:before', 'color', 'txt' ),
	array( '.main .archive-pagination span.current', 'color', 'txt' ),
	array( '.primary-content nav a.selected', 'background-color', 'txt' ),
	array( '.main article a.post-lead-category:hover', 'color', 'txt' ),
	array( 'ol.commentlist li.comment .reply a, ol.commentlist li.trackback .reply a, ol.commentlist li.pingback .reply a', 'color', 'txt' ),
	array( '.infinite-scroll #infinite-handle span', 'color',  'txt', 10 ),
	array( '.testimonials-wrapper header a.button', 'color', 'txt', 10 ),
	array( '.menu-primary .menu-on.menu ul ul li a, .menu-primary .menu-on.menu li ul li a, .menu-primary .menu-on.menu ul li a, .menu-primary .menu-on.menu li li a, .menu-primary .menu-on.menu ul a, .menu-primary .menu-on.menu li a', 'color', 'txt' ),

	//Contrast with secondary accent (Headings)
	array( 'ol.commentlist li.comment .reply a:hover, ol.commentlist li.trackback .reply a:hover, ol.commentlist li.pingback .reply a:hover', 'color', 'link' ),
	array( 'input[type=submit]:hover', 'color', 'link' ),

	//Contrast against submenu dark gray background
	array( 'nav.menu-primary .menu ul ul a', 'color', '#333' ),

	// Contrast against bg
	array( '.main .category_description', 'color', 'bg', 6 ),
) );

add_color_rule( 'extra', '#191919', array(
	array( 'nav.menu-primary .menu li.current-menu-item > a, nav.menu-primary .menu li li.current-menu-item > a, nav.menu-primary .menu li.current_page_item > a, nav.menu-primary .menu li li.current_page_item > a', 'background', 0.2  ),
) );

//Additional palettes

add_color_palette( array(
	'#44749d',
	'#c6d4e1',
	'#ffffff',
), 'One' );

add_color_palette( array(
	'#b3cc57',
	'#f9f929',
	'#fb7f12',
), 'Two' );

add_color_palette( array(
	'#fefafb',
	'#fcd9e5',
	'#f48aaf',
), 'Three' );

add_color_palette( array(
	'#fde6bd',
	'#a1c5ab',
	'#74a973',
), 'Four' );
