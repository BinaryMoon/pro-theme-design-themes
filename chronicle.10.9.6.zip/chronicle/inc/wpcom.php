<?php
/**
 * WordPress.com specific functionality
 *
 * @package Chronicle
 */

/**
 * Dequeue Google Fonts if Custom Fonts are being used instead.
 */
function chronicle_dequeue_fonts() {

	if ( class_exists( 'TypekitData' ) && class_exists( 'CustomDesign' ) && CustomDesign::is_upgrade_active() ) {
	    $custom_fonts = TypekitData::get( 'families' );

		if ( $custom_fonts && $custom_fonts['headings']['id'] && $custom_fonts['body-text']['id'] ) {
			wp_dequeue_style( 'broadsheet-style-lato-web' );
		}
	}

}

add_action( 'wp_enqueue_scripts', 'chronicle_dequeue_fonts', 11 );


/**
 * Theme colours for wp.com custom functionality
 *
 * @global string $themecolors
 */
function chronicle_theme_colors() {

	global $themecolors;

	/**
	 * Set a default theme color array for WP.com.
	 *
	 * @global array $themecolors
	 */
	if ( ! isset( $themecolors ) ) {
		$themecolors = array(
			'bg'     => 'ffffff',
			'border' => 'f2f2f2',
			'text'   => '111111',
			'link'   => 'd65548',
			'url'    => 'aaaaaa',
		);
	}

}

add_action( 'after_setup_theme', 'chronicle_theme_colors' );
