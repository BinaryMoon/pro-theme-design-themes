<?php
/**
 * Jetpack Featured Content
 * See: http://jetpack.me/support/featured-content/
 *
 * @package Chronicle
 */

	$display_page = (int) get_theme_mod( 'broadsheet_featured_content_display', 1 );

	// If display is set to homepage only, and we're not on the homepage then quit.
	if ( ! is_front_page() && 2 === $display_page ) {
		return;
	}

	if ( broadsheet_has_featured_posts() ) {
		$featured_posts = broadsheet_get_featured_posts( 4 );
?>
	<section class="showcase">
<?php
		$count = 0;
		foreach ( $featured_posts as $post ) {
			setup_postdata( $post );
			$image = broadsheet_archive_image_url( get_the_ID(), 'chronicle-feature' );
			$count ++;
			$styles = '';

			if ( $image && $image[0] ) {
				$styles = 'style="background-image:url(' . esc_url( $image[0] ) . ');"';
			}
?>
		<div class="item item-<?php echo esc_attr( $count ); ?>">
				<a href="<?php the_permalink(); ?>" class="thumbnail" <?php echo $styles; ?>></a>
				<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
		</div>
<?php
		}
?>
	</section>
<?php
		wp_reset_postdata();
	}
