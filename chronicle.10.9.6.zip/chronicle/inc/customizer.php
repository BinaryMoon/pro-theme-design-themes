<?php
/**
 * Theme Customizer
 *
 * @package Chronicle
 */

/**
 * Theme customizer properties
 *
 * @param object $wp_customize WordPress customizer object.
 */
function chronicle_customizer_settings( $wp_customize ) {

	// How many categories to display on the homepage category summaries.
	$wp_customize->add_setting(
		'chronicle_post_archive_layout',
		array(
			'default' => 0,
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'broadsheet_sanitize_int',
		)
	);

	$wp_customize->add_control(
		new Broadsheet_Dropdown_Custom_control(
			$wp_customize,
			'chronicle_post_archive_layout',
			array(
				'label' => esc_html__( 'Archive Post Layout', 'chronicle' ),
				'section' => 'broadsheet_options',
				'params' => array(
					0 => esc_html__( 'Thumbnails full size, above post (Default)', 'chronicle' ),
					1 => esc_html__( 'Thumbnails left aligned', 'chronicle' ),
					2 => esc_html__( 'Thumbnails right aligned', 'chronicle' ),
				),
				'default' => 0,
			)
		)
	);

}

add_action( 'customize_register', 'chronicle_customizer_settings' );
