=== Chronicle ===

Contributors: binarymoon
Requires at least: 4.1
Tested up to: 4.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: gray, red, white, light, one-column, two-columns, three-columns, four-columns, left-sidebar, right-sidebar, responsive-layout, custom-background, custom-colors, custom-header, custom-menu, featured-images, featured-image-header, flexible-header, full-width-template, infinite-scroll, post-slider, rtl-language-support, theme-options, translation-ready, blog, business, education, gaming, magazine, music, news, bright, clean, conservative, contemporary, formal, geometric, industrial, light, minimal, modern, professional, sophisticated, site-logo

== Description ==

Chronicle is a magazine theme. With 3 optional widget areas, featured posts, and a huge homepage slider, there are lots of options for creating interesting, immersive websites.

[Theme documentation](https://prothemedesign.com/documentation/theme/chronicle/)

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Chronicle includes support for most features in Jetpack, including Infinite Scroll, Featured Content, and Site Logo.

Chronicle includes support for Styleguide - a plugin that allows you to change fonts, and colours in WordPress themes.

== Changelog ==

= 10.9.6 - 18th September 2021 =
* Bug fix for theme build error.

= 10.9.5 - 26th July 2021 =
* Fix error with possible undefined image in featured content.

= 10.9.4 - 2nd April 2021 =
* Fix text input width.

= 10.9.3 - 31st January 2021 =
* Clear html widget to prevent floated content from breaking the layout.

= 10.9.2 - 1st January 2021 =
* Fix mobile menu colours.

= 10.9.1 - 5th October 2020 =
* Add support for wp_body_open

= 10.9 - 11th March 2020 =
* Add support for Gutenberg features.
* Update RTL files.

= 10.8.2 - 12th February 2020 =
* Adjust WooCommerce category header image changes to use the page header image rather than the site header image.
* Hide right hand sidebar on WooCommerce pages.

= 10.8.1 - 6th February 2020 =
* Fix problem with WooCommerce change.

= 10.8 - 5th February 2020 =
* Add support for WooCommerce category images

= 10.7.8 - 9th November 2019 =
* Fix sizing overflow issue with small devices related to infinite scroll.

= 10.7.7 - 4th October 2019 =
* Change figcaption styles to differentiate them from paragraph text.
* Fix the order of the homepage content on mobile devices.
* Add more consistent margins for image and gallery blocks.

= 10.7.6 - 13th September 2019 =
* Tweak the homepage layout so that the small left sidebar never gets hidden, even on small screens.

= 10.7.5 - 25th June 2019 =
* Tweak button styles so they match input[type=submit] styles.

= 10.7.4 - 15th May 2019 =
* Add font display swap to Google Font loading, to increase font display speed.
* Make paragraph, list, and blockquote margins consistent in blog posts.

= 10.7.3 - 5th January 2019 =
* Fix position of portfolio & page featured image.

= 10.7.2 - 20th November 2018 =
* Improve typography on small screens to make it more readable (less oversized text).

= 10.7.1 - 18th November 2018 =
* Improve consistency of page layout and spacings to make website feel more complete.
* Fix display of featured image on single posts and pages (so that it doesn't have a right margin).
* Reduce the height of the page on mobile by reducing the margin between widgets when they are stacked vertically.
* Simplify browser prefixes.

= 10.7 - 27th June 2018 =
* Increase size of featured image so that it can fill the entire width of the featured content space. Uses the same ratio (and size is fixed with css) so existing layouts will not change.
* Add option to enable featured images on single blog posts.

= 10.6 - 25th May 2018 =
* Add support for privacy policy link in the site footer.
* Fix display of the cookie consent checkbox in the comments form.

= 10.5 - 1st April 2018 =
* Make credits editable in the customizer (.org only).

= 10.4.2 - 28th January 2018 =
* Improve css browser prefixes.

= 10.4.1 - 30th November 2017 =
* Improve display of full blog posts on archive pages when using Jetpack content options.

= 10.4 - 1st November 2017 =
* Add setting to allow featured content to be displayed on the homepage only/ on all pages as happens currently.

= 10.3.1 - 1st October 2017 =
* Add footer credits filter to allow footer credits to be edited through custom plugin.

= 10.3 - 20th July 2017 =
* Add support for Jetpack content options to allow altering of some website content.
* Includes support for adding the Author Bio on single blog posts.

= 10.2.6 - 16th July 2017 =
* Minor tweaks to css styles to improve readability

= 10.2.5 - 5th July 2017 =
* Small css tweaks to improve design consistency

= 10.2.4 - 18th April 2017 =
* Update content_width to ensure post content is sized correctly.

= 10.2.3 - 31st October 2016 =
* Make attachment pages display in the loop so that content and excerpts display correctly
* Tweak attachment page display to be more attractive (improve whitespace)

= 10.2.2 - 12th September 2016 =
* tweak word-wrap css
* fix attachment page layout
* fix size of attachment image so that it better fills the space
* remove css box-shadow prefixes

= 10.2.1 - 1st August 2016 =
* tweak css styles for site logo and featured category column
* improve site footer if there's no javascript enabled or a javascript error

= 10.2 - 16 July 2016 =
* Tidy codes and more sanitization
* Improve responsive styles so that column layout works properly on lower resolution devices.

= 10.1 - 26 May 2016 =
* Tweak responsive styles so that they start earlier, which means they work on an ipad. This improves the menu usage on tablets.

= 10 =
* bump version again, to avoid clashes with .org version

= 2.1 =
* Improve responsive behavior of social menu

= 2.0.2 =
* Add next and previous arrows to post navigation

= 2.0.1 =
* Improve the slider so that it scales better on small screens
* Remove wp_title() (no longer needed since Broadsheet uses `add_theme_support( 'title-tag' )`)

= 2.0 =
* Update version number
* various css improvements

= 1.0 =
* Initial release

== Credits ==

* [Lato](https://www.google.com/fonts/specimen/Open+Sans) Font from Google Fonts, licensed under [SIL Open Font License, 1.1](http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL).
* Genericons: font by Automattic (http://automattic.com/), licensed under [GPL2](https://www.gnu.org/licenses/gpl-2.0.html)
