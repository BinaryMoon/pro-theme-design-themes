<?php
/**
 * Header Template
 *
 * @package Chronicle
 */

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta http-equiv="Content-Type" content="<?php bloginfo( 'html_type' ); ?>; charset=<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<?php wp_head(); ?>

	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />

	<!--[if lt IE 9]>
	<script src="<?php echo get_template_directory_uri(); ?>/js/html5.js" type="text/javascript"></script>
	<![endif]-->

</head>

<body <?php body_class(); ?>>
	<?php wp_body_open(); ?>

	<nav class="menu-primary" role="navigation">
		<div class="container">
			<?php broadsheet_social_links(); ?>
			<div class="menu">
				<h3 class="menu-toggle"><?php esc_html_e( 'Menu', 'chronicle' ); ?></h3>
				<?php wp_nav_menu( array( 'theme_location' => 'top_menu', 'menu_id' => 'nav', 'menu_class' => 'menu-wrap clearfix' ) ); ?>
			</div>
		</div>
	</nav>
	<header class="masthead" role="banner">
		<div class="container">
			<?php do_action( 'before' ); ?>
			<div class="branding">
				<?php if ( function_exists( 'jetpack_the_site_logo' ) ) { jetpack_the_site_logo(); } ?>
				<h1 class="logo">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php esc_attr_e( 'Home', 'chronicle' ); ?>">
						<?php bloginfo( 'name' ); ?>
					</a>
				</h1>
				<h2 class="description">
					<?php bloginfo( 'description' ); ?>
				</h2>
			</div>
			<div class="search-wrapper">
				<?php get_search_form(); ?>
			</div>
		</div>
	</header>

	<div class="container hfeed">

	<?php broadsheet_header(); ?>

	<div class="main">
