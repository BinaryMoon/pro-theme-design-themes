<?php
/**
 * Error - file not found
 *
 * @package Vision
 */

	get_header();
?>
<article class="page-404">
	<h1 class="title"><?php _e( 'Error 404 - Not Found', 'vision' ); ?></h1>

	<div class="entry">

		<p class="text-404"><?php _e( 'Sorry, but the page you are looking for has not been found. Try checking the URL for errors, then hit the refresh button in your browser.', 'vision' ); ?></p>
<?php
	$args = array(
		'posts_per_page' => 5,
		'ignore_sticky_posts' => true,
	);
	$query = new WP_Query( $args );

	if ( $query->have_posts() ) {
?>
		<h3><?php _e( 'Recent Posts', 'vision' ); ?></h3>
		<ul>
<?php
		while ( $query->have_posts() ) {
			$query->the_post();
?>
			<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
<?php
		}
?>
		</ul>
<?php
	} else {
		get_template_part( 'content-empty' );
	}
	wp_reset_postdata();
?>
	</div>
</article>
<?php
	get_footer();