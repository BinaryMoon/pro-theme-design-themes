<?php
/**
 * Single post content
 *
 * @package Vision
 */

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<?php
	the_title( '<h1 class="title entry-title">', '</h1>' );
	get_template_part( 'inc/post-metadata' );
?>
	<section class="entry">
<?php
	the_content();

	edit_post_link();

	wp_link_pages( array(
		'before' => '<div class="archive-pagination">' . __( 'Pages: ', 'vision' ),
		'after'  => '</div>',
		'link_before' => '<span>',
		'link_after'  => '</span>',
	) );

	get_template_part( 'inc/post-terms' );
?>
	</section>
</article>
<nav class="postnav">
	<div class="prev">
		<?php previous_post_link( __( '<span class="more-link">%link</span>', 'vision' ) ); ?>
	</div>
	<div class="next">
		<?php next_post_link( __( '<span class="more-link">%link</span>', 'vision' ) ); ?>
	</div>
</nav>
