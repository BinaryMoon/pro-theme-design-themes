<?php
/**
 * Homepage Template
 *
 * @package Vision
 */

	get_header();

	get_template_part( 'inc/featured-content' );

	if ( have_posts() ) {
?>
	<div id="main-content">
<?php
		while ( have_posts() ) {
			the_post();
			get_template_part( 'content', get_post_format() );
		}
		vision_numeric_pagination();
?>
	</div>
<?php
	} else {
		get_template_part( 'content-empty' );
	}

	get_template_part( 'inc/jetpack-testimonials' );

	get_footer();
