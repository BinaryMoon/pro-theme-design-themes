<?php
/**
 * Author post listing
 *
 * @package Vision
 */

	get_header();
	$user_id = get_query_var( 'author' );
?>
	<h1 class="title">
		<?php _e( 'Author Archives','vision' ); ?>
	</h1>
	<div class="writer">
		<?php echo get_avatar( get_the_author_meta( 'user_email', $user_id ), '80' ); ?>
		<h3><?php the_author_meta( 'display_name', $user_id ); ?></h3>
		<?php echo wpautop( get_the_author_meta( 'description', $user_id ) ); ?>
	</div>

<?php
	if ( have_posts() ) {

		while ( have_posts() ) {
			the_post();
			get_template_part( 'content', get_post_format() );
		}
		vision_numeric_pagination();

	} else {
		get_template_part( 'content-empty' );
	}


	get_footer();