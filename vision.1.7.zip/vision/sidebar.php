<?php
/**
 * Sidebar template
 *
 * @package Vision
 */

	if ( is_active_sidebar( 'sidebar-1' ) && is_singular() && ! is_page_template( 'custom-templates/full-width.php' ) ) {
?>
<div class="col-sidebar">
<?php
	do_action( 'before_sidebar' );
	dynamic_sidebar( 'sidebar-1' );
?>
</div>
<?php
	}
