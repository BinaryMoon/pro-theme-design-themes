=== Vision ===

Contributors: binarymoon
Requires at least: 4.1
Tested up to: 4.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: black, gray, orange, dark, two-columns, right-sidebar, responsive-layout, custom-background, custom-colors, custom-header, custom-menu, featured-images, full-width-template, infinite-scroll, post-formats, post-slider, rtl-language-support, sticky-post, translation-ready, art, artwork, design, fashion, photoblogging, photography, portfolio, scrapbooking, clean, conservative, contemporary, elegant, formal, geometric, minimal, modern, professional, simple, sophisticated

== Description ==

Vision is a clean, grid-based photography theme with a flat minimal design. Perfect for showcasing your skills.

[Theme documentation](https://prothemedesign.com/documentation/theme/vision/)

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Vision includes support for [Styleguide](https://wordpress.org/plugins/styleguide/) - a plugin that allows you to change fonts, and colours in WordPress themes.

Vision includes support for most features in [Jetpack](https://wordpress.org/plugins/jetpack/), including Infinite Scroll, Featured Content, and Site Logo.

== Changelog ==

= 1.8 - 19th March 2020 =
* Improve coding standards.
* Add support for Gutenberg.
* Use the_archive_description for archive descriptions.
* Make the sidebar and content the same length.
* Improve colour contrast and white space for better readability and consistency.
* Improve the design of the 'no search results' page.

= 1.7 - 25th May 2018 =
* Add support for privacy policy link in the site footer.
* Fix display of the cookie consent checkbox in the comments form.

= 1.6.2 - 28th January 2018 =
* Improve css browser prefixes.

= 1.6.1 - 28th March 2017 =
* Improve responsive display of social widgets.

= 1.6 - 29th October 2016 =
* Fix issue with slider not working properly when there’s multiple sliders setup (header slider, and featured content).
* some code tidying
* add short_ping for pingback display
* small css tweaks to improve spacing/ readability

= 1.5 - 11 July 2016 =
* Fix issue with responsive navigation not allowing the first item to be selected

= 1.4.2 - 21 June 2016 =
* Fix issue with testimonials and footer widgets positioning

= 1.4.1 - 14 June 2016 =
* Fix issue with current menu item that is selected and the colours cascading down to child menus

= 1.4 - 9 June 2016 =
* Add automatic theme updates and getting started page (.org version only)
* Switch to add_theme_support( title-tag ) for better core title tag support
* Add support for jetpack responsive videos
* Add support for adding pages and projects to slider
* Improve layout of social media widgets in footer
* Update JS to use latest version of jquery masonry plugin
* Update slider js to latest version
* Improve subscribe to post css so that the checkbox fits in better
* Fix bug with slider items that don't have a featured image
* Some code formatting improvements

= 1.3.1 =
* Fix small issue with image attachment template
* Tweak IS behavior to fix strange showing/ hiding effect

= 1.3 =
* fix full width sidebar template so it works properly

= 1.0 =
* Initial release

== Credits ==

* [Open Sans](https://www.google.com/fonts/specimen/Open+Sans) Font from Google Fonts, licensed under [Apache License, version 2.0](http://www.apache.org/licenses/LICENSE-2.0.html)
* [Oswald](https://www.google.com/fonts/specimen/Oswald) Font from Google Fonts, licensed under [SIL Open Font License, 1.1](http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL)
* Genericons: font by Automattic (http://automattic.com/), licensed under [GPL2](https://www.gnu.org/licenses/gpl-2.0.html)
