<?php
/**
 * Search results template
 *
 * @package Vision
 */

	get_header();

	if ( have_posts() ) {

?>
	<h1 class="title">
		<?php printf( __( 'Search results for &#8216;<em>%s</em>&#8217;', 'vision' ), get_search_query() ); ?>
	</h1>

	<div id="main-content">
<?php
		while ( have_posts() ) {
			the_post();
			get_template_part( 'content', get_post_format() );
		}

		vision_numeric_pagination();
?>
	</div>
<?php
	} else {
?>
<article class="page-404">
	<h1 class="title"><?php esc_html_e( 'No Search Results', 'vision' ); ?></h1>

	<div class="entry">
		<p class="text-404"><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'vision' ); ?></p>
		<?php get_search_form(); ?>
	</div>
</article>
<?php
	}

	get_footer();
