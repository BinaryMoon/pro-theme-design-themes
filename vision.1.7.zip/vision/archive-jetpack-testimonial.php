<?php
/**
 * Testimonials Archive Template
 *
 * displays at: http://website.com/testimonial/
 *
 * @package Vision
 */

	get_header();

	$testimonials = new WP_Query( array(
		'post_type' => 'jetpack-testimonial',
		'orderby' => 'menu_order',
		'posts_per_page' => 999,
		'no_found_rows' => true,
		'order' => 'ASC',
	) );

	if ( $testimonials->have_posts() ) {
?>
	<h1 class="title"><?php vision_testimonials_title(); ?></h1>
<?php
	if ( $description = vision_testimonials_description() ) {
?>
	<div class="category-description">
		<?php echo $description; ?>
	</div>
<?php
	}
	if ( $image = vision_testimonials_image() ) {
?>
	<div class="page-image-header">
		<?php echo $image; ?>
	</div>
<?php
	}
?>
	<div id="main-content" class="testimonials testimonials-wrapper">
<?php
		while ( $testimonials->have_posts() ) {
			$testimonials->the_post();
			get_template_part( 'content', 'testimonial' );
		}
?>
	</div>
<?php
	} else {
		get_template_part( 'content-empty' );
	}

	get_footer();