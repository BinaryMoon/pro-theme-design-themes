<?php
/**
 * Content layout for image post formats
 *
 * @package Vision
 */

	if ( ! has_post_thumbnail() ) {

		get_template_part( 'content' );

	} else {

		$image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'vision-image-format' );
		$styles = '';
		$post_classes = array( 'post-archive' );

		if ( $image[0] ) {
			$post_classes[] = 'has-image';
			$styles = 'style="background-image:url(' . esc_url( $image[0] ) . ');"';
		}
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( $post_classes ); ?>>
	<div class="image-wrapper">
<?php
		if ( $image[0] ) {
?>
		<a href="<?php echo esc_url( get_permalink() ); ?>" class="thumbnail" <?php echo $styles; ?>></a>
<?php
		}
?>
		<section class="entry">
			<h2 class="posttitle">
				<a href="<?php the_permalink() ?>" rel="bookmark">
					<?php the_title(); ?>
				</a>
			</h2>
			<p class="postmetadata">
				<a href="<?php the_permalink(); ?>"><?php echo vision_human_time_diff(); ?></a>
			</p>
		</section>
	</div>
</article>
<?php
	}
