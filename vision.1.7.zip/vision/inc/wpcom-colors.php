<?php
/**
 * Color annotation for Vision, by Pro Theme Design.
 */

add_color_rule( 'bg', '#1a1a1a', array(
 	array( 'body', 'background-color' ),
), __( 'Main Background' ) );

add_color_rule( 'txt', '#57b5cf', array(
 	array( '.masthead-wrapper,#footer', 'background-color' ),
 	array( '.masthead-wrapper', 'border-bottom-color', 'txt', 1.5 ),
 	array( '#footer', 'border-top-color', 'txt', 1.5 ),
 	array( '#footer hr', 'border-color', 'txt', 1.5 ),
), __( 'Header and Footer Background' ) );

add_color_rule( 'link', '#e67e22', array(
	array( 'a:hover,
		.main .postmetadata a:hover,
		label.error,
		.widget.widget_flickr #flickr_badge_uber_wrapper td a,
		.widget.widget_flickr #flickr_badge_wrapper td a,
		#respond p.logged-in-as a:hover,
		.main .postmetadata a:hover,
		form.searchform button.searchsubmit', 'color', '#ffffff', 3 ),
	array( '#footer a:hover,form.searchform button.searchsubmit,form.searchform button.searchsubmit:hover', 'color', 'txt' ),
	array( '.menu li ul,
		.main .postnav .next a:before,
		.main .postnav .prev a:before,
		.main .postnav .next a:after,
		.main .postnav .prev a:after,
		form input[type=submit],
		form input[type=submit]:hover,
		.main .archive-pagination span.current,
		.main .showcase .showcase-wrapper nav a.selected,
		.social_links a:before,
		.infinite-scroll #infinite-handle span,
		.infinite-scroll #infinite-handle span:hover', 'background-color', '#ffffff', 3 ),

	array( '.menu li ul:before', 'border-bottom-color', '#ffffff', 3 ),
	array( '.menu li ul li', 'border-bottom-color', '#ffffff', 2 ),
	array( 'form input[type=submit]', 'border-color', '#ffffff', 3 ),

	array( '.masthead-wrapper .menu li ul', 'background-color', '#ffffff', 4 ),
	array( '.masthead-wrapper .menu li ul:before', 'border-bottom-color' ),
	array( '.masthead-wrapper .menu li ul li.current-menu-item a', 'background-color' ),

	array( 'blockquote,
		input[type=text]:focus,
		input[type=password]:focus,
		input[type=email]:focus,
		input[type=url]:focus,
		input.text:focus,
		textarea:focus,
		input.settings-input:focus,
		input[type=submit],
		textarea.error,
		input.error,
		.infinite-scroll #infinite-handle span,
		.infinite-scroll #infinite-handle span:hover,
		.main .contributor a.contributor-posts-link,
		ol.commentlist li.comment .reply a,
		ol.commentlist li.trackback .reply a,
		ol.commentlist li.pingback .reply a,
		ol.commentlist li.comment.bypostauthor > article,
		ol.commentlist li.trackback.bypostauthor > article,
		ol.commentlist li.pingback.bypostauthor > article', 'border-color', '#ffffff', 4 ),

	array( 'input[type=text]:focus,
		input[type=password]:focus,
		input[type=email]:focus,
		input[type=url]:focus,
		input.text:focus,
		textarea:focus,
		input.settings-input:focus', 'outline-color', '#ffffff', 4 ),

	array( '.masthead-wrapper .menu li ul li', 'border-color', 'link', 2 ),
	array( '.masthead-wrapper .menu li ul li a.sf-with-ul:after', 'border-left-color', 'link', 2 ),
	array( '.rtl .masthead-wrapper .menu li ul li a.sf-with-ul:after', 'border-right-color', 'link', 2 ),
), __( 'Submenu Background' ) );

add_color_rule( 'fg1', '#000000', array(
) ); // not used

add_color_rule( 'fg2', '#000000', array(
) ); // not used

add_color_rule( 'extra', '#ffffff', array(
 	array( '.masthead-wrapper .masthead .branding h1.logo a,.masthead-wrapper .masthead .branding h2.description,.menu li a:hover', 'color', 'txt' ),
) );

add_color_rule( 'extra', '#b3b3b3', array(
 	array( '.menu li a,.menu li a.sf-with-ul:after,#footer a', 'color', 'txt' ),
 	array( '.menu li a.sf-with-ul:after', 'border-top-color', 'txt' ),
) );

add_color_rule( 'extra', '#808080', array(
 	array( '#footer', 'color', 'txt' ),
) );

add_color_rule( 'extra', '#333333', array(
 	array( '.archive-pagination a', 'color', 'bg' ),
) );

/**
 * Additional CSS
 */
function vision_custom_colors_css() { ?>
	.menu li ul li a.sf-with-ul:after {
		border-left-color: #fff;
	}
	.menu li li a:hover {
		color: #fff;
	}

	.infinite-scroll #infinite-handle span,
	.infinite-scroll #infinite-handle span:hover,
	form input[type=submit],
	form input[type=submit]:hover {
		background-image: none;
	}

	.rtl .masthead-wrapper .menu li ul li a.sf-with-ul:after {
		border-left-color: transparent;
	}
<?php }
add_theme_support( 'custom_colors_extra_css', 'vision_custom_colors_css' );
