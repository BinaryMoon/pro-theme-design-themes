<?php
/**
 * Jetpack Featured Content
 * See: http://jetpack.me/support/featured-content/
 *
 * @package Vision
 */

	if ( vision_has_featured_posts() && is_front_page() ) {
		$featured_posts = vision_get_featured_posts( 4 );
?>
	<section class="showcase">
		<div class="showcase-wrapper">
<?php
		foreach ( $featured_posts as $post ) {
			setup_postdata( $post );

			$image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'vision-featured' );
			$styles = '';

			if ( $image[0] ) {
				$styles = 'style="background-image:url(' . esc_url( $image[0] ) . ');"';
			}
?>
		<article class="item">
<?php
			if ( $image ) {
?>
			<a href="<?php the_permalink(); ?>" class="item-image" <?php echo $styles; ?>>
				<?php the_title(); ?>
			</a>
<?php
			}
?>
			<div class="entry">
				<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
				<p class="postmetadata">
					<a href="<?php the_permalink(); ?>"><?php echo vision_human_time_diff(); ?></a>
				</p>
<?php
			the_excerpt();
?>
			</div>
		</article>

<?php
		}
?>
		</div>
	</section>
<?php
		wp_reset_postdata();
	}