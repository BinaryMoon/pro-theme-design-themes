<?php
/**
 * Jetpack Compatibility File
 * See: http://jetpack.me/
 *
 * @package Vision
 */

/**
 * Add theme support for Infinite Scroll.
 * See: http://jetpack.me/support/infinite-scroll/
 */
function vision_jetpack_init() {

	$settings = array(
		'container' => 'main-content',
		'footer_widgets' => 'sidebar-2',
		'footer' => 'footer-widgets',
		'wrapper' => false,
	);

	add_theme_support( 'infinite-scroll', $settings );

	add_theme_support(
		'social-links',
		array(
			'facebook',
			'twitter',
			'linkedin',
			'tumblr',
			'google_plus',
		)
	);

	add_theme_support( 'featured-content', array(
		'featured_content_filter' => 'vision_get_featured_posts',
		'max_posts' => 4,
		'post_types' => array( 'post', 'page', 'jetpack-portfolio' ),
	) );

	add_theme_support( 'jetpack-testimonial' );

	add_theme_support( 'jetpack-responsive-videos' );

}

add_action( 'after_setup_theme', 'vision_jetpack_init' );


/**
 * Get social links from jetpack publicise functionality
 * http://jetpack.me/support/social-links/
 */
function vision_social_links() {

	$social_links = array(
		array(
			'slug' => 'twitter',
			'name' => __( 'Twitter', 'vision' ),
		),
		array(
			'slug' => 'facebook',
			'name' => __( 'Facebook', 'vision' ),
		),
		array(
			'slug' => 'tumblr',
			'name' => __( 'Tumblr', 'vision' ),
		),
		array(
			'slug' => 'linkedin',
			'name' => __( 'LinkedIn', 'vision' ),
		),
		array(
			'slug' => 'google_plus',
			'name' => __( 'Google+', 'vision' ),
		),
	);
	$links = '';

	foreach ( $social_links as $social ) {

		$url = get_theme_mod( 'jetpack-' . $social['slug'] );
		if ( $url ) {
			$links .= '<a href="' . esc_url( $url ) . '" class="' . esc_attr( 'social_link_' . $social['slug'] ) . '"><span>' . $social['name'] . '<span></a>';
		}
	}

	if ( $links ) {
		echo '<div class="social_links"><hr />' . $links . '</div>';
	}

}


/**
 * Featured posts filter.
 */
function vision_get_featured_posts() {

	return apply_filters( 'vision_get_featured_posts', array() );

}


/**
 * Check to see if there are featured posts available for the current page.
 *
 * @param type $minimum
 * @return boolean
 */
function vision_has_featured_posts( $minimum = 1 ) {

	if ( is_paged() ) {
	    return false;
	}

	$minimum = absint( $minimum );
	$featured_posts = apply_filters( 'vision_get_featured_posts', array() );

	if ( ! is_array( $featured_posts ) ) {
	    return false;
	}

	if ( $minimum > count( $featured_posts ) ) {
	    return false;
	}

	return true;

}


/**
 * Get Jetpack Testimonials Title
 */
function vision_testimonials_title() {

	$jetpack_options = get_theme_mod( 'jetpack_testimonials' );

	if ( '' !== $jetpack_options['page-title'] ) {
		echo esc_html( $jetpack_options['page-title'] );
	} else {
		esc_html_e( 'Testimonials', 'vision' );
	}

}


/**
 * Retrieve and format jetpack testimonials description as set in theme customiser
 *
 * @return type
 */
function vision_testimonials_description() {

	$jetpack_options = get_theme_mod( 'jetpack_testimonials' );
	$content = '';

	if ( '' !== $jetpack_options['page-content'] ) {
		$content = $jetpack_options['page-content'];
		$content = addslashes( $content );
		$content = wp_kses_post( $content );
		$content = stripslashes( $content );
		$content = wptexturize( $content );
		$content = convert_smilies( $content );
		$content = convert_chars( $content );
	}

	return $content;

}


/**
 * Get Jetpack Testimonials Image
 *
 * @return type
 */
function vision_testimonials_image() {

	$jetpack_options = get_theme_mod( 'jetpack_testimonials' );
	$image = '';

	if ( '' !== $jetpack_options['featured-image'] ) {
		$image = wp_get_attachment_image( (int) $jetpack_options['featured-image'], 'vision-testimonial-header' );
	}

	return $image;

}


/**
 * Flush rewrite rules for CPT on setup and switch
 */
function vision_flush_rewrite_rules() {

	flush_rewrite_rules();

}

add_action( 'after_switch_theme', 'vision_flush_rewrite_rules' );
