<?php
/**
 * Homepage header slides
 *
 * @package Vision
 */

	if ( is_front_page() ) {
		$height = (int) get_theme_mod( 'vision_header_height', 0 );

		if ( $height > 0 ) {
?>
	<div class="showcase-header showcase-header-height-<?php echo $height; ?>">
<?php
			for( $i = 1; $i <= 4; $i ++ ) {
				if ( $message = get_theme_mod( 'vision_header_text_' . $i, false ) ) {
?>
		<div class="item"><span><?php echo $message; ?></span></div>
<?php
				}
			}
?>
	</div>
<?php
		}
	}