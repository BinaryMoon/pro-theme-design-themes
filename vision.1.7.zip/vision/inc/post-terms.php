<?php
/**
 * Post terms
 *
 * @package Vision
 */
?>
		<div class="taxonomies">
			<p class="tax-categories taxonomy"><?php
	_e( 'Categories: ', 'vision' );
	the_category( ', ' );
?>
			</p>
<?php

	// display tags (if there are any
	if ( get_the_tags() ) {
		the_tags( '<p class="tax-tags taxonomy">' . __( 'Tagged as: ', 'vision' ), _x( ', ', 'Tag list seperator', 'vision' ), '</p>' );
	}
?>
		</div>