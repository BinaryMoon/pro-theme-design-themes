<?php
/**
 * Custom header codes
 *
 * @package Vision
 */

/**
 * Custom header image
 */
function vision_custom_header_support() {

	// custom header image
	$args = array(
		'default-image' => apply_filters( 'vision_header_image', '' ),
		'default-text-color' => apply_filters( 'vision_header_textcolor', 'ffffff' ),
		'random-default' => false,
		'width' => apply_filters( 'vision_header_width', 1300 ),
		'height' => apply_filters( 'vision_header_height', 400 ),
		'flex-height' => false,
		'header-text' => true,
		'uploads' => true,
		'wp-head-callback' => 'vision_colour_styles',
		'admin-head-callback' => '',
		'admin-preview-callback' => '',
	);
	add_theme_support( 'custom-header', $args );

}

add_action( 'after_setup_theme', 'vision_custom_header_support' );


/**
 * Print custom header styles
 *
 * @return array
 */
function vision_colour_styles() {

?>
<style>
<?php
	if ( 'blank' == get_header_textcolor() ) {
?>
	.masthead .branding { display:none; }
<?php
	} else {
?>
	.masthead-wrapper .masthead .branding h1.logo a,
	.masthead-wrapper .masthead .branding h1.logo a:hover,
	.masthead-wrapper .masthead .branding h2.description {
		color:#<?php echo get_header_textcolor(); ?>;
	}
<?php
	}

	$header_image = get_header_image();

	if ( ! empty( $header_image ) ) {
?>
	.masthead-wrapper {
		background:url( <?php echo $header_image; ?> ) center center;
		background-size:cover;
	}
<?php
	}
?>
</style>
<?php

	return true;

}