/**
 * main.js v1
 * Created by Ben Gillbanks <http://www.binarymoon.co.uk/>
 * Available under GPL2 license
 */

( function( $ ) {

	$( document ).ready( function() {

		// Set default heights for social media widgets

		// Twitter
		$( 'a.twitter-timeline, iframe.twitter-timeline' ).each( function() {

			var thisHeight = $( this ).attr( 'height' );
			$( this ).parent().css( 'min-height', thisHeight + 'px' );

		} );

		// Facebook
		$( '.fb-page' ).each( function() {

			var $set_height = $( this ).data( 'height' );
			var $show_facepile = $( this ).data( 'show-facepile' );
			var $show_posts = $( this ).data( 'show-posts' ); // AKA stream
			var $min_height = $set_height; // set the default 'min-height'

			// These values are defaults from the FB widget.
			var $no_posts_no_faces = 130;
			var $no_posts = 220;

			if ( $show_posts ) {

				// Showing posts; may also be showing faces and/or cover - the latter doesn't affect the height at all.
				$min_height = $set_height;

			} else if ( $show_facepile ) {

				// Showing facepile with or without cover image - both would be same height.
				// If the user selected height is lower than the no_posts height, we'll use that instead
				$min_height = ( $set_height < $no_posts ) ? $set_height : $no_posts;

			} else {

				// Either just showing cover, or nothing is selected (both are same height).
				// If the user selected height is lower than the no_posts_no_faces height, we'll use that instead
				$min_height = ( $set_height < $no_posts_no_faces ) ? $set_height : $no_posts_no_faces;

			}

			// apply min-height to .fb-page container
			$( this ).css( 'min-height', $min_height + 'px' );

		} );


		$( 'ul#nav' ).superfish( {
			animation: { opacity: 'show', height: 'show' },
			speed: 250
		} );

		$( 'ul#nav' ).responsiveNavigation();

		// attachment page navigation
		if ( $( 'body' ).hasClass( 'attachment' ) ) {

			$( document ).keydown( function( e ) {

				if ( $( 'textarea, input' ).is( ':focus' ) ) {
					return;
				}

				var url = false;

				switch ( e.which ) {
					// left arrow key (previous attachment)
					case 37:
						url = $( '.image-previous a' ).attr( 'href' );
						break;

					// right arrow key (next attachment)
					case 39:
						url = $( '.image-next a' ).attr( 'href' );
						break;

				}

				if ( url ) {
					window.location = url;
				}
			} );

		}

		$( window ).on(
			'load',
			function() {

				// Arrange footer widgets vertically.
				if ( typeof $.fn.masonry === 'function' ) {

					// masonry grid sizer
					$( '#footer .footer-widgets, #main-content.testimonials' ).prepend( '<div class="grid-sizer"></div>' );

					var $footer = $( '#footer .footer-widgets' ).masonry( {
						itemSelector: '.widget',
						columnWidth: '.grid-sizer',
						gutter: 0,
						isOriginLeft: !$( 'body' ).is( '.rtl' )
					} );

					$footer.imagesLoaded( function() {

						$footer.masonry( 'layout' );

						// Resposition when social widgets have finished loading
						setTimeout( function() {
							$footer.masonry( 'layout' );
						}, 2000 );

					} );

					var $testimonials = $( '#main-content.testimonials' ).masonry( {
						itemSelector: '.testimonial',
						columnWidth: '.grid-sizer',
						gutter: 0,
						isOriginLeft: !$( 'body' ).is( '.rtl' )
					} );

					$testimonials.imagesLoaded( function() {

						$testimonials.masonry( 'layout' );

					} );

				}

			}
		);

		// Load slides
		if ( typeof $.fn.elementalSlides === 'function' ) {
			$( '.showcase-wrapper' ).elementalSlides();
			$( '.showcase-header' ).elementalSlides(
				{
					group_selector: '.item',
					interval: 5000
				}
			);
		}

	} );

} )( jQuery );
