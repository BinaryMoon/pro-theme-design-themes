<?php
/**
 * Full width page template
 * Template Name: Full Width
 *
 * @package Vision
 */

	get_header();

	get_template_part( 'inc/featured-content' );

?>
<section class="row">
	<div class="full-width">
<?php
	if ( have_posts() ) {
		while ( have_posts() ) {
			the_post();
			get_template_part( 'content-page' );
		}
	}
?>
	</div>
</section>
<?php
	get_footer();