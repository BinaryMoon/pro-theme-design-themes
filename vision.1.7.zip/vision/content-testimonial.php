<?php
/**
 * Individual Testimonial layout
 *
 * @package Vision
 */

?>
<article id="post-<?php the_ID(); ?>" class="testimonial">
<?php
	the_post_thumbnail( 'vision-attachment' );
?>
	<div class="entry">
<?php
	the_content();
?>
		<h3><?php the_title(); ?></h3>
	</div>
</article>
