<?php
/**
 * Footer Template
 *
 * @package Vision
 */

?>
	</div>
<?php
	get_sidebar();

	if ( is_singular() ) {
?>
	</div>
<?php
	}
?>
</div><!--/container-->

<footer role="contentinfo" id="footer">
<?php
	if ( is_active_sidebar( 'sidebar-2' ) ) {
?>
	<aside class="footer-widgets">
		<?php dynamic_sidebar( 'sidebar-2' ); ?>
	</aside>
<?php
	}

	vision_social_links();
?>
	<hr />
	<section class="footer-wrap">
<?php
		if ( function_exists( 'the_privacy_policy_link' ) ) {
			the_privacy_policy_link( '', '<span class="sep"> | </span>' );
		}
?>
			<a href="http://wordpress.org/" title="<?php esc_attr_e( 'A Semantic Personal Publishing Platform', 'vision' ); ?>" rel="generator"><?php printf( __( 'Proudly powered by %s', 'vision' ), 'WordPress' ); ?></a>
			<span class="sep"> | </span>
			<?php printf( __( 'Theme: %1$s by %2$s.', 'vision' ), 'Vision', '<a href="https://prothemedesign.com/" rel="designer">Pro Theme Design</a>' ); ?>
	</section>
</footer>

<?php wp_footer(); ?>

</body>
</html>
