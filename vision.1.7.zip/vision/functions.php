<?php
/**
 * Reusable theme functions
 *
 * @package Vision
 */

require 'inc/custom-header.php';
require 'inc/jetpack.php';
require 'inc/class-customizer.php';

// This is the max width - it's the same on all pages,
// Keep in mind the theme is responsive so the width is likely to be narrower.
if ( ! isset( $content_width ) ) {
	$content_width = 705;
}


/**
 * Adjust the content width.
 *
 * @global int $content_width
 */
function vision_adjust_content_width() {

	global $content_width;

	if ( is_singular() && ! is_active_sidebar( 'sidebar-1' ) ) {
		$content_width = 860;
	}

	if ( is_page_template( 'custom-templates/full-width.php' ) ) {
		$content_width = 860;
	}

}

add_action( 'template_redirect', 'vision_adjust_content_width' );



/**
 * Enqueue all the styles
 *
 * @global type $wp_scripts
 */
function vision_enqueue() {

	wp_enqueue_style( 'vision-style', get_template_directory_uri() . '/styles/css/styles.css', null, '1.2' );
	wp_enqueue_style( 'genericons', get_template_directory_uri() . '/styles/genericons/genericons.css', array(), '3.0.3' );

	// Fonts.
	$fonts_url = vision_fonts();
	if ( $fonts_url ) {
		wp_enqueue_style( 'vision-fonts', $fonts_url, array(), '1.0' );
	}

	// Only enqueue slider if it's needed.
	if ( is_front_page() ) {
		wp_enqueue_script( 'vision-script-slider', get_template_directory_uri() . '/js/slider.js', array( 'jquery' ), '1.0.1', false );
	}

	if ( is_active_sidebar( 'sidebar-2' ) || is_post_type_archive( 'testimonial' ) ) {
		wp_enqueue_script( 'masonry' );
	}

	wp_enqueue_script( 'vision-script-superfish', get_template_directory_uri() . '/js/superfish.js', array( 'jquery' ), '1.0', false );
	wp_enqueue_script( 'vision-script-main', get_template_directory_uri() . '/js/main.js', array( 'jquery' ), '1.0', false );
	wp_enqueue_script( 'vision-script-responsive-navigation', get_template_directory_uri() . '/js/responsive-navigation.js', array( 'jquery', 'vision-script-main' ), '1.0', false );

	// Localized Javascript strings.
	wp_localize_script(
		'vision-script-main',
		'site_settings',
		array(
			'i18n' => array(
				'next' => esc_html__( 'Next', 'vision' ),
				'prev' => esc_html__( 'Previous', 'vision' ),
				'menu' => esc_html__( 'Menu', 'vision' ),
			),
		)
	);

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

}

add_action( 'wp_enqueue_scripts', 'vision_enqueue' );


/**
 * Set up all the theme properties and extras
 */
function vision_after_setup_theme() {

	load_theme_textdomain( 'vision', get_template_directory() . '/languages' );

	add_theme_support( 'automatic-feed-links' );

	// Post thumbnails.
	add_theme_support( 'post-thumbnails' );

	// Used for attachment (image.php) page links.
	add_image_size( 'vision-attachment', 100, 100, true );
	add_image_size( 'vision-archive', 340, 180, true );
	add_image_size( 'vision-featured', 720, 420, true );
	add_image_size( 'vision-testimonial-header', 1140, 350, true );
	add_image_size( 'vision-image-format', 340, 420, true );

	add_theme_support( 'title-tag' );

	// Custom background.
	$args = array(
		'default-color' => '1a1a1a',
	);
	add_theme_support( 'custom-background', $args );

	// HTML5 ftw.
	add_theme_support(
		'html5',
		array(
			'comment-list',
			'search-form',
			'comment-form',
		)
	);

	// Custom post formats.
	add_theme_support( 'post-formats', array( 'image' ) );

	register_nav_menu( 'top_menu', esc_html__( 'Top Menu', 'vision' ) );

	// Add support for full width images and other content such as videos.
	add_theme_support( 'align-wide' );

	// Disable custom font sizes, ensuring consistent vertical rhythm.
	add_theme_support( 'disable-custom-font-sizes' );

	// Make Gutenberg embeds responsive.
	add_theme_support( 'responsive-embeds' );

	// Editor font sizes.
	// Uses the default slugs to ensure consistency across themes.
	add_theme_support(
		'editor-font-sizes',
		array(
			array(
				'name' => esc_html__( 'small', 'vision' ),
				'size' => 10,
				'slug' => 'small',
			),
			array(
				'name' => esc_html__( 'normal', 'vision' ),
				'size' => 12,
				'slug' => 'normal',
			),
			array(
				'name' => esc_html__( 'medium', 'vision' ),
				'size' => 14,
				'slug' => 'medium',
			),
			array(
				'name' => esc_html__( 'large', 'vision' ),
				'size' => 16,
				'slug' => 'large',
			),
			array(
				'name' => esc_html__( 'huge', 'vision' ),
				'size' => 24,
				'slug' => 'huge',
			),
		)
	);

	// Add support for editor styles.
	add_theme_support( 'editor-styles' );

	// Editor Style.
	$fonts_url = vision_fonts();

	if ( $fonts_url ) {
		add_editor_style( $fonts_url );
	}

	add_editor_style( 'styles/css/editor-styles.css' );

}


/**
 * Enqueue WordPress theme styles within Gutenberg.
 */
function vision_editor_blocks_styles() {

	// Load the additional editor styles.
	// This covers things like the editor title that can't be styled with the normal editor styles.
	wp_enqueue_style( 'vision-editor-blocks', get_theme_file_uri( '/styles/css/editor-blocks.css' ), null, '1' );

	/**
	 * Overwrite Core theme styles with empty styles.
	 * @see https://github.com/WordPress/gutenberg/issues/7776#issuecomment-406700703
	 */
	wp_deregister_style( 'wp-block-library-theme' );
	wp_register_style( 'wp-block-library-theme', '' );

}

add_action( 'enqueue_block_editor_assets', 'vision_editor_blocks_styles' );
add_action( 'enqueue_block_assets', 'vision_editor_blocks_styles' );


/**
 * Get url for Google fonts.
 */
function vision_fonts() {

	/**
	 * Translators: If there are characters in your language that are not
	 * supported by Source Sans Pro, translate this to 'off'. Do not translate into your
	 * own language.
	 */
	$font = _x( 'on', 'Source Sans Pro font: on or off', 'vision' );
	if ( 'off' !== $font ) {
		$fonts['source-sans-pro'] = 'Source+Sans+Pro:400,700';
	}

	/**
	 * Translators: If there are characters in your language that are not
	 * supported, translate this to 'off'. Do not translate into your
	 * own language.
	 */
	$font = _x( 'on', 'Open Sans: on or off', 'vision' );
	if ( 'off' !== $font ) {
		$fonts['roboto-slab'] = 'Roboto Slab:400,700';
	}

	$fonts = apply_filters( 'vision_fonts', $fonts );

	if ( $fonts ) {

		$query_args = array(
			'family' => rawurlencode( implode( '|', $fonts ) ),
			'subset' => rawurlencode( 'latin,latin-ext' ),
			'display' => 'swap',
		);

		return add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );

	}

}


/**
 * Initialize Widgets
 */
function vision_widgets_init() {

	// Sidebar.
	register_sidebar(
		array(
			'name' => __( 'Sidebar Widgets', 'vision' ),
			'id' => 'sidebar-1',
			'description' => __( 'Widgets that display on the side of your website', 'vision' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h3 class="widgettitle">',
			'after_title' => '</h3>',
		)
	);

	// Footer.
	register_sidebar(
		array(
			'name' => __( 'Footer Widgets', 'vision' ),
			'id' => 'sidebar-2',
			'description' => __( 'Widgets that display at the bottom of your website', 'vision' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h3 class="widgettitle">',
			'after_title' => '</h3>',
		)
	);

}

add_action( 'widgets_init', 'vision_widgets_init' );


/**
 * Custom excerpt length
 *
 * @param int $length Default excerpt length.
 * @return int
 */
function vision_excerpt_length( $length ) {

	if ( has_post_thumbnail() ) {
		return 22;
	} else {
		return 82;
	}

}


/**
 * Add a standard class to menus.
 *
 * @param string $ulclass The menu html.
 * @return string
 */
function vision_add_menu_class( $ulclass ) {

	return preg_replace( '/<ul>/', '<ul id="nav">', $ulclass, 1 );

}


/**
 * Numeric pagination for custom queries
 * Much nicer than next and previous links :)
 *
 * @global $wp_query
 * @param int         $page_count The number of page links to display.
 * @param object|null $query The current page query to paginate.
 * @return void
 */
function vision_numeric_pagination( $page_count = 9, $query = null ) {

	if ( empty( $query ) ) {
		global $wp_query;
		$query = $wp_query;
	}

	if ( 1 >= $query->max_num_pages ) {
		return;
	}

	$big = 9999999999; // need an unlikely integer.

	echo '<div class="archive-pagination pagination">';
	echo paginate_links(
		array(
			'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
			'format' => '?paged=%#%',
			'current' => max( 1, get_query_var( 'paged' ) ),
			'total' => $query->max_num_pages,
			'end_size' => 0,
			'mid_size' => $page_count,
			'next_text' => __( 'Older &rsaquo;', 'vision' ),
			'prev_text' => __( '&lsaquo; Newer', 'vision' ),
		)
	);
	echo '</div>';

}


/**
 * Add additional body classes that may be helpful
 *
 * @param array $styles The default page styles.
 * @return string
 */
function vision_body_class( $styles ) {

	if ( is_singular() ) {
		$styles[] = 'singular';
	}

	if ( is_active_sidebar( 'sidebar-1' ) ) {
		$styles[] = 'themes-sidebar1-active';
	} else {
		$styles[] = 'themes-sidebar1-inactive';
	}

	if ( is_active_sidebar( 'sidebar-2' ) ) {
		$styles[] = 'themes-sidebar2-active';
	} else {
		$styles[] = 'themes-sidebar2-inactive';
	}

	return $styles;

}

/**
 * Calculate the time since posting in a human readable format.
 *
 * @return string
 */
function vision_human_time_diff() {

	$post_time = get_the_time( 'U' );
	$human_time = '';

	$time_now = gmdate( 'U' );

	/**
	 * Use human time if less that 60 days ago:
	 * 60 seconds * 60 minutes * 24 hours * 90 days.
	 */
	if ( $post_time > $time_now - ( 60 * 60 * 24 * 90 ) ) {
		// Translators: %s = The time duration. Eg 'hours' ago.
		$human_time = sprintf( __( '%s ago', 'vision' ), human_time_diff( $post_time, current_time( 'timestamp' ) ) );
	} else {
		$human_time = get_the_date();
	}

	return $human_time;

}


/**
 * Theme customizer properties
 *
 * @param object $wp_customize The WP Customize object.
 */
function vision_customizer_settings( $wp_customize ) {

	// Vision theme options section.
	$wp_customize->add_section(
		'vision_options',
		array(
			'title' => __( 'Theme', 'vision' ),
			'description' => __( 'Options for the Vision theme.', 'vision' ),
		)
	);

	// ---
	// Setting to select a category to set as featured in the main site content.
	$wp_customize->add_setting(
		'vision_header_height',
		array(
			'default' => 0,
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'vision_sanitize_height',
		)
	);

	// Control for hiding the category list under the header.
	$wp_customize->add_control(
		new Vision_Dropdown_Custom_control(
			$wp_customize,
			'vision_header_height',
			array(
				'label' => esc_html__( 'Homepage Header Height', 'vision' ),
				'section' => 'vision_options',
				'params' => array(
					0 => esc_html__( 'Small (default - messages will be hidden)', 'vision' ),
					1 => esc_html__( 'Medium', 'vision' ),
					2 => esc_html__( 'Tall', 'vision' ),
				),
			)
		)
	);

	// ---
	// setting to display the featured images on single post pages
	for ( $i = 1; $i <= 4; $i ++ ) {

		$wp_customize->add_setting(
			'vision_header_text_' . $i,
			array(
				'default' => '',
				'capability' => 'edit_theme_options',
				'sanitize_callback' => 'sanitize_text_field',
			)
		);

		$wp_customize->add_control(
			'vision_header_text_' . $i,
			array(
				// Translators: %d = number.
				'label' => sprintf( esc_html__( 'Home header text %d', 'vision' ), $i ),
				'section' => 'vision_options',
				'type' => 'text',
			)
		);

	}

}



/**
 * Sanitize alignment value
 * make sure it's an int
 *
 * @param int|string $setting Setting to turn into an int.
 * @return int
 */
function vision_sanitize_height( $setting ) {

	return (int) $setting;

}


/**
 * Replace "[...]" in the Read More link with a linked ellipsis.
 *
 * @param string $more The Read More text.
 */
function vision_excerpt_more( $more ) {

	if ( ! is_admin() ) {
		// Do a str replace so that the space is on the correct side in rtl languages.
		$more = str_replace( '[&hellip;]', '[<a href="' . get_the_permalink() . '">&hellip;</a>]', $more );
	}

	return $more;

}

add_filter( 'excerpt_more', 'vision_excerpt_more' );


add_action( 'customize_register', 'vision_customizer_settings' );
add_action( 'after_setup_theme', 'vision_after_setup_theme' );

add_filter( 'body_class', 'vision_body_class' );
add_filter( 'use_default_gallery_style', '__return_false' );
add_filter( 'excerpt_length', 'vision_excerpt_length', 999 );
add_filter( 'wp_page_menu', 'vision_add_menu_class' );


$themecolors = array(
	'bg'     => 'ffffff',
	'border' => 'eeeeee',
	'text'   => '666666',
	'link'   => 'aaaaaa',
	'url'    => 'aaaaaa',
);
