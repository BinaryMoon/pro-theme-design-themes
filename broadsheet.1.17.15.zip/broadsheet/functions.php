<?php
/**
 * Reusable theme functions
 *
 * @package Broadsheet
 */

require_once 'inc/custom-header.php';
require_once 'inc/jetpack.php';
require_once 'inc/class-custom-controls.php';
require_once 'inc/customizer.php';
if ( class_exists( 'WooCommerce' ) ) {
	require 'inc/woocommerce.php';
}

// Keep in mind the theme is responsive so the width is likely to be narrower.
if ( ! isset( $content_width ) ) {
	$content_width = 639;
}


/**
 * Work out content_width
 *
 * @global int $content_width
 */
function broadsheet_adjust_content_width() {

	global $content_width;

	if ( is_page_template( 'custom-templates/full-width.php' ) ) {

		$content_width = 780;

	} else {

		// Slightly unusual technique here.
		// But it's a simpler method than calculating the different combinations of sidebars.
		if ( ! is_active_sidebar( 'sidebar-1' ) ) {
			$content_width += 285;
		}

		if ( ! is_active_sidebar( 'sidebar-3' ) ) {
			$content_width += 190;
		}
	}

}

add_action( 'template_redirect', 'broadsheet_adjust_content_width' );


/**
 * Enqueue all the styles
 *
 * @global type $wp_scripts
 */
function broadsheet_enqueue() {

	wp_enqueue_style( 'broadsheet-style', get_stylesheet_uri(), null, '1.0' );
	wp_enqueue_style( 'genericons', get_template_directory_uri() . '/styles/genericons/genericons.css', array(), '3.0.3' );

	/**
	 * Translators: If there are characters in your language that are not
	 * supported by Neuton, translate this to 'off'. Do not translate into your
	 * own language.
	 */
	$font = broadsheet_fonts();

	if ( $font ) {
		wp_enqueue_style( 'broadsheet-style-neuton', $font, null, '1.0', 'all' );
	}

	if ( is_active_sidebar( 'sidebar-2' ) || is_post_type_archive( 'testimonial' ) ) {
		wp_enqueue_script( 'masonry' );
	}

	if ( get_theme_mod( 'broadsheet_primary_content_category', -2 ) > -2 ) {
		wp_enqueue_script( 'broadsheet-script-slider', get_template_directory_uri() . '/js/slider.js', array( 'jquery' ), '1.2', false );
	}

	wp_enqueue_script( 'broadsheet-script-main', get_template_directory_uri() . '/js/main.js', array( 'jquery' ), '1.0', false );

	wp_localize_script(
		'broadsheet-script-main',
		'js_i18n',
		array(
			'next' => esc_html__( 'next', 'broadsheet' ),
			'prev' => esc_html__( 'previous', 'broadsheet' ),
			'menu' => esc_html__( 'Menu', 'broadsheet' ),
		)
	);

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

}

add_action( 'wp_enqueue_scripts', 'broadsheet_enqueue' );


/**
 * Get url(s) for Google fonts
 *
 * @return string|boolean font url or false if there are no fonts
 */
function broadsheet_fonts() {

	$fonts = array();

	/**
	 * translators: If there are characters in your language that are not
	 * supported by Noto serif, translate this to 'off'. Do not translate into
	 * your own language.
	 */
	if ( 'off' !== esc_html_x( 'on', 'Noto Serif: on or off', 'broadsheet' ) ) {
		$fonts['neuton'] = 'Noto+Serif:400,400i,700,700i';
	}

	$fonts = apply_filters( 'broadsheet_fonts', $fonts );

	if ( $fonts ) {
		$query_args = array(
			'family' => implode( '|', $fonts ),
			'subset' => 'latin,latin-ext',
			'display' => 'swap',
		);

		return esc_url_raw( add_query_arg( $query_args, 'https://fonts.googleapis.com/css' ) );
	}

	return false;

}


/**
 * Set up all the theme properties and extras
 */
function broadsheet_after_setup_theme() {

	load_theme_textdomain( 'broadsheet', get_template_directory() . '/languages' );

	// Add feed links.
	add_theme_support( 'automatic-feed-links' );

	// Add selective refresh to widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );

	// Post thumbnails.
	add_theme_support( 'post-thumbnails' );

	// Used for attachment (image.php) page links.
	add_image_size( 'broadsheet-attachment', 120, 120, true );
	add_image_size( 'broadsheet-attachment-fullsize', 1200, 9999 );
	add_image_size( 'broadsheet-archive', 100, 80, true );
	add_image_size( 'broadsheet-archive-featured', 1200, 400, true );
	add_image_size( 'broadsheet-category-summary', 350, 150, true );
	add_image_size( 'broadsheet-feature', 260, 163, true );
	add_image_size( 'broadsheet-header', 1140, 500, true );
	add_image_size( 'broadsheet-logo', 360, 360, true );

	// Custom background.
	$args = array(
		'default-color' => apply_filters( 'broadsheet_background_color', 'ffffff' ),
	);
	add_theme_support( 'custom-background', $args );

	add_theme_support( 'title-tag' );

	// HTML5 FTW.
	add_theme_support(
		'html5',
		array(
			'comment-list',
			'search-form',
			'comment-form',
			'navigation-widgets',
		)
	);

	register_nav_menu( 'top_menu', esc_html__( 'Top Menu', 'broadsheet' ) );
	register_nav_menu( 'social_menu', esc_html__( 'Social Menu', 'broadsheet' ) );

	// Site logo.
	add_theme_support(
		'site-logo',
		array(
			'header-text' => array(
				'logo',
				'description',
			),
			'size' => 'broadsheet-logo',
		)
	);

	// Add support for full width images and other content such as videos.
	add_theme_support( 'align-wide' );

	// Disable custom font sizes, ensuring consistent vertical rhythm.
	add_theme_support( 'disable-custom-font-sizes' );

	// Make Gutenberg embeds responsive.
	add_theme_support( 'responsive-embeds' );

	// Editor font sizes.
	// Uses the default slugs to ensure consistency across themes.
	add_theme_support(
		'editor-font-sizes',
		array(
			array(
				'name' => esc_html__( 'small', 'broadsheet' ),
				'size' => 12.25,
				'slug' => 'small',
			),
			array(
				'name' => esc_html__( 'normal', 'broadsheet' ),
				'size' => 14.29,
				'slug' => 'normal',
			),
			array(
				'name' => esc_html__( 'medium', 'broadsheet' ),
				'size' => 16.33,
				'slug' => 'medium',
			),
			array(
				'name' => esc_html__( 'large', 'broadsheet' ),
				'size' => 24.5,
				'slug' => 'large',
			),
			array(
				'name' => esc_html__( 'huge', 'broadsheet' ),
				'size' => 32.66,
				'slug' => 'huge',
			),
		)
	);

	// Add support for editor styles.
	add_theme_support( 'editor-styles' );

	// Editor Style.
	$fonts_url = broadsheet_fonts();

	if ( $fonts_url ) {
		add_editor_style( $fonts_url );
	}

	add_editor_style( 'styles/css/editor-styles.css' );

}


/**
 * Enqueue WordPress theme styles within Gutenberg.
 */
function broadsheet_editor_blocks_styles() {

	// Load the additional editor styles.
	// This covers things like the editor title that can't be styled with the normal editor styles.
	wp_enqueue_style( 'broadsheet-editor-blocks', get_theme_file_uri( '/styles/css/editor-blocks.css' ), null, '1' );

	/**
	 * Overwrite Core theme styles with empty styles.
	 *
	 * @see https://github.com/WordPress/gutenberg/issues/7776#issuecomment-406700703
	 */
	wp_deregister_style( 'wp-block-library-theme' );
	wp_register_style( 'wp-block-library-theme', '' );

}

add_action( 'enqueue_block_editor_assets', 'broadsheet_editor_blocks_styles' );
add_action( 'enqueue_block_assets', 'broadsheet_editor_blocks_styles' );


/**
 * Initialise widgets
 */
function broadsheet_widgets_init() {

	// Sidebar.
	register_sidebar(
		array(
			'name' => esc_html__( 'Sidebar Widgets', 'broadsheet' ),
			'id' => 'sidebar-1',
			'description' => esc_html__( 'Widgets that display on the right hand side of your website', 'broadsheet' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h3 class="widgettitle">',
			'after_title' => '</h3>',
		)
	);

	// Footer widgets.
	register_sidebar(
		array(
			'name' => esc_html__( 'Footer Widgets', 'broadsheet' ),
			'id' => 'sidebar-2',
			'description' => esc_html__( 'Widgets that display at the bottom of your website. They are arranged in 4 columns and lined up automatically to make the best use of the space available.', 'broadsheet' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h3 class="widgettitle">',
			'after_title' => '</h3>',
		)
	);

	// Left widgets.
	register_sidebar(
		array(
			'name' => esc_html__( 'Small Left Widgets', 'broadsheet' ),
			'id' => 'sidebar-3',
			'description' => esc_html__( 'Widgets that display on the left hand side of the homepage and single blog posts and pages.', 'broadsheet' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s"><div class="widget-wrap">',
			'after_widget' => '</div></section>',
			'before_title' => '<h3 class="widgettitle">',
			'after_title' => '</h3>',
		)
	);

}

add_action( 'widgets_init', 'broadsheet_widgets_init' );


/**
 * Custom excerpt length
 *
 * @param int $length Default excerpt length.
 * @return int New excerpt length.
 */
function broadsheet_excerpt_length( $length ) {

	return 32;

}

add_filter( 'excerpt_length', 'broadsheet_excerpt_length', 18 );



/**
 * Add a consistent menu class to the site navigation
 *
 * @param string $ulclass Default menu html.
 * @return type
 */
function broadsheet_add_menu_class( $ulclass ) {

	return preg_replace( '/<ul>/', '<ul id="nav">', $ulclass, 1 );

}


/**
 * Numeric pagination for custom queries
 * Much nicer than next and previous links :)
 *
 * @global type $wp_query
 */
function broadsheet_numeric_pagination() {

	global $wp_query, $wp_rewrite;

	if ( 1 >= $wp_query->max_num_pages ) {
		return;
	}

	$paged = get_query_var( 'paged' ) ? intval( get_query_var( 'paged' ) ) : 1;
	$pagenum_link = html_entity_decode( get_pagenum_link() );
	$query_args = array();
	$url_parts = explode( '?', $pagenum_link );

	if ( isset( $url_parts[1] ) ) {
		wp_parse_str( $url_parts[1], $query_args );
	}

	$pagenum_link = remove_query_arg( array_keys( $query_args ), $pagenum_link );
	$pagenum_link = trailingslashit( $pagenum_link ) . '%_%';

	$format = $wp_rewrite->using_index_permalinks() && ! strpos( $pagenum_link, 'index.php' ) ? 'index.php/' : '';
	$format .= $wp_rewrite->using_permalinks() ? user_trailingslashit( $wp_rewrite->pagination_base . '/%#%', 'paged' ) : '?paged=%#%';

	// Set up paginated links.
	$links = paginate_links(
		array(
			'base'     => $pagenum_link,
			'format'   => $format,
			'total'    => $wp_query->max_num_pages,
			'current'  => $paged,
			'mid_size' => 5,
			'add_args' => array_map( 'urlencode', $query_args ),
			'next_text' => esc_html__( 'Older &rsaquo;', 'broadsheet' ),
			'prev_text' => esc_html__( '&lsaquo; Newer', 'broadsheet' ),
		)
	);

	if ( $links ) {
?>
	<nav class="archive-pagination pagination" role="navigation">
		<h1 class="screen-reader"><?php esc_html_e( 'Posts navigation', 'broadsheet' ); ?></h1>
		<?php echo $links; ?>
	</nav>
<?php
	}

}


/**
 * Add additional body classes that may be helpful
 *
 * @param array $styles Array of styles to add to.
 * @return array
 */
function broadsheet_body_class( $styles ) {

	if ( is_singular() ) {
		$styles[] = 'singular';
	}

	if ( is_active_sidebar( 'sidebar-1' ) ) {
		$styles[] = 'themes-sidebar1-active';
	} else {
		$styles[] = 'themes-sidebar1-inactive';
	}

	if ( is_active_sidebar( 'sidebar-2' ) ) {
		$styles[] = 'themes-sidebar2-active';
	} else {
		$styles[] = 'themes-sidebar2-inactive';
	}

	if ( is_active_sidebar( 'sidebar-3' ) ) {
		$styles[] = 'themes-sidebar3-active';
	} else {
		$styles[] = 'themes-sidebar3-inactive';
	}

	$category_summaries_quantity = apply_filters( 'broadsheet_display_category_summaries', get_theme_mod( 'broadsheet_display_category_summaries', 0 ) );
	$category_summaries = get_theme_mod( 'broadsheet_home_categories', null );

	if ( ( $category_summaries_quantity > 0 && null === $category_summaries ) || strlen( $category_summaries ) > 0 ) {
		$styles[] = 'themes-category-summaries-active';
	} else {
		$styles[] = 'themes-category-summaries-inactive';
	}

	if ( broadsheet_has_featured_posts() ) {
		$styles[] = 'themes-has-featured-posts';
	} else {
		$styles[] = 'themes-no-featured-posts';
	}

	$homepage_content = broadsheet_get_homepage_primary_content();

	if ( ! empty( $homepage_content ) ) {
		$styles[] = 'themes-has-primary-content';
	} else {
		$styles[] = 'themes-no-primary-content';
	}

	return $styles;

}


/**
 * Display site header image
 *
 * Will use the default WordPress site header, unless on a page that has a post
 * size that is large enough in which case that will be used instead
 */
function broadsheet_header() {

	$header_image = get_header_image();
	$header_image_width = get_theme_support( 'custom-header', 'width' );
	$header_image_actual_width = get_custom_header()->width;
	$header_image_actual_height = get_custom_header()->height;

	// Use custom headers on pages, but only if the image is large enough.
	if ( apply_filters( 'broadsheet_featured_image_header', is_page() ) ) {
		$image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'broadsheet-header' );
		if ( ! empty( $image ) && $image[1] >= $header_image_width ) {
			$header_image = esc_url( $image[0] );
			$header_image_actual_width = (int) $image[1];
			$header_image_actual_height = (int) $image[2];
		}
	}

	$header_image = apply_filters( 'broadsheet_header_image', $header_image );

	if ( ! empty( $header_image ) ) {
?>
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home" class="header-image">
			<img src="<?php echo esc_url( $header_image ); ?>" width="<?php echo (int) $header_image_actual_width; ?>" height="<?php echo (int) $header_image_actual_height; ?>" alt="" />
		</a>
<?php
	}

}


/**
 * Display the Featured categories
 *
 * Also adds a wrapper when the theme is viewed in the customizer. This is to
 * allow the customize partials to work.
 */
function broadsheet_category_list() {

	if ( is_customize_preview() ) {
		echo '<div class="broadsheet-category-list-preview">';
	}

	broadsheet_category_list_display();

	if ( is_customize_preview() ) {
		echo '</div>';
	}

}


/**
 * List of categories displayed on the homepage with thumbnails.
 */
function broadsheet_category_list_display() {

	// Category transient cache.
	$cache = get_transient( 'broadsheet_category_list' );

	// Should we update the cache.
	$set_cache = false;

	// The default quantity.
	$quantity = 3;

	/**
	 * Check for available cache.
	 * Clears cache when using customizer to make sure the values update when
	 * previewing.
	 */
	if ( empty( $cache ) || is_customize_preview() ) {
		$set_cache = true;
		$cache = array();
	}

	// See if categories are cached.
	if ( isset( $cache['categories'] ) ) {

		// Set categories to cached value.
		$categories = $cache['categories'];

	} else {

		/**
		 *  Load categories. This needs different methods depending upon the
		 *  version of the theme that was used to setup the categories.
		 */
		$categories = get_theme_mod( 'broadsheet_home_categories', null );

		// If new categories are not set then use the 'classic' method.
		if ( null === $categories ) {

			$quantity = (int) apply_filters( 'broadsheet_display_category_summaries', get_theme_mod( 'broadsheet_display_category_summaries', 0 ) );

			// Hide column if quantity set to 0.
			if ( 0 === $quantity ) {
				return;
			}

			$category_args = array(
				'orderby' => 'count',
				'order' => 'desc',
				'number' => $quantity,
				'hierachical' => 0,
			);

		} else {

			// Hide if there's no categories selected.
			if ( '' === $categories ) {
				return;
			}

			$category_args = array(
				'orderby' => 'include',
				'hierachical' => 0,
				'include' => explode( ',', $categories ),
			);

		}

		$categories = get_categories( $category_args );
		$cache['categories'] = $categories;

	}

	// Bail if no categories selected.
	if ( empty( $categories ) ) {

		// Flush cache if there's a cache set. No need to cache an empty query.
		if ( ! $set_cache ) {

			delete_transient( 'broadsheet_category_list' );

		}

		return;

	}

	// List of post ids to ignore - so that we don't get duplicate content being
	// displayed.
	$broadsheet_ignore_post_ids = array();

?>
	<div class="sidebar sidebar-category-summaries">
<?php
		$posts_per_page = (int) get_theme_mod( 'broadsheet_home_categories_quantity', 3 );

		if ( isset( $cache['category_posts'] ) ) {
			$cached_posts = $cache['category_posts'];
		} else {
			$cached_posts = array();
			$cache['category_posts'] = array();
		}

		foreach ( $categories as $i => $category ) {

			if ( isset( $cached_posts[ $i ] ) ) {

				$category_posts = $cached_posts[ $i ];

			} else {

				$args = array(
					'posts_per_page' => $posts_per_page,
					'cat' => $category->term_id,
					'meta_key' => '_thumbnail_id',
					'ignore_sticky_posts' => true,
					'post__not_in' => $broadsheet_ignore_post_ids,
				);

				$category_posts = new WP_Query( $args );
				$cache['category_posts'][ $i ] = $category_posts;

			}

			if ( $category_posts->have_posts() ) {
?>
		<div class="item item-category-<?php echo (int) $category->term_id; ?>">
			<h3><a href="<?php echo esc_url( get_category_link( $category->term_id ) ); ?>"><?php printf( esc_html__( '%s &raquo;', 'broadsheet' ), esc_html( $category->name ) ); ?></a></h3>
<?php
				while ( $category_posts->have_posts() ) {
					$category_posts->the_post();
					$broadsheet_ignore_post_ids[] = get_the_ID();
					get_template_part( 'inc/homepage-category-list' );
				}
?>
		</div>
<?php
			}

			wp_reset_postdata();

		}

		// Fallback in case there's not enough posts to display in the selected
		// categories.
		if ( count( $broadsheet_ignore_post_ids ) <= 0 ) {

			if ( isset( $cache['fallback_posts'] ) ) {

				$category_posts = $cache['fallback_posts'];

			} else {

				$args = array(
					'posts_per_page' => 3 * $quantity,
					'meta_key' => '_thumbnail_id',
					'ignore_sticky_posts' => true,
				);

				$category_posts = new WP_Query( $args );

			}

			// Another fallback in case there's no recent posts with images.
			// Without this there's likely to be an empty column.
			if ( ! $category_posts->have_posts() ) {

				$args = array(
					'posts_per_page' => 3 * $quantity,
					'ignore_sticky_posts' => true,
					'orderby' => 'comment_count',
					'order' => 'DESC',
					'date_query' => array(
						array(
							'column' => 'post_date_gmt',
							'after' => '4 months ago',
						),
					),
				);

				$category_posts = new WP_Query( $args );

			}

			// There's 2 types of fallback posts, however they both use the same
			// cache. Theres no need to keep 2 copies of different posts. If the
			// fallback cache is used then it will be loaded. This could also
			// reduce the number of WP_Queries in the event the fallback is
			// needed.
			$cache['fallback_posts'] = $category_posts;

			if ( $category_posts->have_posts() ) {
?>
		<div class="item">
<?php
				// Display a message to the user if there are no featured posts
				// for the chosen category. Helps to explain why the fallback
				// posts are being used.
				if ( is_customize_preview() ) {
?>
			<div class="warning">
				<?php esc_html_e( 'No suitable posts for the chosen categories so showing recent posts instead.', 'broadsheet' ); ?>
			</div>
<?php
				}

				while ( $category_posts->have_posts() ) {

					$category_posts->the_post();
					get_template_part( 'inc/homepage-category-list' );

				}
?>
		</div>
<?php
			}

			wp_reset_postdata();

		}
?>
	</div>
<?php

	// Set transient cache if needed.
	if ( $set_cache ) {

		set_transient( 'broadsheet_category_list', $cache, 24 * HOUR_IN_SECONDS );

	}

}


/**
 * Clear the category summary transient cache when a new post is published.
 */
function broadsheet_clear_category_list() {

	delete_transient( 'broadsheet_category_list' );

}

add_action( 'publish_post', 'broadsheet_clear_category_list' );


/**
 * Flush the category list cache whenever a post is published, trashed, or updated,
 * Also runs when a category is updated.
 *
 * @see https://codex.wordpress.org/Plugin_API/Action_Reference/post_updated
 * @see https://codex.wordpress.org/Plugin_API/Action_Reference/publish_post
 * @see https://codex.wordpress.org/Plugin_API/Action_Reference/trash_post
 * @see https://codex.wordpress.org/Plugin_API/Action_Reference/edited_$taxonomy
 */
function broadsheet_category_list_flush_cache() {

	delete_transient( 'broadsheet_category_list' );

}


/**
 * Fill empty post thumbnails with images from the first attachment added to a post
 *
 * @param type $html Image html.
 * @param type $post_id Post ID.
 * @param type $thumbnail_id Thumbnail Attachment ID.
 * @param type $size Thumbnail size.
 * @return string
 */
function broadsheet_post_thumbnail_html( $html, $post_id, $thumbnail_id, $size = '' ) {

	if ( empty( $html ) ) {

		$html = '';

		$values = get_attached_media( 'image', $post_id );

		if ( $values ) {
			foreach ( $values as $child_id => $attachment ) {
				$html = wp_get_attachment_image( $child_id, $size );
				break;
			}

			// Add image style.
			$html = str_replace( 'class="', 'class="wp-post-image ', $html );
		}
	}

	return $html;

}


/**
 * Get post thumbnail url
 * If a thumbnail doesn't exist then use the first attachment
 * reduces user confusion since they don't always understand the featured image functionality
 *
 * @param int    $post_id ID of post to get thumbnail for.
 * @param string $thumbnail_size Thumbnail key.
 * @return boolean|string false if no image, else url of thumbnail image
 */
function broadsheet_archive_image_url( $post_id = null, $thumbnail_size = 'broadsheet-archive' ) {

	if ( ! $post_id ) {
		$post_id = get_the_ID();
	}

	$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post_id ), $thumbnail_size );

	// If there's no featured image then grab an attachment image and use that instead.
	if ( ! $image || ! $image[0] ) {

		$values = get_attached_media( 'image', $post_id );

		if ( $values ) {
			foreach ( $values as $child_id => $attachment ) {
				$image = wp_get_attachment_image_src( $child_id, $thumbnail_size );
				break;
			}
		}
	}

	if ( $image ) {
		return $image;
	} else {
		return false;
	}

}


/**
 * Get homepage slider properties
 */
function broadsheet_get_homepage_primary_content() {

	$args = array();
	$primary_category = get_theme_mod( 'broadsheet_primary_content_category', -2 );

	$primary_category = (int) $primary_category;

	if ( -2 === $primary_category ) {
		return $args;
	}

	$args = array(
		'posts_per_page' => 6,
		'meta_key' => '_thumbnail_id',
		'ignore_sticky_posts' => true,
	);

	if ( $primary_category > 0 ) {
		$args['cat'] = $primary_category;
	}

	return apply_filters( 'broadsheet_slider', $args );

}


/**
 * Display the first category for the current post
 */
function broadsheet_the_main_category() {

	$category = get_the_category();

	if ( isset( $category[0] ) ) {
?>
<a href="<?php echo esc_url( get_category_link( $category[0]->term_id ) ); ?>" class="post-lead-category"><?php echo esc_html( $category[0]->cat_name ); ?></a>
<?php
	}

}


/**
 * Generate content to display in the footer
 */
function broadsheet_footer_content() {

	$items = array();

	// Categories.
	$args = array(
		'number' => 10,
		'order' => 'DESC',
		'hierachical' => 0,
		'orderby' => 'count',
	);
	$categories = get_categories( $args );

	if ( $categories ) {
		$category_list = array();
		foreach ( $categories as $category ) {
			$category_list[] = '<a href="' . esc_url( get_category_link( $category->term_id ) ) . '">' . $category->name . '</a>';
		}
		$items[] = '<li class="footer-top-categories">' . sprintf( __( '<strong>Top categories: </strong> %s', 'broadsheet' ), implode( '<span class="sep"> / </span>', $category_list ) ) . '</li>';
	}

	// Tags.
	$args = array(
		'number' => 10,
		'order' => 'DESC',
		'orderby' => 'count',
	);
	$terms = get_terms( 'post_tag', $args );

	if ( $terms ) {
		$term_list = array();
		foreach ( $terms as $term ) {
			$term_link = get_term_link( $term );
			if ( ! is_wp_error( $term_link ) ) {
				$term_list[] = ' <a href="' . $term_link . '">' . $term->name . '</a>';
			}
		}
		if ( $term_list ) {
			$items[] = '<li class="footer-top-tags">' . sprintf( __( '<strong>Top tags: </strong> %s', 'broadsheet' ), implode( '<span class="sep"> / </span>', $term_list ) ) . '</li>';
		}
	}

	// Social links.
	$social_links = broadsheet_social_links( false );
	if ( $social_links ) {
		$items[] = '<li class="footer-social-links">' . sprintf( __( '<strong>Social links: </strong> %s', 'broadsheet' ), $social_links ) . '</li>';
	}

	if ( ! empty( $items ) ) {
?>
		<ul class="footer-site-content-links">
			<?php echo implode( '', $items ); ?>
		</ul>
<?php
	}

}


/**
 * Display current date.
 *
 * The date is localised to the sites defined language.
 */
function broadsheet_display_date() {

	$time = '';

	$date_format = get_theme_mod( 'broadsheet_date_format', 'l, F jS, Y' );

	if ( ! empty( $date_format ) ) {
		// Use date_i18n for localized dates.
		$time = date_i18n( $date_format );
	}

	// Display the time.
	if ( ! empty( $time ) ) {
		echo '<span class="header-date">' . esc_html( $time ) . '</span>';
	}

}


/**
 * Display social links menu.
 */
function broadsheet_display_social_links() {

	$social_links = broadsheet_social_links( false );

	if ( $social_links ) {
		echo '<span class="sep">|</span>' . $social_links;
	}

}


add_action( 'after_setup_theme', 'broadsheet_after_setup_theme' );
add_action( 'post_updated', 'broadsheet_category_list_flush_cache' );
add_action( 'publish_post', 'broadsheet_category_list_flush_cache' );
add_action( 'trash_post', 'broadsheet_category_list_flush_cache' );
add_action( 'edit_category', 'broadsheet_category_list_flush_cache' );

add_filter( 'body_class', 'broadsheet_body_class' );
add_filter( 'use_default_gallery_style', '__return_false' );
add_filter( 'wp_page_menu', 'broadsheet_add_menu_class' );
add_filter( 'post_thumbnail_html', 'broadsheet_post_thumbnail_html', 10, 4 );
