<?php
/**
 * Jetpack Compatibility File
 * See: http://jetpack.me/
 *
 * @package Broadsheet
 */

/**
 * Add theme support for Infinite Scroll.
 * See: http://jetpack.me/support/infinite-scroll/
 */
function broadsheet_jetpack_init() {

	$settings = array(
		'container' => 'main-content',
		'footer_widgets' => (
			( function_exists( 'jetpack_is_mobile' ) && jetpack_is_mobile() )
			|| is_active_sidebar( 'sidebar-2' )
		),
		'footer' => 'footer-widgets',
	);

	add_theme_support( 'infinite-scroll', $settings );

	add_theme_support(
		'social-links',
		array(
			'facebook',
			'twitter',
			'linkedin',
			'tumblr',
			'google_plus',
		)
	);

	add_theme_support(
		'featured-content',
		array(
			'featured_content_filter' => 'broadsheet_get_featured_posts',
			'max_posts' => 4,
			'post_types' => array( 'post', 'page', 'jetpack-portfolio' ),
		)
	);

	add_theme_support( 'jetpack-testimonial' );

	add_theme_support( 'jetpack-responsive-videos' );

	// Add support for Jetpack content options.
	add_theme_support(
		'jetpack-content-options',
		array(
			'blog-display' => 'excerpt',
			'author-bio' => true,
			'author-bio-default' => false,
			'post-details' => array(
				'stylesheet' => 'broadsheet-style',
				'date' => '.postmetadata .text-on, .postmetadata a[rel=bookmark], .postmetadata .sep',
				'categories' => '.tax-categories, a.post-lead-category, .footer-top-categories',
				'tags' => '.tax-tags, .footer-top-tags',
				'author' => '.postmetadata .text-by, .postmetadata .author',
			),
		)
	);

}

add_action( 'after_setup_theme', 'broadsheet_jetpack_init' );


/**
 * Change default jetpack infinite scroll setttings
 *
 * @param array $settings Default IS settings.
 * @return array
 */
function broadsheet_infinite_scroll_js_settings( $settings ) {

	$settings['text'] = esc_html__( 'More Posts', 'broadsheet' );

	return $settings;

}

add_filter( 'infinite_scroll_js_settings', 'broadsheet_infinite_scroll_js_settings' );


/**
 * Get social links from jetpack publicise functionality
 * http://jetpack.me/support/social-links/
 *
 * @param boolean $echo True to output the social links, false to return them.
 */
function broadsheet_social_links( $echo = true ) {

	$links = '';

	$args = array(
		'theme_location' => 'social_menu',
		'echo' => false,
		'container' => '',
		'depth' => 1,
		'link_before' => '<span class="screen-reader">',
		'link_after' => '</span>',
		'fallback_cb' => '__return_false',
		'menu_class' => '',
	);

	$links = wp_nav_menu( $args );

	if ( empty( $links ) ) {

		$social_links = array(
			array(
				'slug' => 'twitter',
				'name' => __( 'Twitter', 'broadsheet' ),
			),
			array(
				'slug' => 'facebook',
				'name' => __( 'Facebook', 'broadsheet' ),
			),
			array(
				'slug' => 'google_plus',
				'name' => __( 'Google+', 'broadsheet' ),
			),
			array(
				'slug' => 'tumblr',
				'name' => __( 'Tumblr', 'broadsheet' ),
			),
			array(
				'slug' => 'linkedin',
				'name' => __( 'LinkedIn', 'broadsheet' ),
			),
		);

		foreach ( $social_links as $social ) {

			$url = get_theme_mod( 'jetpack-' . $social['slug'], '' );
			if ( $url ) {
				$links .= '<a href="' . esc_url( $url ) . '" class="' . esc_attr( 'social_link_' . $social['slug'] ) . '"><span>' . $social['name'] . '<span></a>';
			}
		}
	}

	if ( $links ) {

		$links = '<div class="social_links menu-social-links">' . $links . '</div>';

		if ( $echo ) {
			echo $links;
		} else {
			return $links;
		}
	}

	return false;

}


/**
 * Get the Jetpack featured posts
 */
function broadsheet_get_featured_posts() {

	return apply_filters( 'broadsheet_get_featured_posts', array() );

}


/**
 * Check if there are any Jetpack featured posts
 *
 * @param type $minimum Minimum number of posts to display.
 * @return boolean
 */
function broadsheet_has_featured_posts( $minimum = 1 ) {

	if ( is_paged() ) {
		return false;
	}

	$minimum = absint( $minimum );
	$featured_posts = apply_filters( 'broadsheet_get_featured_posts', array() );

	if ( ! is_array( $featured_posts ) ) {
		return false;
	}

	if ( $minimum > count( $featured_posts ) ) {
		return false;
	}

	return true;

}


/**
 * Get Jetpack Testimonials Title
 */
function broadsheet_testimonials_title() {

	$jetpack_options = get_theme_mod( 'jetpack_testimonials' );

	if ( ! empty( $jetpack_options['page-title'] ) ) {
		echo esc_html( $jetpack_options['page-title'] );
	} else {
		esc_html_e( 'Testimonials', 'broadsheet' );
	}

}


/**
 * Retrieve and format jetpack testimonials description as set in theme customiser
 *
 * @return string
 */
function broadsheet_testimonials_description() {

	$jetpack_options = get_theme_mod( 'jetpack_testimonials' );
	$content = '';

	if ( ! empty( $jetpack_options['page-content'] ) ) {
		$content = $jetpack_options['page-content'];
		$content = addslashes( $content );
		$content = wp_kses_post( $content );
		$content = stripslashes( $content );
		$content = wptexturize( $content );
		$content = convert_smilies( $content );
		$content = convert_chars( $content );
	}

	return $content;

}


/**
 * Get Jetpack Testimonials Image
 *
 * @return type
 */
function broadsheet_testimonials_image() {

	$jetpack_options = get_theme_mod( 'jetpack_testimonials' );
	$image = '';

	if ( ! empty( $jetpack_options['featured-image'] ) ) {
		$image = wp_get_attachment_image( (int) $jetpack_options['featured-image'], 'broadsheet-page-thumbnail' );
	}

	return $image;

}


/**
 * Flush rewrite rules for CPT on setup and switch
 */
function broadsheet_flush_rewrite_rules() {

	flush_rewrite_rules();

}

add_action( 'after_switch_theme', 'broadsheet_flush_rewrite_rules' );
