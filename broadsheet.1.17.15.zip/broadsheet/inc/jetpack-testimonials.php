<?php
/**
 * List Testimonials on a page
 *
 * @package Broadsheet
 */

	$testimonials = new WP_Query(
		array(
			'post_type'      => 'jetpack-testimonial',
			'orderby'        => 'rand',
			'posts_per_page' => 3,
			'no_found_rows'  => true,
		)
	);

	// Only display if there are some testimonials to display.
	if ( $testimonials->have_posts() ) {
?>
	<section class="testimonials-wrapper">
		<header>
			<h2 class="entry-title"><?php broadsheet_testimonials_title(); ?></h2>
			<a href="<?php echo esc_url( site_url( 'testimonial/' ) ); ?>" class="button"><?php esc_html_e( 'View All &rsaquo;', 'broadsheet' ); ?></a>
		</header>
		<div class="testimonials">
<?php
		while ( $testimonials->have_posts() ) {
			$testimonials->the_post();
			get_template_part( 'content-testimonial' );
		}
?>
		</div>
	</section>
<?php
	}

	wp_reset_postdata();
