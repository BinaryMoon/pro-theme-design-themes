<?php
/**
 * Add support for WooCommerce.
 *
 * @see https://wordpress.org/plugins/woocommerce/
 * @package broadsheet
 */

/**
 * Disable sidebar on WooCommerce pages
 *
 * @param  boolean $is_active_sidebar Current value of sidebar visibility.
 * @param  boolean $index             Sidebar to test.
 * @return boolean                    Whether to display the sidebar or not.
 */
function broadsheet_wc_is_sidebar_active( $is_active_sidebar, $index ) {

	if ( ! class_exists( 'WooCommerce' ) ) {
		return $is_active_sidebar;
	}

	if ( 'sidebar-1' === $index ) {

		// Not WooCommerce so return default.
		if ( ! broadsheet_is_woocommerce() ) {
			return $is_active_sidebar;
		}

		return false;

	}

	return $is_active_sidebar;

}

add_filter( 'is_active_sidebar', 'broadsheet_wc_is_sidebar_active', 10, 2 );


/**
 * Check to see if the current page is a WooCommerce page or not.
 *
 * @return boolean
 */
function broadsheet_is_woocommerce() {

	if ( ! class_exists( 'WooCommerce' ) ) {
		return false;
	}

	if ( is_woocommerce() ) {
		return true;
	}

	if ( is_account_page() ) {
		return true;
	}

	if ( is_checkout() || is_cart() ) {
		return true;
	}

	return false;

}
