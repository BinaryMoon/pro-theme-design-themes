<?php
/**
 * Attachment template
 *
 * @package Broadsheet
 */

/**
 * Theme colours for wp.com custom functionality
 *
 * @global string $themecolors
 */
function broadsheet_theme_colors() {

	global $themecolors;

	/**
	 * Set a default theme color array for WP.com.
	 *
	 * @global array $themecolors
	 */
	if ( ! isset( $themecolors ) ) {
		$themecolors = array(
			'bg'     => 'ffffff',
			'border' => 'eeeeee',
			'text'   => '333333',
			'link'   => '2980b9',
			'url'    => '999999',
		);
	}

}

add_action( 'after_setup_theme', 'broadsheet_theme_colors' );


/**
 * Dequeue Google Fonts if Custom Fonts are being used instead.
 */
function broadsheet_dequeue_fonts() {

	if ( class_exists( 'TypekitData' ) && class_exists( 'CustomDesign' ) && CustomDesign::is_upgrade_active() ) {
		$custom_fonts = TypekitData::get( 'families' );

		// Both body and header have to be custom fonts else neuton will still be needed.
		if ( $custom_fonts && $custom_fonts['headings']['id'] && $custom_fonts && $custom_fonts['body-text']['id'] ) {
			wp_dequeue_style( 'broadsheet-style-neuton' );
		}
	}

}

add_action( 'wp_enqueue_scripts', 'broadsheet_dequeue_fonts', 11 );


/**
 * Remove widont since it doesn't work properly with Neuton unfortunately
 */
function broadsheet_wido() {

	remove_filter( 'the_title', 'widont' );

}

add_action( 'init', 'broadsheet_wido' );
