<?php
/**
 * Custom header codes
 *
 * @package Broadsheet
 */

/**
 * Custom header image
 */
function broadsheet_custom_header_support() {

	// Custom header image.
	$args = array(
		'default-text-color' => apply_filters( 'broadsheet_header_textcolor', '000' ),
		'random-default' => false,
		'width' => apply_filters( 'broadsheet_header_width', 1140 ),
		'height' => apply_filters( 'broadsheet_header_height', 150 ),
		'flex-height' => true,
		'header-text' => true,
		'uploads' => true,
		'wp-head-callback' => 'broadsheet_colour_styles',
		'admin-head-callback' => '',
		'admin-preview-callback' => '',
	);
	add_theme_support( 'custom-header', $args );

}

add_action( 'after_setup_theme', 'broadsheet_custom_header_support' );


/**
 * Print custom header styles
 *
 * @return array
 */
function broadsheet_colour_styles() {

?>
<style>
<?php
	if ( 'blank' === get_header_textcolor() ) {
		if ( ! get_theme_mod( 'broadsheet_display_date_social', true ) ) {
?>
	.masthead {
		padding:0;
	}
<?php
		}
?>
	.masthead .branding h1.logo,
	.masthead .branding h2.description {
		clip: rect( 1px, 1px, 1px, 1px );
		position: absolute;
	}
<?php
	} else {
?>
	.masthead .branding h1.logo a,
	.masthead .branding h1.logo a:hover,
	.masthead .branding h2.description {
		color:#<?php echo esc_attr( get_header_textcolor() ); ?>;
	}
<?php
	}

	// Hide the date and social menu if in the customizer preview.
	// On the live site this is hidden with PHP, but this allows it to be
	// toggled with javascript.
	if ( is_customize_preview() ) {

		if ( ! get_theme_mod( 'broadsheet_display_date_social', true ) ) {
?>
	.masthead .postmetadata {
		display: none;
	}
<?php
		}
	}
?>
</style>
<?php

	return true;

}
