<?php
/**
 * Customize for category dropdowns, extends the WP customizer
 *
 * @package    Broadsheet
 */

if ( ! class_exists( 'WP_Customize_Control' ) ) {
	return null;
}

/**
 * A category selector control for the Customizer
 */
class Broadsheet_Category_Dropdown_Custom_control extends WP_Customize_Control {

	/**
	 * Render the control
	 */
	public function render_content() {

		$value = $this->value();
		if ( empty( $value ) ) {
			$value = -2;
		}
?>
	<label>
		<span class="customize-category-select-control customize-control-title"><?php echo esc_html( $this->label ); ?></span>
		<select <?php $this->link(); ?>>
			<option value="-2" <?php echo selected( $value, -2, false ); ?>><?php echo esc_html__( 'No Categories (Hide)', 'broadsheet' ); ?></option>
			<option value="-1" <?php echo selected( $value, -1, false ); ?>><?php echo esc_html__( 'All Categories', 'broadsheet' ); ?></option>
<?php
		$args = array();
		$cats = get_categories( $args );
		foreach ( $cats as $cat ) {
			echo '<option value="' . esc_attr( $cat->term_id ) . '"' . selected( $value, $cat->term_id, false ) . '>' . esc_html( $cat->name ) . '</option>';
		}
?>
		</select>
	</label>
<?php
	}
}


/**
 * A generic dropdown control that displays the parameters specified in the control options
 */
class Broadsheet_Dropdown_Custom_control extends WP_Customize_Control {

	/**
	 * The control parameters
	 *
	 * @var array
	 */
	public $params;

	/**
	 * Default value.
	 *
	 * @var [type]
	 */
	public $default;

	/**
	 * Create the control
	 *
	 * @param object $manager
	 * @param string $id
	 * @param array  $args
	 */
	public function __construct( $manager, $id, $args = array() ) {

		$this->params = $args['params'];
		$this->default = (int) $args['default'];
		parent::__construct( $manager, $id, $args );

	}

	/**
	 * Rence the control
	 */
	public function render_content() {

		$value = $this->value();

		if ( empty( $value ) ) {
			$value = $this->default;
		}
?>
	<label>
		<span class="customize-select-control customize-control-title"><?php echo esc_html( $this->label ); ?></span>
		<select <?php $this->link(); ?>>
<?php
	foreach ( $this->params as $k => $v ) {
?>
			<option value="<?php echo esc_attr( $k ); ?>" <?php echo selected( $value, $k, false ); ?>><?php echo esc_html( $v ); ?></option>
<?php
	}
?>
		</select>
	</label>
<?php
	}
}

/**
 * A custom control that creates a list of elements that you can rearrange with drag and drop
 */
class Broadsheet_DragDrop_List_Control extends WP_Customize_Control {

	/**
	 * The control type - for referencing in html
	 *
	 * @var string
	 */
	public $type = 'dragdrop-list';

	/**
	 * Construct the control
	 *
	 * @param type $manager
	 * @param type $id
	 * @param type $args
	 */
	public function __construct( $manager, $id, $args = array() ) {

		parent::__construct( $manager, $id, $args );

		add_action( 'customize_controls_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

	}


	/**
	 * Display list of checkboxes for categories
	 */
	public function render_content() {

		// Displays checkbox heading.
		echo '<span class="customize-control-title">' . esc_html( $this->label ) . '</span>';

		$values = explode( ',', $this->value() );

		// Displays selected items.
		echo '<ul class="broadsheet-sortable">';
		foreach ( get_categories() as $category ) {
			if ( in_array( $category->term_id, $values ) ) {
				echo '<li data-value="' . (int) $category->term_id . '">' . esc_html( $category->name ) . '</li>';
			}
		}
		echo '</ul>';

		// Displays selectable items.
		echo '<select class="broadsheet-dragdrop-select">';
		echo '<option disabled selected value="default">' . esc_html__( 'Select a category to display +', 'broadsheet' ) . '</option>';
		foreach ( get_categories() as $category ) {
			if ( ! in_array( $category->term_id, $values ) ) {
				echo '<option value="' . (int) $category->term_id . '">' . esc_html( $category->name ) . '</option>';
			}
		}
		echo '</select>';

		// Hidden input field that stores the saved category list.
?>
		<input type="hidden" id="<?php echo esc_attr( $this->id ); ?>" class="broadsheet-hidden-categories" <?php $this->link(); ?> value="<?php echo esc_attr( $this->value() ); ?>">
<?php
	}

	/**
	 * Enqueue control scripts
	 */
	public function enqueue_scripts() {

		wp_enqueue_script( 'jquery-ui-sortable' );
		wp_enqueue_script( 'broadsheet-theme-customizer', get_template_directory_uri() . '/js/customize-controls.js', array( 'jquery' ), '1.0', true );
		wp_enqueue_style( 'broadsheet-theme-customizer', get_template_directory_uri() . '/styles/css/customizer.css' );

	}
}
