<?php

/**
 * Color annotation for Broadsheet, by Pro Theme Design.
 */

add_color_rule(
	'bg',
	'#ffffff',
	array(
		// Page background.
		array( 'body', 'background-color' ),

		// Menu background.
		array( '.menu-primary .menu li ul.sub-menu, .menu-primary .menu li.current-menu-item a', 'background-color', 'bg', 8 ),
		array( '.menu-primary .menu li ul.sub-menu:before', 'border-bottom-color', 'bg', 8 ),

		// Menu link color.
		array( '.menu-primary .menu li ul.sub-menu, .menu-primary .menu li.current-menu-item a', 'color' ),
		array( '.menu-primary .menu li ul.sub-menu li a, .menu-primary .menu li ul.sub-menu li a:hover', 'color' ),

	),
	__( 'Background' )
);

add_color_rule(
	'fg1',
	'#1a1a1a',
	array(
		array( '.masthead .branding h1.logo a, .masthead .branding h1.logo a:hover, .masthead .branding h2.description', 'color', '#ffffff', 3 ),
		array( '.widget-title', 'color' ),
		array( '.menu', 'border-bottom-color' ),
	),
	__( 'Headings' )
);

add_color_rule(
	'fg2',
	'#f8fbfd',
	array(
		// Showcase.
		array( '.showcase', 'background' ),
		array( '.showcase', 'border-bottom-color', '-3' ),

		// Category summaries.
		array( '.sidebar-category-summaries .item h4 span', 'background-color', '-3' ),
		array( '.sidebar-category-summaries .item h4 span:hover', 'background-color', '-6' ),

		array( '.primary-content .primary-wrapper .item .image-meta', 'background-color', '-3' ),
		array( '.primary-content .primary-wrapper .item .image-meta:hover', 'background-color', '-6' ),
		array( '.text-by, .text-on, .commentcount, .primary-content .primary-wrapper .item .postmetadata', 'color', '#ffffff', 3 ),

		array( '.primary-content nav a.selected', 'background-color', '#ffffff', 3 ),

		array( '.main article a.post-lead-category', 'background-color' ),
		array( '.main article a.post-lead-category:hover', 'background-color', '-3' ),


		array( '.primary-content .primary-wrapper .item .image-meta', 'color', '#ffffff', '.4' ),
		// array( '.menu-primary .menu li ul.sub-menu li a', 'color', 'bg', 1 ),

		array( '.infinite-scroll #infinite-handle span, input[type=submit], .main .archive-pagination span.current, ol.commentlist li.comment .reply a, ol.commentlist li.trackback .reply a, ol.commentlist li.pingback .reply a', 'background-color', '#ffffff', 3 ),
		array( '.infinite-scroll #infinite-handle span, .infinite-scroll #infinite-handle span:hover, input[type=submit], input[type=submit]:hover, ol.commentlist li.comment .reply a:hover, ol.commentlist li.trackback .reply a:hover, ol.commentlist li.pingback .reply a:hover', 'background-color', '#ffffff', 3 ),
	),
	__( 'Showcase' )
);

add_color_rule( 'link', '#2980b9', array(
	array( 'a', 'color', '#ffffff' ),
	array( '.menu-primary .menu li a', 'color', '#ffffff' ),
	array( '.menu-primary .menu ul li a:before, ', 'color', '#ffffff', '.3' ),

	array( '.menu-primary .menu li.page_item_has_children > a:after, .menu-primary .menu li.menu-item-has-children > a:after', 'border-top-color', '#ffffff', 3 ),
	array( '.menu-primary .menu li.current-menu-item.page_item_has_children > a:after, .menu-primary .menu li.current-menu-item.menu-item-has-children > a:after', 'border-top-color', '#ffffff' ),
	array( '.showcase a, .showcase a:hover, .showcase a:visited', 'color', 'fg2' ),
	array( '.posttitle, .posttitle a', 'color', '#ffffff', 3 ),

) );

add_color_rule(
	'txt',
	'#ffffff',
	array(

		// array( '.menu-primary .menu li ul.sub-menu li a, .menu-primary .menu li ul.sub-menu li a:hover', 'color', 'bg' ),

		array( '.showcase .postmetadata, .showcase .text-by', 'color', 'fg2' ),
		array( '.showcase', 'color', 'bg', '#ffffff', '-6' ),


	array( 'h3.widgettitle:before, form.searchform button.searchsubmit', 'color', '#ffffff' ),

	array( '.postmetadata', 'color', '#ffffff' ),
	array( 'body', 'color', '#ffffff' ),

	array( 'blockquote', 'border-left-color' ),
	array( 'pre', 'color', 'bg', '10'),
	array( 'pre', 'background-color', '#ffffff' ),
	array( 'input[type=text]:focus, input[type=password]:focus, input[type=email]:focus, input[type=url]:focus, input.text:focus, textarea:focus, input.settings-input:focus', 'border-color', 5 ),

), __( 'Color' ) );



/* Adding extra CSS... */

add_theme_support( 'custom_colors_extra_css', 'broadsheet_extra_css' );
function broadsheet_extra_css() { ?>
	.sidebar-category-summaries .item h4 span{
		opacity: .9;
	}
	.infinite-scroll #infinite-handle span, input[type=submit], ol.commentlist li.comment .reply a, ol.commentlist li.trackback .reply a, ol.commentlist li.pingback .reply a{
		border: none;
		background-image: none;
	}
	.infinite-scroll #infinite-handle span:hover, input[type=submit]:hover, ol.commentlist li.comment .reply a:hover, ol.commentlist li.trackback .reply a:hover, ol.commentlist li.pingback .reply a:hover{
		border: none;
		background-image: none;
	}
	input[type=search]:focus, input[type=text]:focus, input[type=password]:focus, input[type=email]:focus, input[type=url]:focus, input.text:focus, textarea:focus, input.settings-input:focus {
		outline-color: #ffffff !important;
		-webkit-box-shadow: none;
		-moz-box-shadow: none;
		box-shadow: none;
		border: 1px solid #e6e6e6;
	}
	.primary-content nav a {
		background-color: #ccc;
	}
	.menu-primary .menu li ul.sub-menu li {
		border-bottom: 1px solid rgba(0, 0, 0, 0.05);
	}
	.showcase .text-by {
		opacity: 0.6;
	}
<?php
}
