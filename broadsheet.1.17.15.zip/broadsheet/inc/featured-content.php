<?php
/**
 * Jetpack Featured Content
 * See: http://jetpack.me/support/featured-content/
 *
 * @package Broadsheet
 */

	$display_page = (int) get_theme_mod( 'broadsheet_featured_content_display', 1 );

	// If display is set to homepage only, and we're not on the homepage then quit.
	if ( ! is_front_page() && 2 === $display_page ) {
		return;
	}

	if ( broadsheet_has_featured_posts() ) {
		$featured_posts = broadsheet_get_featured_posts( 4 );
?>
	<section class="showcase">
<?php
		$count = 0;
		foreach ( $featured_posts as $post ) {
			setup_postdata( $post );
			$image = get_the_post_thumbnail( get_the_ID(), 'broadsheet-feature' );
			$count ++;
?>
		<div class="item item-<?php echo (int) $count; ?>">
			<div class="entry">
<?php
			if ( $image ) {
?>
				<a href="<?php the_permalink(); ?>" class="thumbnail"><?php echo $image; ?></a>
<?php
			}
?>
				<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
				<div class="postmetadata">
<?php
	printf(
		__( '<span class="text-by">By</span> <span class="author vcard"><a class="url fn n" href="%1$s" title="%2$s" rel="author">%3$s</a></span>', 'broadsheet' ),
		esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
		// Translators: %s = author name.
		esc_attr( sprintf( __( 'View all posts by %s', 'broadsheet' ), get_the_author() ) ),
		get_the_author()
	);
?>
				</div>
			</div>
		</div>

<?php
		}
?>
	</section>
<?php
		wp_reset_postdata();
	}
