<?php
/**
 * Homepage category list
 *
 * @package Broadsheet
 */

	$image = broadsheet_archive_image_url( get_the_ID(), 'broadsheet-category-summary' );
	$style = '';
	if ( $image[0] ) {
		$style = 'background-image:url(' . $image[0] . ');';
	}
?>
			<h4>
				<a href="<?php the_permalink(); ?>" style="<?php echo $style; ?>" class="thumbnail">
					<span><?php the_title(); ?></span>
				</a>
			</h4>
