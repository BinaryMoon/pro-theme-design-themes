<?php
/**
 * Post terms
 *
 * @package Broadsheet
 */

?>
	<div class="taxonomies">
		<p class="tax-categories taxonomy">
<?php
	esc_html_e( 'Categories: ', 'broadsheet' );
	the_category( ', ' );
?>
		</p>
<?php

	// Display tags (if there are any).
	if ( get_the_tags() ) {
		the_tags( '<p class="tax-tags taxonomy">' . __( 'Tagged as: ', 'broadsheet' ), _x( ', ', 'Tag list seperator', 'broadsheet' ), '</p>' );
	}
?>
	</div>
