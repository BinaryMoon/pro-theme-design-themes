<?php
/**
 * Theme Customizer
 *
 * @package Broadsheet
 */

/**
 * Theme customizer properties
 *
 * @param object $wp_customize The wp_customize object.
 */


function broadsheet_customizer_settings( $wp_customize ) {

	// Broadsheet theme options section.
	$wp_customize->add_section(
		'broadsheet_options',
		array(
			'title' => esc_html__( 'Theme', 'broadsheet' ),
			'description' => esc_html__( 'Theme specific options.', 'broadsheet' ),
		)
	);

	// ---
	// setting to allow the date under the header to be hidden
	$wp_customize->add_setting(
		'broadsheet_display_date_social',
		array(
			'default' => true,
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'broadsheet_sanitize_checkboxes',
		)
	);

	// Control for hiding the category list under the header.
	$wp_customize->add_control(
		'broadsheet_display_date_social',
		array(
			'label' => esc_html__( 'Display Date and Social Links in Header', 'broadsheet' ),
			'section' => 'broadsheet_options',
			'type' => 'checkbox',
		)
	);

	// ---
	// setting to allow the date under the header to be hidden
	$wp_customize->add_setting(
		'broadsheet_date_format',
		array(
			'default' => 'l, F jS, Y',
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'wp_kses',
		)
	);

	// Control for hiding the category list under the header.
	$wp_customize->add_control(
		'broadsheet_date_format',
		array(
			'label' => esc_html__( 'Date Format', 'broadsheet' ),
			'description' => '<a href="https://wordpress.org/support/article/formatting-date-and-time/" target="_blank">' . esc_html__( 'Documentation on date and time formatting.', 'broadsheet' ) . '</a>',
			'section' => 'broadsheet_options',
			'type' => 'text',
		)
	);

	// ---
	// setting to select a category to set as featured in the main site content
	$wp_customize->add_setting(
		'broadsheet_primary_content_category',
		array(
			'default' => '-2',
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'broadsheet_sanitize_int',
		)
	);

	// Control for hiding the category list under the header.
	$wp_customize->add_control(
		new Broadsheet_Category_Dropdown_Custom_control(
			$wp_customize,
			'broadsheet_primary_content_category',
			array(
				'label' => esc_html__( 'Homepage Slider Category', 'broadsheet' ),
				'section' => 'broadsheet_options',
			)
		)
	);

	// Select categories to display in the homepage featured categories space.
	$wp_customize->add_setting(
		'broadsheet_home_categories',
		array(
			'default' => '',
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'broadsheet_sanitize_categories',
			'transport' => 'postMessage',
		)
	);

	$wp_customize->add_control(
		new Broadsheet_DragDrop_List_Control(
			$wp_customize,
			'broadsheet_home_categories',
			array(
				'label' => esc_html__( 'Featured Categories', 'broadsheet' ),
				'section' => 'broadsheet_options',
				'settings' => 'broadsheet_home_categories',
			)
		)
	);

	// Select categories to display in the homepage featured categories space.
	$wp_customize->add_setting(
		'broadsheet_home_categories_quantity',
		array(
			'default' => 3,
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'broadsheet_sanitize_featured_category_quantity',
			'transport' => 'postMessage',
		)
	);

	$wp_customize->add_control(
		'broadsheet_home_categories_quantity',
		array(
			'type' => 'number',
			'label' => esc_html__( 'Maximum Featured Category Amount', 'broadsheet' ),
			'section' => 'broadsheet_options',
			'settings' => 'broadsheet_home_categories_quantity',
			'input_attrs' => array(
				'min' => 1,
				'max' => 10,
				'step' => 1,
			),
		)
	);

	// Setting to chose where the featured content slider will appear.
	$wp_customize->add_setting(
		'broadsheet_featured_content_display',
		array(
			'default' => 1,
			'capability' => 'edit_theme_options',
			'sanitize_callback' => 'broadsheet_sanitize_int',
		)
	);

	// Control for changing the header height.
	$wp_customize->add_control(
		'broadsheet_featured_content_display',
		array(
			'label' => esc_html__( 'Display featured content on...', 'broadsheet' ),
			'section' => 'broadsheet_options',
			'type' => 'radio',
			'choices'  => array(
				1 => esc_html__( 'All pages (default)', 'broadsheet' ),
				2 => esc_html__( 'Homepage only', 'broadsheet' ),
			),
		)
	);

	// Setting to control whether featured image displays on blog posts.
	$wp_customize->add_setting(
		'broadsheet_display_featured_image_on_single',
		array(
			'default' => false,
			'capability' => 'edit_theme_options',
			'transport' => 'postMessage',
			'sanitize_callback' => 'broadsheet_sanitize_checkboxes',
		)
	);

	$wp_customize->add_control(
		'broadsheet_display_featured_image_on_single',
		array(
			'label' => esc_html__( 'Display the Feature image on single blog posts', 'broadsheet' ),
			'section' => 'broadsheet_options',
			'type' => 'checkbox',
		)
	);

	// Setting to control whether featured image displays on pages.
	$wp_customize->add_setting(
		'broadsheet_display_featured_image_on_page',
		array(
			'default' => false,
			'capability' => 'edit_theme_options',
			'transport' => 'postMessage',
			'sanitize_callback' => 'broadsheet_sanitize_checkboxes',
		)
	);

	$wp_customize->add_control(
		'broadsheet_display_featured_image_on_page',
		array(
			'label' => esc_html__( 'Display the Feature image on pages', 'broadsheet' ),
			'section' => 'broadsheet_options',
			'type' => 'checkbox',
		)
	);

}

add_action( 'customize_register', 'broadsheet_customizer_settings' );


/**
 * Update Theme Elements without refreshing content.
 *
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function broadsheet_register_customize_refresh( WP_Customize_Manager $wp_customize ) {

	// Ensure selective refresh is enabled.
	if ( ! isset( $wp_customize->selective_refresh ) ) {
		return false;
	}

	// Update site title.
	$wp_customize->get_setting( 'blogname' )->transport = 'postMessage';

	$wp_customize->selective_refresh->add_partial(
		'blogname',
		array(
			'selector' => '.masthead h1.logo',
			'render_callback' => function() {
				bloginfo( 'name' );
			},
		)
	);

	// Update site description.
	$wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';

	$wp_customize->selective_refresh->add_partial(
		'blogdescription',
		array(
			'selector' => '.masthead h2.description',
			'render_callback' => function() {
				bloginfo( 'description' );
			},
		)
	);

	// Show and hide header text.
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

	// Show and hide date and social menu.
	$wp_customize->get_setting( 'broadsheet_display_date_social' )->transport = 'postMessage';

	// Featured Categories.
	$wp_customize->selective_refresh->add_partial(
		'broadsheet_home_categories',
		array(
			'selector' => '.broadsheet-category-list-preview',
			'render_callback' => function() {
				broadsheet_category_list_display();
			},
		)
	);

	// Featured Categories Post Count.
	$wp_customize->selective_refresh->add_partial(
		'broadsheet_home_categories_quantity',
		array(
			'selector' => '.broadsheet-category-list-preview',
			'render_callback' => function() {
				broadsheet_category_list_display();
			},
		)
	);

}

add_action( 'customize_register', 'broadsheet_register_customize_refresh' );


/**
 * Binds JS handlers to make the Customizer preview reload changes asynchronously.
 */
function broadsheet_customize_preview_js() {

	wp_enqueue_script( 'broadsheet-customize-preview', get_template_directory_uri() . '/js/customize-preview.js', array( 'customize-preview' ), '1.0', true );

}

add_action( 'customize_preview_init', 'broadsheet_customize_preview_js' );


/**
 * Sanitize the featured category quantity.
 * Should be a number between 1 and 5 inclusive.
 *
 * @param int $amount Number of posts to display.
 * @return int
 */
function broadsheet_sanitize_featured_category_quantity( $amount ) {

	$amount = (int) $amount;

	$amount = min( $amount, 10 );
	$amount = max( $amount, 1 );

	return $amount;

}


/**
 * Sanitize checkbox
 *
 * @param int $setting The value of the checkbox to be checked.
 * @return int|string
 */
function broadsheet_sanitize_checkboxes( $setting ) {

	if ( 1 == $setting || true === $setting ) {
		return 1;
	} else {
		return '';
	}

}


/**
 * Sanitize integers (dropdown selects)
 *
 * @param int $setting Number.
 * @return int
 */
function broadsheet_sanitize_int( $setting ) {

	return (int) $setting;

}


/**
 * Sanitize category list
 * list is comma separated
 * so loop through all categories and make sure they are ints then join them back together again
 *
 * @param string $setting Comma separated list of category ids.
 * @return string comma separated list of category ids
 */
function broadsheet_sanitize_categories( $setting ) {

	$cats = explode( ',', $setting );
	$clean_cats = array();

	foreach ( $cats as $c ) {

		$c = (int) $c;

		if ( $c > 0 ) {
			$clean_cats[] = $c;
		}
	}

	return implode( ',', $clean_cats );

}


/**
 * The featured categories system was changed and so there may be an old property that is no longer needed
 * It's kept for backwards compatability - but if the new property is saved the old one should be removed
 * This will allow people to hide the featured categories column entirely
 */
function broadsheet_delete_options() {

	// Only remove the old option if the new option is set.
	if ( get_theme_mod( 'broadsheet_home_categories' ) ) {

		remove_theme_mod( 'broadsheet_display_category_summaries' );

	}

}

add_filter( 'customize_save_after', 'broadsheet_delete_options' );
