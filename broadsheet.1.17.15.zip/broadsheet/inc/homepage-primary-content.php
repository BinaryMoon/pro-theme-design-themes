<?php
/**
 * Homepage primary content
 *
 * @package Broadsheet
 */

	$args = broadsheet_get_homepage_primary_content();

	if ( ! empty( $args ) ) {

		$query = new WP_Query( $args );

		if ( $query->have_posts() ) {
?>
	<section class="primary-content">
		<div class="primary-wrapper">
<?php
			while ( $query->have_posts() ) {
				$query->the_post();

				$image = broadsheet_archive_image_url( get_the_ID(), 'broadsheet-archive-featured' );
				$style = '';
				if ( $image[0] ) {
					$style = 'background-image:url(' . $image[0] . ');';
				}
?>
		<article class="item">
<?php
				if ( $style ) {
?>
			<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>" class="thumbnail" style="<?php echo $style; ?>"></a>
			<div class="image-meta">
				<h2><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
				<?php get_template_part( 'inc/post-metadata' ); ?>
			</div>
<?php
				}
?>
		</article>
<?php
			}
?>
		</div>
	</section>
<?php
			wp_reset_postdata();
		}
	}
