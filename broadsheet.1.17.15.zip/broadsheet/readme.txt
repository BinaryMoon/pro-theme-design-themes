=== Broadsheet ===

Contributors: binarymoon
Requires at least: 4.1
Tested up to: 4.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: black, gray, white, light, one-column, two-columns, three-columns, four-columns, left-sidebar, right-sidebar, responsive-layout, custom-background, custom-colors, custom-header, custom-menu, featured-images, featured-image-header, flexible-header, full-width-template, infinite-scroll, post-slider, rtl-language-support, sticky-post, theme-options, translation-ready, blog, business, education, gaming, magazine, news, conservative, formal, industrial, minimal, professional, simple, site-logo

== Description ==

Broadsheet is a newspaper theme. With 3 optional widget areas, and a huge homepage slider there are lots of options for creating interesting, immersive websites.

[Theme documentation](https://prothemedesign.com/documentation/theme/broadsheet/)

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Broadsheet includes support for Styleguide - a plugin that allows you to change fonts, and colours in WordPress themes.

Broadsheet includes support for most features in Jetpack, including Infinite Scroll, Featured Content, and Site Logo.

== Changelog ==

= 1.17.15 - 18th September 2021 =
* Bug fix for theme build error.

= 1.17.14 - 26th July 2021 =
* Fix error with possible undefined image in featured content.
* Fix problem with featured content showing the wrong posts.

= 1.17.13 - 19th April 2021 =
* Remove override of WordPress global.
* Add comments to help translators with localization.

= 1.17.12 - 2nd April 2021 =
* Fix text input width.

= 1.17.11 - 31st January 2021 =
* Clear html widget to prevent floated content from breaking the layout.

= 1.17.10 - 3rd January 2021 =
* Fix default header date format so it displays correctly. The date format can still be changed in the customizer.
* Update date format docs link to point to the latest WP documentation.

= 1.17.9 - 1st January 2021 =
* Tweak block image margins.
* Fix mobile menu colours.
* Update javascript for JQuery 3.
* Tidy JS.

= 1.17.8 - ? =
* Oops - think I skipped a version number here :)

= 1.17.7 - 18th November 2020 =
* Make links readable in paragraphs where the text colour has been changed.

= 1.17.6 - 27th October 2020 =
* Add 'navigation-widgets' to supported html5 types.

= 1.17.5 - 5th October 2020 =
* Add support for wp_body_open.

= 1.17.4 - 11th July 2020 =
* Fix infinite scroll button styles.
* Improve RTL styles.

= 1.17.3 - 9th July 2020 =
* Remove use of deprecated Jetpack function `is_ipad`.

= 1.17.2 - 28th June 2020 =
* Tweak comment reply and reply cancel button styles to make them more readable & reliable.

= 1.17.1 - 26th June 2020 =
* Increase number of posts allowed in featured categories.
* Extend category summary cache for 24 hours, and clear the cache when a new post is published.

= 1.17 - 11th March 2020 =
* Add support for Gutenberg functionality.
* Hide footer 'top tags' and 'top categories' using content options.

= 1.16.3 - 21st February 2020 =
* Tweak heading sizes in post content to add a bit more contrast and improve readability.

= 1.16.2 - 12th February 2020 =
* Adjust WooCommerce category header image changes to use the page header image rather than the site header image.
* Hide right hand sidebar on WooCommerce pages.
* Remove bottom margin on figures inside wp-block-image.
* add class to comment count separator to make it easier to target with custom css.

= 1.16.1 - 6th February 2020 =
* Fix problem with WooCommerce change.

= 1.16 - 5th February 2020 =
* Add support for WooCommerce category images

= 1.15.6 - 29th December 2019 =
* Tweak size of margins on tables for consistency.

= 1.15.5 - 9th November 2019 =
* Fix sizing overflow issue with small devices related to infinite scroll.
* Fix bug with showcase sizing on small devices.

= 1.15.4 - 4th October 2019 =
* Add styles for figcaptions to differentiate content from paragraphs.
* Add more consistent margins for image and gallery blocks.

= 1.15.3 - 12th September 2019 =
* Tweak the homepage layout so that the small left sidebar never gets hidden, even on small screens.

= 1.15.2 - 25th June 2019 =
* Tweak button styles so they match input[type=submit] styles.

= 1.15.1 - 15th May 2019 =
* Add font display swap to Google Font loading, to increase font display speed.
* Make paragraph, list, and blockquote margins consistent in blog posts.

= 1.15 - 2nd February 2019 =
* Add support for featured images on pages.

= 1.14.1 - 9th January 2019 =
* Tweak slider font size on small screens so it doesn't take up so much space.

= 1.14 - 9th November 2018 =
* Improve coding standards.
* Escape more things.
* Update browser prefixes.

= 1.13 - 26th June 2018 =
* Increase size of featured image so that it can fill the entire width of the featured content space. Uses the same ratio (and size is fixed with css) so existing layouts will not change.
* Add filter to the slider parameters so that we can edit the number of posts in the slider (and other params) in a plugin.
* Add option to enable featured images on single blog posts.

= 1.12 - 25th May 2018 =
* Add support for privacy policy link in the site footer.
* Fix display of the cookie consent checkbox in the comments form.

= 1.11 - 1st April 2018 =
* Make credits editable in the customizer (.org only)

= 1.10.2 - 30th November 2017 =
* Improve display of full blog posts on archive pages when using Jetpack content options.

= 1.10.1 - 6th November 2017 =
* Improve styles for responsive menus.

= 1.10 - 2nd November 2017 =
* Add support for localized dates in the site header. Supports previously saved settings.

= 1.9 - 1st November 2017 =
* Add setting to allow featured content to be displayed on the homepage only/ on all pages as happens currently.

= 1.8.1 - 1st October 2017 =
* Add footer credits filter to allow footer credits to be edited through custom plugin.

= 1.8 - 20th July 2017 =
* Add support for Jetpack content options to allow altering of some website content.
* Includes support for adding the Author Bio on single blog posts.
* Extra escaping

= 1.7 - 13th July 2017 =
* Remove include for inc/wpcom.php, since it's automatically included by WordPress.com sites
* Minor tweaks to css styles to improve readability

= 1.6 - 5th July 2017 =
* General style tweaks to improve spacing and consistency across the theme.
* Fix issues with social widgets being too wide.

= 1.5.1 - 19th January 2017 =
* Remove console.log from customizer code
* Add body class when featured categories change to ensure the layout flows properly
* Display a message in the customizer if the fallback posts are used in the featured categories to make it clearer why they are being used.
* Delete theme-customizer.js which has been superseded.

= 1.5 - 13th January 2017 =
* Add transient caching to featured categories to improve site speed
* Make customizer previews work in real time
* Make widgets easier to edit in the customizer
* Tidy customizer code
* Improve footer widget masonry loading
* Tidy codes

= 1.4.6 - 20th December 2016 =
* Add a filter so that users can enable the featured content header on more post formats (and not just pages which is the default)
* tidy codes and sanitize some translations

= 1.4.5 - 31st October 2016 =
* Make attachment pages display in the loop so that content and excerpts display correctly
* Tweak attachment page display to be more attractive (improve whitespace)

= 1.4.4 - 15th September 2016 =
* tweak wordwrap css
* fix attachment page layout
* increase size of image on image.php page so that it shows the image off better
* remove css box-shadow prefixes

= 1.4.3 - 2nd August 2016 =
* Add support for auto updates (self hosted version only)

= 1.4.2 - 1st August 2016 =
* tweak css styles for site logo and featured category column
* improve site footer if there's no javascript enabled or a javascript error

= 1.4.1 - 16th July 2016 =
* Some code formatting and tidying up

= 1.4 - 26 May 2016 =
* Tweak responsive styles so that they start earlier, which means they work on an ipad. This improves the menu usage on tablets.
* Improve responsive menu behavior on touch devices
* Improve jetpack subscription form styles so that they display out more nicely

= 1.3.1 =
* Add support for pages and projects to featured content

= 1.3 =
* Add a new customizer option that lets users select how many posts appear in the featured categories

= 1.2.4 =
* increase size of logo so that it can be adjusted with css

= 1.2.3 =
* Fix issue with image attachments
* Fix issue with responsive sizes
* Add additional classes to footer links to allow easier targeting with css

= 1.2.2 =
* Add next and previous arrows to postnav

= 1.2.1 =
* Make the slider work better on small screens

= 1.2 =
* Remove duplicate title tag in head
* Improve coding standards
* Tweaks and improvements to CSS
* Fix bug that only happens on older versions of PHP

= 1.1.4 =
* Fix undefined variable errors related to Testimonials
* Fix some css issues with image alignment

= 1.1.3 =
* make comments show the short_ping format again - it was changed in core so that a different layout is used by default

= 1.1.2 =
* add wrapper around the date in the header so that the date can be hidden with css
* some more css tweaks to improve reading in widgets

= 1.1.1 =
* tweak size of paragraph margins to make things read a bit more nicely
* make padding consistent on sidebars when there are no featured posts or primary content displayed

= 1.1 =
* Fix bug that has happened because of a change to the featured categories

= 1.0 =
* Initial release

== Credits ==

* [Noto Serif](https://www.google.com/fonts/specimen/Noto+Serif) Font from Google Fonts, licensed under [Apache License, version 2.0](http://www.apache.org/licenses/LICENSE-2.0.html).
* Genericons: font by Automattic (http://automattic.com/), licensed under [GPL2](https://www.gnu.org/licenses/gpl-2.0.html)
