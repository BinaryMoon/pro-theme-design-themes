<?php
/**
 * Single post content
 *
 * @package Broadsheet
 */

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<?php

	if ( get_theme_mod( 'broadsheet_display_featured_image_on_single', 0 ) || is_customize_preview() ) {
		get_template_part( 'archive-header-image' );
	}

	broadsheet_the_main_category();

	the_title( '<h1 class="title">', '</h1>' );

	get_template_part( 'inc/post-metadata' );

?>
	<section class="entry">
<?php
	the_content();

	edit_post_link();

	wp_link_pages(
		array(
			'before' => '<div class="archive-pagination">' . esc_html__( 'Pages: ', 'broadsheet' ),
			'after'  => '</div>',
			'link_before' => '<span>',
			'link_after'  => '</span>',
		)
	);

	get_template_part( 'inc/post-terms' );
?>
	</section>
</article>
<?php
	$prev = get_previous_post_link( '%link' );
	$next = get_next_post_link( '%link' );
?>
<nav class="postnav">
	<h1 class="screen-reader"><?php esc_html_e( 'Post navigation', 'broadsheet' ); ?></h1>
<?php
	if ( $prev ) {
?>
	<div class="prev">
		<span class="more-link"><?php echo $prev; ?></span>
	</div>
<?php
	}

	if ( $next ) {
?>
	<div class="next">
		<span class="more-link"><?php echo $next; ?></span>
	</div>
<?php
	}
?>
</nav>
<?php
	if ( function_exists( 'jetpack_author_bio' ) ) {
		jetpack_author_bio();
	}
