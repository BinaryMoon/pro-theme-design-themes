<?php
/**
 * Individual Testimonial layout
 *
 * @package Broadsheet
 */

?>
<article id="post-<?php the_ID(); ?>" class="testimonial">
	<footer>
<?php
	the_post_thumbnail( 'broadsheet-attachment' );
?>
		<h3><?php the_title(); ?></h3>
	</footer>
	<div class="entry">
<?php
	the_content();
?>
	</div>
</article>
