/**
 * Live-update changed settings in real time in the Customizer preview.
 *
 * Filename: customizer-preview.js v1
 *
 * Created by Ben Gillbanks <https://prothemedesign.com/>
 * Available under GPL2 license
 *
 * @link https://developer.wordpress.org/themes/advanced-topics/customizer-api/#javascript-driven-widget-support
 *
 * @package Granule
 */

/* global jQuery, document, wp */

; ( function( $, document ) {

	$( document ).ready(
		function() {

			// Site title.
			wp.customize(
				'blogname',
				function( value ) {
					value.bind(
						function( to ) {
							$( '.masthead h1.logo' ).text( to );
						}
					);
				}
			);

			// Site description.
			wp.customize(
				'blogdescription',
				function( value ) {
					value.bind(
						function( to ) {
							$( '.masthead h2.description' ).text( to );
						}
					);
				}
			);

			// Header text color.
			wp.customize(
				'header_textcolor',
				function( value ) {
					value.bind(
						function( to ) {
							if ( 'blank' === to ) {
								$( '.masthead .branding h1.logo, .masthead .branding h2.description' ).css(
									{
										'clip': 'rect(1px, 1px, 1px, 1px)',
										'position': 'absolute'
									}
								);
							} else {
								$( '.masthead .branding h1.logo, .masthead .branding h2.description' ).css(
									{
										'clip': 'auto',
										'position': 'relative'
									}
								);

								$( '.masthead .branding h1.logo a, .masthead .branding h1.logo a:hover, .masthead .branding h2.description' ).css(
									{
										'color': to
									}
								);
							}
						}
					);
				}
			);

			// Display date and social menu.
			wp.customize(
				'broadsheet_display_date_social',
				function( value ) {
					value.bind(
						function( to ) {
							if ( to ) {
								$( '.masthead .postmetadata' ).show();
							} else {
								$( '.masthead .postmetadata' ).hide();
							}
						}
					);
				}
			);

			// Show/ Hide featured image on single psots.
			wp.customize(
				'broadsheet_display_featured_image_on_single',
				function( value ) {

					var $image = $( 'img.post-header-image' );

					$image.hide();

					if ( value._value ) {
						$image.show();
					}

					value.bind(
						function( to ) {

							if ( to ) {
								$image.show();
							} else {
								$image.hide();
							}

						}
					);
				}
			);

			// Show/ Hide featured image on pages.
			wp.customize(
				'broadsheet_display_featured_image_on_page',
				function( value ) {

					var $image = $( 'img.post-header-image' );

					$image.hide();

					if ( value._value ) {
						$image.show();
					}

					value.bind(
						function( to ) {

							if ( to ) {
								$image.show();
							} else {
								$image.hide();
							}

						}
					);
				}
			);

			// Reorder featured categories.
			wp.customize(
				'broadsheet_home_categories',
				function( value ) {
					value.bind(
						function( to ) {

							// Add and remove body classes to ensure correct layout.
							if ( '' === to ) {
								$( 'body' ).addClass( 'themes-category-summaries-inactive' );
								$( 'body' ).removeClass( 'themes-category-summaries-active' );
								$( '.broadsheet-category-list-preview' ).css(
									{
										'clip': 'rect(1px, 1px, 1px, 1px)',
										'position': 'absolute'
									}
								);
							} else {
								$( 'body' ).addClass( 'themes-category-summaries-active' );
								$( 'body' ).removeClass( 'themes-category-summaries-inactive' );
								$( '.broadsheet-category-list-preview' ).css(
									{
										'clip': 'auto',
										'position': 'relative'
									}
								);
							}

							$( '.sidebar-category-summaries' ).orderChildren( to, '.item-category-' );

						}
					);
				}
			);

		}
	);

	// Sort contents of container based on comma separated string of ids.
	$.fn.orderChildren = function( order, element_prefix ) {

		this.each(
			function() {

				order = order.split( ',' );

				var $this = $( this );

				for ( var i = order.length; i >= 0; i-- ) {
					var item = element_prefix + parseInt( order[ i ] );
					$this.prepend( $this.children( item ) );
				}

			}
		);

		return this;

	};

} )( jQuery, document );
