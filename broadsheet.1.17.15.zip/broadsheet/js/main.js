/**
 * main.js v1
 * Created by Ben Gillbanks <http://www.binarymoon.co.uk/>
 * Available under GPL2 license
 */

; ( function( $ ) {

	// js mobile detection
	var is_touch_device = function() {

		return ( ( 'ontouchstart' in window ) || ( navigator.MaxTouchPoints > 0 ) || ( navigator.msMaxTouchPoints > 0 ) );

	};


	$( document ).ready( function() {

		// attachment page navigation
		if ( $( 'body' ).hasClass( 'attachment' ) ) {

			$( document ).keydown( function( e ) {

				if ( $( 'textarea, input' ).is( ':focus' ) ) {
					return;
				}

				var url = false;

				switch ( e.which ) {
					// left arrow key (previous attachment)
					case 37:
						url = $( '.image-previous a' ).attr( 'href' );
						break;

					// right arrow key (next attachment)
					case 39:
						url = $( '.image-next a' ).attr( 'href' );
						break;

				}

				if ( url ) {
					window.location = url;
				}
			} );

		}

		// Masonry
		$( window ).on(
			'load',
			function() {

				// Arrange footer widgets
				if ( typeof $.fn.masonry === 'function' ) {

					var $footer_widgets = null;

					$footer_widgets = $( 'footer#footer .footer-widgets' ).masonry(
						{
							itemSelector: '.widget',
							gutter: 0,
							isOriginLeft: !$( 'body' ).is( '.rtl' )
						}
					);

					// Update again once images have loaded.
					$footer_widgets.imagesLoaded(
						function() {

							$footer_widgets.masonry( 'layout' );

						}
					);

					// Reflow widgets after 2 seconds to ensure the correct position
					// due to dynamic widgets like facebook and twitter loading.
					setTimeout(
						function() {
							$footer_widgets.masonry( 'layout' );
						},
						2000
					);

					// Reflow Footer Widgets if changed in the Customizer.
					if ( 'undefined' !== typeof wp && wp.customize && wp.customize.selectiveRefresh ) {

						wp.customize.selectiveRefresh.bind(
							'sidebar-updated',
							function( sidebarPartial ) {
								if ( 'sidebar-2' === sidebarPartial.sidebarId ) {
									$footer_widgets.masonry( 'reloadItems' );
									$footer_widgets.masonry( 'layout' );
								}
							}
						);

					}

					$( 'body.archive .testimonials' ).imagesLoaded( function() {
						$( 'body.archive .testimonials' ).masonry( {
							itemSelector: '.testimonial',
							gutter: 0,
							isOriginLeft: !$( 'body' ).is( '.rtl' )
						} );
					} );
				}

			}
		);

		// Allow menu items to trigger properly on touch devices
		$.fn.touchTwice = function() {

			if ( !is_touch_device() ) {
				return;
			}

			this.each( function() {

				// Current clicked item
				var $curItem = false;

				// Element clicked
				$( this ).on( 'click', function( e ) {

					var $item = $( this );

					// The item clicked is not the currently active item so cancel the default behaviour
					if ( $item[ 0 ] !== $curItem[ 0 ] ) {

						e.preventDefault();
						$curItem = $item;

					}

				} );

				// On click outside of menu - reset menu
				$( document ).on( 'click touchstart MSPointerDown', function( e ) {

					var resetItem = true;
					var $parents = $( e.target ).parents();

					// Ensure it's not the menu being clicked
					for ( var i = 0; i < $parents.length; i++ ) {

						// It's a child of the menu so let's not reset now
						if ( $parents[ i ] === $curItem[ 0 ] ) {
							resetItem = false;
						}

					}

					if ( resetItem ) {
						$curItem = false;
					}

				} );

			} );

			return this;

		};


		// Load slides
		if ( typeof $.fn.elementalSlides === 'function' ) {
			$( '.primary-wrapper' ).elementalSlides( {
				'nav_arrows': true
			} );
		}

		// responsive navigation
		$( '.menu-toggle' ).on( 'click', function() {
			$( this ).parent().toggleClass( 'menu-on' );
		} );

		// Add focus class on touch devices
		$( '.menu' ).find( 'a' ).on( 'focus blur', function() {
			$( this ).parents().toggleClass( 'focus' );
		} );

		// Allow
		$( '.menu li:has(ul)' ).touchTwice();

	} );

} )( jQuery );
