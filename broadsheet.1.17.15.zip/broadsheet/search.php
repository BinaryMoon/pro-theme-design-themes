<?php
/**
 * Search results template
 *
 * @package Broadsheet
 */

	get_header();
?>
	<h1 class="title">
<?php
		// Translators: %s = search query.
		printf( __( 'Search results for &#8216;<em>%s</em>&#8217;', 'broadsheet' ), get_search_query() );
?>
	</h1>

	<div id="main-content">
<?php
	if ( have_posts() ) {
		while ( have_posts() ) {

			the_post();
			get_template_part( 'content', get_post_format() );

		}
	} else {

		get_template_part( 'content-empty' );

	}

	broadsheet_numeric_pagination();
?>
	</div>
<?php
	get_footer();
