<?php
/**
 * Author post listing
 *
 * @package Broadsheet
 */

	get_header();
	$user_id = get_query_var( 'author' );
?>
	<h1 class="title"><?php esc_html_e( 'Author Archives', 'broadsheet' ); ?></h1>
	<div id="main-content">
		<div class="writer">
			<?php echo get_avatar( get_the_author_meta( 'user_email', $user_id ), '80' ); ?>
			<h3><?php the_author_meta( 'display_name', $user_id ); ?></h3>
			<?php echo wpautop( get_the_author_meta( 'description', $user_id ) ); ?>
		</div>
<?php
	if ( have_posts() ) {

		while ( have_posts() ) {
			the_post();
			get_template_part( 'content', get_post_format() );
		}
		broadsheet_numeric_pagination();

	} else {
		get_template_part( 'content-empty' );
	}
?>
	</div>
<?php

	get_footer();
