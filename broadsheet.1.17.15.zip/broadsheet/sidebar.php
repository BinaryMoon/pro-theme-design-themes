<?php
/**
 * Sidebar template
 *
 * @package Broadsheet
 */

	if ( is_active_sidebar( 'sidebar-1' ) ) {

?>
<div class="col-sidebar sidebar-main" role="complementary">
<?php

	do_action( 'before_sidebar' );
	dynamic_sidebar( 'sidebar-1' );

?>
</div>
<?php

	}
