<?php
/**
 * Single page template
 *
 * @package Broadsheet
 */

	get_header();

	get_template_part( 'inc/featured-content' );

	get_sidebar( 'small' );

	if ( have_posts() ) {
?>
	<div class="main-content">
<?php
		while ( have_posts() ) {
			the_post();
			get_template_part( 'content-page' );
			if ( comments_open() || '0' != get_comments_number() ) {
				comments_template( '', true );
			}
		}
?>
	</div>
<?php
	} else {
		get_template_part( 'content-empty' );
	}

	get_footer();
