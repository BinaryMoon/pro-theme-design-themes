<?php
/**
 * Archive Template
 *
 * @package Broadsheet
 */

	get_header();

	if ( have_posts() ) {

		the_archive_title( '<h1 class="title">', '</h1>' );
		the_archive_description( '<div class="category-description category_description">', '</div>' );
?>
	<div id="main-content">
<?php
		while ( have_posts() ) {
			the_post();
			get_template_part( 'content', get_post_format() );
		}

		broadsheet_numeric_pagination();
	} else {
		get_template_part( 'content-empty' );
	}
?>
	</div>
<?php

	get_footer();
