<?php
/**
 * Footer Template
 *
 * @package Broadsheet
 */

?>
	</div>
<?php
	if (
		( 'page' === get_option( 'show_on_front' ) || ! is_front_page() )
		&& ! is_page_template( 'page-templates/full-width.php' )
		&& ! is_404()
	) {
		get_sidebar();
	}
?>
</div>

<footer role="contentinfo" id="footer" class="container">
<?php
	if ( is_active_sidebar( 'sidebar-2' ) ) {
?>
	<aside class="footer-widgets sidebar-footer">
		<?php dynamic_sidebar( 'sidebar-2' ); ?>
	</aside>
<?php
	}
?>
	<section class="footer-wrap">
<?php

	echo broadsheet_footer_content();

	/**
	 * Check to see if a custom credits option is set.
	 * If custom credits are set then the filter should output the credits and
	 * return a non false value. This will hide the default footer credits.
	 */
	if ( false === apply_filters( 'broadsheet_credits', false ) ) {

?>
		<div class="footer-credits">
<?php
	if ( function_exists( 'the_privacy_policy_link' ) ) {
		the_privacy_policy_link( '', '<span class="sep" role="separator" aria-hidden="true"> | </span>' );
	}
?>
			<a href="http://wordpress.org/" title="<?php esc_attr_e( 'A Semantic Personal Publishing Platform', 'broadsheet' ); ?>" rel="generator"><?php printf( esc_html__( 'Proudly powered by %s', 'broadsheet' ), 'WordPress' ); ?></a>
			<span class="sep" role="separator" aria-hidden="true"> | </span>
<?php
		printf( esc_html__( 'Theme: %1$s by %2$s.', 'broadsheet' ), 'Broadsheet', '<a href="https://prothemedesign.com/" rel="designer">Pro Theme Design</a>' );
?>
		</div>
<?php
	}

?>
	</section>
</footer>

<?php wp_footer(); ?>

</body>
</html>
