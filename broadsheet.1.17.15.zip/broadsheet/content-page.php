<?php
/**
 * Page content
 *
 * @package Broadsheet
 */

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<?php

	if ( get_theme_mod( 'broadsheet_display_featured_image_on_page', 0 ) || is_customize_preview() ) {
		get_template_part( 'archive-header-image' );
	}

	the_title( '<h1 class="title">', '</h1>' );

?>
	<section class="entry">
<?php
	the_content();

	edit_post_link();

	wp_link_pages(
		array(
			'before' => '<div class="archive-pagination">' . esc_html__( 'Pages: ', 'broadsheet' ),
			'after'  => '</div>',
			'link_before' => '<span>',
			'link_after'  => '</span>',
		)
	);
?>
	</section>
</article>
