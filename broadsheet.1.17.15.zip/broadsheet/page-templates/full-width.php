<?php
/**
 * Full width page template
 * Template Name: Full Width
 *
 * @package Broadsheet
 */

	get_header();

	get_template_part( 'inc/featured-content' );

?>
<div class="main-content full-width">
<?php
	if ( have_posts() ) {
		while ( have_posts() ) {
			the_post();
			get_template_part( 'content-page' );
		}
	}
?>
</div>
<?php
	get_footer();
