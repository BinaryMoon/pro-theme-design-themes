<?php
/**
 * Testimonials Archive Template
 * displays at: http://website.com/testimonial/
 *
 * @package Broadsheet
 */

	get_header();

	$testimonials = new WP_Query(
		array(
			'post_type' => 'jetpack-testimonial',
			'orderby' => 'menu_order',
			'posts_per_page' => 999,
			'no_found_rows' => true,
			'order' => 'ASC',
		)
	);

	if ( $testimonials->have_posts() ) {
?>
	<h1 class="title entry-title entry-archive-title"><?php broadsheet_testimonials_title(); ?></h1>
<?php
	$description = broadsheet_testimonials_description();
	if ( $description ) {
?>
	<div class="testimonial-description">
		<?php echo $description; ?>
	</div>
<?php
	}

	$image = broadsheet_testimonials_image();
	if ( $image ) {

		$image_allowed_properties = array(
			'src' => array(),
			'width' => array(),
			'height' => array(),
			'class' => array(),
		);
?>
	<div class="page-image-header">
		<?php echo wp_kses( $image, array( 'img' => $image_allowed_properties ) ); ?>
	</div>
<?php
	}
?>
	<div class="testimonials testimonials-wrapper">
<?php
		while ( $testimonials->have_posts() ) {
			$testimonials->the_post();
			get_template_part( 'content', 'testimonial' );
		}
?>
	</div>
<?php
	} else {
		get_template_part( 'content-empty' );
	}

	get_footer();
