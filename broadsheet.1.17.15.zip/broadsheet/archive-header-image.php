<?php
/**
 * Display the header image on posts and pages.
 * Includes a special case for WooCommerce product archives since they use the page template.
 *
 * @package broadsheet
 */

if ( function_exists( 'is_product_category' ) && is_product_category() ) {

	global $wp_query;
	$cat_query = $wp_query->get_queried_object();
	$thumbnail_id = get_term_meta( $cat_query->term_id, 'thumbnail_id', true );

	$image = wp_get_attachment_image(
		$thumbnail_id,
		'broadsheet-archive-featured',
		false,
		array(
			'class' => 'post-header-image',
		)
	);

	if ( $image ) {
		echo $image;
	}
} else {

	the_post_thumbnail(
		'broadsheet-archive-featured',
		array(
			'class' => 'post-header-image',
		)
	);

}
