<?php
/**
 * Sidebar template for the left hand of the homepage
 *
 * @package Broadsheet
 */

	if ( is_active_sidebar( 'sidebar-3' ) ) {
?>
<div class="col-sidebar sidebar-small" role="complementary">
<?php
	dynamic_sidebar( 'sidebar-3' );
?>
</div>
<?php
	}
