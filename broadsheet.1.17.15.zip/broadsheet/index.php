<?php
/**
 * Homepage Template
 *
 * @package Broadsheet
 */

	get_header();

	get_template_part( 'inc/featured-content' );

	get_template_part( 'inc/homepage-primary-content' );

	get_sidebar( 'small' );

?>
	<div class="main-post-list">
<?php
	if ( have_posts() ) {
?>
		<div id="main-content">
<?php
		while ( have_posts() ) {
			the_post();
			get_template_part( 'content', get_post_format() );
		}

		broadsheet_numeric_pagination();
?>
		</div>
<?php
	} else {
		get_template_part( 'content-empty' );
	}
?>
	</div>

<?php

	broadsheet_category_list();

	get_sidebar();

	get_template_part( 'inc/jetpack-testimonials' );

	get_footer();
